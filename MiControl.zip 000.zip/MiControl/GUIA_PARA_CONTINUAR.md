# Mi Control — guía para seguir desarrollando la app

App Android para camioneros argentinos: viajes, horas y horas extras, gastos, plata de la empresa (rendición), recorrido GPS, mapas, rutas para camión, navegación con voz, informes PDF, clientes y ubicaciones de WhatsApp.
El dueño NO programa: trabaja desde el celular. Hablarle en español rioplatense, con pasos cortos y concretos (qué botón tocar).

## 1. Cómo está armado
- Kotlin + Jetpack Compose (Material 3) + Room (SQLite). Paquete `com.micontrol.app`, minSdk 29, targetSdk 34.
- Mapas: osmdroid con tiles de MapTiler (claro, oscuro, satélite). Rutas para camión: OpenRouteService (perfil driving-hgv, https://api.heigit.org/openrouteservice).
- Versión actual del código: ver `versionName` en `app/build.gradle.kts` (la 1.5.0 todavía NO se confirmó que compile en GitHub; la última APK confirmada fue la 1.3.1).

Carpetas principales (`app/src/main/java/com/micontrol/app/`):
- `data/`: entidades y base Room (`Entities.kt`, `Daos.kt`, `AppDatabase.kt` con migraciones 1→4), `Geo.kt` (búsqueda de direcciones), `UbicacionLink.kt` (lee links/textos de ubicación de WhatsApp), `RutaCamion.kt` (OpenRouteService), `Actualizaciones.kt` (avisa versión nueva leyendo GitHub Releases), `Ajustes.kt`, `Fotos.kt`, `CompartirApp.kt`.
- `domain/`: `Calculos.kt` (km por odómetro, horas extras >9 h por día, saldo con la empresa), `Navegacion.kt`, `Asistente.kt` (asistente local sin internet: entiende frases en español, responde con los datos del teléfono y anota gastos/adelantos con confirmación).
- `gps/`: `TrackingService.kt` (GPS en segundo plano) y `Gps.kt`.
- `pdf/InformePdf.kt`: informe PDF por viaje.
- `ui/`: pantallas (`Screens.kt` inicio/viaje, `Mapa.kt`, `NavegacionUi.kt`, `Clientes.kt`, `AjustesScreen.kt`, `UbicacionRecibida.kt`, `Cercania.kt`, `AsistenteScreen.kt`), tema rojo y negro (`Theme.kt`), `MainActivity.kt` (navegación + barra inferior).
- Imágenes del diseño en `app/src/main/res/drawable-nodpi/`.

Reglas del negocio (no cambiar sin avisar): los km OFICIALES salen solo del odómetro (final − inicial); el GPS es solo referencia. Horas extras = máx(0, horas del día − 9). Saldo = plata recibida de la empresa − gastos.

## 2. Cómo se compila y se publica (sin PC)
El dueño NO usa Android Studio. En su repositorio de GitHub (público) hay solo:
- `MiControl.zip` (este proyecto, con la carpeta `MiControl/` adentro)
- `.github/workflows/main.yml`

Cada vez que sube un `MiControl.zip` nuevo (Code > Add file > Upload files), GitHub Actions lo descomprime, compila `assembleDebug`, y publica un Release con el APK. La app instalada avisa sola cuando hay una versión más nueva.

Para que una actualización funcione:
1. Subir `versionCode` (número entero) y `versionName` en `app/build.gradle.kts` en CADA versión.
2. Actualizar `NOVEDADES.txt` (se muestra como "qué hay de nuevo" en el aviso).
3. Entregar un `.zip` con la carpeta `MiControl/` en la raíz y NADA de archivos sueltos o viejos adentro.
4. No cambiar `applicationId` ni el archivo `app/micontrol-debug.keystore`: la firma tiene que ser siempre la misma o las versiones no se instalan encima y se pierden los datos.

Claves (NO están en el código): GitHub > Settings > Secrets and variables > Actions: `MAPTILER_KEY` y `ORS_KEY`. El workflow las pasa al compilar y quedan dentro del APK. El repositorio (`GITHUB_REPOSITORY`) también se inyecta al compilar.

Texto de `.github/workflows/main.yml` (por si hay que restaurarlo):

```yaml
name: Compilar APK
on:
  workflow_dispatch:
  push:
    branches: [main]
permissions:
  contents: write
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: unzip -q MiControl.zip
      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: 17
      - uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: 8.7
      - run: gradle assembleDebug
        working-directory: MiControl
        env:
          MAPTILER_KEY: ${{ secrets.MAPTILER_KEY }}
          ORS_KEY: ${{ secrets.ORS_KEY }}
      - uses: actions/upload-artifact@v4
        with:
          name: MiControl-APK
          path: MiControl/app/build/outputs/apk/debug/*.apk
      - id: ver
        run: |
          code=$(grep -oP 'versionCode = \K[0-9]+' MiControl/app/build.gradle.kts)
          name=$(grep -oP 'versionName = "\K[^"]+' MiControl/app/build.gradle.kts)
          echo "code=$code" >> "$GITHUB_OUTPUT"
          echo "name=$name" >> "$GITHUB_OUTPUT"
          cp MiControl/app/build/outputs/apk/debug/app-debug.apk "MiControl-$name.apk"
      - uses: softprops/action-gh-release@v2
        with:
          tag_name: build-${{ steps.ver.outputs.code }}
          name: Mi Control ${{ steps.ver.outputs.name }}
          body_path: MiControl/NOVEDADES.txt
          files: MiControl-${{ steps.ver.outputs.name }}.apk
```

## 3. Cómo seguir trabajando con otra IA (o herramienta)
Lo más simple desde el celular: abrir un chat nuevo de una IA que acepte archivos (Claude, ChatGPT, etc.), subir `MiControl.zip` y este archivo, y pegar el mensaje de abajo. La IA te devuelve un `MiControl.zip` nuevo; se sube a GitHub como siempre.
Con PC: abrir la carpeta en Android Studio, Cursor o Claude Code y compilar con `./gradlew assembleDebug`.

Mensaje para pegar:
> Te paso el proyecto Android "Mi Control" (zip) y su guía. Leé primero GUIA_PARA_CONTINUAR.md. Quiero seguir mejorando la app. Yo trabajo solo desde el celular, sin PC: cada cambio tiene que volver como un nuevo MiControl.zip con la misma estructura, subiendo versionCode y versionName y actualizando NOVEDADES.txt. Explicame los pasos cortos y en español. Antes de decir que algo está listo, revisá que el código compile (la 1.5.0 todavía no se confirmó).

## 4. Lecciones de errores anteriores (para no repetirlos)
- Archivos sueltos o de otro intento dentro del zip rompieron la compilación: el zip tiene que quedar limpio.
- En Kotlin una función con cuerpo de expresión (`= try {...}`) no puede usar `return`.
- Usamos Material 3 de la BOM 2024.06 (compose 1.6): evitar APIs más nuevas.
- Cualquier cambio en las entidades Room exige una migración nueva en `AppDatabase.kt` (versión actual 4).
- El copiado desde páginas traducidas por el navegador rompe archivos YAML (palabras traducidas).

## 5. Pendientes e ideas
- Versión 1.5.0 (nueva): botón "Pegar ubicación de WhatsApp" en Inicio, mapa manual más simple (arranca donde estás, abre solo si la ubicación es aproximada), filtros para abrir links de Google Maps y Asistente local (`Asistente.kt`). Hay que probarla en el teléfono.
- Android 12+ no abre solo los links https en apps no verificadas: el camino confiable es copiar el mensaje y usar "Pegar ubicación". Si se quiere que abra links directo: Ajustes del teléfono > Apps > Mi Control > Abrir de forma predeterminada > agregar enlaces.
- IA en línea (un modelo de lenguaje de verdad): NO se hizo a propósito. Una clave de API dentro del APK (el repo y los Releases son públicos) puede ser extraída y gastada por otros. Si se quiere, hace falta un servidor intermedio que guarde la clave. Mientras tanto el Asistente local cubre preguntas y anotaciones.
- Confirmar que la 1.4.2 compile y andar bien las ubicaciones de WhatsApp con solo dirección (geo:?q=Dirección): hoy se busca por MapTiler/OpenStreetMap, queda "aproximada" y hay que ajustarla en el mapa con el satélite.
- Leer el importe de la foto del ticket (OCR) — no implementado.
- Mapa vectorial (más fluido) y cuenta propia de Google Maps — no implementados.
- Los logos de Guerrini y Kumho Tire son de esas marcas: si la app sale de la empresa, pedir autorización.

## 6. Archivos del proyecto
```
  NOVEDADES.txt
  app/build.gradle.kts
  app/micontrol-debug.keystore
  app/src/main/AndroidManifest.xml
  app/src/main/java/com/micontrol/app/data/Actualizaciones.kt
  app/src/main/java/com/micontrol/app/data/Ajustes.kt
  app/src/main/java/com/micontrol/app/data/AppDatabase.kt
  app/src/main/java/com/micontrol/app/data/CompartirApp.kt
  app/src/main/java/com/micontrol/app/data/Daos.kt
  app/src/main/java/com/micontrol/app/data/Entities.kt
  app/src/main/java/com/micontrol/app/data/Fotos.kt
  app/src/main/java/com/micontrol/app/data/Geo.kt
  app/src/main/java/com/micontrol/app/data/RutaCamion.kt
  app/src/main/java/com/micontrol/app/data/UbicacionLink.kt
  app/src/main/java/com/micontrol/app/domain/Asistente.kt
  app/src/main/java/com/micontrol/app/domain/Calculos.kt
  app/src/main/java/com/micontrol/app/domain/Navegacion.kt
  app/src/main/java/com/micontrol/app/gps/Gps.kt
  app/src/main/java/com/micontrol/app/gps/TrackingService.kt
  app/src/main/java/com/micontrol/app/pdf/InformePdf.kt
  app/src/main/java/com/micontrol/app/ui/ActualizacionDialog.kt
  app/src/main/java/com/micontrol/app/ui/AjustesScreen.kt
  app/src/main/java/com/micontrol/app/ui/AsistenteScreen.kt
  app/src/main/java/com/micontrol/app/ui/Cercania.kt
  app/src/main/java/com/micontrol/app/ui/Clientes.kt
  app/src/main/java/com/micontrol/app/ui/MainActivity.kt
  app/src/main/java/com/micontrol/app/ui/MainViewModel.kt
  app/src/main/java/com/micontrol/app/ui/Mapa.kt
  app/src/main/java/com/micontrol/app/ui/NavegacionUi.kt
  app/src/main/java/com/micontrol/app/ui/RutaCamionUi.kt
  app/src/main/java/com/micontrol/app/ui/Screens.kt
  app/src/main/java/com/micontrol/app/ui/Theme.kt
  app/src/main/java/com/micontrol/app/ui/UbicacionRecibida.kt
  app/src/main/res/drawable-nodpi/bg_footer.jpg
  app/src/main/res/drawable-nodpi/bg_header.jpg
  app/src/main/res/drawable-nodpi/ic_hero_ruta.png
  app/src/main/res/drawable-nodpi/ic_stat_monedas.png
  app/src/main/res/drawable-nodpi/ic_stat_reloj.png
  app/src/main/res/drawable-nodpi/ic_stat_ruta.png
  app/src/main/res/drawable-nodpi/ic_stat_tablero.png
  app/src/main/res/drawable-nodpi/nav_ajustes_gris.png
  app/src/main/res/drawable-nodpi/nav_ajustes_rojo.png
  app/src/main/res/drawable-nodpi/nav_camion_gris.png
  app/src/main/res/drawable-nodpi/nav_camion_rojo.png
  app/src/main/res/drawable-nodpi/nav_casa_gris.png
  app/src/main/res/drawable-nodpi/nav_casa_roja.png
  app/src/main/res/drawable-nodpi/nav_gente_gris.png
  app/src/main/res/drawable-nodpi/nav_gente_rojo.png
  app/src/main/res/drawable/ic_truck.xml
  app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml
  app/src/main/res/mipmap-anydpi-v26/ic_launcher_round.xml
  app/src/main/res/values/colors.xml
  app/src/main/res/values/themes.xml
  app/src/main/res/xml/file_paths.xml
  build.gradle.kts
  gradle.properties
  settings.gradle.kts
```
