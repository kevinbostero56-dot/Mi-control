package com.micontrol.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.micontrol.app.data.*
import com.micontrol.app.domain.Calculos
import com.micontrol.app.domain.Recorrido
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File
import java.time.LocalDate

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val db = AppDatabase.get(app)
    private fun <T> kotlinx.coroutines.flow.Flow<T>.state(init: T) =
        stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), init)

    val viajes = db.viajeDao().todos().state(emptyList())
    val clientes = db.clienteDao().todos().state(emptyList())
    val todasJornadas = db.jornadaDao().todas().state(emptyList())
    val todosGastos = db.gastoDao().todos().state(emptyList())
    val todosAdelantos = db.adelantoDao().todos().state(emptyList())

    fun viaje(id: String) = db.viajeDao().porId(id)
    fun jornadas(id: String) = db.jornadaDao().porViaje(id)
    fun gastos(id: String) = db.gastoDao().porViaje(id)
    fun puntos(id: String) = db.puntoDao().porViaje(id)
    fun paradas(id: String) = db.paradaDao().porViaje(id)
    fun adelantos(id: String) = db.adelantoDao().porViaje(id)

    /** Al iniciar el viaje se guarda la hora de inicio y se abre la primera jornada con esa hora. */
    fun iniciarViaje(v: Viaje, paradas: List<Parada> = emptyList()) = viewModelScope.launch {
        if (v.cliente.isNotBlank()) db.clienteDao().insertar(Cliente(nombre = v.cliente.trim()))
        db.viajeDao().insertar(v)
        if (paradas.isNotEmpty()) db.paradaDao().insertarTodas(paradas)
        db.jornadaDao().insertar(
            Jornada(viajeId = v.id, fecha = LocalDate.now().toString(),
                inicioMin = Calculos.minutoActual(), finMin = Calculos.ABIERTA)
        )
    }

    /** Al finalizar se guarda la hora de fin y se cierra la jornada abierta (las extras se calculan solas). */
    fun finalizarViaje(v: Viaje, odometroFinal: Long) = viewModelScope.launch {
        db.jornadaDao().abiertas(v.id).forEach {
            db.jornadaDao().actualizar(it.copy(finMin = Calculos.minutoActual()))
        }
        db.viajeDao().actualizar(
            v.copy(estado = Viaje.Estado.FINALIZADO, fin = System.currentTimeMillis(), odometroFinal = odometroFinal)
        )
    }

    fun iniciarJornada(viajeId: String) = viewModelScope.launch {
        if (db.jornadaDao().abiertas(viajeId).isEmpty()) {
            db.jornadaDao().insertar(
                Jornada(viajeId = viajeId, fecha = LocalDate.now().toString(),
                    inicioMin = Calculos.minutoActual(), finMin = Calculos.ABIERTA)
            )
        }
    }

    fun finalizarJornada(j: Jornada) = viewModelScope.launch {
        db.jornadaDao().actualizar(j.copy(finMin = Calculos.minutoActual()))
    }

    fun guardarCliente(c: Cliente) = viewModelScope.launch {
        if (c.id == 0L) db.clienteDao().insertar(c) else db.clienteDao().actualizar(c)
    }
    fun borrarCliente(c: Cliente) = viewModelScope.launch { db.clienteDao().borrar(c) }
    fun agregarParada(p: Parada) = viewModelScope.launch { db.paradaDao().insertar(p) }
    fun borrarParada(p: Parada) = viewModelScope.launch { db.paradaDao().borrar(p) }

    fun actualizarViaje(v: Viaje) = viewModelScope.launch { db.viajeDao().actualizar(v) }
    fun borrarViaje(v: Viaje) = viewModelScope.launch { db.viajeDao().borrar(v) }

    fun guardarJornada(j: Jornada) = viewModelScope.launch {
        if (j.id == 0L) db.jornadaDao().insertar(j) else db.jornadaDao().actualizar(j)
    }
    fun borrarJornada(j: Jornada) = viewModelScope.launch { db.jornadaDao().borrar(j) }

    fun guardarGasto(g: Gasto) = viewModelScope.launch {
        if (g.id == 0L) db.gastoDao().insertar(g) else db.gastoDao().actualizar(g)
    }
    fun borrarGasto(g: Gasto) = viewModelScope.launch {
        db.gastoDao().borrar(g)
        g.fotoPath?.let { File(it).delete() }
    }

    fun guardarAdelanto(a: Adelanto) = viewModelScope.launch {
        if (a.id == 0L) db.adelantoDao().insertar(a) else db.adelantoDao().actualizar(a)
    }
    fun borrarAdelanto(a: Adelanto) = viewModelScope.launch { db.adelantoDao().borrar(a) }

    // ---- Ubicaciones recibidas por WhatsApp (compartir > Mi Control)
    data class Recibida(val cargando: Boolean, val punto: UbicacionLink.Punto?, val texto: String)
    private val _recibida = MutableStateFlow<Recibida?>(null)
    val recibida: StateFlow<Recibida?> = _recibida

    fun recibirUbicacion(texto: String) {
        viewModelScope.launch {
            _recibida.value = Recibida(true, null, texto)
            val clave = Ajustes.claveMapTiler(getApplication<Application>())
            val p = UbicacionLink.resolver(texto, clave)
            val completo = p?.copy(direccion = p.direccion ?: Geo.direccion(p.lat, p.lng))
            _recibida.value = Recibida(false, completo, texto)
        }
    }
    fun descartarRecibida() { _recibida.value = null }

    /** La persona eligió a mano el lugar en el mapa (cuando la búsqueda automática no alcanzó). */
    fun fijarRecibida(lat: Double, lng: Double, direccion: String?, nombre: String?) {
        val texto = _recibida.value?.texto ?: ""
        _recibida.value = Recibida(false, UbicacionLink.Punto(lat, lng, nombre, direccion, manual = true), texto)
    }

    // ---- Actualizaciones de la app
    private val _actualizacion = MutableStateFlow<Actualizaciones.Nueva?>(null)
    val actualizacion: StateFlow<Actualizaciones.Nueva?> = _actualizacion

    /** Busca una versión nueva. Sola, como mucho una vez cada 12 horas; a mano, siempre. */
    fun buscarActualizacion(manual: Boolean, alTerminar: (String?) -> Unit = {}) {
        val app = getApplication<Application>()
        if (!manual && System.currentTimeMillis() - Ajustes.ultimaBusqueda(app) < 12 * 3600 * 1000L) return
        viewModelScope.launch {
            when (val r = Actualizaciones.buscar()) {
                is Actualizaciones.Resultado.Hay -> {
                    Ajustes.marcarBusqueda(app)
                    _actualizacion.value = r.n
                    alTerminar(null)
                }
                Actualizaciones.Resultado.AlDia -> {
                    Ajustes.marcarBusqueda(app)
                    alTerminar("Ya tenés la última versión.")
                }
                Actualizaciones.Resultado.Error ->
                    alTerminar(if (manual) "No se pudo comprobar. Revisá tu conexión a internet." else null)
            }
        }
    }
    fun cerrarActualizacion() { _actualizacion.value = null }

    /** Agrega varias paradas al final, en el orden dado. */
    fun agregarParadas(viajeId: String, lugares: List<Recorrido.Lugar>) = viewModelScope.launch {
        var n = db.paradaDao().cuenta(viajeId)
        lugares.forEach {
            db.paradaDao().insertar(Parada(viajeId = viajeId, orden = n++, nombre = it.nombre, lat = it.lat, lng = it.lng))
        }
    }

    fun paradaAlFinal(viajeId: String, nombre: String, lat: Double, lng: Double) = viewModelScope.launch {
        val n = db.paradaDao().cuenta(viajeId)
        db.paradaDao().insertar(Parada(viajeId = viajeId, orden = n, nombre = nombre, lat = lat, lng = lng))
    }
}
