package com.micontrol.app.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder

/** Lee ubicaciones de lo que se pasa por WhatsApp: links de Google Maps, geo:, coordenadas sueltas, nombres de lugar. */
object UbicacionLink {
    data class Punto(
        val lat: Double,
        val lng: Double,
        val nombre: String? = null,
        val direccion: String? = null,
        val aproximada: Boolean = false,  // true si se buscó por el nombre o la dirección
        val zona: Boolean = false,        // true si solo se encontró la localidad, no la dirección
        val consulta: String? = null,     // lo que se buscó
        val manual: Boolean = false       // true si la persona la eligió a mano en el mapa
    )

    private const val N = """(-?\d{1,3}\.\d+)"""

    private val patrones = listOf(
        Regex("""[?&](?:q|ll|query|destination|daddr|center|sll)=(?:loc:)?$N\s*,\s*$N"""),
        Regex("""!3d$N!4d$N"""),
        Regex("""@$N,$N"""),
        Regex("""geo:$N,$N"""),
        Regex("""[?&]mlat=$N&(?:amp;)?mlon=$N"""),
        Regex("""#map=\d+/$N/$N"""),
        Regex("""$N\s*[,;]\s*$N""")
    )
    private val geoQ = Regex("""geo:[^?\s]*\?(?:[^\s&]*&)*q=([^&\s]+)""")
    private val urlQ = Regex("""[?&](?:q|query|destination|daddr|address)=([^&\s]+)""")
    private val codigoPostal = Regex("""(?i)(cp\s*)?[A-Z]?\d{4}[A-Z]{0,3}""")
    private val lugar = Regex("""/maps/place/([^/@?]+)""")
    private val etiquetaGeo = Regex("""geo:\S*\(([^)]{1,80})\)""")
    private val consultaGeo = Regex("""geo:[^?\s]*\?(?:[^\s]*&)?q=([^&\s]+)""")
    private val enlaces = Regex("""https?://[^\s"'<>]+""")
    private val lineaInutil = Regex("""(?i)(mi )?(ubicaci[oó]n|location)( en vivo)?[:\s]*""")
    private val lineaConCoordenadas = Regex(""".*-?\d{1,3}\.\d+\s*,\s*-?\d{1,3}\.\d+.*""")

    private fun decodificar(t: String) = try { URLDecoder.decode(t, "UTF-8") } catch (e: Exception) { t }

    /** Texto de búsqueda de un geo:?q=... (lo que manda WhatsApp cuando el lugar no trae coordenadas). */
    fun consultaDeTexto(texto: String): String? {
        val m = consultaGeo.find(texto) ?: return null
        val q = decodificar(m.groupValues[1]).replace(Regex("""\([^)]*\)\s*$"""), "").trim()
        return q.ifBlank { null }
    }

    /** Partes de una dirección separadas por coma, sin el código postal ni "Argentina". */
    fun partes(q: String): List<String> = q.split(",").map { it.trim() }.filter {
        it.isNotBlank() && !it.matches(Regex("""(?i)(cp|c\.p\.)\s*\d+""")) && !it.equals("Argentina", true)
    }

    /** Nombre y dirección tal como vienen en el mensaje (si vienen). */
    private fun nombreYDireccion(t: String): Pair<String?, String?> {
        etiquetaGeo.find(t)?.groupValues?.get(1)?.trim()?.takeIf { it.isNotBlank() }?.let { return it to null }
        lugar.find(t)?.groupValues?.get(1)?.replace('+', ' ')?.trim()?.takeIf { it.isNotBlank() }?.let { return it to null }
        val lineas = t.lines()
            .map { it.trim().trim('*', '_', '~').removePrefix("📍").trim() }
            .filter {
                it.isNotBlank() && !it.startsWith("http", true) && !it.startsWith("geo:", true) &&
                    !it.contains("maps.") && !lineaInutil.matches(it) && !lineaConCoordenadas.matches(it)
            }
        return lineas.firstOrNull() to lineas.drop(1).joinToString(", ").ifBlank { null }
    }

    /** Busca coordenadas en el texto, sin usar internet. */
    fun extraer(texto: String): Punto? {
        val t = decodificar(texto)
        for (r in patrones) {
            val m = r.find(t) ?: continue
            val lat = m.groupValues[1].toDoubleOrNull() ?: continue
            val lng = m.groupValues[2].toDoubleOrNull() ?: continue
            if (lat !in -90.0..90.0 || lng !in -180.0..180.0 || (lat == 0.0 && lng == 0.0)) continue
            val (nombre, direccion) = nombreYDireccion(t)
            return Punto(lat, lng, nombre, direccion)
        }
        return null
    }

    /** En el contenido de una página solo se aceptan formas seguras (nada de números sueltos). */
    private fun extraerCuerpo(cuerpo: String): Punto? {
        val t = decodificar(cuerpo)
        for (r in patrones.take(3)) {
            val m = r.find(t) ?: continue
            val lat = m.groupValues[1].toDoubleOrNull() ?: continue
            val lng = m.groupValues[2].toDoubleOrNull() ?: continue
            if (lat in -90.0..90.0 && lng in -180.0..180.0 && !(lat == 0.0 && lng == 0.0)) return Punto(lat, lng)
        }
        return null
    }

    /** Dirección o nombre que viene como texto, por ejemplo geo:?q=Calle 123, Ciudad. */
    private fun consultaTexto(texto: String): String? {
        val crudo = geoQ.find(texto)?.groupValues?.get(1) ?: urlQ.find(texto)?.groupValues?.get(1) ?: return null
        val t = decodificar(crudo).replace(Regex("""\([^)]*\)\s*$"""), "").trim()
        if (t.isBlank() || patrones.any { it.containsMatchIn(t) }) return null
        return t
    }

    /** Si pegaron una dirección suelta (sin links), se usa tal cual. */
    private fun textoPlano(texto: String): String? {
        val lineas = texto.lines().map { it.trim() }.filter { it.isNotBlank() && !it.startsWith("http", true) }
        val t = lineas.take(2).joinToString(", ")
        return if (t.isBlank() || t.length > 200) null else t
    }

    /** Cuanto más bajo, más precisa la ubicación encontrada. */
    private fun nivel(tipo: String?): Int = when (tipo) {
        "address", "poi" -> 0
        "street" -> 1
        null -> 2
        "neighbourhood" -> 3
        "locality" -> 4
        "municipality", "joint_municipality" -> 5
        else -> 6
    }

    /** Prueba varias versiones de la dirección y se queda con el resultado más preciso. */
    private suspend fun buscarDireccion(consulta: String, clave: String): Pair<Geo.Lugar, Int>? {
        val partes = consulta.split(",").map { it.trim() }.filter { it.isNotBlank() }
        val sinCp = partes.filterNot { codigoPostal.matches(it) }
        val intentos = LinkedHashSet<String>()
        intentos.add(partes.joinToString(", "))
        intentos.add(sinCp.joinToString(", "))
        if (sinCp.size > 1) intentos.add(sinCp.drop(1).joinToString(", "))
        if (sinCp.size >= 3) intentos.add((listOf(sinCp.first()) + sinCp.takeLast(2)).joinToString(", "))
        if (sinCp.size > 3) intentos.add(sinCp.takeLast(3).joinToString(", "))
        var mejor: Pair<Geo.Lugar, Int>? = null
        for (q in intentos) {
            if (q.isBlank()) continue
            val l = Geo.geocodificar(q, clave) ?: continue
            val n = nivel(l.tipo)
            if (mejor == null || n < mejor.second) mejor = l to n
            if (n <= 0) break
        }
        return mejor
    }

    private class Hallazgo(val punto: Punto?, val nombreLugar: String?)

    /** Sigue los redirects de un link corto (maps.app.goo.gl) buscando coordenadas o, al menos, el nombre del lugar. */
    private fun seguir(url: String): Hallazgo {
        var actual = url
        var nombreLugar: String? = null
        repeat(8) {
            val c = URL(actual).openConnection() as HttpURLConnection
            try {
                c.instanceFollowRedirects = false
                c.connectTimeout = 8000
                c.readTimeout = 8000
                c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36")
                c.setRequestProperty("Accept-Language", "es-AR,es;q=0.9")
                val codigo = c.responseCode
                if (codigo in 300..399) {
                    val destino = c.getHeaderField("Location") ?: return Hallazgo(null, nombreLugar)
                    actual = URL(URL(actual), destino).toString()
                    extraer(actual)?.let { return Hallazgo(it, null) }
                    lugar.find(decodificar(actual))?.groupValues?.get(1)?.trim()?.let { nombreLugar = it }
                } else {
                    val cuerpo = c.inputStream.bufferedReader().use { it.readText().take(400_000) }
                    return Hallazgo(extraer(actual) ?: extraerCuerpo(cuerpo), nombreLugar)
                }
            } finally {
                c.disconnect()
            }
        }
        return Hallazgo(null, nombreLugar)
    }

    /**
     * Devuelve la ubicación que haya en el texto o link. Si el link solo trae el nombre del lugar,
     * lo busca por nombre y marca el resultado como aproximado.
     */
    suspend fun resolver(texto: String, claveMapTiler: String = ""): Punto? = withContext(Dispatchers.IO) {
        val (nombreTexto, direccionTexto) = nombreYDireccion(decodificar(texto))
        extraer(texto)?.let { return@withContext it }

        // WhatsApp manda geo:?q=Dirección cuando el lugar no trae coordenadas: se busca por la dirección
        val consultaGeoTexto = consultaDeTexto(texto)
        if (consultaGeoTexto != null) {
            val (l, n) = buscarDireccion(consultaGeoTexto, claveMapTiler) ?: return@withContext null
            val ps = partes(consultaGeoTexto)
            val nombre = ps.firstOrNull()?.takeIf { it.isNotBlank() && !it[0].isDigit() }
            val direccion = ps.drop(1).joinToString(", ").ifBlank { l.nombre }
            return@withContext Punto(
                l.lat, l.lng, nombre, direccion,
                aproximada = true, zona = n >= 3, consulta = consultaGeoTexto
            )
        }

        var nombreLugar: String? = null
        var huboEnlaces = false
        for (m in enlaces.findAll(texto)) {
            huboEnlaces = true
            val h = try { seguir(m.value) } catch (e: Exception) { null }
            if (h == null) continue
            val p = h.punto
            if (p != null) {
                return@withContext p.copy(nombre = p.nombre ?: nombreTexto, direccion = p.direccion ?: direccionTexto)
            }
            if (nombreLugar == null) nombreLugar = h.nombreLugar
        }

        // Sin coordenadas: se busca por la dirección o el nombre que vengan en el mensaje
        val consulta = consultaTexto(texto) ?: nombreLugar ?: (if (!huboEnlaces) textoPlano(texto) else null)
            ?: return@withContext null
        val (l, n) = buscarDireccion(consulta, claveMapTiler) ?: return@withContext null
        val primera = consulta.split(",").firstOrNull()?.trim()
        Punto(
            l.lat, l.lng, nombreTexto ?: primera, direccionTexto ?: l.nombre,
            aproximada = true, zona = n >= 3, consulta = consulta
        )
    }
}
