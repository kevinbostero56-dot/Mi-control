package com.micontrol.app.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

/** Prueba si las claves de mapas y rutas funcionan. */
object Servicios {
    suspend fun probarMapTiler(clave: String): String = withContext(Dispatchers.IO) {
        if (clave.isBlank()) "No hay clave cargada."
        else probar("https://api.maptiler.com/geocoding/Mendoza.json?key=$clave&limit=1")
    }

    suspend fun probarOrs(clave: String): String = withContext(Dispatchers.IO) {
        if (clave.isBlank()) "No hay clave cargada."
        else probar("https://api.heigit.org/openrouteservice/geocode/search?api_key=$clave&text=Mendoza&size=1")
    }

    private fun probar(url: String): String = try {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 8000
            c.readTimeout = 8000
            when (val codigo = c.responseCode) {
                200 -> "Funciona ✅"
                401, 403 -> "La clave fue rechazada. Revisá que esté bien copiada."
                429 -> "La clave llegó al límite de uso por hoy."
                else -> "El servicio respondió con un error ($codigo)."
            }
        } finally {
            c.disconnect()
        }
    } catch (e: Exception) {
        "Sin conexión a internet."
    }
}
