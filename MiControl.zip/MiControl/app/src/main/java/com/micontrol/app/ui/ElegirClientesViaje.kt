package com.micontrol.app.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.micontrol.app.data.Cliente

/** Lista de todos los lugares guardados para elegir los del viaje (con buscador, filtro por lista y edición del nombre). */
@Composable
fun ElegirClientesViajeDialog(vm: MainViewModel, onDismiss: () -> Unit, onOk: (List<Cliente>) -> Unit) {
    val clientes by vm.clientes.collectAsStateWithLifecycle()
    var busqueda by remember { mutableStateOf("") }
    var lista by remember { mutableStateOf<String?>(null) }
    var marcados by remember { mutableStateOf(setOf<Long>()) }
    var edit by remember { mutableStateOf<Cliente?>(null) }

    val listas = clientes.map { it.lista }.filter { it.isNotBlank() }.distinct().sorted()
    val visibles = clientes.filter { c ->
        (lista == null || c.lista == lista) &&
            (busqueda.isBlank() || c.nombre.contains(busqueda, true) || (c.direccion ?: "").contains(busqueda, true))
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Elegí los clientes del viaje") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(busqueda, { busqueda = it }, Modifier.fillMaxWidth(), label = { Text("Buscar") }, singleLine = true)
                if (listas.isNotEmpty()) {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listas.forEach { l ->
                            AssistChip({ lista = if (lista == l) null else l }, { Text(if (lista == l) "✔ $l" else l, maxLines = 1) })
                        }
                    }
                }
                Text("${marcados.size} elegidos · tocá ✏️ para cambiarle el nombre", style = MaterialTheme.typography.bodySmall)
                LazyColumn(Modifier.heightIn(max = 380.dp)) {
                    if (visibles.isEmpty()) item { Text("No hay lugares con ese filtro.") }
                    items(visibles, key = { it.id }) { c ->
                        val conUbicacion = c.lat != null && c.lng != null
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(c.id in marcados, { marcados = if (it) marcados + c.id else marcados - c.id }, enabled = conUbicacion)
                            Column(Modifier.weight(1f)) {
                                Text(c.nombre, maxLines = 2)
                                if (!conUbicacion) Text("Sin ubicación en el mapa", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                                else if (c.lista.isNotBlank()) Text(c.lista, style = MaterialTheme.typography.bodySmall)
                            }
                            TextButton({ edit = c }) { Text("✏️") }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton({ onOk(clientes.filter { it.id in marcados }) }, enabled = marcados.isNotEmpty()) { Text("Agregar ${marcados.size}") }
        },
        dismissButton = { TextButton(onDismiss) { Text("Cancelar") } }
    )

    edit?.let { c ->
        DialogoCliente(c, onDismiss = { edit = null }, onBorrar = { vm.borrarCliente(c); edit = null }) {
            vm.guardarCliente(it); edit = null
        }
    }
}
