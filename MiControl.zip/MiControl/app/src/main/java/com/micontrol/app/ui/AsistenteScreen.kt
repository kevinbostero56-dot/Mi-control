package com.micontrol.app.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.micontrol.app.data.Adelanto
import com.micontrol.app.data.Gasto
import com.micontrol.app.domain.Asistente

private data class Mensaje(val mio: Boolean, val texto: String, val accion: Asistente.Accion? = null)

/** Chat con el asistente: contesta con los datos del teléfono y anota gastos o plata recibida (siempre pide confirmación). */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AsistenteScreen(vm: MainViewModel, nav: NavController) {
    val viajes by vm.viajes.collectAsStateWithLifecycle()
    val jornadas by vm.todasJornadas.collectAsStateWithLifecycle()
    val gastos by vm.todosGastos.collectAsStateWithLifecycle()
    val adelantos by vm.todosAdelantos.collectAsStateWithLifecycle()
    val mensajes = remember { mutableStateListOf(Mensaje(false, Asistente.SALUDO)) }
    var texto by remember { mutableStateOf("") }
    val lista = rememberLazyListState()

    LaunchedEffect(mensajes.size) {
        if (mensajes.isNotEmpty()) lista.animateScrollToItem(mensajes.size - 1)
    }

    fun enviar(q: String) {
        val limpio = q.trim()
        if (limpio.isEmpty()) return
        mensajes.add(Mensaje(true, limpio))
        val r = Asistente.responder(limpio, Asistente.Datos(viajes, jornadas, gastos, adelantos))
        mensajes.add(Mensaje(false, r.texto, r.accion))
        texto = ""
    }

    fun confirmar(i: Int) {
        val m = mensajes[i]
        val a = m.accion
        if (a is Asistente.Accion.NuevoGasto) {
            vm.guardarGasto(
                Gasto(
                    viajeId = a.viajeId, fechaHora = System.currentTimeMillis(),
                    categoria = a.categoria, importeCentavos = a.centavos, descripcion = a.descripcion
                )
            )
            mensajes[i] = m.copy(accion = null)
            mensajes.add(Mensaje(false, "Listo, gasto guardado ✅"))
        } else if (a is Asistente.Accion.NuevoAdelanto) {
            vm.guardarAdelanto(
                Adelanto(
                    viajeId = a.viajeId, fechaHora = System.currentTimeMillis(),
                    importeCentavos = a.centavos, descripcion = a.descripcion
                )
            )
            mensajes[i] = m.copy(accion = null)
            mensajes.add(Mensaje(false, "Listo, plata recibida guardada ✅"))
        }
    }

    fun cancelar(i: Int) {
        mensajes[i] = mensajes[i].copy(accion = null)
        mensajes.add(Mensaje(false, "Bueno, no lo guardé."))
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp).imePadding()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton({ nav.popBackStack() }) { Text("← Volver") }
            Text("Asistente", style = MaterialTheme.typography.titleLarge)
        }
        LazyColumn(Modifier.weight(1f), state = lista, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(mensajes) { i, m ->
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = if (m.mio) Arrangement.End else Arrangement.Start
                ) {
                    Card(
                        Modifier.widthIn(max = 300.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (m.mio) MaterialTheme.colorScheme.primaryContainer
                            else MaterialTheme.colorScheme.surfaceVariant
                        )
                    ) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(m.texto)
                            if (m.accion != null) {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    BotonP({ confirmar(i) }) { Text("Guardar") }
                                    BotonSec({ cancelar(i) }) { Text("No") }
                                }
                            }
                        }
                    }
                }
            }
        }
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("¿Cuánto gasté?", "Horas extras del mes", "¿Cuánto me deben?", "Km del último viaje", "Resumen").forEach { s ->
                AssistChip(onClick = { enviar(s) }, label = { Text(s) })
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                texto, { texto = it }, Modifier.weight(1f),
                placeholder = { Text("Escribí acá…") }, singleLine = true
            )
            BotonP({ enviar(texto) }, enabled = texto.isNotBlank()) { Text("Enviar") }
        }
    }
}
