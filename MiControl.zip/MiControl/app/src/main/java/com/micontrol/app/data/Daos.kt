package com.micontrol.app.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ClienteDao {
    @Query("SELECT * FROM clientes ORDER BY nombre") fun todos(): Flow<List<Cliente>>
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insertar(c: Cliente)
    @Update(onConflict = OnConflictStrategy.IGNORE) suspend fun actualizar(c: Cliente)
    @Delete suspend fun borrar(c: Cliente)
    @Query("DELETE FROM clientes WHERE id IN (:ids)") suspend fun borrarVarios(ids: List<Long>)
    @Query("UPDATE clientes SET lista = :lista WHERE id IN (:ids)") suspend fun cambiarLista(ids: List<Long>, lista: String)
    @Query("UPDATE clientes SET tipo = :tipo WHERE id IN (:ids)") suspend fun cambiarTipo(ids: List<Long>, tipo: String)
}

@Dao
interface RecorridoDao {
    @Query("SELECT * FROM recorridos ORDER BY creado DESC") fun todos(): Flow<List<RecorridoGuardado>>
    @Insert suspend fun insertar(r: RecorridoGuardado)
    @Delete suspend fun borrar(r: RecorridoGuardado)
}

@Dao
interface ViajeDao {
    @Query("SELECT * FROM viajes ORDER BY inicio DESC") fun todos(): Flow<List<Viaje>>
    @Query("SELECT * FROM viajes WHERE id = :id") fun porId(id: String): Flow<Viaje?>
    @Insert suspend fun insertar(v: Viaje)
    @Update suspend fun actualizar(v: Viaje)
    @Delete suspend fun borrar(v: Viaje)
}

@Dao
interface JornadaDao {
    @Query("SELECT * FROM jornadas WHERE viajeId = :id ORDER BY fecha, inicioMin") fun porViaje(id: String): Flow<List<Jornada>>
    @Query("SELECT * FROM jornadas") fun todas(): Flow<List<Jornada>>
    @Query("SELECT * FROM jornadas WHERE viajeId = :id AND finMin < 0") suspend fun abiertas(id: String): List<Jornada>
    @Insert suspend fun insertar(j: Jornada)
    @Update suspend fun actualizar(j: Jornada)
    @Delete suspend fun borrar(j: Jornada)
}

@Dao
interface GastoDao {
    @Query("SELECT * FROM gastos WHERE viajeId = :id ORDER BY fechaHora") fun porViaje(id: String): Flow<List<Gasto>>
    @Query("SELECT * FROM gastos") fun todos(): Flow<List<Gasto>>
    @Insert suspend fun insertar(g: Gasto)
    @Update suspend fun actualizar(g: Gasto)
    @Delete suspend fun borrar(g: Gasto)
}

@Dao
interface PuntoDao {
    @Query("SELECT * FROM puntos_gps WHERE viajeId = :id ORDER BY tiempo") fun porViaje(id: String): Flow<List<PuntoGps>>
    @Insert suspend fun insertar(p: PuntoGps)
}

@Dao
interface ParadaDao {
    @Query("SELECT * FROM paradas WHERE viajeId = :id ORDER BY orden, id") fun porViaje(id: String): Flow<List<Parada>>
    @Insert suspend fun insertar(p: Parada)
    @Insert suspend fun insertarTodas(l: List<Parada>)
    @Query("SELECT COUNT(*) FROM paradas WHERE viajeId = :id") suspend fun cuenta(id: String): Int
    @Delete suspend fun borrar(p: Parada)
    @Update suspend fun actualizar(p: Parada)
}

@Dao
interface AdelantoDao {
    @Query("SELECT * FROM adelantos WHERE viajeId = :id ORDER BY fechaHora") fun porViaje(id: String): Flow<List<Adelanto>>
    @Query("SELECT * FROM adelantos") fun todos(): Flow<List<Adelanto>>
    @Insert suspend fun insertar(a: Adelanto)
    @Update suspend fun actualizar(a: Adelanto)
    @Delete suspend fun borrar(a: Adelanto)
}

@Dao
interface MantenimientoDao {
    @Query("SELECT * FROM mantenimientos ORDER BY tipo") fun todos(): Flow<List<Mantenimiento>>
    @Insert suspend fun insertar(m: Mantenimiento)
    @Update suspend fun actualizar(m: Mantenimiento)
    @Delete suspend fun borrar(m: Mantenimiento)
}

@Dao
interface VencimientoDao {
    @Query("SELECT * FROM vencimientos ORDER BY fecha") fun todos(): Flow<List<Vencimiento>>
    @Insert suspend fun insertar(v: Vencimiento)
    @Update suspend fun actualizar(v: Vencimiento)
    @Delete suspend fun borrar(v: Vencimiento)
}
