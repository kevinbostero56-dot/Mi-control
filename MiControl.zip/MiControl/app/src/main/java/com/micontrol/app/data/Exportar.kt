package com.micontrol.app.data

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Exporta datos a archivos .csv que se abren en Excel (separados por punto y coma, con números en formato argentino). */
object Exportar {
    private val ar = Locale("es", "AR")
    private fun fecha(ms: Long) = SimpleDateFormat("dd/MM/yyyy HH:mm", ar).format(Date(ms))
    private fun texto(s: String) = "\"" + s.replace("\"", "\"\"").replace("\n", " ").replace("\r", " ") + "\""
    private fun plata(centavos: Long) = "%.2f".format(ar, centavos / 100.0)

    private fun archivo(ctx: Context, nombre: String): File {
        val limpio = nombre.lowercase(ar).replace(Regex("[^a-z0-9]+"), "-").trim('-')
        return File(File(ctx.cacheDir, "informes").apply { mkdirs() }, "MiControl-$limpio.csv")
    }

    fun gastos(ctx: Context, titulo: String, gastos: List<Gasto>, viajes: List<Viaje>): File {
        val porId = viajes.associateBy { it.id }
        val sb = StringBuilder("﻿")
        sb.append("Fecha;Viaje;Cliente;Categoría;Importe (ARS);Litros;Descripción;Observaciones\r\n")
        gastos.sortedBy { it.fechaHora }.forEach { g ->
            val v = porId[g.viajeId]
            sb.append(
                listOf(
                    texto(fecha(g.fechaHora)), texto(v?.nombre ?: ""), texto(v?.cliente ?: ""), texto(g.categoria),
                    plata(g.importeCentavos), g.litros?.let { "%.2f".format(ar, it) } ?: "",
                    texto(g.descripcion), texto(g.observaciones)
                ).joinToString(";")
            ).append("\r\n")
        }
        return archivo(ctx, "gastos-$titulo").also { it.writeText(sb.toString(), Charsets.UTF_8) }
    }

    fun viajes(ctx: Context, titulo: String, viajes: List<Viaje>, gastos: List<Gasto>): File {
        val sb = StringBuilder("﻿")
        sb.append("Inicio;Fin;Viaje;Cliente;Origen;Destino;Estado;Odómetro inicial;Odómetro final;Km (odómetro);Gastos (ARS)\r\n")
        viajes.sortedBy { it.inicio }.forEach { v ->
            val km = com.micontrol.app.domain.Calculos.kmDecimas(v)?.let { "%.1f".format(ar, it / 10.0) }
            val total = gastos.filter { it.viajeId == v.id }.sumOf { it.importeCentavos }
            sb.append(
                listOf(
                    texto(fecha(v.inicio)), texto(v.fin?.let { fecha(it) } ?: ""), texto(v.nombre), texto(v.cliente),
                    texto(v.origen), texto(v.destino), texto(v.estado),
                    "%.1f".format(ar, (v.odometroInicial * 10 + v.odoInicialDec) / 10.0), v.odometroFinal?.let { "%.1f".format(ar, (it * 10 + v.odoFinalDec) / 10.0) } ?: "", km ?: "", plata(total)
                ).joinToString(";")
            ).append("\r\n")
        }
        return archivo(ctx, "viajes-$titulo").also { it.writeText(sb.toString(), Charsets.UTF_8) }
    }

    fun compartir(ctx: Context, f: File) {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(i, "Compartir planilla").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
