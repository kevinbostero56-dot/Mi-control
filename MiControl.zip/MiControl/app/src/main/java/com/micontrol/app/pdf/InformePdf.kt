package com.micontrol.app.pdf

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.RectF
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.pdf.PdfDocument
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import com.micontrol.app.data.*
import com.micontrol.app.domain.Calculos
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Date
import java.util.Locale
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min

object InformePdf {
    private val AZUL = Color.rgb(13, 43, 82)
    private val fechaHoraFmt = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("es", "AR"))
    private val fechaFmt = DateTimeFormatter.ofPattern("dd/MM/yyyy")

    private fun paint(size: Float, bold: Boolean = false, color: Int = Color.BLACK, der: Boolean = false) =
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = size
            isFakeBoldText = bold
            this.color = color
            if (der) textAlign = Paint.Align.RIGHT
        }

    private class Doc {
        val pdf = PdfDocument()
        private var page: PdfDocument.Page? = null
        lateinit var c: Canvas
        var y = 0f
        private var n = 0

        fun nueva() {
            page?.let { pdf.finishPage(it) }
            n++
            val p = pdf.startPage(PdfDocument.PageInfo.Builder(595, 842, n).create())
            page = p; c = p.canvas; y = 50f
        }
        fun asegurar(h: Float) { if (page == null || y + h > 800f) nueva() }
        fun espacio(h: Float) { y += h }
        fun linea(t: String, p: Paint, h: Float = 16f) { asegurar(h); c.drawText(t, 40f, y + 12f, p); y += h }
        fun parrafo(t: String, p: Paint, ancho: Float = 515f) {
            var rest = t.trim()
            while (rest.isNotEmpty()) {
                var k = p.breakText(rest, true, ancho, null)
                if (k < rest.length) { val sp = rest.lastIndexOf(' ', k); if (sp > 0) k = sp }
                k = max(k, 1)
                linea(rest.substring(0, k).trim(), p)
                rest = rest.substring(k).trim()
            }
        }
        /** Fila de tabla: cada columna en su x; si `der`, el texto se alinea a la derecha de ese x. */
        fun fila(cols: List<String>, xs: List<Float>, p: Paint, h: Float = 16f) {
            asegurar(h)
            cols.forEachIndexed { i, t -> c.drawText(t, xs[i], y + 12f, p) }
            y += h
        }
        fun regla() {
            asegurar(4f)
            c.drawLine(40f, y, 555f, y, paint(1f, color = Color.GRAY).apply { strokeWidth = 0.8f })
            y += 4f
        }
        fun cerrar() { page?.let { pdf.finishPage(it) } }
    }

    fun generar(ctx: Context, v: Viaje, jornadas: List<Jornada>, gastos: List<Gasto>, puntos: List<PuntoGps>): File {
        val d = Doc()
        d.nueva()
        val titulo = paint(18f, true, AZUL)
        val h2 = paint(13f, true, AZUL)
        val n = paint(10.5f)
        val nb = paint(10.5f, true)
        val chico = paint(9f, color = Color.DKGRAY)
        val der = paint(10.5f, der = true)
        val derB = paint(10.5f, true, der = true)

        d.linea("Mi Control — Informe de viaje", titulo, 26f)
        d.linea("ID del viaje: ${v.id}", chico)
        d.espacio(6f)
        d.linea("Nombre: ${v.nombre}", nb)
        d.parrafo("Cliente: ${v.cliente.ifBlank { "—" }}", n)
        d.parrafo("Origen: ${v.origen.ifBlank { "—" }}", n)
        d.parrafo("Destino: ${v.destino.ifBlank { "—" }}", n)
        d.linea("Inicio: ${fechaHoraFmt.format(Date(v.inicio))}", n)
        d.linea("Fin: ${v.fin?.let { fechaHoraFmt.format(Date(it)) } ?: "—"}", n)
        d.linea("Estado: ${v.estado}", n)
        d.espacio(6f)
        d.linea("Kilómetros oficiales (odómetro)", h2, 20f)
        d.linea("Odómetro inicial: ${v.odometroInicial} km", n)
        d.linea("Odómetro final: ${v.odometroFinal?.let { "$it km" } ?: "—"}", n)
        d.linea("Kilómetros oficiales: ${Calculos.kmOficiales(v.odometroInicial, v.odometroFinal)?.let { "$it km" } ?: "pendiente"}", nb)
        d.linea("Calculados solo con el odómetro (final − inicial).", chico)

        // ---- Horas ----
        d.espacio(8f)
        d.linea("Horas trabajadas por jornada", h2, 20f)
        val xs = listOf(40f, 115f, 170f, 225f, 290f, 360f, 440f)
        d.fila(listOf("Fecha", "Inicio", "Fin", "Pausa", "Total", "Normales", "Extras"), xs, nb)
        d.regla()
        jornadas.forEach { j ->
            val t = Calculos.minutosTrabajados(j)
            val fecha = runCatching { LocalDate.parse(j.fecha).format(fechaFmt) }.getOrDefault(j.fecha)
            if (j.finMin < 0) d.fila(listOf(fecha, Calculos.hhmm(j.inicioMin), "en curso", "", "", "", ""), xs, n)
            else d.fila(
                listOf(fecha, Calculos.hhmm(j.inicioMin), Calculos.hhmm(j.finMin),
                    "${j.pausaMin} min" + if (j.descuentaPausa) "" else "*",
                    Calculos.hhmm(t), Calculos.hhmm(Calculos.normales(t)), Calculos.hhmm(Calculos.extras(t))),
                xs, n
            )
        }
        if (jornadas.isEmpty()) d.linea("Sin jornadas registradas.", n)
        d.regla()
        d.linea("Total horas extras del viaje: ${Calculos.hhmm(Calculos.extrasTotales(jornadas))} h", nb)
        d.linea("Jornada normal de referencia: 9 h. Las extras se calculan por día. * pausa no descontada.", chico)

        // ---- Gastos ----
        d.espacio(8f)
        d.linea("Gastos por categoría", h2, 20f)
        CATEGORIAS_GASTO.forEach { cat ->
            val tot = gastos.filter { it.categoria == cat }.sumOf { it.importeCentavos }
            if (tot > 0) {
                d.asegurar(16f)
                d.c.drawText(cat, 40f, d.y + 12f, n)
                d.c.drawText(Calculos.pesos(tot), 555f, d.y + 12f, der)
                d.y += 16f
            }
        }
        d.regla()
        d.asegurar(18f)
        d.c.drawText("Total general", 40f, d.y + 12f, nb)
        d.c.drawText(Calculos.pesos(gastos.sumOf { it.importeCentavos }), 555f, d.y + 12f, derB)
        d.y += 20f
        if (gastos.isNotEmpty()) {
            d.linea("Detalle", nb)
            gastos.forEach { g ->
                d.asegurar(16f)
                d.c.drawText("${fechaHoraFmt.format(Date(g.fechaHora))}  ${g.categoria}  ${g.descripcion}".take(70), 40f, d.y + 12f, n)
                d.c.drawText(Calculos.pesos(g.importeCentavos), 555f, d.y + 12f, der)
                d.y += 16f
            }
        }

        // ---- Recorrido ----
        d.espacio(8f)
        d.linea("Recorrido GPS registrado", h2, 20f)
        val img = File(ctx.filesDir, "recorridos/${v.id}.png")
        if (img.exists()) dibujarImagen(d, img) else dibujarRecorrido(d, puntos)
        d.linea("Puntos registrados: ${puntos.size} · Distancia GPS: ${"%.1f".format(Calculos.distanciaGpsKm(puntos))} km (solo referencia, no oficial)", n)
        d.linea("Representación esquemática sin mapa de fondo. Un corte en la línea indica pérdida de señal.", chico)

        // ---- Observaciones ----
        d.espacio(8f)
        d.linea("Observaciones", h2, 20f)
        d.parrafo(v.observaciones.ifBlank { "Sin observaciones." }, n)
        d.espacio(10f)
        d.linea("Informe generado el ${fechaHoraFmt.format(Date())}", chico)

        d.cerrar()
        val dir = File(ctx.cacheDir, "informes").apply { mkdirs() }
        val seguro = v.nombre.replace(Regex("[^A-Za-z0-9]+"), "_").trim('_').ifBlank { "viaje" }
        val f = File(dir, "Informe_${seguro}_${v.id.take(6)}.pdf")
        FileOutputStream(f).use { d.pdf.writeTo(it) }
        d.pdf.close()
        return f
    }

    /** Mapa del recorrido guardado al finalizar el viaje. */
    private fun dibujarImagen(d: Doc, f: File) {
        val bmp = BitmapFactory.decodeFile(f.path)
        if (bmp == null) { d.linea("No se pudo leer la imagen del mapa guardado.", paint(10.5f)); return }
        val esc = min(515f / bmp.width, 300f / bmp.height)
        val w = bmp.width * esc
        val h = bmp.height * esc
        d.asegurar(h + 10f)
        d.c.drawBitmap(bmp, null, RectF(40f, d.y, 40f + w, d.y + h), null)
        d.y += h + 8f
    }

    private fun dibujarRecorrido(d: Doc, puntos: List<PuntoGps>) {
        val h = 190f; val w = 515f; val x0 = 40f
        d.asegurar(h + 10f)
        val y0 = d.y
        val c = d.c
        c.drawRect(x0, y0, x0 + w, y0 + h, paint(1f, color = Color.GRAY).apply { style = Paint.Style.STROKE })
        if (puntos.isEmpty()) {
            c.drawText("Sin datos GPS registrados", x0 + 10f, y0 + h / 2, paint(10.5f, color = Color.DKGRAY))
            d.y += h + 8f
            return
        }
        val minLat = puntos.minOf { it.lat }; val maxLat = puntos.maxOf { it.lat }
        val minLng = puntos.minOf { it.lng }; val maxLng = puntos.maxOf { it.lng }
        val kx = cos(Math.toRadians((minLat + maxLat) / 2))
        val anchoGrados = max((maxLng - minLng) * kx, 1e-6)
        val altoGrados = max(maxLat - minLat, 1e-6)
        val escala = min((w - 20f) / anchoGrados, (h - 20f) / altoGrados)
        val offX = (w - anchoGrados * escala) / 2
        val offY = (h - altoGrados * escala) / 2
        fun px(lng: Double) = (x0 + offX + (lng - minLng) * kx * escala).toFloat()
        fun py(lat: Double) = (y0 + h - offY - (lat - minLat) * escala).toFloat()

        val linea = paint(1f, color = AZUL).apply { style = Paint.Style.STROKE; strokeWidth = 2f }
        Calculos.segmentos(puntos).forEach { seg ->
            val path = Path()
            seg.forEachIndexed { i, p -> if (i == 0) path.moveTo(px(p.lng), py(p.lat)) else path.lineTo(px(p.lng), py(p.lat)) }
            c.drawPath(path, linea)
        }
        val ini = puntos.first(); val fin = puntos.last()
        c.drawCircle(px(ini.lng), py(ini.lat), 5f, paint(1f, color = Color.rgb(46, 125, 50)))
        c.drawCircle(px(fin.lng), py(fin.lat), 5f, paint(1f, color = Color.RED))
        c.drawText("Verde: primer punto · Rojo: último punto", x0 + 8f, y0 + h - 6f, paint(8.5f, color = Color.DKGRAY))
        d.y += h + 8f
    }

    fun compartirImagen(ctx: Context, f: File) {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(i, "Compartir imagen del recorrido").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun compartir(ctx: Context, f: File) {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(i, "Compartir informe").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    /** Copia el PDF a la carpeta Descargas del teléfono. */
    fun guardarEnDescargas(ctx: Context, f: File): Boolean {
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, f.name)
            put(MediaStore.Downloads.MIME_TYPE, "application/pdf")
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
        }
        val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return false
        ctx.contentResolver.openOutputStream(uri)?.use { out -> f.inputStream().use { it.copyTo(out) } } ?: return false
        return true
    }
}
