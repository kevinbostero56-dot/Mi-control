package com.micontrol.app.pdf

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.RectF
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.pdf.PdfDocument
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import com.micontrol.app.data.*
import com.micontrol.app.domain.Calculos
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Date
import java.util.Locale
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min

object InformePdf {
    private val AZUL = Color.rgb(13, 43, 82)
    private val fechaHoraFmt = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("es", "AR"))
    private val fechaFmt = DateTimeFormatter.ofPattern("dd/MM/yyyy")

    private fun paint(size: Float, bold: Boolean = false, color: Int = Color.BLACK, der: Boolean = false) =
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = size
            isFakeBoldText = bold
            this.color = color
            if (der) textAlign = Paint.Align.RIGHT
        }

    private class Doc {
        val pdf = PdfDocument()
        private var page: PdfDocument.Page? = null
        lateinit var c: Canvas
        var y = 0f
        private var n = 0

        fun nueva() {
            page?.let { pdf.finishPage(it) }
            n++
            val p = pdf.startPage(PdfDocument.PageInfo.Builder(595, 842, n).create())
            page = p; c = p.canvas; y = 50f
        }
        fun asegurar(h: Float) { if (page == null || y + h > 800f) nueva() }
        fun espacio(h: Float) { y += h }
        fun linea(t: String, p: Paint, h: Float = 16f) { asegurar(h); c.drawText(t, 40f, y + 12f, p); y += h }
        fun parrafo(t: String, p: Paint, ancho: Float = 515f) {
            var rest = t.trim()
            while (rest.isNotEmpty()) {
                var k = p.breakText(rest, true, ancho, null)
                if (k < rest.length) { val sp = rest.lastIndexOf(' ', k); if (sp > 0) k = sp }
                k = max(k, 1)
                linea(rest.substring(0, k).trim(), p)
                rest = rest.substring(k).trim()
            }
        }
        /** Fila de tabla: cada columna en su x; si `der`, el texto se alinea a la derecha de ese x. */
        fun fila(cols: List<String>, xs: List<Float>, p: Paint, h: Float = 16f) {
            asegurar(h)
            cols.forEachIndexed { i, t -> c.drawText(t, xs[i], y + 12f, p) }
            y += h
        }
        fun regla() {
            asegurar(4f)
            c.drawLine(40f, y, 555f, y, paint(1f, color = Color.GRAY).apply { strokeWidth = 0.8f })
            y += 4f
        }
        fun cerrar() { page?.let { pdf.finishPage(it) } }
    }

    fun generar(
        ctx: Context, v: Viaje, jornadas: List<Jornada>, gastos: List<Gasto>,
        puntos: List<PuntoGps>, adelantos: List<Adelanto>,
        perfil: Perfiles.Perfil? = null
    ): File {
        val d = Doc()
        d.nueva()
        val titulo = paint(18f, true, AZUL)
        val h2 = paint(13f, true, AZUL)
        val n = paint(10.5f)
        val nb = paint(10.5f, true)
        val chico = paint(9f, color = Color.DKGRAY)
        val der = paint(10.5f, der = true)
        val derB = paint(10.5f, true, der = true)

        d.linea("Mi Control — Informe de viaje", titulo, 26f)
        d.linea("ID del viaje: ${v.id}", chico)
        if (perfil != null) {
            d.linea("Chofer: ${perfil.nombre}", nb)
            if (perfil.camion.isNotBlank()) d.linea("Camión: ${perfil.camion}", n)
            if (perfil.empresa.isNotBlank()) d.linea("Empresa: ${perfil.empresa}", n)
        }
        d.espacio(6f)
        d.linea("Nombre: ${v.nombre}", nb)
        d.parrafo("Cliente: ${v.cliente.ifBlank { "—" }}", n)
        d.parrafo("Origen: ${v.origen.ifBlank { "—" }}", n)
        d.parrafo("Destino: ${v.destino.ifBlank { "—" }}", n)
        d.linea("Inicio: ${fechaHoraFmt.format(Date(v.inicio))}", n)
        d.linea("Fin: ${v.fin?.let { fechaHoraFmt.format(Date(it)) } ?: "—"}", n)
        d.linea("Estado: ${v.estado}", n)
        d.espacio(6f)
        d.linea("Kilómetros oficiales (odómetro)", h2, 20f)
        d.linea("Odómetro inicial: ${Calculos.decimasTxt(Calculos.odoDecimas(v.odometroInicial, v.odoInicialDec))} km", n)
        d.linea("Odómetro final: ${v.odometroFinal?.let { "${Calculos.decimasTxt(Calculos.odoDecimas(it, v.odoFinalDec))} km" } ?: "—"}", n)
        d.linea("Kilómetros oficiales: ${Calculos.kmViajeTxt(v)?.let { "$it km" } ?: "pendiente"}", nb)
        d.linea("Calculados solo con el odómetro (final − inicial).", chico)

        // ---- Horas ----
        d.espacio(8f)
        d.linea("Horas trabajadas por jornada", h2, 20f)
        val xs = listOf(40f, 115f, 170f, 225f, 290f, 360f, 440f)
        d.fila(listOf("Fecha", "Inicio", "Fin", "Pausa", "Total", "Normales", "Extras"), xs, nb)
        d.regla()
        jornadas.forEach { j ->
            val t = Calculos.minutosTrabajados(j)
            val fecha = runCatching { LocalDate.parse(j.fecha).format(fechaFmt) }.getOrDefault(j.fecha)
            if (j.finMin < 0) d.fila(listOf(fecha, Calculos.hhmm(j.inicioMin), "en curso", "", "", "", ""), xs, n)
            else d.fila(
                listOf(fecha, Calculos.hhmm(j.inicioMin), Calculos.hhmm(j.finMin),
                    "${j.pausaMin} min" + if (j.descuentaPausa) "" else "*",
                    Calculos.hhmm(t), Calculos.hhmm(Calculos.normales(t)), Calculos.hhmm(Calculos.extras(t))),
                xs, n
            )
        }
        if (jornadas.isEmpty()) d.linea("Sin jornadas registradas.", n)
        d.regla()
        d.linea("Total horas extras del viaje: ${Calculos.hhmm(Calculos.extrasTotales(jornadas))} h", nb)
        d.linea("Jornada normal de referencia: 9 h. Las extras se calculan por día. * pausa no descontada.", chico)

        // ---- Gastos ----
        d.espacio(8f)
        d.linea("Gastos por categoría", h2, 20f)
        CATEGORIAS_GASTO.forEach { cat ->
            val tot = gastos.filter { it.categoria == cat }.sumOf { it.importeCentavos }
            if (tot > 0) {
                d.asegurar(16f)
                d.c.drawText(cat, 40f, d.y + 12f, n)
                d.c.drawText(Calculos.pesos(tot), 555f, d.y + 12f, der)
                d.y += 16f
            }
        }
        d.regla()
        d.asegurar(18f)
        d.c.drawText("Total general", 40f, d.y + 12f, nb)
        d.c.drawText(Calculos.pesos(gastos.sumOf { it.importeCentavos }), 555f, d.y + 12f, derB)
        d.y += 20f
        val consumo = Calculos.consumo(gastos, Calculos.kmDecimas(v)?.let { it / 10.0 }, Calculos.distanciaGpsKm(puntos))
        if (consumo != null) {
            d.linea("Combustible: ${"%.1f".format(consumo.litros)} L cargados", n)
            if (consumo.lPor100 == null) d.linea("Consumo pendiente (falta el odómetro final)", n)
            if (consumo.lPor100 != null && consumo.kmPorLitro != null) {
                d.linea(
                    "Consumo: ${"%.1f".format(consumo.lPor100)} L cada 100 km (${"%.2f".format(consumo.kmPorLitro)} km/L)" +
                        if (consumo.kmDeGps) " - km del GPS, referencia" else " - km del odómetro",
                    n
                )
            }
        }
        if (gastos.isNotEmpty()) {
            d.linea("Detalle", nb)
            gastos.forEach { g ->
                d.asegurar(16f)
                d.c.drawText("${fechaHoraFmt.format(Date(g.fechaHora))}  ${g.categoria}  ${g.descripcion}".take(70), 40f, d.y + 12f, n)
                d.c.drawText(Calculos.pesos(g.importeCentavos), 555f, d.y + 12f, der)
                d.y += 16f
            }
        }

        // ---- Rendición con la empresa ----
        val recibido = adelantos.sumOf { it.importeCentavos }
        val gastado = gastos.sumOf { it.importeCentavos }
        val saldo = recibido - gastado
        d.espacio(8f)
        d.linea("Rendición con la empresa", h2, 20f)
        adelantos.forEach { a ->
            d.asegurar(16f)
            d.c.drawText("${fechaHoraFmt.format(Date(a.fechaHora))}  Plata recibida  ${a.descripcion}".take(70), 40f, d.y + 12f, n)
            d.c.drawText(Calculos.pesos(a.importeCentavos), 555f, d.y + 12f, der)
            d.y += 16f
        }
        if (adelantos.isEmpty()) d.linea("No se registró plata recibida de la empresa.", n)
        d.regla()
        d.asegurar(16f)
        d.c.drawText("Total recibido de la empresa", 40f, d.y + 12f, n)
        d.c.drawText(Calculos.pesos(recibido), 555f, d.y + 12f, der)
        d.y += 16f
        d.asegurar(16f)
        d.c.drawText("Total de gastos", 40f, d.y + 12f, n)
        d.c.drawText(Calculos.pesos(gastado), 555f, d.y + 12f, der)
        d.y += 16f
        d.asegurar(20f)
        d.c.drawText(
            when {
                saldo > 0 -> "A devolver a la empresa"
                saldo < 0 -> "La empresa debe al chofer"
                else -> "Saldo"
            }, 40f, d.y + 13f, nb
        )
        d.c.drawText(if (saldo == 0L) "A mano" else Calculos.pesos(kotlin.math.abs(saldo)), 555f, d.y + 13f, derB)
        d.y += 22f

        // ---- Comprobantes (fotos de tickets) ----
        val conFoto = gastos.filter { g -> g.fotoPath?.let { File(it).exists() } == true }
        if (conFoto.isNotEmpty()) {
            d.espacio(8f)
            d.linea("Comprobantes", h2, 20f)
            conFoto.forEach { g ->
                val bmp = Fotos.cargar(g.fotoPath!!, 1000) ?: return@forEach
                val esc = min(300f / bmp.width, 280f / bmp.height)
                val w = bmp.width * esc
                val h = bmp.height * esc
                d.asegurar(h + 28f)
                d.linea("${g.categoria} · ${fechaHoraFmt.format(Date(g.fechaHora))} · ${Calculos.pesos(g.importeCentavos)}", chico)
                d.c.drawBitmap(bmp, null, RectF(40f, d.y, 40f + w, d.y + h), null)
                d.y += h + 10f
            }
        }

        // ---- Recorrido ----
        d.espacio(8f)
        d.linea("Recorrido GPS registrado", h2, 20f)
        val img = File(ctx.filesDir, "recorridos/${v.id}.png")
        if (img.exists()) dibujarImagen(d, img) else dibujarRecorrido(d, puntos)
        d.linea("Puntos registrados: ${puntos.size} · Distancia GPS: ${"%.1f".format(Calculos.distanciaGpsKm(puntos))} km (solo referencia, no oficial)", n)
        d.linea("Representación esquemática sin mapa de fondo. Un corte en la línea indica pérdida de señal.", chico)

        // ---- Observaciones ----
        d.espacio(8f)
        d.linea("Observaciones", h2, 20f)
        d.parrafo(v.observaciones.ifBlank { "Sin observaciones." }, n)
        d.espacio(10f)
        d.linea("Informe generado el ${fechaHoraFmt.format(Date())}", chico)

        d.cerrar()
        val dir = File(ctx.cacheDir, "informes").apply { mkdirs() }
        val seguro = v.nombre.replace(Regex("[^A-Za-z0-9]+"), "_").trim('_').ifBlank { "viaje" }
        val f = File(dir, "Informe_${seguro}_${v.id.take(6)}.pdf")
        FileOutputStream(f).use { d.pdf.writeTo(it) }
        d.pdf.close()
        return f
    }

    /**
     * Informe del mes: la primera página trae la tabla de viajes con los totales y después va una sección por viaje
     * (odómetro, jornadas, gastos, plata recibida, saldo y fotos de tickets). Funciona sin internet.
     */
    fun generarMes(
        ctx: Context, mes: java.time.YearMonth, viajes: List<Viaje>, jornadas: List<Jornada>,
        gastos: List<Gasto>, adelantos: List<Adelanto>, perfil: Perfiles.Perfil? = null
    ): File {
        val d = Doc()
        d.nueva()
        val titulo = paint(18f, true, AZUL)
        val h2 = paint(13f, true, AZUL)
        val n = paint(10.5f)
        val nb = paint(10.5f, true)
        val chico = paint(9f, color = Color.DKGRAY)
        val der = paint(10.5f, der = true)
        val derB = paint(10.5f, true, der = true)
        val nombreMes = mes.month.getDisplayName(java.time.format.TextStyle.FULL, Locale("es", "AR")).replaceFirstChar { it.uppercase() } + " " + mes.year
        val ordenados = viajes.sortedBy { it.inicio }

        fun jDe(v: Viaje) = jornadas.filter { it.viajeId == v.id }
        fun gDe(v: Viaje) = gastos.filter { it.viajeId == v.id }
        fun aDe(v: Viaje) = adelantos.filter { it.viajeId == v.id }

        d.linea("Mi Control — Informe del mes", titulo, 26f)
        d.linea(nombreMes, h2, 20f)
        if (perfil != null) {
            d.linea("Chofer: ${perfil.nombre}", nb)
            if (perfil.camion.isNotBlank()) d.linea("Camión: ${perfil.camion}", n)
            if (perfil.empresa.isNotBlank()) d.linea("Empresa: ${perfil.empresa}", n)
        }
        d.espacio(8f)
        d.linea("Viajes del mes", h2, 20f)
        val xs = listOf(40f, 215f, 285f, 345f, 440f)
        d.fila(listOf("Viaje", "Fecha", "Km", "Extras", "Gastos / Recibido"), xs, nb)
        d.regla()
        var kmTot = 0L; var extrasTot = 0; var gastosTot = 0L; var recibidoTot = 0L
        ordenados.forEach { v ->
            val km = Calculos.kmDecimas(v)
            if (v.estado == Viaje.Estado.FINALIZADO && km != null) kmTot += km
            val ex = Calculos.extrasTotales(jDe(v))
            val g = gDe(v).sumOf { it.importeCentavos }
            val r = aDe(v).sumOf { it.importeCentavos }
            extrasTot += ex; gastosTot += g; recibidoTot += r
            d.fila(
                listOf(
                    v.nombre.take(30), SimpleDateFormat("dd/MM/yy", Locale("es", "AR")).format(Date(v.inicio)),
                    km?.let { Calculos.decimasTxt(it) } ?: "—", Calculos.hhmm(ex),
                    "${Calculos.pesos(g)} / ${Calculos.pesos(r)}"
                ), xs, n
            )
        }
        if (ordenados.isEmpty()) d.linea("No hay viajes en este mes.", n)
        d.regla()
        val trabajadosMes = jornadas.sumOf { Calculos.minutosTrabajados(it) }
        d.linea("Kilómetros por odómetro: ${Calculos.decimasTxt(kmTot)} km", nb)
        d.linea("Horas trabajadas: ${Calculos.hhmm(trabajadosMes)} h", nb)
        d.linea("Horas extras (más de 9 h por día): ${Calculos.hhmm(Calculos.extrasTotales(jornadas))} h", nb)
        d.linea("Gastos totales: ${Calculos.pesos(gastosTot)}", nb)
        d.linea("Plata recibida de la empresa: ${Calculos.pesos(recibidoTot)}", nb)
        val saldoMes = recibidoTot - gastosTot
        d.linea(
            when {
                saldoMes > 0 -> "Saldo: a devolver a la empresa ${Calculos.pesos(saldoMes)}"
                saldoMes < 0 -> "Saldo: la empresa debe al chofer ${Calculos.pesos(kotlin.math.abs(saldoMes))}"
                else -> "Saldo: a mano"
            }, h2, 20f
        )
        d.linea("Los kilómetros salen solo del odómetro (final − inicial). Detalle de cada viaje en las páginas siguientes.", chico)

        // ---- Una sección por viaje ----
        ordenados.forEach { v ->
            d.nueva()
            d.linea(v.nombre, titulo, 26f)
            d.linea("Cliente: ${v.cliente.ifBlank { "—" }}", n)
            d.linea("Inicio: ${fechaHoraFmt.format(Date(v.inicio))}   Fin: ${v.fin?.let { fechaHoraFmt.format(Date(it)) } ?: "—"}", n)
            d.linea("Estado: ${v.estado}", n)
            d.linea("Odómetro: ${Calculos.decimasTxt(Calculos.odoDecimas(v.odometroInicial, v.odoInicialDec))} → ${v.odometroFinal?.let { Calculos.decimasTxt(Calculos.odoDecimas(it, v.odoFinalDec)) } ?: "—"} km", n)
            d.linea("Kilómetros oficiales: ${Calculos.kmViajeTxt(v)?.let { "$it km" } ?: "pendiente"}", nb)
            d.espacio(6f)
            d.linea("Jornadas", h2, 20f)
            val xj = listOf(40f, 115f, 170f, 225f, 290f, 360f, 440f)
            d.fila(listOf("Fecha", "Inicio", "Fin", "Pausa", "Total", "Normales", "Extras"), xj, nb)
            d.regla()
            jDe(v).forEach { j ->
                val t = Calculos.minutosTrabajados(j)
                val fecha = runCatching { LocalDate.parse(j.fecha).format(fechaFmt) }.getOrDefault(j.fecha)
                if (j.finMin < 0) d.fila(listOf(fecha, Calculos.hhmm(j.inicioMin), "en curso", "", "", "", ""), xj, n)
                else d.fila(
                    listOf(fecha, Calculos.hhmm(j.inicioMin), Calculos.hhmm(j.finMin), "${j.pausaMin} min",
                        Calculos.hhmm(t), Calculos.hhmm(Calculos.normales(t)), Calculos.hhmm(Calculos.extras(t))), xj, n
                )
            }
            d.linea("Horas extras del viaje: ${Calculos.hhmm(Calculos.extrasTotales(jDe(v)))} h", nb)
            d.espacio(6f)
            d.linea("Gastos", h2, 20f)
            CATEGORIAS_GASTO.forEach { cat ->
                val tot = gDe(v).filter { it.categoria == cat }.sumOf { it.importeCentavos }
                if (tot > 0) {
                    d.asegurar(16f)
                    d.c.drawText(cat, 40f, d.y + 12f, n)
                    d.c.drawText(Calculos.pesos(tot), 555f, d.y + 12f, der)
                    d.y += 16f
                }
            }
            val comb = Calculos.consumo(gDe(v), Calculos.kmDecimas(v)?.let { it / 10.0 }, 0.0)
            if (comb != null) {
                d.linea("Combustible: ${"%.1f".format(Locale("es", "AR"), comb.litros)} L" +
                    (comb.lPor100?.let { " · ${"%.1f".format(Locale("es", "AR"), it)} L/100 km" } ?: " · consumo pendiente"), n)
            }
            gDe(v).forEach { g ->
                d.asegurar(16f)
                d.c.drawText("${fechaHoraFmt.format(Date(g.fechaHora))}  ${g.categoria}  ${g.descripcion}".take(70), 40f, d.y + 12f, chico)
                d.c.drawText(Calculos.pesos(g.importeCentavos), 555f, d.y + 12f, der)
                d.y += 15f
            }
            d.regla()
            val g = gDe(v).sumOf { it.importeCentavos }
            val r = aDe(v).sumOf { it.importeCentavos }
            d.asegurar(16f); d.c.drawText("Total de gastos", 40f, d.y + 12f, n); d.c.drawText(Calculos.pesos(g), 555f, d.y + 12f, der); d.y += 16f
            d.asegurar(16f); d.c.drawText("Plata recibida de la empresa", 40f, d.y + 12f, n); d.c.drawText(Calculos.pesos(r), 555f, d.y + 12f, der); d.y += 16f
            val s = r - g
            d.asegurar(20f)
            d.c.drawText(
                when { s > 0 -> "A devolver a la empresa"; s < 0 -> "La empresa debe al chofer"; else -> "Saldo" }, 40f, d.y + 13f, nb
            )
            d.c.drawText(if (s == 0L) "A mano" else Calculos.pesos(kotlin.math.abs(s)), 555f, d.y + 13f, derB)
            d.y += 22f
            val conFoto = gDe(v).filter { x -> x.fotoPath?.let { File(it).exists() } == true }
            conFoto.forEach { x ->
                val bmp = Fotos.cargar(x.fotoPath!!, 900) ?: return@forEach
                val esc = min(260f / bmp.width, 240f / bmp.height)
                val w = bmp.width * esc
                val h = bmp.height * esc
                d.asegurar(h + 28f)
                d.linea("Ticket: ${x.categoria} · ${fechaHoraFmt.format(Date(x.fechaHora))} · ${Calculos.pesos(x.importeCentavos)}", chico)
                d.c.drawBitmap(bmp, null, RectF(40f, d.y, 40f + w, d.y + h), null)
                d.y += h + 10f
            }
        }
        d.espacio(10f)
        d.linea("Informe generado el ${fechaHoraFmt.format(Date())}", chico)
        d.cerrar()
        val dir = File(ctx.cacheDir, "informes").apply { mkdirs() }
        val f = File(dir, "Informe_mes_${mes.year}-${"%02d".format(mes.monthValue)}.pdf")
        FileOutputStream(f).use { d.pdf.writeTo(it) }
        d.pdf.close()
        return f
    }

    /** Mapa del recorrido guardado al finalizar el viaje. */
    private fun dibujarImagen(d: Doc, f: File) {
        val bmp = BitmapFactory.decodeFile(f.path)
        if (bmp == null) { d.linea("No se pudo leer la imagen del mapa guardado.", paint(10.5f)); return }
        val esc = min(515f / bmp.width, 300f / bmp.height)
        val w = bmp.width * esc
        val h = bmp.height * esc
        d.asegurar(h + 10f)
        d.c.drawBitmap(bmp, null, RectF(40f, d.y, 40f + w, d.y + h), null)
        d.y += h + 8f
    }

    private fun dibujarRecorrido(d: Doc, puntos: List<PuntoGps>) {
        val h = 190f; val w = 515f; val x0 = 40f
        d.asegurar(h + 10f)
        val y0 = d.y
        val c = d.c
        c.drawRect(x0, y0, x0 + w, y0 + h, paint(1f, color = Color.GRAY).apply { style = Paint.Style.STROKE })
        if (puntos.isEmpty()) {
            c.drawText("Sin datos GPS registrados", x0 + 10f, y0 + h / 2, paint(10.5f, color = Color.DKGRAY))
            d.y += h + 8f
            return
        }
        val minLat = puntos.minOf { it.lat }; val maxLat = puntos.maxOf { it.lat }
        val minLng = puntos.minOf { it.lng }; val maxLng = puntos.maxOf { it.lng }
        val kx = cos(Math.toRadians((minLat + maxLat) / 2))
        val anchoGrados = max((maxLng - minLng) * kx, 1e-6)
        val altoGrados = max(maxLat - minLat, 1e-6)
        val escala = min((w - 20f) / anchoGrados, (h - 20f) / altoGrados)
        val offX = (w - anchoGrados * escala) / 2
        val offY = (h - altoGrados * escala) / 2
        fun px(lng: Double) = (x0 + offX + (lng - minLng) * kx * escala).toFloat()
        fun py(lat: Double) = (y0 + h - offY - (lat - minLat) * escala).toFloat()

        val linea = paint(1f, color = AZUL).apply { style = Paint.Style.STROKE; strokeWidth = 2f }
        Calculos.segmentos(puntos).forEach { seg ->
            val path = Path()
            seg.forEachIndexed { i, p -> if (i == 0) path.moveTo(px(p.lng), py(p.lat)) else path.lineTo(px(p.lng), py(p.lat)) }
            c.drawPath(path, linea)
        }
        val ini = puntos.first(); val fin = puntos.last()
        c.drawCircle(px(ini.lng), py(ini.lat), 5f, paint(1f, color = Color.rgb(46, 125, 50)))
        c.drawCircle(px(fin.lng), py(fin.lat), 5f, paint(1f, color = Color.RED))
        c.drawText("Verde: primer punto · Rojo: último punto", x0 + 8f, y0 + h - 6f, paint(8.5f, color = Color.DKGRAY))
        d.y += h + 8f
    }

    fun compartirImagen(ctx: Context, f: File) {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(i, "Compartir imagen del recorrido").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun compartir(ctx: Context, f: File) {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(i, "Compartir informe").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    /** Manda el PDF directo por WhatsApp (si no está instalado, abre el menú de compartir). */
    fun compartirWhatsApp(ctx: Context, f: File) {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)
        fun intento(paquete: String?) = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            if (paquete != null) setPackage(paquete)
        }
        for (paquete in listOf("com.whatsapp", "com.whatsapp.w4b")) {
            try {
                ctx.startActivity(intento(paquete))
                return
            } catch (e: Exception) {
                // prueba con el siguiente
            }
        }
        compartir(ctx, f)
    }

    /** Copia el PDF a la carpeta Descargas del teléfono. */
    fun guardarEnDescargas(ctx: Context, f: File): Boolean {
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, f.name)
            put(MediaStore.Downloads.MIME_TYPE, "application/pdf")
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
        }
        val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return false
        ctx.contentResolver.openOutputStream(uri)?.use { out -> f.inputStream().use { it.copyTo(out) } } ?: return false
        return true
    }
}
