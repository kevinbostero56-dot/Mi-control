package com.micontrol.app.data

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.util.zip.ZipInputStream

/**
 * Lee los lugares guardados que Google entrega en "Descargar tus datos" (Takeout):
 * archivos .json (Lugares guardados / etiquetados), .csv (listas) o .kml, sueltos o dentro de un .zip.
 */
object ImportarGoogle {
    data class Item(val nombre: String, val direccion: String?, val lat: Double?, val lng: Double?, val url: String?)

    private const val MAX_BYTES = 40 * 1024 * 1024

    fun leer(ctx: Context, uri: Uri): List<Item> {
        val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return emptyList()
        if (bytes.size > MAX_BYTES) return emptyList()
        val out = ArrayList<Item>()
        if (bytes.size > 4 && bytes[0] == 'P'.code.toByte() && bytes[1] == 'K'.code.toByte()) {
            ZipInputStream(bytes.inputStream()).use { z ->
                var e = z.nextEntry
                while (e != null) {
                    val n = e.name.lowercase()
                    if (!e.isDirectory && (n.endsWith(".json") || n.endsWith(".csv") || n.endsWith(".kml"))) {
                        out.addAll(interpretar(z.readBytes().toString(Charsets.UTF_8)))
                    }
                    e = z.nextEntry
                }
            }
        } else {
            out.addAll(interpretar(bytes.toString(Charsets.UTF_8)))
        }
        // Sin repetidos (mismo nombre y mismo lugar)
        return out.distinctBy { "${it.nombre.lowercase()}|${it.lat}|${it.lng}|${it.url}" }
    }

    private fun interpretar(textoCrudo: String): List<Item> {
        val t = textoCrudo.trimStart('﻿', ' ', '\n', '\r', '\t')
        return try {
            when {
                t.startsWith("{") || t.startsWith("[") -> desdeJson(t)
                t.contains("<kml", ignoreCase = true) -> desdeKml(t)
                else -> desdeCsv(t)
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun coordValida(lat: Double?, lng: Double?): Boolean =
        lat != null && lng != null && lat in -90.0..90.0 && lng in -180.0..180.0 && !(lat == 0.0 && lng == 0.0)

    private fun texto(o: JSONObject?, vararg claves: String): String? {
        if (o == null) return null
        for (c in claves) {
            val v = o.optString(c, "").trim()
            if (v.isNotBlank() && v != "null") return v
        }
        return null
    }

    // ---------- JSON (GeoJSON de "Lugares guardados" / "Sitios etiquetados") ----------
    private fun desdeJson(t: String): List<Item> {
        val elementos = ArrayList<JSONObject>()
        if (t.startsWith("[")) {
            val a = JSONArray(t)
            for (i in 0 until a.length()) a.optJSONObject(i)?.let { elementos.add(it) }
        } else {
            val raiz = JSONObject(t)
            val f = raiz.optJSONArray("features")
            if (f != null) for (i in 0 until f.length()) f.optJSONObject(i)?.let { elementos.add(it) }
            else elementos.add(raiz)
        }
        val out = ArrayList<Item>()
        for (e in elementos) {
            val props = e.optJSONObject("properties") ?: e
            val loc = props.optJSONObject("location") ?: props.optJSONObject("Location")
            val nombre = texto(loc, "business_name", "Business Name") ?: texto(props, "Title", "title", "name") ?: continue
            val direccion = texto(loc, "address", "Address")
            val url = texto(props, "google_maps_url", "Google Maps URL", "url", "URL")

            var lat: Double? = null
            var lng: Double? = null
            val coords = e.optJSONObject("geometry")?.optJSONArray("coordinates")
            if (coords != null && coords.length() >= 2) {
                lng = coords.optDouble(0, Double.NaN).takeIf { !it.isNaN() }
                lat = coords.optDouble(1, Double.NaN).takeIf { !it.isNaN() }
            }
            if (!coordValida(lat, lng)) {
                val g = loc?.optJSONObject("Geo Coordinates") ?: loc?.optJSONObject("geo_coordinates")
                lat = texto(g, "Latitude", "latitude")?.replace(',', '.')?.toDoubleOrNull()
                lng = texto(g, "Longitude", "longitude")?.replace(',', '.')?.toDoubleOrNull()
            }
            if (!coordValida(lat, lng)) {
                val d = url?.let { UbicacionLink.coordenadasDirectas(it) }
                lat = d?.first; lng = d?.second
            }
            val ok = coordValida(lat, lng)
            out.add(Item(nombre, direccion, if (ok) lat else null, if (ok) lng else null, url))
        }
        return out
    }

    // ---------- CSV (listas guardadas) ----------
    private fun filasCsv(t: String): List<List<String>> {
        val filas = ArrayList<List<String>>()
        var fila = ArrayList<String>()
        val campo = StringBuilder()
        var comillas = false
        var i = 0
        while (i < t.length) {
            val c = t[i]
            when {
                comillas && c == '"' && i + 1 < t.length && t[i + 1] == '"' -> { campo.append('"'); i++ }
                c == '"' -> comillas = !comillas
                !comillas && c == ',' -> { fila.add(campo.toString()); campo.clear() }
                !comillas && (c == '\n' || c == '\r') -> {
                    if (c == '\r' && i + 1 < t.length && t[i + 1] == '\n') i++
                    fila.add(campo.toString()); campo.clear()
                    if (fila.any { it.isNotBlank() }) filas.add(fila)
                    fila = ArrayList()
                }
                else -> campo.append(c)
            }
            i++
        }
        fila.add(campo.toString())
        if (fila.any { it.isNotBlank() }) filas.add(fila)
        return filas
    }

    private fun desdeCsv(t: String): List<Item> {
        val filas = filasCsv(t)
        if (filas.size < 2) return emptyList()
        val cab = filas[0].map { it.trim().lowercase() }
        fun idx(vararg n: String) = cab.indexOfFirst { it in n }
        val iTitulo = idx("title", "título", "titulo", "nombre", "name")
        val iUrl = idx("url", "enlace", "link")
        val iNota = idx("note", "nota")
        val iDir = idx("address", "dirección", "direccion")
        if (iTitulo < 0 && iUrl < 0) return emptyList()
        val out = ArrayList<Item>()
        for (f in filas.drop(1)) {
            fun v(i: Int) = if (i >= 0 && i < f.size) f[i].trim().ifBlank { null } else null
            val url = v(iUrl)
            val nombre = v(iTitulo) ?: v(iNota) ?: continue
            val d = url?.let { UbicacionLink.coordenadasDirectas(it) }
            out.add(Item(nombre, v(iDir), d?.first, d?.second, url))
        }
        return out
    }

    // ---------- KML (Mis mapas) ----------
    private fun desdeKml(t: String): List<Item> {
        val out = ArrayList<Item>()
        val lugar = Regex("""<Placemark[\s\S]*?</Placemark>""", RegexOption.IGNORE_CASE)
        val nombreRx = Regex("""<name>([\s\S]*?)</name>""", RegexOption.IGNORE_CASE)
        val coordRx = Regex("""<coordinates>\s*(-?[0-9.]+)\s*,\s*(-?[0-9.]+)""", RegexOption.IGNORE_CASE)
        fun limpio(s: String) = s.replace("<![CDATA[", "").replace("]]>", "").trim()
        for (m in lugar.findAll(t)) {
            val bloque = m.value
            val nombre = nombreRx.find(bloque)?.groupValues?.get(1)?.let { limpio(it) }?.takeIf { it.isNotBlank() } ?: continue
            val c = coordRx.find(bloque)
            val lng = c?.groupValues?.get(1)?.toDoubleOrNull()
            val lat = c?.groupValues?.get(2)?.toDoubleOrNull()
            val ok = coordValida(lat, lng)
            out.add(Item(nombre, null, if (ok) lat else null, if (ok) lng else null, null))
        }
        return out
    }
}
