package com.micontrol.app.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.micontrol.app.data.Compu
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val PASOS = """1) En el celular abrí Chrome, tocá ⋮ y marcá "Sitio de escritorio". Entrá a script.google.com con tu cuenta de Google.
2) Tocá "Nuevo proyecto". Borrá lo que aparece escrito y pegá el código (tocá antes "📋 Copiar el código").
3) Tocá el disquete 💾 para guardar.
4) Arriba a la derecha: "Implementar" > "Nueva implementación" > en el engranaje elegí "Aplicación web". En "Quién tiene acceso" poné "Cualquier usuario". Tocá "Implementar" y aceptá los permisos (si dice "Google no verificó esta app": "Configuración avanzada" > "Ir a…", es tu propio código).
5) Copiá la "URL de la aplicación web" (termina en /exec) y pegala acá abajo."""

/** Ajustes > "Ver desde la computadora". */
@Composable
fun CompuGrupo() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var url by remember { mutableStateOf(Compu.url(ctx)) }
    var conectado by remember { mutableStateOf(Compu.activo(ctx)) }
    var vivo by remember { mutableStateOf(Compu.enVivo(ctx)) }
    var verPasos by remember { mutableStateOf(false) }
    var enviando by remember { mutableStateOf(false) }
    var ultimo by remember { mutableStateOf(Compu.ultimoEnvio(ctx)) }
    var admin by remember { mutableStateOf(Compu.adminLugares(ctx)) }
    var horaLug by remember { mutableStateOf(Compu.horaLugares(ctx)) }
    var lugaresTrabajando by remember { mutableStateOf(false) }

    fun enviar() {
        enviando = true
        scope.launch {
            val ok = Compu.enviarDatos(ctx)
            enviando = false
            ultimo = Compu.ultimoEnvio(ctx)
            Toast.makeText(
                ctx, if (ok) "Listo: los datos ya se ven en la computadora." else "No se pudo mandar. Revisá internet y el link.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("🖥️ Ver desde la computadora", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
            if (!conectado && Compu.incluido()) {
                BotonP({ Compu.guardarUrl(ctx, ""); url = Compu.url(ctx); conectado = true; enviar() }, Modifier.fillMaxWidth()) {
                    Text("Conectar a la página de la empresa")
                }
                Text("O, si querés usar una página propia, seguí los pasos de abajo.", style = MaterialTheme.typography.bodySmall)
            }
            if (!conectado) {
                Text(
                    "Otra persona (la empresa, un compañero) ve en la computadora dónde estás en vivo y tus viajes, km, horas extras y gastos " +
                        "cuando quiera. Es gratis: queda en una planilla de Google tuya. Se configura una sola vez.",
                    style = MaterialTheme.typography.bodyMedium
                )
                BotonP({ copiar(ctx, Compu.script(ctx)); Toast.makeText(ctx, "Código copiado", Toast.LENGTH_SHORT).show() }, Modifier.fillMaxWidth()) {
                    Text("📋 Copiar el código")
                }
                BotonSec({ verPasos = !verPasos }, Modifier.fillMaxWidth()) { Text(if (verPasos) "Ocultar los pasos" else "📖 Cómo se hace (5 pasos)") }
                if (verPasos) {
                    Text(PASOS, style = MaterialTheme.typography.bodySmall)
                    BotonSec({ ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://script.google.com/home/projects/create"))) }, Modifier.fillMaxWidth()) {
                        Text("🌐 Abrir script.google.com")
                    }
                }
                OutlinedTextField(
                    url, { url = it }, Modifier.fillMaxWidth(),
                    label = { Text("Link de la aplicación web (termina en /exec)") }, singleLine = true
                )
                BotonP({
                    val limpio = url.trim()
                    if (!limpio.startsWith("https://script.google.com/") || !limpio.contains("/exec")) {
                        Toast.makeText(ctx, "Ese link no es el de la aplicación web. Tiene que empezar con https://script.google.com/ y terminar en /exec", Toast.LENGTH_LONG).show()
                    } else {
                        Compu.guardarUrl(ctx, limpio)
                        conectado = true
                        enviar()
                    }
                }, Modifier.fillMaxWidth(), enabled = url.isNotBlank() && !enviando) { Text("Conectar") }
            } else {
                Text(
                    if (Compu.usaIncluido(ctx)) "✔ Conectado a la página de la empresa" else "✔ Conectado",
                    color = Verde, style = MaterialTheme.typography.bodyLarge
                )
                Text(
                    if (ultimo > 0) "Último envío: " + SimpleDateFormat("dd/MM HH:mm", Locale("es", "AR")).format(Date(ultimo))
                    else "Todavía no se mandó nada.",
                    style = MaterialTheme.typography.bodySmall
                )
                Text(
                    "Los datos se mandan solos cada vez que salís de la app. La ubicación se manda cada 2 minutos mientras el GPS del viaje está andando.",
                    style = MaterialTheme.typography.bodySmall
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(vivo, { vivo = it; Compu.guardarEnVivo(ctx, it) })
                    Text("  Mostrar mi ubicación en vivo durante los viajes", Modifier.weight(1f))
                }
                BotonP({
                    val i = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(
                            Intent.EXTRA_TEXT,
                            "Acá podés ver mis viajes, km, horas extras, gastos y dónde estoy (se actualiza solo):\n" + Compu.url(ctx)
                        )
                    }
                    ctx.startActivity(Intent.createChooser(i, "Mandar el link"))
                }, Modifier.fillMaxWidth()) { Text("📤 Mandar el link a quien lo tenga que ver") }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    BotonSec({ enviar() }, Modifier.weight(1f), enabled = !enviando) { Text(if (enviando) "Mandando…" else "🔄 Mandar ahora") }
                    BotonSec({ ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(Compu.url(ctx)))) }, Modifier.weight(1f)) { Text("👀 Ver cómo queda") }
                }
                // ---- Lugares compartidos
                Divider()
                Text("📍 Lugares compartidos", style = MaterialTheme.typography.titleSmall)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(admin, { admin = it; Compu.guardarAdminLugares(ctx, it) })
                    Text("  Yo cargo los lugares para todos (mis clientes, hoteles, etc. les aparecen a los demás choferes)", Modifier.weight(1f))
                }
                Text(
                    if (admin) "Tus lugares se suben solos cada vez que salís de la app." +
                        (if (horaLug.isNotBlank()) " Última vez: $horaLug." else "")
                    else "Los lugares que comparte el administrador se agregan solos a tus Lugares (no se borra nada tuyo)." +
                        (if (horaLug.isNotBlank()) " Última lista: $horaLug." else ""),
                    style = MaterialTheme.typography.bodySmall
                )
                BotonSec({
                    lugaresTrabajando = true
                    scope.launch {
                        val msg = if (admin) {
                            if (Compu.subirLugares(ctx)) "Listo: tus lugares ya están compartidos." else "No se pudo subir. Revisá internet."
                        } else {
                            val n = Compu.bajarLugares(ctx, forzar = true)
                            when {
                                n < 0 -> "No se pudo bajar. Revisá internet."
                                n == 0 -> "Ya tenés todos los lugares compartidos."
                                else -> "Se agregaron o corrigieron $n lugares."
                            }
                        }
                        horaLug = Compu.horaLugares(ctx)
                        lugaresTrabajando = false
                        Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
                    }
                }, Modifier.fillMaxWidth(), enabled = !lugaresTrabajando) {
                    Text(if (lugaresTrabajando) "Un momento…" else if (admin) "⬆️ Compartir mis lugares ahora" else "⬇️ Bajar los lugares compartidos ahora")
                }
                TextButton({ Compu.desconectar(ctx); url = ""; conectado = false }) {
                    Text("Desconectar", color = MaterialTheme.colorScheme.error)
                }
            }
        }
    }
}

private fun copiar(ctx: Context, texto: String) {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("Mi Control", texto))
}
