package com.micontrol.app.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.micontrol.app.data.Compu
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val PASOS = """1) En el celular abrí Chrome, tocá ⋮ y marcá "Sitio de escritorio". Entrá a script.google.com con tu cuenta de Google.
2) Tocá "Nuevo proyecto". Borrá lo que aparece escrito y pegá el código (tocá antes "📋 Copiar el código").
3) Tocá el disquete 💾 para guardar.
4) Arriba a la derecha: "Implementar" > "Nueva implementación" > en el engranaje elegí "Aplicación web". En "Quién tiene acceso" poné "Cualquier usuario". Tocá "Implementar" y aceptá los permisos (si dice "Google no verificó esta app": "Configuración avanzada" > "Ir a…", es tu propio código).
5) Copiá la "URL de la aplicación web" (termina en /exec) y pegala acá abajo."""

/** Ajustes > "Ver desde la computadora". */
@Composable
fun CompuGrupo() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var url by remember { mutableStateOf(Compu.url(ctx)) }
    var conectado by remember { mutableStateOf(Compu.activo(ctx)) }
    var vivo by remember { mutableStateOf(Compu.enVivo(ctx)) }
    var verPasos by remember { mutableStateOf(false) }
    var enviando by remember { mutableStateOf(false) }
    var ultimo by remember { mutableStateOf(Compu.ultimoEnvio(ctx)) }
    var admin by remember { mutableStateOf(Compu.adminLugares(ctx)) }
    var horaLug by remember { mutableStateOf(Compu.horaLugares(ctx)) }
    var lugaresTrabajando by remember { mutableStateOf(false) }

    fun enviar() {
        enviando = true
        scope.launch {
            val ok = Compu.enviarDatos(ctx)
            enviando = false
            ultimo = Compu.ultimoEnvio(ctx)
            Toast.makeText(
                ctx, if (ok) "Listo: los datos ya se ven en la computadora." else "No se pudo mandar. Revisá internet y el link.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("🖥️ Ver desde la computadora", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
            if (!conectado && Compu.incluido()) {
                BotonP({ Compu.guardarUrl(ctx, ""); url = Compu.url(ctx); conectado = true; enviar() }, Modifier.fillMaxWidth()) {
                    Text("Conectar a la página de la empresa")
                }
                Text("O, si querés usar una página propia, seguí los pasos de abajo.", style = MaterialTheme.typography.bodySmall)
            }
            if (!conectado) {
                Text(
                    "Otra persona (la empresa, un compañero) ve en la computadora dónde estás en vivo y tus viajes, km, horas extras y gastos " +
                        "cuando quiera. Es gratis: queda en una planilla de Google tuya. Se configura una sola vez.",
                    style = MaterialTheme.typography.bodyMedium
                )
                BotonP({ copiar(ctx, Compu.script(ctx)); Toast.makeText(ctx, "Código copiado", Toast.LENGTH_SHORT).show() }, Modifier.fillMaxWidth()) {
                    Text("📋 Copiar el código")
                }
                BotonSec({ verPasos = !verPasos }, Modifier.fillMaxWidth()) { Text(if (verPasos) "Ocultar los pasos" else "📖 Cómo se hace (5 pasos)") }
                if (verPasos) {
                    Text(PASOS, style = MaterialTheme.typography.bodySmall)
                    BotonSec({ ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://script.google.com/home/projects/create"))) }, Modifier.fillMaxWidth()) {
                        Text("🌐 Abrir script.google.com")
                    }
                }
                OutlinedTextField(
                    url, { url = it }, Modifier.fillMaxWidth(),
                    label = { Text("Link de la aplicación web (termina en /exec)") }, singleLine = true
                )
                BotonP({
                    val limpio = url.trim()
                    if (!limpio.startsWith("https://script.google.com/") || !limpio.contains("/exec")) {
                        Toast.makeText(ctx, "Ese link no es el de la aplicación web. Tiene que empezar con https://script.google.com/ y terminar en /exec", Toast.LENGTH_LONG).show()
                    } else {
                        Compu.guardarUrl(ctx, limpio)
                        conectado = true
                        enviar()
                    }
                }, Modifier.fillMaxWidth(), enabled = url.isNotBlank() && !enviando) { Text("Conectar") }
            } else {
                Text(
                    if (Compu.usaIncluido(ctx)) "✔ Conectado a la página de la empresa" else "✔ Conectado",
                    color = Verde, style = MaterialTheme.typography.bodyLarge
                )
                Text(
                    if (ultimo > 0) "Último envío: " + SimpleDateFormat("dd/MM HH:mm", Locale("es", "AR")).format(Date(ultimo))
                    else "Todavía no se mandó nada.",
                    style = MaterialTheme.typography.bodySmall
                )
                Text(
                    "Los datos se mandan solos cada vez que salís de la app. La ubicación se manda cada 2 minutos mientras el GPS del viaje está andando.",
                    style = MaterialTheme.typography.bodySmall
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(vivo, { vivo = it; Compu.guardarEnVivo(ctx, it) })
                    Text("  Mostrar mi ubicación en vivo durante los viajes", Modifier.weight(1f))
                }
                BotonP({
                    val i = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(
                            Intent.EXTRA_TEXT,
                            "Acá podés ver mis viajes, km, horas extras, gastos y dónde estoy (se actualiza solo):\n" + Compu.url(ctx)
                        )
                    }
                    ctx.startActivity(Intent.createChooser(i, "Mandar el link"))
                }, Modifier.fillMaxWidth()) { Text("📤 Mandar el link a quien lo tenga que ver") }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    BotonSec({ enviar() }, Modifier.weight(1f), enabled = !enviando) { Text(if (enviando) "Mandando…" else "🔄 Mandar ahora") }
                    BotonSec({ ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(Compu.url(ctx)))) }, Modifier.weight(1f)) { Text("👀 Ver cómo queda") }
                }
                // ---- Lugares compartidos
                Divider()
                Text("📍 Lugares compartidos", style = MaterialTheme.typography.titleSmall)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(admin, { admin = it; Compu.guardarAdminLugares(ctx, it) })
                    Text("  Yo cargo los lugares para todos (mis clientes, hoteles, etc. les aparecen a los demás choferes)", Modifier.weight(1f))
                }
                Text(
                    if (admin) "Tus lugares se suben solos cada vez que salís de la app." +
                        (if (horaLug.isNotBlank()) " Última vez: $horaLug." else "")
                    else "Los lugares que comparte el administrador se agregan solos a tus Lugares (no se borra nada tuyo)." +
                        (if (horaLug.isNotBlank()) " Última lista: $horaLug." else ""),
                    style = MaterialTheme.typography.bodySmall
                )
                BotonSec({
                    lugaresTrabajando = true
                    scope.launch {
                        val msg = if (admin) {
                            if (Compu.subirLugares(ctx)) "Listo: tus lugares ya están compartidos." else "No se pudo subir. Revisá internet."
                        } else {
                            val n = Compu.bajarLugares(ctx, forzar = true)
                            when {
                                n < 0 -> "No se pudo bajar. Revisá internet."
                                n == 0 -> "Ya tenés todos los lugares compartidos."
                                else -> "Se agregaron o corrigieron $n lugares."
                            }
                        }
                        horaLug = Compu.horaLugares(ctx)
                        lugaresTrabajando = false
                        Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
                    }
                }, Modifier.fillMaxWidth(), enabled = !lugaresTrabajando) {
                    Text(if (lugaresTrabajando) "Un momento…" else if (admin) "⬆️ Compartir mis lugares ahora" else "⬇️ Bajar los lugares compartidos ahora")
                }
                TextButton({ Compu.desconectar(ctx); url = ""; conectado = false }) {
                    Text("Desconectar", color = MaterialTheme.colorScheme.error)
                }
            }
        }
    }
}

private fun copiar(ctx: Context, texto: String) {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("Mi Control", texto))
}

/** Ajustes > Administración: este celular, la clave del dueño y los celulares autorizados. */
@Composable
fun AdminGrupo() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var estado by remember { mutableStateOf(Compu.estadoCelular(ctx)) }
    var admin by remember { mutableStateOf(Compu.soyAdmin(ctx)) }
    var hayAdmin by remember { mutableStateOf(Compu.hayAdmin(ctx)) }
    var pidiendoClave by remember { mutableStateOf(false) }
    var lista by remember { mutableStateOf<List<org.json.JSONObject>>(emptyList()) }
    var trabajando by remember { mutableStateOf(false) }

    fun refrescar() {
        trabajando = true
        scope.launch {
            Compu.consultarEstado(ctx)
            estado = Compu.estadoCelular(ctx); admin = Compu.soyAdmin(ctx); hayAdmin = Compu.hayAdmin(ctx)
            if (admin) {
                val r = Compu.dispositivos(ctx)
                val a = r?.optJSONArray("dispositivos")
                lista = if (a == null) emptyList() else (0 until a.length()).map { a.getJSONObject(it) }
            }
            trabajando = false
        }
    }
    LaunchedEffect(Unit) { if (Compu.activo(ctx)) refrescar() }
    if (!Compu.activo(ctx)) return

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("👑 Administración y celulares", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
            Text(
                when {
                    admin -> "✔ Este celular es el ADMINISTRADOR."
                    estado == "autorizado" -> "✔ Este celular está autorizado (chofer)."
                    estado == "pendiente" -> "⏳ Este celular está esperando que el administrador lo autorice. Hasta entonces no se manda nada."
                    estado == "revocado" -> "⛔ El administrador quitó el permiso a este celular."
                    else -> "Sin datos todavía (hace falta internet)."
                },
                color = if (admin || estado == "autorizado") Verde else Ambar
            )
            if (!hayAdmin) Text(
                "Todavía no hay administrador: cualquier celular conectado puede mandar datos. El dueño tiene que crear su clave de administrador.",
                style = MaterialTheme.typography.bodySmall
            )
            if (!admin) BotonSec({ pidiendoClave = true }, Modifier.fillMaxWidth()) {
                Text(if (hayAdmin) "🔑 Soy el dueño (entrar con mi clave)" else "🔑 Soy el dueño: crear la clave de administrador")
            }
            if (admin) {
                Text("Celulares", style = MaterialTheme.typography.titleSmall)
                lista.forEach { d ->
                    val id = d.optString("id")
                    val est = d.optString("estado")
                    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                        Column(Modifier.padding(10.dp)) {
                            Text(
                                d.optString("nombre").ifBlank { "Celular" } + (if (d.optBoolean("yo")) " (este)" else "") + (if (d.optBoolean("admin")) " 👑" else ""),
                                style = MaterialTheme.typography.bodyLarge
                            )
                            Text(
                                when (est) { "autorizado" -> "✔ Autorizado"; "pendiente" -> "⏳ Pide permiso"; "revocado" -> "⛔ Sin permiso"; else -> est } +
                                    " · visto: " + d.optString("visto").take(10),
                                style = MaterialTheme.typography.bodySmall
                            )
                            if (!d.optBoolean("yo")) Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                if (est != "autorizado") BotonP({
                                    scope.launch { Compu.dispositivos(ctx, id, "autorizado"); refrescar() }
                                }, Modifier.weight(1f)) { Text("Autorizar", maxLines = 1) }
                                if (est != "revocado") BotonSec({
                                    scope.launch { Compu.dispositivos(ctx, id, "revocado"); refrescar() }
                                }, Modifier.weight(1f)) { Text("Quitar permiso", maxLines = 1) }
                            }
                        }
                    }
                }
            }
            BotonSec({ refrescar() }, Modifier.fillMaxWidth(), enabled = !trabajando) { Text(if (trabajando) "Consultando…" else "🔄 Actualizar") }
        }
    }

    if (pidiendoClave) {
        var clave by remember { mutableStateOf("") }
        var clave2 by remember { mutableStateOf("") }
        var error by remember { mutableStateOf<String?>(null) }
        val crear = !hayAdmin
        AlertDialog(
            onDismissRequest = { pidiendoClave = false },
            title = { Text(if (crear) "Crear clave de administrador" else "Clave de administrador") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        if (crear) "Elegí una clave de al menos 6 caracteres y anotala en un lugar seguro: con ella recuperás la administración si cambiás de celular. No se guarda en la app ni en el código."
                        else "Escribí tu clave de administrador. Sirve también para recuperar la administración en un celular nuevo.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    OutlinedTextField(clave, { clave = it }, Modifier.fillMaxWidth(), label = { Text("Clave") }, singleLine = true,
                        visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation())
                    if (crear) OutlinedTextField(clave2, { clave2 = it }, Modifier.fillMaxWidth(), label = { Text("Repetí la clave") }, singleLine = true,
                        visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation())
                    error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                }
            },
            confirmButton = {
                TextButton({
                    if (clave.length < 6) { error = "Tiene que tener al menos 6 caracteres."; return@TextButton }
                    if (crear && clave != clave2) { error = "Las dos claves no son iguales."; return@TextButton }
                    scope.launch {
                        val r = Compu.reclamarAdmin(ctx, clave)
                        if (r == null) error = "Sin conexión. Probá con internet."
                        else if (!r.optBoolean("ok")) error = r.optString("error", "No se pudo.")
                        else { pidiendoClave = false; Toast.makeText(ctx, "Listo: este celular es el administrador.", Toast.LENGTH_LONG).show(); refrescar() }
                    }
                }) { Text("Aceptar") }
            },
            dismissButton = { TextButton({ pidiendoClave = false }) { Text("Cancelar") } }
        )
    }
}
