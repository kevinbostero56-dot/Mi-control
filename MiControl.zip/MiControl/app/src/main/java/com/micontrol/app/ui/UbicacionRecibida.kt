package com.micontrol.app.ui

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.micontrol.app.data.Cliente
import com.micontrol.app.data.Viaje

/** Aparece cuando compartís una ubicación (desde WhatsApp o Google Maps) hacia Mi Control. */
@Composable
fun UbicacionRecibidaDialog(vm: MainViewModel) {
    val ctx = LocalContext.current
    val recibida by vm.recibida.collectAsStateWithLifecycle()
    val viajes by vm.viajes.collectAsStateWithLifecycle()
    val clientes by vm.clientes.collectAsStateWithLifecycle()
    val rec = recibida ?: return
    val p = rec.punto
    val activo = viajes.firstOrNull { it.estado == Viaje.Estado.EN_CURSO }
    var nombre by remember(p) { mutableStateOf(p?.nombre?.split(",")?.firstOrNull()?.trim() ?: "") }
    val coords = p?.let { "%.5f, %.5f".format(it.lat, it.lng) } ?: ""
    val etiqueta = nombre.ifBlank { p?.nombre ?: coords }

    AlertDialog(
        onDismissRequest = { vm.descartarRecibida() },
        title = { Text("Ubicación recibida") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                when {
                    rec.cargando -> {
                        CircularProgressIndicator()
                        Text("Leyendo la ubicación…")
                    }
                    p == null -> Text(
                        "No pude encontrar una ubicación en lo que compartiste. " +
                            "Probá copiar el link y usar \"Pegar ubicación\" al elegir un lugar en el mapa."
                    )
                    else -> {
                        Text(p.nombre ?: coords)
                        Text(coords, style = MaterialTheme.typography.bodySmall)
                        OutlinedTextField(
                            nombre, { nombre = it }, Modifier.fillMaxWidth(),
                            label = { Text("Nombre del cliente o lugar") }, singleLine = true
                        )
                        BotonP({
                            if (clientes.any { it.nombre.equals(nombre.trim(), ignoreCase = true) }) {
                                Toast.makeText(ctx, "Ya hay un cliente con ese nombre.", Toast.LENGTH_LONG).show()
                            } else {
                                vm.guardarCliente(Cliente(nombre = nombre.trim(), direccion = p.nombre, lat = p.lat, lng = p.lng))
                                Toast.makeText(ctx, "Guardado en Clientes", Toast.LENGTH_LONG).show()
                                vm.descartarRecibida()
                            }
                        }, Modifier.fillMaxWidth(), enabled = nombre.isNotBlank()) { Text("Guardar como cliente") }
                        if (activo != null) {
                            BotonSec({
                                vm.paradaAlFinal(activo.id, etiqueta, p.lat, p.lng)
                                Toast.makeText(ctx, "Parada agregada al viaje en curso", Toast.LENGTH_LONG).show()
                                vm.descartarRecibida()
                            }, Modifier.fillMaxWidth()) { Text("Agregar como parada del viaje") }
                            BotonSec({
                                vm.actualizarViaje(activo.copy(destino = etiqueta, destinoLat = p.lat, destinoLng = p.lng))
                                Toast.makeText(ctx, "Destino del viaje actualizado", Toast.LENGTH_LONG).show()
                                vm.descartarRecibida()
                            }, Modifier.fillMaxWidth()) { Text("Usar como destino del viaje") }
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton({ vm.descartarRecibida() }) { Text("Cerrar") } }
    )
}
