package com.micontrol.app.ui

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.micontrol.app.data.Cliente
import com.micontrol.app.data.Viaje
import org.osmdroid.util.GeoPoint

/** Aparece cuando compartís una ubicación (desde WhatsApp o Google Maps) hacia Mi Control. */
@Composable
fun UbicacionRecibidaDialog(vm: MainViewModel) {
    val ctx = LocalContext.current
    val recibida by vm.recibida.collectAsStateWithLifecycle()
    val viajes by vm.viajes.collectAsStateWithLifecycle()
    val clientes by vm.clientes.collectAsStateWithLifecycle()
    val rec = recibida ?: return
    val p = rec.punto
    val activo = viajes.firstOrNull { it.estado == Viaje.Estado.EN_CURSO }

    var nombre by remember(p) {
        mutableStateOf(p?.nombre ?: p?.direccion?.split(",")?.firstOrNull()?.trim() ?: "")
    }
    // Punto que se va a guardar (puede ajustarse a mano en el mapa)
    var latU by remember(p) { mutableStateOf(p?.lat) }
    var lngU by remember(p) { mutableStateOf(p?.lng) }
    var dirU by remember(p) { mutableStateOf(p?.direccion) }
    var ajustada by remember(p) { mutableStateOf(p?.aproximada != true) }
    var ajustando by remember(p) { mutableStateOf(p?.aproximada == true) }
    var tocada by remember(p) { mutableStateOf(false) }

    val lat = latU ?: p?.lat ?: 0.0
    val lng = lngU ?: p?.lng ?: 0.0
    val coords = "%.7f, %.7f".format(java.util.Locale.US, lat, lng)
    val etiqueta = nombre.ifBlank { dirU ?: coords }

    if (ajustando && p != null) {
        SelectorUbicacion(
            "Ajustá el punto exacto", onDismiss = { ajustando = false },
            inicial = GeoPoint(lat, lng), textoInicial = dirU ?: "", zoomInicial = if (p.zona) 14.0 else 18.0
        ) { txt, la, lo ->
            latU = la; lngU = lo; dirU = txt; ajustada = true; tocada = true; ajustando = false
        }
    }

    AlertDialog(
        onDismissRequest = { vm.descartarRecibida() },
        title = { Text("Ubicación recibida") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                when {
                    rec.cargando -> {
                        CircularProgressIndicator()
                        Text("Buscando el pin exacto en Google Maps… (puede tardar unos segundos)")
                    }
                    p == null -> {
                        Text(
                            "No pude encontrar una ubicación en lo que compartiste. " +
                                "Probá copiar el link y usar \"Pegar ubicación\" al elegir un lugar en el mapa."
                        )
                        Text("Recibí esto:", style = MaterialTheme.typography.labelMedium)
                        Text(rec.texto.take(300), style = MaterialTheme.typography.bodySmall)
                    }
                    else -> {
                        MapaOsm(
                            Modifier.fillMaxWidth().height(170.dp),
                            listOf(GeoPoint(lat, lng) to "Ubicación recibida"),
                            emptyList(),
                            Centro(GeoPoint(lat, lng), if (ajustada) 1 else 0, if (p.zona && !ajustada) 13.0 else 17.0)
                        )
                        if (p.aproximada && !ajustada) {
                            Text(
                                if (p.zona) {
                                    "Solo encontré la ZONA (la localidad), no la dirección exacta. Ubicá el punto a mano en el mapa; el satélite te ayuda."
                                } else {
                                    "Ubicación APROXIMADA: la busqué por la dirección y puede estar a varias cuadras. Ajustala en el mapa antes de guardarla."
                                },
                                color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium
                            )
                            p.consulta?.let { Text("Dirección que te mandaron: $it", style = MaterialTheme.typography.bodySmall) }
                            Text(
                                "Para que sea exacta: abrila en Google Maps, mantené apretado el punto y compartila a Mi Control " +
                                    "(o copiá las coordenadas y pegalas).",
                                style = MaterialTheme.typography.bodySmall
                            )
                        } else {
                            Text(
                                if (tocada || p.manual) "✔ Ubicación ajustada a mano."
                                else "✔ " + p.fuente.ifBlank { "Ubicación exacta" },
                                color = Verde, style = MaterialTheme.typography.bodyMedium
                            )
                            if (p.vista && !tocada) {
                                Text(
                                    "Son las coordenadas del centro del mapa del link y pueden diferir unos metros del pin de Google. " +
                                        "Tocá \"Comparar en Google Maps\" y, si no coincide, ajustala.",
                                    color = Ambar, style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                        dirU?.let { Text(it, style = MaterialTheme.typography.bodyMedium) }

                        // Con el pin exacto de Google no hace falta comparar ni ajustar: se guarda directo
                        val dudosa = p.aproximada || p.vista
                        if (dudosa) {
                            BotonSec({ abrirEnGoogleMaps(ctx, lat, lng) }, Modifier.fillMaxWidth()) { Text("Comparar en Google Maps") }
                        }
                        if (p.aproximada && !ajustada) {
                            BotonP({ ajustando = true }, Modifier.fillMaxWidth()) { Text("Ajustar el punto exacto en el mapa") }
                        } else if (dudosa) {
                            BotonSec({ ajustando = true }, Modifier.fillMaxWidth()) { Text("Ajustar el punto en el mapa") }
                        }

                        OutlinedTextField(
                            nombre, { nombre = it }, Modifier.fillMaxWidth(),
                            label = { Text("Nombre del cliente o lugar") }, singleLine = true
                        )
                        BotonP({
                            if (clientes.any { it.nombre.equals(nombre.trim(), ignoreCase = true) }) {
                                Toast.makeText(ctx, "Ya hay un cliente con ese nombre.", Toast.LENGTH_LONG).show()
                            } else {
                                vm.guardarCliente(Cliente(nombre = nombre.trim(), direccion = dirU ?: p.nombre, lat = lat, lng = lng))
                                Toast.makeText(ctx, "Guardado en Clientes", Toast.LENGTH_LONG).show()
                                vm.descartarRecibida()
                            }
                        }, Modifier.fillMaxWidth(), enabled = nombre.isNotBlank() && ajustada) { Text("Guardar como cliente") }
                        if (activo != null) {
                            BotonSec({
                                vm.paradaAlFinal(activo.id, etiqueta, lat, lng)
                                Toast.makeText(ctx, "Parada agregada al viaje en curso", Toast.LENGTH_LONG).show()
                                vm.descartarRecibida()
                            }, Modifier.fillMaxWidth(), enabled = ajustada) { Text("Agregar como parada del viaje") }
                            BotonSec({
                                vm.actualizarViaje(activo.copy(destino = etiqueta, destinoLat = lat, destinoLng = lng))
                                Toast.makeText(ctx, "Destino del viaje actualizado", Toast.LENGTH_LONG).show()
                                vm.descartarRecibida()
                            }, Modifier.fillMaxWidth(), enabled = ajustada) { Text("Usar como destino del viaje") }
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton({ vm.descartarRecibida() }) { Text("Cerrar") } }
    )
}
