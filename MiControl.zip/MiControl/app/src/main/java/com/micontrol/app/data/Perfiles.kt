package com.micontrol.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * Perfiles de la app: cada persona tiene el suyo en el mismo teléfono, con sus propios viajes, gastos,
 * horas y clientes (cada perfil usa su propia base de datos). El perfil "principal" conserva los datos de siempre.
 */
object Perfiles {
    const val PRINCIPAL = "principal"

    data class Perfil(val id: String, val nombre: String, val camion: String = "", val empresa: String = "") {
        val inicial: String get() = nombre.trim().firstOrNull()?.uppercaseChar()?.toString() ?: "?"
    }

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("perfiles", Context.MODE_PRIVATE)

    fun todos(ctx: Context): List<Perfil> {
        val txt = prefs(ctx).getString("lista", null)
        val lista = if (txt == null) emptyList() else runCatching {
            val a = JSONArray(txt)
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                Perfil(o.getString("id"), o.getString("nombre"), o.optString("camion"), o.optString("empresa"))
            }
        }.getOrDefault(emptyList())
        return lista.ifEmpty { listOf(Perfil(PRINCIPAL, "Mi perfil")) }
    }

    private fun guardar(ctx: Context, lista: List<Perfil>) {
        val a = JSONArray()
        lista.forEach {
            a.put(JSONObject().put("id", it.id).put("nombre", it.nombre).put("camion", it.camion).put("empresa", it.empresa))
        }
        prefs(ctx).edit().putString("lista", a.toString()).apply()
    }

    fun activo(ctx: Context): Perfil {
        val lista = todos(ctx)
        val id = prefs(ctx).getString("activo", null)
        return lista.firstOrNull { it.id == id } ?: lista.first()
    }

    fun activoId(ctx: Context): String = activo(ctx).id

    fun activar(ctx: Context, id: String) {
        prefs(ctx).edit().putString("activo", id).apply()
    }

    fun crear(ctx: Context, nombre: String, camion: String, empresa: String): Perfil {
        val nuevo = Perfil(UUID.randomUUID().toString().take(8), nombre, camion, empresa)
        guardar(ctx, todos(ctx) + nuevo)
        return nuevo
    }

    fun actualizar(ctx: Context, p: Perfil) {
        guardar(ctx, todos(ctx).map { if (it.id == p.id) p else it })
    }

    /** Borra el perfil y todos sus datos. No deja borrar el último. */
    fun eliminar(ctx: Context, id: String): Boolean {
        val lista = todos(ctx)
        if (lista.size <= 1 || lista.none { it.id == id }) return false
        val resto = lista.filter { it.id != id }
        guardar(ctx, resto)
        AppDatabase.borrar(ctx, id)
        if (prefs(ctx).getString("activo", null) == id) activar(ctx, resto.first().id)
        return true
    }
}
