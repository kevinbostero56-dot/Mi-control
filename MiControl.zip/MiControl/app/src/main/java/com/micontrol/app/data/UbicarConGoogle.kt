package com.micontrol.app.data

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume

/**
 * Abre el link de un lugar guardado de Google Maps en un navegador oculto (el mismo que usaría el teléfono) y espera a
 * que Google lo lleve a la dirección con las coordenadas del pin. No usa ninguna API paga ni clave.
 * Si Google no entrega el punto en unos segundos, devuelve null y el lugar queda sin ubicación (no se inventa nada).
 */
object UbicarConGoogle {
    private const val UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"

    @SuppressLint("SetJavaScriptEnabled")
    suspend fun resolver(ctx: Context, url: String, esperaMs: Long = 15000L): Pair<Double, Double>? =
        withContext(Dispatchers.Main) {
            suspendCancellableCoroutine { cont ->
                val handler = Handler(Looper.getMainLooper())
                val wv = try { WebView(ctx.applicationContext) } catch (e: Exception) { null }
                if (wv == null) { cont.resume(null); return@suspendCancellableCoroutine }
                var terminado = false
                fun fin(r: Pair<Double, Double>?) {
                    if (terminado) return
                    terminado = true
                    handler.removeCallbacksAndMessages(null)
                    try { wv.stopLoading(); wv.destroy() } catch (e: Exception) { /* nada */ }
                    if (cont.isActive) cont.resume(r)
                }
                wv.settings.javaScriptEnabled = true
                wv.settings.domStorageEnabled = true
                wv.settings.userAgentString = UA
                wv.settings.cacheMode = WebSettings.LOAD_DEFAULT
                wv.webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                        val u = request?.url?.toString() ?: return false
                        return !u.startsWith("http")   // no dejar que abra la app de Maps ni otros esquemas
                    }
                }
                val inicio = System.currentTimeMillis()
                val sondeo = object : Runnable {
                    override fun run() {
                        if (terminado) return
                        val actual = try { wv.url } catch (e: Exception) { null }
                        val pin = actual?.let { UbicacionLink.coordenadasDirectas(it) }
                        if (pin != null) { fin(pin); return }
                        if (System.currentTimeMillis() - inicio > esperaMs) { fin(null); return }
                        handler.postDelayed(this, 400)
                    }
                }
                cont.invokeOnCancellation { handler.post { fin(null) } }
                try {
                    wv.loadUrl(url)
                    handler.postDelayed(sondeo, 1000)
                } catch (e: Exception) {
                    fin(null)
                }
            }
        }
}
