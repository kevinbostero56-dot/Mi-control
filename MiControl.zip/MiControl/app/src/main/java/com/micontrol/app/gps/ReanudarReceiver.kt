package com.micontrol.app.gps

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.micontrol.app.ui.MainActivity

/**
 * Después de actualizar Mi Control o reiniciar el teléfono, el GPS del viaje se corta.
 * Si había un viaje registrándose, avisa con una notificación: al tocarla se abre la app
 * y el GPS se vuelve a prender solo (ver MainViewModel.reanudarGps).
 */
class ReanudarReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent?) {
        val accion = intent?.action ?: return
        if (accion != Intent.ACTION_BOOT_COMPLETED && accion != Intent.ACTION_MY_PACKAGE_REPLACED) return
        if (Gps.viajeQueSeguia(ctx) == null) return
        if (!Gps.tienePermiso(ctx)) return

        // Android no deja prender el GPS desde acá sin la app abierta: se avisa y al tocar se prende solo
        try {
            if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) return
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(CANAL, "Viaje en curso", NotificationManager.IMPORTANCE_HIGH))
            val abrir = PendingIntent.getActivity(
                ctx, 3, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val notif = NotificationCompat.Builder(ctx, CANAL)
                .setContentTitle("🚛 Tenés un viaje en curso")
                .setContentText("Tocá para seguir registrando el recorrido y mandando tu ubicación.")
                .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .setContentIntent(abrir)
                .setAutoCancel(true)
                .build()
            nm.notify(3, notif)
        } catch (e: Exception) { /* sin aviso */ }
    }

    companion object {
        private const val CANAL = "viaje_en_curso"
    }
}
