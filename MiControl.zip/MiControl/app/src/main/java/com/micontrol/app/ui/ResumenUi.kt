package com.micontrol.app.ui

import android.content.Intent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import android.widget.Toast
import com.micontrol.app.data.CATEGORIAS_GASTO
import com.micontrol.app.data.Exportar
import com.micontrol.app.data.Viaje
import com.micontrol.app.domain.Calculos
import java.time.Instant
import java.time.YearMonth
import java.time.ZoneId
import java.time.format.TextStyle
import java.util.Locale
import kotlin.math.abs

private fun mesDe(ms: Long): YearMonth = YearMonth.from(Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()))

/** Resumen del mes: viajes, kilómetros, horas extras, gastos por tipo, consumo y saldo con la empresa. */
@Composable
fun ResumenScreen(vm: MainViewModel, nav: NavController) {
    val ctx = LocalContext.current
    val ar = Locale("es", "AR")
    val viajes by vm.viajes.collectAsStateWithLifecycle()
    val jornadas by vm.todasJornadas.collectAsStateWithLifecycle()
    val gastos by vm.todosGastos.collectAsStateWithLifecycle()
    val adelantos by vm.todosAdelantos.collectAsStateWithLifecycle()
    val perfil by vm.perfil.collectAsStateWithLifecycle()
    var mes by remember { mutableStateOf(YearMonth.now()) }

    val viajesMes = viajes.filter { mesDe(it.inicio) == mes }
    val terminados = viajesMes.filter { it.estado == Viaje.Estado.FINALIZADO }
    val kmTotal = terminados.sumOf { Calculos.kmDecimas(it) ?: 0L }
    val jornadasMes = jornadas.filter { it.fecha.startsWith(mes.toString()) }
    val extras = Calculos.extrasTotales(jornadasMes)
    val trabajados = jornadasMes.sumOf { Calculos.minutosTrabajados(it) }
    val gastosMes = gastos.filter { mesDe(it.fechaHora) == mes }
    val totalGastos = gastosMes.sumOf { it.importeCentavos }
    val recibido = adelantos.filter { mesDe(it.fechaHora) == mes }.sumOf { it.importeCentavos }
    val saldo = recibido - totalGastos

    // Consumo: solo viajes terminados del mes que tengan litros y kilómetros
    var litros = 0.0
    var kmConLitros = 0.0
    terminados.forEach { v ->
        val km = (Calculos.kmDecimas(v) ?: 0L) / 10.0
        val l = gastos.filter { it.viajeId == v.id && it.categoria == "Combustible" }.sumOf { it.litros ?: 0.0 }
        if (km > 0 && l > 0.0) { litros += l; kmConLitros += km }
    }
    val lPor100 = if (kmConLitros > 0) litros / kmConLitros * 100.0 else null

    val titulo = mes.month.getDisplayName(TextStyle.FULL, ar).replaceFirstChar { it.uppercase() } + " " + mes.year

    fun texto(): String = buildString {
        appendLine("Mi Control — Resumen de $titulo (${perfil.nombre})")
        appendLine("Viajes: ${viajesMes.size} (terminados: ${terminados.size})")
        appendLine("Kilómetros (odómetro): ${Calculos.decimasTxt(kmTotal)} km")
        appendLine("Horas trabajadas: ${Calculos.hhmm(trabajados)} h · extras: ${Calculos.hhmm(extras)} h")
        appendLine("Gastos: ${Calculos.pesos(totalGastos)}")
        CATEGORIAS_GASTO.forEach { c ->
            val t = gastosMes.filter { it.categoria == c }.sumOf { it.importeCentavos }
            if (t > 0) appendLine("  - $c: ${Calculos.pesos(t)}")
        }
        if (lPor100 != null) appendLine("Consumo: ${"%.1f".format(ar, lPor100)} L cada 100 km (${"%.0f".format(ar, litros)} L)")
        appendLine("Plata recibida de la empresa: ${Calculos.pesos(recibido)}")
        append(
            when {
                saldo > 0 -> "A devolver a la empresa: ${Calculos.pesos(saldo)}"
                saldo < 0 -> "La empresa te debe: ${Calculos.pesos(abs(saldo))}"
                else -> "Estás a mano con la empresa"
            }
        )
    }

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Resumen del mes", style = MaterialTheme.typography.headlineSmall)
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton({ mes = mes.minusMonths(1) }) { Text("◀") }
            Text(titulo, Modifier.weight(1f), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            TextButton({ mes = mes.plusMonths(1) }, enabled = mes < YearMonth.now()) { Text("▶") }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Fila("Viajes", "${viajesMes.size} (terminados: ${terminados.size})")
                Fila("Kilómetros (odómetro)", "${Calculos.decimasTxt(kmTotal)} km")
                Fila("Horas trabajadas", Calculos.hhmm(trabajados) + " h")
                Fila("Horas extras", Calculos.hhmm(extras) + " h")
            }
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Gastos", style = MaterialTheme.typography.titleMedium)
                CATEGORIAS_GASTO.forEach { c ->
                    val t = gastosMes.filter { it.categoria == c }.sumOf { it.importeCentavos }
                    if (t > 0) Fila(c, Calculos.pesos(t))
                }
                if (gastosMes.isEmpty()) Text("Sin gastos este mes.", style = MaterialTheme.typography.bodySmall)
                Divider(Modifier.padding(vertical = 4.dp))
                Fila("Total", Calculos.pesos(totalGastos), negrita = true)
            }
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Combustible", style = MaterialTheme.typography.titleMedium)
                if (lPor100 != null) {
                    Text("${"%.1f".format(ar, lPor100)} L cada 100 km", style = MaterialTheme.typography.headlineSmall, color = Verde)
                    Text("${"%.0f".format(ar, litros)} L en ${"%.0f".format(ar, kmConLitros)} km (viajes terminados con litros cargados)", style = MaterialTheme.typography.bodySmall)
                } else {
                    Text("Para ver el consumo, cargá los litros de cada carga y terminá el viaje.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Rendición con la empresa", style = MaterialTheme.typography.titleMedium)
                Fila("Plata recibida", Calculos.pesos(recibido))
                Fila("Gastos", Calculos.pesos(totalGastos))
                Divider(Modifier.padding(vertical = 4.dp))
                Text(
                    when {
                        saldo > 0 -> "A devolver a la empresa: ${Calculos.pesos(saldo)}"
                        saldo < 0 -> "La empresa te debe: ${Calculos.pesos(abs(saldo))}"
                        else -> "Estás a mano"
                    },
                    fontWeight = FontWeight.Bold,
                    color = when { saldo > 0 -> Ambar; saldo < 0 -> Verde; else -> MaterialTheme.colorScheme.onSurfaceVariant }
                )
            }
        }
        BotonP({
            val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, texto()) }
            ctx.startActivity(Intent.createChooser(i, "Compartir resumen").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }, Modifier.fillMaxWidth().height(52.dp)) { Text("📤 Compartir resumen") }
        Text("Para Excel o planillas:", style = MaterialTheme.typography.bodySmall)
        BotonSec({
            try { Exportar.compartir(ctx, Exportar.gastos(ctx, titulo, gastosMes, viajes)) }
            catch (e: Exception) { Toast.makeText(ctx, "No se pudo armar la planilla.", Toast.LENGTH_LONG).show() }
        }, Modifier.fillMaxWidth()) { Text("📄 Gastos del mes (Excel)") }
        BotonSec({
            try { Exportar.compartir(ctx, Exportar.viajes(ctx, titulo, viajesMes, gastos)) }
            catch (e: Exception) { Toast.makeText(ctx, "No se pudo armar la planilla.", Toast.LENGTH_LONG).show() }
        }, Modifier.fillMaxWidth()) { Text("📄 Viajes del mes (Excel)") }
        TextButton({ nav.popBackStack() }) { Text("Volver") }
    }
}

@Composable
private fun Fila(etiqueta: String, valor: String, negrita: Boolean = false) {
    Row {
        Text(etiqueta, Modifier.weight(1f))
        Text(valor, fontWeight = if (negrita) FontWeight.ExtraBold else FontWeight.Bold)
    }
}
