package com.micontrol.app.ui

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.sp
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null) recibir(intent)
        if (savedInstanceState == null) vm.buscarActualizacion(false)
        setContent { MiControlTheme { AppNav(vm) } }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        recibir(intent)
    }

    /** Ubicación compartida desde WhatsApp o Google Maps (Compartir > Mi Control). */
    private fun recibir(i: Intent?) {
        val texto = when (i?.action) {
            Intent.ACTION_SEND -> i?.getStringExtra(Intent.EXTRA_TEXT)
            Intent.ACTION_VIEW -> i?.dataString
            else -> null
        }
        if (!texto.isNullOrBlank()) vm.recibirUbicacion(texto)
    }
}

@Composable
fun AppNav(vm: MainViewModel) {
    val nav = rememberNavController()
    val entrada by nav.currentBackStackEntryAsState()
    val ruta = entrada?.destination?.route
    val pestanas = listOf(
        Triple("home", "🏠", "Inicio"),
        Triple("historial", "🚛", "Viajes"),
        Triple("clientes", "👥", "Clientes"),
        Triple("ajustes", "⚙️", "Ajustes")
    )
    Scaffold(bottomBar = {
        if (pestanas.any { it.first == ruta }) {
            NavigationBar {
                pestanas.forEach { (destino, emoji, nombre) ->
                    NavigationBarItem(
                        selected = ruta == destino,
                        onClick = {
                            if (ruta != destino) nav.navigate(destino) {
                                popUpTo("home")
                                launchSingleTop = true
                            }
                        },
                        icon = { Text(emoji, fontSize = 22.sp) },
                        label = { Text(nombre) }
                    )
                }
            }
        }
    }) { padding ->
        NavHost(nav, startDestination = "home", modifier = Modifier.padding(padding)) {
            composable("home") { HomeScreen(vm, nav) }
            composable("nuevo") { NuevoViajeScreen(vm, nav) }
            composable("historial") { HistorialScreen(vm, nav) }
            composable("clientes") { ClientesScreen(vm, nav) }
            composable("ajustes") { AjustesScreen(vm, nav) }
            composable("viaje/{id}", listOf(navArgument("id") { type = NavType.StringType })) {
                DetalleViajeScreen(vm, nav, it.arguments!!.getString("id")!!)
            }
        }
        UbicacionRecibidaDialog(vm)
        ActualizacionDialog(vm)
    }
}
