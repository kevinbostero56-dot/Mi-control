package com.micontrol.app.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import androidx.core.content.ContextCompat
import com.micontrol.app.R
import com.micontrol.app.data.Ajustes
import com.micontrol.app.work.Tareas

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()
    private var salioA = 0L
    private val pedirNotificaciones = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null) recibir(intent)
        if (savedInstanceState == null) vm.buscarActualizacion(false)
        if (savedInstanceState == null) {
            Tareas.programar(this)
            vm.tareasAlAbrir()
            if (Build.VERSION.SDK_INT >= 33 && !Ajustes.notifPedido(this) &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                Ajustes.marcarNotifPedido(this)
                pedirNotificaciones.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
        setContent {
            MiControlTheme {
                val bloqueado by vm.bloqueado.collectAsStateWithLifecycle()
                Box(Modifier.fillMaxSize()) {
                    AppNav(vm)
                    if (bloqueado) BloqueoPantalla { vm.bloqueado.value = false }
                }
            }
        }
    }

    override fun onStop() {
        super.onStop()
        salioA = SystemClock.elapsedRealtime()
    }

    override fun onStart() {
        super.onStart()
        // Si estuvo más de un minuto fuera de la app, vuelve a pedir el PIN
        if (Ajustes.hayPin(this) && salioA > 0 && SystemClock.elapsedRealtime() - salioA > 60_000L) vm.bloqueado.value = true
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        recibir(intent)
    }

    /** Ubicación compartida desde WhatsApp o Google Maps (Compartir > Mi Control). */
    private fun recibir(i: Intent?) {
        val texto = when (i?.action) {
            Intent.ACTION_SEND -> i?.getCharSequenceExtra(Intent.EXTRA_TEXT)?.toString()
            Intent.ACTION_VIEW -> i?.dataString
            else -> null
        }
        if (!texto.isNullOrBlank()) vm.recibirUbicacion(texto)
    }
}

private class Pestana(val ruta: String, val nombre: String, val gris: Int, val roja: Int)

@Composable
private fun BarraInferior(ruta: String?, onIr: (String) -> Unit) {
    val pestanas = listOf(
        Pestana("home", "Inicio", R.drawable.nav_casa_gris, R.drawable.nav_casa_roja),
        Pestana("historial", "Viajes", R.drawable.nav_camion_gris, R.drawable.nav_camion_rojo),
        Pestana("clientes", "Lugares", R.drawable.nav_gente_gris, R.drawable.nav_gente_rojo),
        Pestana("ajustes", "Ajustes", R.drawable.nav_ajustes_gris, R.drawable.nav_ajustes_rojo)
    )
    val forma = RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp)
    Row(
        Modifier.fillMaxWidth()
            .clip(forma)
            .background(Brush.verticalGradient(listOf(Color(0xFF1C1C20), Color(0xFF0A0A0C))), forma)
            .border(1.dp, Brush.horizontalGradient(listOf(Color(0x00E11D2A), Rojo, Color(0x00E11D2A))), forma)
    ) {
        pestanas.forEach { t ->
            val activa = ruta == t.ruta
            Column(
                Modifier.weight(1f).clickable { onIr(t.ruta) }.padding(top = 8.dp, bottom = 6.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Image(painterResource(if (activa) t.roja else t.gris), contentDescription = t.nombre, modifier = Modifier.size(34.dp))
                Text(
                    t.nombre, fontSize = 12.sp,
                    color = if (activa) Color.White else Color(0xFFB5B5BC),
                    style = MaterialTheme.typography.labelMedium
                )
                Box(
                    Modifier.padding(top = 4.dp).width(38.dp).height(3.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(if (activa) Rojo else Color.Transparent)
                )
            }
        }
    }
}

@Composable
fun AppNav(vm: MainViewModel) {
    val nav = rememberNavController()
    val entrada by nav.currentBackStackEntryAsState()
    val ruta = entrada?.destination?.route
    val rutasPestana = listOf("home", "historial", "clientes", "ajustes")
    Scaffold(bottomBar = {
        if (ruta in rutasPestana) {
            BarraInferior(ruta) { destino ->
                if (ruta != destino) nav.navigate(destino) {
                    popUpTo("home")
                    launchSingleTop = true
                }
            }
        }
    }) { padding ->
        Box(
            Modifier.fillMaxSize().padding(padding).background(
                Brush.radialGradient(listOf(Color(0x40E11D2A), Color.Transparent), center = Offset(0f, 0f), radius = 1000f)
            )
        ) {
            NavHost(nav, startDestination = "home") {
                composable("home") { HomeScreen(vm, nav) }
                composable("nuevo") { NuevoViajeScreen(vm, nav) }
                composable("historial") { HistorialScreen(vm, nav) }
                composable("clientes") { ClientesScreen(vm, nav) }
                composable("ajustes") { AjustesScreen(vm, nav) }
                composable("asistente") { AsistenteScreen(vm, nav) }
                composable("camion") { CamionScreen(vm, nav) }
                composable("resumen") { ResumenScreen(vm, nav) }
                composable("viaje/{id}", listOf(navArgument("id") { type = NavType.StringType })) {
                    DetalleViajeScreen(vm, nav, it.arguments!!.getString("id")!!)
                }
            }
        }
        UbicacionRecibidaDialog(vm)
        ActualizacionDialog(vm)
        NovedadesDialog()
    }
}
