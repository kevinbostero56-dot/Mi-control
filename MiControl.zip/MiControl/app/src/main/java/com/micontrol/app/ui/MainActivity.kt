package com.micontrol.app.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MiControlTheme { AppNav(vm) } }
    }
}

@Composable
fun AppNav(vm: MainViewModel) {
    val nav = rememberNavController()
    NavHost(nav, startDestination = "home") {
        composable("home") { HomeScreen(vm, nav) }
        composable("nuevo") { NuevoViajeScreen(vm, nav) }
        composable("historial") { HistorialScreen(vm, nav) }
        composable("viaje/{id}", listOf(navArgument("id") { type = NavType.StringType })) {
            DetalleViajeScreen(vm, nav, it.arguments!!.getString("id")!!)
        }
    }
}
