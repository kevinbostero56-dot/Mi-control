package com.micontrol.app.ui

import androidx.annotation.DrawableRes
import com.micontrol.app.R

/** Fondos de pantalla disponibles. Cada uno es una imagen separada; el 0 es el fondo liso de siempre. */
class FondoApp(val id: Int, val nombre: String, @DrawableRes val imagen: Int?, @DrawableRes val miniatura: Int?)

val FONDOS = listOf(
    FondoApp(0, "Liso", null, null),
    FondoApp(1, "Negro y rojo", R.drawable.fondo_negro_rojo, R.drawable.th_fondo_negro_rojo),
    FondoApp(2, "Neumático", R.drawable.fondo_neumatico, R.drawable.th_fondo_neumatico),
    FondoApp(3, "Atardecer", R.drawable.fondo_atardecer, R.drawable.th_fondo_atardecer),
    FondoApp(4, "Montaña", R.drawable.fondo_montana, R.drawable.th_fondo_montana)
)
