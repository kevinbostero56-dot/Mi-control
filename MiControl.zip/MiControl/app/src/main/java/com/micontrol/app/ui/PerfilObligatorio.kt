package com.micontrol.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.micontrol.app.data.Compu

/** Un perfil sin nombre ("Mi perfil") no sirve para el panel de la computadora: hay que ponerle nombre. */
fun perfilSinNombre(nombre: String): Boolean {
    val n = nombre.trim()
    return n.isEmpty() || n.equals("Mi perfil", ignoreCase = true)
}

/**
 * La primera vez que se abre la app (o si el perfil sigue llamándose "Mi perfil") pide el nombre del chofer.
 * No se puede cerrar sin ponerlo: así cada chofer aparece con su nombre en el panel de la computadora.
 */
@Composable
fun PerfilObligatorioDialog(vm: MainViewModel) {
    val ctx = LocalContext.current
    val perfil by vm.perfil.collectAsStateWithLifecycle()
    if (!perfilSinNombre(perfil.nombre)) return
    var nombre by remember(perfil.id) { mutableStateOf("") }
    var camion by remember(perfil.id) { mutableStateOf(perfil.camion) }
    val ok = nombre.trim().length >= 3 && !perfilSinNombre(nombre)
    AlertDialog(
        onDismissRequest = { },
        properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false),
        title = { Text("👤 ¿Cómo te llamás?") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    "Poné tu nombre y apellido. Así te ven con tu nombre en el panel de la empresa, " +
                        "con tus propios viajes, kilómetros, horas y gastos.",
                    style = MaterialTheme.typography.bodyMedium
                )
                OutlinedTextField(nombre, { nombre = it }, Modifier.fillMaxWidth(), label = { Text("Nombre y apellido") }, singleLine = true)
                OutlinedTextField(camion, { camion = it }, Modifier.fillMaxWidth(), label = { Text("Camión o patente (opcional)") }, singleLine = true)
                if (nombre.isNotBlank() && !ok) Text("Escribí tu nombre completo.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = {
            TextButton({
                vm.guardarPerfil(perfil.copy(nombre = nombre.trim(), camion = camion.trim()))
                Compu.programarEnvio(ctx)
            }, enabled = ok) { Text("Listo") }
        }
    )
}
