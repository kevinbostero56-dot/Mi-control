package com.micontrol.app.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Ruta para camión con OpenRouteService (perfil driving-hgv). Necesita internet y una clave gratuita. */
object RutaCamion {
    data class Paso(val texto: String, val metros: Double, val idx: Int)
    data class Resultado(
        val puntos: List<Pair<Double, Double>>,   // lat, lng
        val metros: Double,
        val segundos: Double,
        val pasos: List<Paso>,
        val avisos: List<String>
    )

    class ErrorRuta(val mensaje: String, val codigo: Int = 0) : Exception(mensaje)

    private const val URL_RUTA = "https://api.heigit.org/openrouteservice/v2/directions/driving-hgv/geojson"

    /** Tiempo para camión cargado: nunca menos que lo que tardaría a 90% de la velocidad máxima. */
    fun segundosCargado(metros: Double, segundosRuta: Double, velMaxKmh: Double): Double {
        val promedio = (velMaxKmh * 0.9).coerceAtLeast(30.0)
        return maxOf(segundosRuta, metros / 1000.0 / promedio * 3600.0)
    }

    private fun redondear(x: Double) = Math.round(x * 100) / 100.0

    /**
     * Ruta para camión. Si el servicio de camión no responde (clave vencida, límite de consultas, caído)
     * o no hay clave, se usa una ruta de auto gratis (OSRM) para que igual se vean el recorrido, los km y las horas.
     */
    suspend fun calcular(
        clave: String, alto: Double, largo: Double, coords: List<Pair<Double, Double>>, pesoTn: Double = 0.0
    ): Resultado {
        if (clave.isBlank()) return rutaAuto(coords) ?: throw ErrorRuta("No se pudo calcular la ruta. Revisá tu conexión a internet.")
        return try {
            calcularCamion(clave, alto, largo, coords, pesoTn)
        } catch (e: ErrorRuta) {
            if (e.codigo == 401 || e.codigo == 403 || e.codigo == 429 || e.codigo >= 500) rutaAuto(coords) ?: throw e else throw e
        }
    }

    /** Ruta de auto con el servidor gratuito de OSRM (sin clave). Devuelve null si no se pudo. */
    private suspend fun rutaAuto(coords: List<Pair<Double, Double>>): Resultado? = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        if (coords.size < 2) return@withContext null
        val pts = coords.joinToString(";") { "%.6f,%.6f".format(java.util.Locale.US, it.second, it.first) }
        val c = URL("https://router.project-osrm.org/route/v1/driving/$pts?overview=full&geometries=geojson").openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 15000
            c.readTimeout = 30000
            c.setRequestProperty("User-Agent", "MiControl/0.6")
            if (c.responseCode != 200) return@withContext null
            val o = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
            val r = o.optJSONArray("routes")?.optJSONObject(0) ?: return@withContext null
            val cs = r.getJSONObject("geometry").getJSONArray("coordinates")
            val linea = (0 until cs.length()).map { val p = cs.getJSONArray(it); Pair(p.getDouble(1), p.getDouble(0)) }
            Resultado(
                linea, r.getDouble("distance"), r.getDouble("duration"), emptyList(),
                listOf("Ruta calculada para auto: el servicio de rutas para camión no respondió. Revisá alturas y pesos por tu cuenta.")
            )
        } catch (e: Exception) {
            null
        } finally {
            c.disconnect()
        }
    }

    private suspend fun calcularCamion(
        clave: String, alto: Double, largo: Double, coords: List<Pair<Double, Double>>, pesoTn: Double = 0.0
    ): Resultado = withContext(Dispatchers.IO) {
        val cuerpo = JSONObject().apply {
            put("coordinates", JSONArray().apply { coords.forEach { (lat, lng) -> put(JSONArray().put(lng).put(lat)) } })
            put("radiuses", JSONArray().apply { coords.forEach { _ -> put(-1) } })
            put("language", "es")
            put("instructions", true)
            val restricciones = JSONObject().put("height", redondear(alto)).put("length", redondear(largo))
            if (pesoTn > 0.0) restricciones.put("weight", redondear(pesoTn))
            put("options", JSONObject().put("profile_params", JSONObject().put("restrictions", restricciones)))
        }
        val c = URL(URL_RUTA).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.doOutput = true
            c.connectTimeout = 15000
            c.readTimeout = 30000
            c.setRequestProperty("Authorization", clave)
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            c.setRequestProperty("Accept", "application/geo+json, application/json")
            c.setRequestProperty("User-Agent", "MiControl/0.6")
            c.outputStream.use { it.write(cuerpo.toString().toByteArray(Charsets.UTF_8)) }
            val codigo = c.responseCode
            if (codigo !in 200..299) {
                val texto = c.errorStream?.bufferedReader()?.use { it.readText() } ?: ""
                throw ErrorRuta(mensajeError(codigo, texto), codigo)
            }
            parsear(c.inputStream.bufferedReader().use { it.readText() })
        } catch (e: ErrorRuta) {
            throw e
        } catch (e: java.io.IOException) {
            throw ErrorRuta("No se pudo conectar. Revisá tu conexión a internet.")
        } catch (e: Exception) {
            throw ErrorRuta("La respuesta del servicio no se pudo leer.")
        } finally {
            c.disconnect()
        }
    }

    private fun mensajeError(codigo: Int, texto: String): String {
        val detalle = runCatching {
            val e = JSONObject(texto).opt("error")
            when (e) {
                is JSONObject -> e.optString("message")
                is String -> e
                else -> ""
            }
        }.getOrDefault("")
        val base = when (codigo) {
            401, 403 -> "La clave de OpenRouteService no es válida. Revisala en Configuración."
            429 -> "Se superó el límite de consultas. Probá más tarde."
            404 -> "No se encontró una ruta apta para tu camión entre esos puntos."
            else -> "No se pudo calcular la ruta (error $codigo)."
        }
        return if (detalle.isBlank()) base else "$base\n$detalle"
    }

    private fun parsear(texto: String): Resultado {
        val f = JSONObject(texto).getJSONArray("features").getJSONObject(0)
        val cs = f.getJSONObject("geometry").getJSONArray("coordinates")
        val pts = (0 until cs.length()).map { val c = cs.getJSONArray(it); Pair(c.getDouble(1), c.getDouble(0)) }
        val props = f.getJSONObject("properties")
        val sum = props.getJSONObject("summary")
        val pasos = mutableListOf<Paso>()
        props.optJSONArray("segments")?.let { segs ->
            for (i in 0 until segs.length()) {
                val st = segs.getJSONObject(i).optJSONArray("steps") ?: continue
                for (j in 0 until st.length()) {
                    val s = st.getJSONObject(j)
                    pasos.add(Paso(s.optString("instruction"), s.optDouble("distance"), s.optJSONArray("way_points")?.optInt(0, 0) ?: 0))
                }
            }
        }
        val avisos = mutableListOf<String>()
        props.optJSONArray("warnings")?.let { w ->
            for (i in 0 until w.length()) avisos.add(w.getJSONObject(i).optString("message"))
        }
        return Resultado(pts, sum.getDouble("distance"), sum.getDouble("duration"), pasos, avisos)
    }
}
