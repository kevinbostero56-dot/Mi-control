package com.micontrol.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import com.micontrol.app.data.Ajustes

const val LARGO_PIN = 4

/** Pantalla de PIN que tapa la app. Queda por encima, así no se pierde lo que estabas haciendo. */
@Composable
fun BloqueoPantalla(onOk: () -> Unit) {
    val ctx = LocalContext.current
    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }
    var hasta by remember { mutableStateOf(Ajustes.pinBloqueadoHasta(ctx)) }
    var ahora by remember { mutableStateOf(System.currentTimeMillis()) }
    val frenado = ahora < hasta

    LaunchedEffect(hasta) {
        while (System.currentTimeMillis() < hasta) {
            ahora = System.currentTimeMillis()
            delay(500)
        }
        ahora = System.currentTimeMillis()
    }

    LaunchedEffect(pin) {
        if (pin.length == LARGO_PIN) {
            if (System.currentTimeMillis() < hasta) {
                pin = ""
            } else if (Ajustes.pinCorrecto(ctx, pin)) {
                Ajustes.pinAcertado(ctx)
                onOk()
            } else {
                error = true
                pin = ""
                hasta = Ajustes.registrarFalloPin(ctx)
                ahora = System.currentTimeMillis()
            }
        }
    }

    Box(
        Modifier.fillMaxSize().background(Fondo)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { },
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Mi Control", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text("Ingresá tu PIN", style = MaterialTheme.typography.titleMedium)
            Text(
                (0 until LARGO_PIN).joinToString("  ") { if (it < pin.length) "●" else "○" },
                style = MaterialTheme.typography.headlineMedium
            )
            if (frenado) Text("Demasiados intentos. Esperá ${((hasta - ahora) / 1000 + 1)} segundos.", color = MaterialTheme.colorScheme.error)
            else if (error) Text("PIN incorrecto", color = MaterialTheme.colorScheme.error)
            else Text(" ")
            listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"), listOf("", "0", "⌫")).forEach { fila ->
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    fila.forEach { t ->
                        if (t.isEmpty()) Spacer(Modifier.size(width = 76.dp, height = 60.dp))
                        else BotonSec({
                            if (frenado) return@BotonSec
                            error = false
                            if (t == "⌫") pin = pin.dropLast(1) else if (pin.length < LARGO_PIN) pin += t
                        }, Modifier.size(width = 76.dp, height = 60.dp)) { Text(t, style = MaterialTheme.typography.titleLarge) }
                    }
                }
            }
        }
    }
}
