package com.micontrol.app.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle

/** Aviso de versión nueva: muestra las novedades y lleva a la descarga. */
@Composable
fun ActualizacionDialog(vm: MainViewModel) {
    val ctx = LocalContext.current
    val nueva by vm.actualizacion.collectAsStateWithLifecycle()
    val n = nueva ?: return
    AlertDialog(
        onDismissRequest = { vm.cerrarActualizacion() },
        title = { Text("Hay una versión nueva") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(n.nombre, style = MaterialTheme.typography.titleMedium)
                if (n.notas.isNotBlank()) Text(n.notas)
                Text(
                    "Se descarga desde el navegador. Cuando termine, tocá el archivo para instalarla encima de la actual: no se pierden tus datos.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        },
        confirmButton = {
            TextButton({
                ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(n.url)))
                vm.cerrarActualizacion()
            }) { Text("Descargar") }
        },
        dismissButton = { TextButton({ vm.cerrarActualizacion() }) { Text("Más tarde") } }
    )
}

/** Muestra las novedades una vez después de cada actualización. */
@Composable
fun NovedadesDialog() {
    val ctx = LocalContext.current
    var visible by remember { mutableStateOf(com.micontrol.app.data.Ajustes.versionVista(ctx) != com.micontrol.app.BuildConfig.VERSION_CODE) }
    val texto = remember {
        runCatching { ctx.resources.openRawResource(com.micontrol.app.R.raw.novedades).bufferedReader().use { it.readText() } }.getOrDefault("")
    }
    if (!visible || texto.isBlank()) return
    AlertDialog(
        onDismissRequest = {
            com.micontrol.app.data.Ajustes.marcarVersionVista(ctx, com.micontrol.app.BuildConfig.VERSION_CODE)
            visible = false
        },
        title = { Text("¡Mi Control se actualizó!") },
        text = { Column(Modifier.verticalScroll(rememberScrollState())) { Text(texto) } },
        confirmButton = {
            TextButton({
                com.micontrol.app.data.Ajustes.marcarVersionVista(ctx, com.micontrol.app.BuildConfig.VERSION_CODE)
                visible = false
            }) { Text("Entendido") }
        }
    )
}
