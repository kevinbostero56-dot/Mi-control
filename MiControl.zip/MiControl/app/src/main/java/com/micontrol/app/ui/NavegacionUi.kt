package com.micontrol.app.ui

import android.Manifest
import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import android.speech.tts.TextToSpeech
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.micontrol.app.data.Ajustes
import com.micontrol.app.data.RutaCamion
import com.micontrol.app.domain.Navegacion
import com.micontrol.app.gps.Gps
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

private fun metrosTexto(m: Double): String =
    if (m >= 1000) "%.1f km".format(m / 1000) else "${(m / 10).roundToInt() * 10} m"

private fun distanciaM(l: Location, g: GeoPoint): Float {
    val r = FloatArray(1)
    Location.distanceBetween(l.latitude, l.longitude, g.latitude, g.longitude, r)
    return r[0]
}

/**
 * Navegación para camión: te sigue en el mapa, te dice por voz qué hacer y,
 * si te salís de la ruta, la recalcula desde donde estás.
 */
@Composable
fun NavegacionDialog(
    waypoints: List<Pair<String, GeoPoint>>,   // origen, paradas..., destino
    inicial: RutaCamion.Resultado,
    onDismiss: () -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val clave = remember { Ajustes.claveOrs(ctx) }
    val alto = remember { Ajustes.alturaCamion(ctx) }
    val largo = remember { Ajustes.largoCamion(ctx) }

    var resultado by remember { mutableStateOf(inicial) }
    val ruta = remember(resultado) { Navegacion.Ruta(resultado.puntos) }
    val rutaGeo = remember(resultado) { resultado.puntos.map { GeoPoint(it.first, it.second) } }

    var permiso by remember { mutableStateOf(Gps.tieneUbicacion(ctx)) }
    var posicion by remember { mutableStateOf<Location?>(null) }
    var proy by remember { mutableStateOf<Navegacion.Proy?>(null) }
    var recalculando by remember { mutableStateOf(false) }
    var aviso by remember { mutableStateOf<String?>(null) }
    var llegado by remember { mutableStateOf(false) }
    var vozOn by remember { mutableStateOf(true) }
    var oscuro by remember { mutableStateOf(modoOscuroActual(ctx)) }
    var mapView by remember { mutableStateOf<MapView?>(null) }
    var fuera by remember { mutableStateOf(0) }
    var ultimoRecalculo by remember { mutableStateOf(0L) }
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    val visitados = remember { mutableStateListOf<Int>() }
    val anunciadas = remember { mutableSetOf<Int>() }
    val avisadas = remember { mutableSetOf<Int>() }

    val pedir = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        permiso = Gps.tieneUbicacion(ctx)
    }

    // Pantalla encendida mientras se navega
    val vista = LocalView.current
    DisposableEffect(Unit) {
        vista.keepScreenOn = true
        onDispose { vista.keepScreenOn = false }
    }

    // Voz
    DisposableEffect(Unit) {
        var motor: TextToSpeech? = null
        motor = TextToSpeech(ctx) { estado ->
            if (estado == TextToSpeech.SUCCESS) {
                val r = motor?.setLanguage(Locale("es", "AR"))
                if (r == null || r < 0) motor?.setLanguage(Locale("es"))
            }
        }
        tts = motor
        onDispose { motor?.stop(); motor?.shutdown() }
    }
    fun hablar(texto: String) {
        if (vozOn) tts?.speak(texto, TextToSpeech.QUEUE_FLUSH, null, "micontrol")
    }
    LaunchedEffect(Unit) {
        delay(1500)
        hablar("Navegación iniciada. " + (inicial.pasos.firstOrNull()?.texto ?: ""))
    }

    // Ubicación cada segundo
    DisposableEffect(permiso) {
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val oyente = object : LocationListener {
            override fun onLocationChanged(l: Location) { posicion = l }
            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}
            @Deprecated("Deprecated in Java")
            override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        }
        if (permiso) {
            try {
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, oyente, Looper.getMainLooper())
            } catch (e: SecurityException) {
                // sin permiso
            }
        }
        onDispose { lm.removeUpdates(oyente) }
    }

    fun recalcular(l: Location) {
        recalculando = true
        ultimoRecalculo = System.currentTimeMillis()
        hablar("Recalculando")
        val destinos = waypoints.withIndex().filter { it.index > 0 && it.index !in visitados }.map { it.value.second }
        val coords = listOf(l.latitude to l.longitude) + destinos.map { it.latitude to it.longitude }
        scope.launch {
            try {
                resultado = RutaCamion.calcular(clave, alto, largo, coords)
                anunciadas.clear(); avisadas.clear()
                proy = null
                fuera = 0
                aviso = null
            } catch (e: RutaCamion.ErrorRuta) {
                aviso = e.mensaje
            }
            recalculando = false
        }
    }

    fun seguirCamara(m: MapView, l: Location) {
        m.controller.animateTo(GeoPoint(l.latitude, l.longitude))
        if (l.hasBearing() && l.speed > 1.5f) {
            var d = -l.bearing - m.mapOrientation
            while (d > 180f) d -= 360f
            while (d < -180f) d += 360f
            m.mapOrientation = m.mapOrientation + d * 0.35f
        }
        val kmh = l.speed * 3.6f
        val zoom = if (kmh < 40f) 17.0 else if (kmh < 80f) 16.0 else 15.0
        if (abs(m.zoomLevelDouble - zoom) > 0.5) m.controller.setZoom(zoom)
    }

    LaunchedEffect(posicion) {
        val l = posicion ?: return@LaunchedEffect
        val p = Navegacion.proyectar(ruta, l.latitude, l.longitude, proy?.idx ?: 0)
        proy = p
        mapView?.let { seguirCamara(it, l) }

        waypoints.forEachIndexed { i, w ->
            if (i > 0 && i !in visitados && distanciaM(l, w.second) < 80f) visitados.add(i)
        }
        if (!llegado && waypoints.lastIndex in visitados) {
            llegado = true
            hablar("Llegaste a tu destino")
            return@LaunchedEffect
        }

        // ¿Te saliste de la ruta?
        if (p.distM > 60.0 && !recalculando) {
            fuera += 1
            if (fuera >= 3 && System.currentTimeMillis() - ultimoRecalculo > 15_000L) recalcular(l)
        } else if (p.distM <= 60.0) {
            fuera = 0
        }

        // Avisos por voz de la próxima maniobra
        val sig = resultado.pasos.firstOrNull { it.idx > p.idx && it.idx < ruta.acum.size }
        if (sig != null) {
            val falta = ruta.acum[sig.idx] - p.progresoM
            if (falta < 350.0 && anunciadas.add(sig.idx)) hablar("En ${metrosTexto(falta)}, ${sig.texto}")
            if (falta < 60.0 && avisadas.add(sig.idx)) hablar(sig.texto)
        }
    }

    // Datos para mostrar
    val p = proy
    val sig = if (p != null) resultado.pasos.firstOrNull { it.idx > p.idx && it.idx < ruta.acum.size } else null
    val faltaManiobra = if (p != null && sig != null) ruta.acum[sig.idx] - p.progresoM else null
    val restante = if (p != null) maxOf(0.0, ruta.total - p.progresoM) else ruta.total
    val segundosRestantes = if (ruta.total > 0) resultado.segundos * (restante / ruta.total) else 0.0
    val llegada = LocalTime.now().plusSeconds(segundosRestantes.toLong()).format(DateTimeFormatter.ofPattern("HH:mm"))
    val marcadores = remember(waypoints) {
        waypoints.mapIndexed { i, w ->
            val rol = when (i) { 0 -> "Origen"; waypoints.lastIndex -> "Destino"; else -> "Parada $i" }
            w.second to "$rol: ${w.first}"
        }
    }

    Dialog(
        onDismissRequest = {},
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnBackPress = false, dismissOnClickOutside = false)
    ) {
        Surface(Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize()) {
                Surface(color = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        when {
                            llegado -> Text("Llegaste a tu destino", style = MaterialTheme.typography.headlineSmall)
                            !permiso -> {
                                Text("Hace falta el permiso de ubicación para navegar.")
                                BotonP({
                                    pedir.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
                                }) { Text("Permitir ubicación") }
                            }
                            posicion == null -> Text("Esperando la señal del GPS…", style = MaterialTheme.typography.titleMedium)
                            recalculando -> Text("Recalculando la ruta…", style = MaterialTheme.typography.headlineSmall)
                            else -> {
                                if (faltaManiobra != null) Text("En ${metrosTexto(faltaManiobra)}", style = MaterialTheme.typography.titleMedium)
                                Text(sig?.texto ?: "Seguí por la ruta", style = MaterialTheme.typography.headlineSmall)
                            }
                        }
                        if (aviso != null) Text(aviso!!, style = MaterialTheme.typography.bodySmall)
                    }
                }

                MapaOsm(
                    Modifier.weight(1f).fillMaxWidth(), marcadores, listOf(rutaGeo), null,
                    miUbicacion = true, oscuro = oscuro, onMapa = { mapView = it }
                )

                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        "Faltan ${metrosTexto(restante)} · llegada estimada $llegada",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Switch(vozOn, { vozOn = it; if (!it) tts?.stop() })
                        Text("Voz", Modifier.weight(1f))
                        BotonSec({ oscuro = !oscuro }) { Text(if (oscuro) "☀️ Día" else "🌙 Noche") }
                    }
                    BotonP(
                        onDismiss, Modifier.fillMaxWidth().height(52.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                    ) { Text("Terminar navegación") }
                }
            }
        }
    }
}
