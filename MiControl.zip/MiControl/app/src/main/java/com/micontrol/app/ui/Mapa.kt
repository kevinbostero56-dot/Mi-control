package com.micontrol.app.ui

import android.Manifest
import android.content.ClipboardManager
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.clickable
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.core.view.drawToBitmap
import kotlinx.coroutines.delay
import com.micontrol.app.pdf.InformePdf
import java.io.FileOutputStream
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import android.location.Location
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.font.FontWeight
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.micontrol.app.data.Ajustes
import com.micontrol.app.data.Geo
import com.micontrol.app.data.Parada
import com.micontrol.app.data.UbicacionLink
import com.micontrol.app.data.PuntoGps
import com.micontrol.app.data.Viaje
import com.micontrol.app.domain.Calculos
import com.micontrol.app.gps.Gps
import kotlinx.coroutines.launch
import org.osmdroid.config.Configuration
import org.osmdroid.events.MapEventsReceiver
import org.osmdroid.tileprovider.tilesource.ITileSource
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.tileprovider.tilesource.XYTileSource
import org.osmdroid.util.BoundingBox
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.CopyrightOverlay
import org.osmdroid.views.overlay.MapEventsOverlay
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline
import org.osmdroid.views.overlay.TilesOverlay
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay
import java.io.File

/** Pedido de centrar el mapa; `n` cambia para poder pedir lo mismo dos veces. */
data class Centro(val p: GeoPoint, val n: Int = 0, val zoom: Double? = 15.0)

fun hayInternet(ctx: Context): Boolean {
    val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
    return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
}

/** ¿Hay que mostrar el mapa de noche? Según el ajuste, o como esté el teléfono. */
fun modoOscuroActual(ctx: Context): Boolean = when (Ajustes.modoMapa(ctx)) {
    "oscuro" -> true
    "claro" -> false
    else -> (ctx.resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
        android.content.res.Configuration.UI_MODE_NIGHT_YES
}

/** Con clave de MapTiler: mapa de calles (claro/oscuro) o satélite. Sin clave: mapa básico de OpenStreetMap. */
private fun fuenteMapa(ctx: Context, oscuro: Boolean, satelite: Boolean = false): ITileSource {
    val clave = Ajustes.claveMapTiler(ctx)
    if (clave.isBlank()) return TileSourceFactory.MAPNIK
    if (satelite) {
        return XYTileSource(
            "MapTilerSatelite", 0, 19, 256, ".jpg?key=$clave",
            arrayOf("https://api.maptiler.com/maps/hybrid/256/"),
            "© MapTiler © OpenStreetMap contributors"
        )
    }
    val estilo = if (oscuro) "streets-v2-dark" else "streets-v2"
    return XYTileSource(
        if (oscuro) "MapTilerNoche" else "MapTilerDia", 0, 20, 256, ".png?key=$clave",
        arrayOf("https://api.maptiler.com/maps/$estilo/256/"),
        "© MapTiler © OpenStreetMap contributors"
    )
}

/** Si el recorrido tiene miles de puntos, dibuja solo algunos: el mapa se mueve mucho más fluido. */
private fun aligerar(seg: List<GeoPoint>, maximo: Int = 1500): List<GeoPoint> {
    if (seg.size <= maximo) return seg
    val paso = seg.size / maximo + 1
    val out = ArrayList<GeoPoint>(maximo + 2)
    var i = 0
    while (i < seg.size) { out.add(seg[i]); i += paso }
    if (out.last() != seg.last()) out.add(seg.last())
    return out
}

/** Mapa. Cada tramo de `segmentos` se dibuja por separado (sin unir cortes de señal). */
@Composable
fun MapaOsm(
    modifier: Modifier,
    marcadores: List<Pair<GeoPoint, String>>,
    segmentos: List<List<GeoPoint>>,
    centrar: Centro?,
    miUbicacion: Boolean = false,
    oscuro: Boolean = modoOscuroActual(LocalContext.current),
    satelite: Boolean = false,
    ajustar: List<GeoPoint> = emptyList(),
    onMapa: ((MapView) -> Unit)? = null,
    onTap: ((GeoPoint) -> Unit)? = null
) {
    val ctx = LocalContext.current
    val tap = rememberUpdatedState(onTap)
    val centrarActual = rememberUpdatedState(centrar)
    val map = remember {
        Configuration.getInstance().apply {
            userAgentValue = "MiControl/0.5 (com.micontrol.app)"
            // Guarda los mapas ya vistos (más rápido y gasta menos datos)
            tileFileSystemCacheMaxBytes = 1500L * 1024 * 1024
            tileFileSystemCacheTrimBytes = 1200L * 1024 * 1024
            expirationOverrideDuration = 90L * 24 * 3600 * 1000
            osmdroidBasePath = File(ctx.filesDir, "osmdroid")
            osmdroidTileCache = File(ctx.filesDir, "osmdroid/tiles")
        }
        MapView(ctx).apply {
            setTileSource(fuenteMapa(ctx, oscuro, satelite))
            isHorizontalMapRepetitionEnabled = false
            isVerticalMapRepetitionEnabled = false
            setTilesScaledToDpi(true)
            setMultiTouchControls(true)
            controller.setZoom(5.0)
            controller.setCenter(GeoPoint(-34.6, -64.0))
            overlays.add(MapEventsOverlay(object : MapEventsReceiver {
                override fun singleTapConfirmedHelper(p: GeoPoint): Boolean {
                    val f = tap.value ?: return false
                    f(p)
                    return true
                }
                override fun longPressHelper(p: GeoPoint): Boolean = false
            }))
            overlays.add(CopyrightOverlay(ctx))
        }
    }

    val onMapaActual = rememberUpdatedState(onMapa)
    LaunchedEffect(map) { onMapaActual.value?.invoke(map) }

    val lifecycle = LocalLifecycleOwner.current.lifecycle
    DisposableEffect(lifecycle) {
        val obs = LifecycleEventObserver { _, e ->
            when (e) {
                Lifecycle.Event.ON_RESUME -> map.onResume()
                Lifecycle.Event.ON_PAUSE -> map.onPause()
                else -> {}
            }
        }
        lifecycle.addObserver(obs)
        onDispose { lifecycle.removeObserver(obs); map.onDetach() }
    }

    // Punto azul con la ubicación del teléfono (y se centra ahí si nadie pidió otra cosa)
    val miLoc = remember {
        MyLocationNewOverlay(GpsMyLocationProvider(ctx), map)
    }
    DisposableEffect(miUbicacion) {
        if (miUbicacion) {
            miLoc.enableMyLocation()
            map.overlays.add(miLoc)
            miLoc.runOnFirstFix {
                map.post {
                    val p = miLoc.myLocation
                    if (p != null && centrarActual.value == null) {
                        map.controller.setZoom(17.0); map.controller.animateTo(p)
                    }
                }
            }
        }
        onDispose { miLoc.disableMyLocation(); map.overlays.remove(miLoc) }
    }

    LaunchedEffect(ajustar) {
        if (ajustar.size > 1) map.post { map.zoomToBoundingBox(BoundingBox.fromGeoPoints(ajustar), false, 100) }
    }

    // Cambio de día/noche en vivo
    LaunchedEffect(oscuro, satelite) {
        val nueva = fuenteMapa(ctx, oscuro, satelite)
        if (map.tileProvider.tileSource.name() != nueva.name()) map.setTileSource(nueva)
        val sinClave = Ajustes.claveMapTiler(ctx).isBlank()
        map.overlayManager.tilesOverlay.setColorFilter(if (oscuro && sinClave && !satelite) TilesOverlay.INVERT_COLORS else null)
        map.invalidate()
    }

    LaunchedEffect(centrar) {
        centrar?.let { c ->
            c.zoom?.let { z -> map.controller.setZoom(z) }
            map.controller.setCenter(c.p)
        }
    }

    Box(modifier.clipToBounds()) {
    AndroidView(factory = { map }, modifier = Modifier.fillMaxSize(), update = { m ->
        // Solo redibuja el recorrido y los marcadores si cambiaron (evita trabas)
        val firma = listOf(
            marcadores.hashCode(), segmentos.size, segmentos.sumOf { it.size },
            segmentos.lastOrNull()?.lastOrNull()?.hashCode(), segmentos.firstOrNull()?.firstOrNull()?.hashCode()
        ).hashCode()
        if (m.tag != firma) {
            m.tag = firma
            m.overlays.removeAll { it is Marker || it is Polyline }
            segmentos.filter { it.size > 1 }.forEach { seg ->
                m.overlays.add(Polyline().apply {
                    setPoints(aligerar(seg))
                    outlinePaint.color = 0xFF1A73E8.toInt()
                    outlinePaint.strokeWidth = 12f
                })
            }
            marcadores.forEach { (p, t) ->
                m.overlays.add(Marker(m).apply {
                    position = p
                    title = t
                    setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                })
            }
            m.invalidate()
        }
    })
    }
}

/**
 * Elegir un lugar con precisión: el círculo rojo del centro marca el punto exacto.
 * Se mueve el mapa hasta que la cruz quede justo en la entrada; el satélite ayuda a verificar.
 */
@Composable
fun SelectorUbicacion(
    titulo: String,
    onDismiss: () -> Unit,
    inicial: GeoPoint? = null,
    textoInicial: String = "",
    zoomInicial: Double = 18.0,
    onElegido: (String, Double, Double) -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var q by remember { mutableStateOf("") }
    var resultados by remember { mutableStateOf<List<Geo.Lugar>>(emptyList()) }
    var punto by remember { mutableStateOf(inicial) }
    var texto by remember { mutableStateOf(textoInicial) }
    var centro by remember { mutableStateOf<Centro?>(inicial?.let { Centro(it, 0, zoomInicial) }) }
    var mapView by remember { mutableStateOf<MapView?>(null) }
    var satelite by remember { mutableStateOf(false) }
    var buscando by remember { mutableStateOf(false) }
    var sinResultados by remember { mutableStateOf(false) }
    var pegarVisible by remember { mutableStateOf(false) }
    var textoPegado by remember { mutableStateOf("") }
    var mensajePegado by remember { mutableStateOf<String?>(null) }
    var buscandoPegado by remember { mutableStateOf(false) }
    var permiso by remember { mutableStateOf(Gps.tieneUbicacion(ctx)) }
    var cuenta by remember { mutableStateOf(0) }
    val hayClave = remember { Ajustes.claveMapTiler(ctx).isNotBlank() }
    val pedir = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        permiso = Gps.tieneUbicacion(ctx)
    }
    val permisosUbicacion = arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
    LaunchedEffect(Unit) { if (!permiso) pedir.launch(permisosUbicacion) }
    // Si no hay un punto de partida, el mapa arranca donde estás vos
    LaunchedEffect(Unit) {
        if (inicial == null && permiso) {
            val u = Gps.ultimaUbicacion(ctx)
            if (u != null) { cuenta++; centro = Centro(GeoPoint(u.latitude, u.longitude), cuenta, 16.0) }
        }
    }

    fun irA(lat: Double, lng: Double, nombre: String) {
        punto = GeoPoint(lat, lng)
        texto = nombre
        cuenta++
        centro = Centro(GeoPoint(lat, lng), cuenta, 18.0)
    }

    if (pegarVisible) AlertDialog(
        onDismissRequest = { pegarVisible = false },
        title = { Text("Pegar ubicación") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Pegá acá el link o el texto de la ubicación que te mandaron (también sirven coordenadas, ej. -34.6037, -58.3816).", style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(textoPegado, { textoPegado = it }, Modifier.fillMaxWidth(), minLines = 3, maxLines = 6)
                if (buscandoPegado) CircularProgressIndicator()
                mensajePegado?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton({
                scope.launch {
                    buscandoPegado = true
                    mensajePegado = null
                    val u = UbicacionLink.resolver(textoPegado, Ajustes.claveMapTiler(ctx), ctx)
                    buscandoPegado = false
                    if (u == null) {
                        mensajePegado = "No encontré una ubicación en este texto. Probá pegar el link completo."
                    } else {
                        val nombre = listOfNotNull(u.nombre, u.direccion).joinToString(" – ")
                            .ifBlank { Geo.direccion(u.lat, u.lng) ?: "%.6f, %.6f".format(u.lat, u.lng) }
                        irA(u.lat, u.lng, nombre)
                        if (u.aproximada) Toast.makeText(ctx, "Ubicación aproximada: movela hasta el lugar exacto antes de usarla.", Toast.LENGTH_LONG).show()
                        pegarVisible = false
                    }
                }
            }, enabled = textoPegado.isNotBlank() && !buscandoPegado) { Text("Buscar") }
        },
        dismissButton = { TextButton({ pegarVisible = false }) { Text("Cancelar") } }
    )

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(titulo, style = MaterialTheme.typography.titleLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(q, { q = it }, Modifier.weight(1f), label = { Text("Buscar dirección o lugar") }, singleLine = true)
                    BotonP({
                        scope.launch {
                            buscando = true
                            resultados = Geo.buscarLugares(q, Ajustes.claveMapTiler(ctx), 6)
                            sinResultados = resultados.isEmpty()
                            buscando = false
                        }
                    }, enabled = q.isNotBlank() && !buscando) { Text("Buscar") }
                }
                BotonSec({
                    val cb = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    textoPegado = cb.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(ctx)?.toString().orEmpty()
                    mensajePegado = null
                    pegarVisible = true
                }, Modifier.fillMaxWidth()) { Text("📋 Pegar ubicación (de WhatsApp)") }
                if (!hayInternet(ctx)) Text("Sin internet: el mapa y la búsqueda no funcionan.", color = MaterialTheme.colorScheme.error)
                if (sinResultados) Text("No se encontró nada. Probá con otra dirección o movete por el mapa.", style = MaterialTheme.typography.bodySmall)
                resultados.forEach { l ->
                    TextButton({
                        irA(l.lat, l.lng, l.nombre)
                        resultados = emptyList(); sinResultados = false
                    }) { Text(l.nombre, maxLines = 2) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    BotonSec({
                        if (!permiso) pedir.launch(permisosUbicacion)
                        else {
                            val u = Gps.ultimaUbicacion(ctx)
                            if (u != null) { cuenta++; centro = Centro(GeoPoint(u.latitude, u.longitude), cuenta, 18.0) }
                            else Toast.makeText(ctx, "Todavía no hay ubicación. Encendé el GPS y esperá unos segundos.", Toast.LENGTH_LONG).show()
                        }
                    }, Modifier.weight(1f)) { Text("Mi ubicación") }
                    if (hayClave) BotonSec({ satelite = !satelite }, Modifier.weight(1f)) {
                        Text(if (satelite) "🗺️ Mapa" else "🛰️ Satélite", maxLines = 1)
                    }
                    BotonGuardarZona(mapView, Modifier.weight(1f))
                }
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    MapaOsm(
                        Modifier.fillMaxSize(), emptyList(), emptyList(), centro,
                        miUbicacion = permiso, satelite = satelite,
                        onMapa = { mapView = it },
                        onTap = { p -> cuenta++; centro = Centro(p, cuenta, null) }
                    )
                    // La cruz marca el punto exacto que se va a guardar
                    Box(Modifier.align(Alignment.Center).size(40.dp).border(2.dp, Rojo, CircleShape))
                    Box(Modifier.align(Alignment.Center).size(6.dp).background(Rojo, CircleShape))
                }
                Text(
                    "1) Tocá el mapa o buscá la dirección. 2) Movelo hasta que el círculo rojo quede justo en el lugar. 3) Tocá el botón verde.",
                    style = MaterialTheme.typography.bodySmall
                )
                BotonP(
                    {
                        val c = mapView?.mapCenter
                        if (c != null) {
                            val lat = c.latitude
                            val lng = c.longitude
                            scope.launch {
                                val ref = punto
                                var cerca = false
                                if (ref != null && texto.isNotBlank()) {
                                    val r = FloatArray(1)
                                    Location.distanceBetween(lat, lng, ref.latitude, ref.longitude, r)
                                    cerca = r[0] < 30f
                                }
                                val nombre = if (cerca) texto else (Geo.direccion(lat, lng) ?: "%.6f, %.6f".format(lat, lng))
                                onElegido(nombre, lat, lng)
                            }
                        }
                    },
                    Modifier.fillMaxWidth().height(52.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Verde)
                ) { Text("✅ Es acá, usar este punto") }
                TextButton(onDismiss, Modifier.fillMaxWidth()) { Text("Cancelar") }
            }
        }
    }
}

private val horaFmt = SimpleDateFormat("dd/MM HH:mm", Locale("es", "AR"))
private fun hora(ms: Long) = horaFmt.format(Date(ms))

/**
 * Mapa del viaje. En un viaje en curso sigue tu posición en vivo y suma los km recorridos (GPS).
 * Al finalizar guarda una imagen del recorrido que se puede ver después sin internet.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MapaRecorrido(
    v: Viaje, paradas: List<Parada>, puntos: List<PuntoGps>,
    enCurso: Boolean, rastreando: Boolean,
    guardarAuto: Boolean, onGuardado: () -> Unit, onDismiss: () -> Unit
) {
    val ctx = LocalContext.current
    val archivo = remember(v.id) { File(ctx.filesDir, "recorridos/${v.id}.png") }
    var hayImagen by remember { mutableStateOf(archivo.exists()) }
    var versionImg by remember { mutableStateOf(0) }
    var mapView by remember { mutableStateOf<MapView?>(null) }
    var seguir by remember { mutableStateOf(enCurso) }
    var indice by remember { mutableStateOf<Int?>(null) }
    var vista by remember { mutableStateOf(if (!enCurso && !hayInternet(ctx) && archivo.exists()) "imagen" else "mapa") }
    var yaCentro by remember { mutableStateOf(false) }
    LaunchedEffect(puntos.size) { if (puntos.isNotEmpty()) yaCentro = true }

    fun guardarImagen(): Boolean {
        val m = mapView ?: return false
        if (m.width == 0 || m.height == 0) return false
        return try {
            archivo.parentFile?.mkdirs()
            val bmp = m.drawToBitmap()
            FileOutputStream(archivo).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            hayImagen = true
            versionImg++
            true
        } catch (e: Exception) {
            false
        }
    }

    // Al finalizar el viaje: espera a que carguen los mapas y guarda la imagen sola.
    LaunchedEffect(guardarAuto, mapView) {
        if (guardarAuto && mapView != null && puntos.size > 1) {
            if (hayInternet(ctx)) {
                delay(6000)
                if (vista == "mapa" && guardarImagen()) {
                    Toast.makeText(ctx, "Mapa del recorrido guardado", Toast.LENGTH_LONG).show()
                }
            }
            onGuardado()
        }
    }

    val km = remember(puntos.size) { Calculos.distanciaGpsKm(puntos) }
    val segs = remember(puntos.size) { Calculos.segmentos(puntos).map { s -> s.map { GeoPoint(it.lat, it.lng) } } }
    val detenciones = remember(puntos.size) { Calculos.detenciones(puntos) }
    val kmHora = remember(puntos.size) { Calculos.kmPorHora(puntos) }
    val ajustar = remember(puntos.size, enCurso) {
        if (!enCurso && puntos.size > 1) puntos.map { GeoPoint(it.lat, it.lng) } else emptyList()
    }

    val idx = indice?.coerceIn(0, maxOf(0, puntos.lastIndex))
    val sel = if (idx != null && puntos.isNotEmpty()) puntos[idx] else null

    val marc = mutableListOf<Pair<GeoPoint, String>>()
    val oLat = v.origenLat; val oLng = v.origenLng
    val dLat = v.destinoLat; val dLng = v.destinoLng
    if (oLat != null && oLng != null) marc.add(GeoPoint(oLat, oLng) to "Origen: ${v.origen}")
    paradas.forEachIndexed { i, p -> marc.add(GeoPoint(p.lat, p.lng) to "Parada ${i + 1}: ${p.nombre}") }
    if (dLat != null && dLng != null) marc.add(GeoPoint(dLat, dLng) to "Destino: ${v.destino}")
    puntos.lastOrNull()?.let { marc.add(GeoPoint(it.lat, it.lng) to "Última posición: ${hora(it.tiempo)}") }
    if (sel != null) marc.add(GeoPoint(sel.lat, sel.lng) to "Pasaste a las ${hora(sel.tiempo)}")

    val ultimoGeo = puntos.lastOrNull()?.let { GeoPoint(it.lat, it.lng) }
    val centro: Centro? = when {
        sel != null -> Centro(GeoPoint(sel.lat, sel.lng), (idx ?: 0) + 1, null)
        enCurso && seguir && ultimoGeo != null -> Centro(ultimoGeo, puntos.size, if (yaCentro) null else 16.0)
        puntos.isEmpty() -> marc.firstOrNull()?.first?.let { Centro(it, 0, 12.0) }
        else -> null
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(if (enCurso) "Mapa en vivo" else "Recorrido del viaje", style = MaterialTheme.typography.titleLarge)
                if (!hayInternet(ctx) && vista == "mapa") Text("Sin internet: el mapa no se ve, pero los datos están guardados.", color = MaterialTheme.colorScheme.error)
                if (enCurso && !rastreando) Text("El seguimiento GPS está detenido: no se está registrando el recorrido.", color = MaterialTheme.colorScheme.error)
                Text("Km recorridos (GPS, referencia): ${"%.1f".format(km)} km", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                if (puntos.isNotEmpty()) {
                    Text("Registrado de ${hora(puntos.first().tiempo)} a ${hora(puntos.last().tiempo)}", style = MaterialTheme.typography.bodySmall)
                }
                if (enCurso) Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Switch(seguir, { seguir = it; if (it) indice = null })
                    Text("Seguir mi posición")
                }

                when (vista) {
                    "mapa" -> {
                        MapaOsm(
                            Modifier.weight(1f).fillMaxWidth(), marc, segs, centro,
                            miUbicacion = enCurso, ajustar = ajustar,
                            onMapa = { mapView = it },
                            onTap = { g ->
                                if (puntos.isNotEmpty()) {
                                    val r = FloatArray(1)
                                    var mejor = 0
                                    var md = Float.MAX_VALUE
                                    puntos.forEachIndexed { i, pt ->
                                        Location.distanceBetween(g.latitude, g.longitude, pt.lat, pt.lng, r)
                                        if (r[0] < md) { md = r[0]; mejor = i }
                                    }
                                    if (md < 1000f) { indice = mejor; seguir = false }
                                }
                            }
                        )
                        if (puntos.size >= 2) {
                            Slider(
                                value = (idx ?: 0).toFloat(),
                                onValueChange = { indice = it.toInt(); seguir = false },
                                valueRange = 0f..puntos.lastIndex.toFloat()
                            )
                        }
                        Text(
                            sel?.let { "Pasaste por acá: ${hora(it.tiempo)}" }
                                ?: "Mové la barra o tocá el recorrido para ver a qué hora pasaste por ahí.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                    "imagen" -> {
                        val bmp = remember(versionImg, hayImagen) {
                            if (hayImagen) BitmapFactory.decodeFile(archivo.path)?.asImageBitmap() else null
                        }
                        if (bmp != null) {
                            Image(bmp, contentDescription = "Mapa del recorrido guardado", modifier = Modifier.weight(1f).fillMaxWidth(), contentScale = ContentScale.Fit)
                        } else {
                            Text("No hay imagen guardada.")
                        }
                    }
                    else -> {
                        LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            item { Text("Detenciones (más de 10 min en el mismo lugar)", style = MaterialTheme.typography.titleSmall) }
                            if (detenciones.isEmpty()) item { Text("No hay detenciones registradas.") }
                            items(detenciones) { d ->
                                Card(Modifier.fillMaxWidth().clickable { indice = d.idx; seguir = false; vista = "mapa" }) {
                                    Column(Modifier.padding(10.dp)) {
                                        Text("${hora(d.desde)} → ${hora(d.hasta)}")
                                        Text("${(d.hasta - d.desde) / 60000} min detenido (tocá para ver dónde)", style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                            }
                            item { Text("Kilómetros por hora (GPS)", style = MaterialTheme.typography.titleSmall) }
                            if (kmHora.isEmpty()) item { Text("Todavía no hay recorrido registrado.") }
                            items(kmHora) { k ->
                                Card(Modifier.fillMaxWidth().clickable { indice = k.idx; seguir = false; vista = "mapa" }) {
                                    Text("${hora(k.horaMs)} · ${"%.1f".format(k.km)} km", Modifier.padding(10.dp))
                                }
                            }
                        }
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(vista == "mapa", { vista = "mapa" }, label = { Text("Mapa") })
                    FilterChip(vista == "detalle", { vista = "detalle" }, label = { Text("Horas") })
                    if (hayImagen) FilterChip(vista == "imagen", { vista = "imagen" }, label = { Text("Imagen guardada") })
                }
                if (vista == "mapa") BotonGuardarZona(mapView, Modifier.fillMaxWidth())
                if (!enCurso && vista == "mapa" && puntos.size > 1) {
                    BotonSec({
                        val ok = guardarImagen()
                        Toast.makeText(ctx, if (ok) "Imagen del mapa guardada" else "Esperá a que cargue el mapa y probá de nuevo", Toast.LENGTH_LONG).show()
                    }, Modifier.fillMaxWidth()) { Text("Guardar imagen de este mapa") }
                }
                if (hayImagen) BotonSec({ InformePdf.compartirImagen(ctx, archivo) }, Modifier.fillMaxWidth()) { Text("Compartir imagen") }
                BotonP(onDismiss, Modifier.fillMaxWidth().height(52.dp)) { Text("Cerrar") }
            }
        }
    }
}
