package com.micontrol.app.ui

import android.Manifest
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import android.location.Location
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.font.FontWeight
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.micontrol.app.data.Ajustes
import com.micontrol.app.data.Geo
import com.micontrol.app.data.Parada
import com.micontrol.app.data.PuntoGps
import com.micontrol.app.data.Viaje
import com.micontrol.app.domain.Calculos
import com.micontrol.app.gps.Gps
import kotlinx.coroutines.launch
import org.osmdroid.config.Configuration
import org.osmdroid.events.MapEventsReceiver
import org.osmdroid.tileprovider.tilesource.ITileSource
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.tileprovider.tilesource.XYTileSource
import org.osmdroid.util.BoundingBox
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.CopyrightOverlay
import org.osmdroid.views.overlay.MapEventsOverlay
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay
import java.io.File

/** Pedido de centrar el mapa; `n` cambia para poder pedir lo mismo dos veces. */
data class Centro(val p: GeoPoint, val n: Int = 0, val zoom: Double? = 15.0)

fun hayInternet(ctx: Context): Boolean {
    val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
    return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
}

/** Con clave de MapTiler: mapa de calles estilo Google. Sin clave: mapa básico de OpenStreetMap. */
private fun fuenteMapa(ctx: Context): ITileSource {
    val clave = Ajustes.claveMapTiler(ctx)
    return if (clave.isBlank()) TileSourceFactory.MAPNIK
    else XYTileSource(
        "MapTilerStreets", 0, 20, 256, ".png?key=$clave",
        arrayOf("https://api.maptiler.com/maps/streets-v2/256/"),
        "© MapTiler © OpenStreetMap contributors"
    )
}

/** Mapa. Cada tramo de `segmentos` se dibuja por separado (sin unir cortes de señal). */
@Composable
fun MapaOsm(
    modifier: Modifier,
    marcadores: List<Pair<GeoPoint, String>>,
    segmentos: List<List<GeoPoint>>,
    centrar: Centro?,
    miUbicacion: Boolean = false,
    ajustar: List<GeoPoint> = emptyList(),
    onTap: ((GeoPoint) -> Unit)? = null
) {
    val ctx = LocalContext.current
    val tap = rememberUpdatedState(onTap)
    val centrarActual = rememberUpdatedState(centrar)
    val map = remember {
        Configuration.getInstance().apply {
            userAgentValue = "MiControl/0.5 (com.micontrol.app)"
            osmdroidBasePath = File(ctx.filesDir, "osmdroid")
            osmdroidTileCache = File(ctx.filesDir, "osmdroid/tiles")
        }
        MapView(ctx).apply {
            setTileSource(fuenteMapa(ctx))
            setTilesScaledToDpi(true)
            setMultiTouchControls(true)
            controller.setZoom(5.0)
            controller.setCenter(GeoPoint(-34.6, -64.0))
            overlays.add(MapEventsOverlay(object : MapEventsReceiver {
                override fun singleTapConfirmedHelper(p: GeoPoint): Boolean {
                    val f = tap.value ?: return false
                    f(p)
                    return true
                }
                override fun longPressHelper(p: GeoPoint): Boolean = false
            }))
            overlays.add(CopyrightOverlay(ctx))
        }
    }

    val lifecycle = LocalLifecycleOwner.current.lifecycle
    DisposableEffect(lifecycle) {
        val obs = LifecycleEventObserver { _, e ->
            when (e) {
                Lifecycle.Event.ON_RESUME -> map.onResume()
                Lifecycle.Event.ON_PAUSE -> map.onPause()
                else -> {}
            }
        }
        lifecycle.addObserver(obs)
        onDispose { lifecycle.removeObserver(obs); map.onDetach() }
    }

    // Punto azul con la ubicación del teléfono (y se centra ahí si nadie pidió otra cosa)
    val miLoc = remember {
        MyLocationNewOverlay(GpsMyLocationProvider(ctx), map)
    }
    DisposableEffect(miUbicacion) {
        if (miUbicacion) {
            miLoc.enableMyLocation()
            map.overlays.add(miLoc)
            miLoc.runOnFirstFix {
                map.post {
                    val p = miLoc.myLocation
                    if (p != null && centrarActual.value == null) {
                        map.controller.setZoom(15.0); map.controller.animateTo(p)
                    }
                }
            }
        }
        onDispose { miLoc.disableMyLocation(); map.overlays.remove(miLoc) }
    }

    LaunchedEffect(ajustar) {
        if (ajustar.size > 1) map.post { map.zoomToBoundingBox(BoundingBox.fromGeoPoints(ajustar), false, 100) }
    }

    LaunchedEffect(centrar) {
        centrar?.let { c ->
            c.zoom?.let { z -> map.controller.setZoom(z) }
            map.controller.setCenter(c.p)
        }
    }

    Box(modifier.clipToBounds()) {
    AndroidView(factory = { map }, modifier = Modifier.fillMaxSize(), update = { m ->
        m.overlays.removeAll { it is Marker || it is Polyline }
        segmentos.filter { it.size > 1 }.forEach { seg ->
            m.overlays.add(Polyline().apply {
                setPoints(seg)
                outlinePaint.color = 0xFF1A73E8.toInt()
                outlinePaint.strokeWidth = 12f
            })
        }
        marcadores.forEach { (p, t) ->
            m.overlays.add(Marker(m).apply {
                position = p
                title = t
                setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
            })
        }
        m.invalidate()
    })
    }
}

/** Pantalla completa para elegir una ubicación: buscar una dirección o tocar el mapa. */
@Composable
fun SelectorUbicacion(titulo: String, onDismiss: () -> Unit, onElegido: (String, Double, Double) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var q by remember { mutableStateOf("") }
    var resultados by remember { mutableStateOf<List<Geo.Lugar>>(emptyList()) }
    var punto by remember { mutableStateOf<GeoPoint?>(null) }
    var texto by remember { mutableStateOf("") }
    var centro by remember { mutableStateOf<Centro?>(null) }
    var buscando by remember { mutableStateOf(false) }
    var sinResultados by remember { mutableStateOf(false) }
    var permiso by remember { mutableStateOf(Gps.tieneUbicacion(ctx)) }
    var cuenta by remember { mutableStateOf(0) }
    val pedir = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        permiso = Gps.tieneUbicacion(ctx)
    }
    val permisosUbicacion = arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
    LaunchedEffect(Unit) { if (!permiso) pedir.launch(permisosUbicacion) }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(titulo, style = MaterialTheme.typography.titleLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(q, { q = it }, Modifier.weight(1f), label = { Text("Buscar dirección o lugar") }, singleLine = true)
                    Button({
                        scope.launch {
                            buscando = true
                            resultados = Geo.buscar(q)
                            sinResultados = resultados.isEmpty()
                            buscando = false
                        }
                    }, enabled = q.isNotBlank() && !buscando) { Text("Buscar") }
                }
                if (!hayInternet(ctx)) Text("Sin internet: el mapa y la búsqueda no funcionan.", color = MaterialTheme.colorScheme.error)
                if (Ajustes.claveMapTiler(ctx).isBlank()) Text("Mapa básico. Para el estilo Google cargá la clave en Configuración.", style = MaterialTheme.typography.bodySmall)
                if (sinResultados) Text("No se encontró nada. Probá con otra dirección o tocá el mapa.", style = MaterialTheme.typography.bodySmall)
                resultados.forEach { l ->
                    TextButton({
                        punto = GeoPoint(l.lat, l.lng); texto = l.nombre
                        cuenta++; centro = Centro(punto!!, cuenta)
                        resultados = emptyList(); sinResultados = false
                    }) { Text(l.nombre, maxLines = 2) }
                }
                MapaOsm(
                    Modifier.weight(1f).fillMaxWidth(),
                    marcadores = listOfNotNull(punto?.let { it to "Elegido" }),
                    segmentos = emptyList(),
                    centrar = centro,
                    miUbicacion = permiso,
                    onTap = { p ->
                        punto = p
                        texto = "%.5f, %.5f".format(p.latitude, p.longitude)
                        scope.launch { Geo.direccion(p.latitude, p.longitude)?.let { if (punto == p) texto = it } }
                    }
                )
                Text(if (punto == null) "Tocá el mapa para marcar el lugar." else texto, maxLines = 3)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton({
                        if (!permiso) pedir.launch(permisosUbicacion)
                        else {
                            val u = Gps.ultimaUbicacion(ctx)
                            if (u != null) { cuenta++; centro = Centro(GeoPoint(u.latitude, u.longitude), cuenta) }
                            else Toast.makeText(ctx, "Todavía no hay ubicación. Encendé el GPS y esperá unos segundos.", Toast.LENGTH_LONG).show()
                        }
                    }, Modifier.weight(1f).height(52.dp)) { Text("Mi ubicación") }
                    Button(
                        { onElegido(texto, punto!!.latitude, punto!!.longitude) },
                        Modifier.weight(1f).height(52.dp), enabled = punto != null,
                        colors = ButtonDefaults.buttonColors(containerColor = Verde)
                    ) { Text("Usar este lugar") }
                }
                TextButton(onDismiss, Modifier.fillMaxWidth()) { Text("Cancelar") }
            }
        }
    }
}

private val horaFmt = SimpleDateFormat("dd/MM HH:mm", Locale("es", "AR"))
private fun hora(ms: Long) = horaFmt.format(Date(ms))

/**
 * Mapa del viaje. En un viaje en curso sigue tu posición en vivo y suma los km recorridos (GPS).
 * Después permite ver el camino, a qué hora pasaste por cada lugar y dónde te detuviste.
 */
@Composable
fun MapaRecorrido(
    v: Viaje, paradas: List<Parada>, puntos: List<PuntoGps>,
    enCurso: Boolean, rastreando: Boolean, onDismiss: () -> Unit
) {
    val ctx = LocalContext.current
    var seguir by remember { mutableStateOf(enCurso) }
    var indice by remember { mutableStateOf<Int?>(null) }
    var vista by remember { mutableStateOf("mapa") }
    var yaCentro by remember { mutableStateOf(false) }
    LaunchedEffect(puntos.size) { if (puntos.isNotEmpty()) yaCentro = true }

    val km = remember(puntos.size) { Calculos.distanciaGpsKm(puntos) }
    val segs = remember(puntos.size) { Calculos.segmentos(puntos).map { s -> s.map { GeoPoint(it.lat, it.lng) } } }
    val detenciones = remember(puntos.size) { Calculos.detenciones(puntos) }
    val kmHora = remember(puntos.size) { Calculos.kmPorHora(puntos) }
    val ajustar = remember(puntos.size, enCurso) {
        if (!enCurso && puntos.size > 1) puntos.map { GeoPoint(it.lat, it.lng) } else emptyList()
    }

    val idx = indice?.coerceIn(0, maxOf(0, puntos.lastIndex))
    val sel = if (idx != null && puntos.isNotEmpty()) puntos[idx] else null

    val marc = mutableListOf<Pair<GeoPoint, String>>()
    val oLat = v.origenLat; val oLng = v.origenLng
    val dLat = v.destinoLat; val dLng = v.destinoLng
    if (oLat != null && oLng != null) marc.add(GeoPoint(oLat, oLng) to "Origen: ${v.origen}")
    paradas.forEachIndexed { i, p -> marc.add(GeoPoint(p.lat, p.lng) to "Parada ${i + 1}: ${p.nombre}") }
    if (dLat != null && dLng != null) marc.add(GeoPoint(dLat, dLng) to "Destino: ${v.destino}")
    puntos.lastOrNull()?.let { marc.add(GeoPoint(it.lat, it.lng) to "Última posición: ${hora(it.tiempo)}") }
    if (sel != null) marc.add(GeoPoint(sel.lat, sel.lng) to "Pasaste a las ${hora(sel.tiempo)}")

    val ultimoGeo = puntos.lastOrNull()?.let { GeoPoint(it.lat, it.lng) }
    val centro: Centro? = when {
        sel != null -> Centro(GeoPoint(sel.lat, sel.lng), (idx ?: 0) + 1, null)
        enCurso && seguir && ultimoGeo != null -> Centro(ultimoGeo, puntos.size, if (yaCentro) null else 16.0)
        puntos.isEmpty() -> marc.firstOrNull()?.first?.let { Centro(it, 0, 12.0) }
        else -> null
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(if (enCurso) "Mapa en vivo" else "Recorrido del viaje", style = MaterialTheme.typography.titleLarge)
                if (!hayInternet(ctx)) Text("Sin internet: el mapa no se ve, pero los datos están guardados.", color = MaterialTheme.colorScheme.error)
                if (enCurso && !rastreando) Text("El seguimiento GPS está detenido: no se está registrando el recorrido.", color = MaterialTheme.colorScheme.error)
                Text("Km recorridos (GPS, referencia): ${"%.1f".format(km)} km", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                if (puntos.isNotEmpty()) {
                    Text("Registrado de ${hora(puntos.first().tiempo)} a ${hora(puntos.last().tiempo)}", style = MaterialTheme.typography.bodySmall)
                }
                if (enCurso) Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Switch(seguir, { seguir = it; if (it) indice = null })
                    Text("Seguir mi posición")
                }

                if (vista == "mapa") {
                    MapaOsm(
                        Modifier.weight(1f).fillMaxWidth(), marc, segs, centro,
                        miUbicacion = enCurso, ajustar = ajustar,
                        onTap = { g ->
                            if (puntos.isNotEmpty()) {
                                val r = FloatArray(1)
                                var mejor = 0
                                var md = Float.MAX_VALUE
                                puntos.forEachIndexed { i, pt ->
                                    Location.distanceBetween(g.latitude, g.longitude, pt.lat, pt.lng, r)
                                    if (r[0] < md) { md = r[0]; mejor = i }
                                }
                                if (md < 1000f) { indice = mejor; seguir = false }
                            }
                        }
                    )
                    if (puntos.size >= 2) {
                        Slider(
                            value = (idx ?: 0).toFloat(),
                            onValueChange = { indice = it.toInt(); seguir = false },
                            valueRange = 0f..puntos.lastIndex.toFloat()
                        )
                    }
                    Text(
                        sel?.let { "Pasaste por acá: ${hora(it.tiempo)}" }
                            ?: "Mové la barra o tocá el recorrido para ver a qué hora pasaste por ahí.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                } else {
                    LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        item { Text("Detenciones (más de 10 min en el mismo lugar)", style = MaterialTheme.typography.titleSmall) }
                        if (detenciones.isEmpty()) item { Text("No hay detenciones registradas.") }
                        items(detenciones) { d ->
                            Card(Modifier.fillMaxWidth().clickable { indice = d.idx; seguir = false; vista = "mapa" }) {
                                Column(Modifier.padding(10.dp)) {
                                    Text("${hora(d.desde)} → ${hora(d.hasta)}")
                                    Text("${(d.hasta - d.desde) / 60000} min detenido (tocá para ver dónde)", style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                        item { Text("Kilómetros por hora (GPS)", style = MaterialTheme.typography.titleSmall) }
                        if (kmHora.isEmpty()) item { Text("Todavía no hay recorrido registrado.") }
                        items(kmHora) { k ->
                            Card(Modifier.fillMaxWidth().clickable { indice = k.idx; seguir = false; vista = "mapa" }) {
                                Text("${hora(k.horaMs)} · ${"%.1f".format(k.km)} km", Modifier.padding(10.dp))
                            }
                        }
                    }
                }

                OutlinedButton({ vista = if (vista == "mapa") "detalle" else "mapa" }, Modifier.fillMaxWidth()) {
                    Text(if (vista == "mapa") "Ver horas y detenciones" else "Volver al mapa")
                }
                Button(onDismiss, Modifier.fillMaxWidth().height(52.dp)) { Text("Cerrar") }
            }
        }
    }
}
