package com.micontrol.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.micontrol.app.data.Geo
import com.micontrol.app.data.PuntoGps
import com.micontrol.app.data.Viaje
import com.micontrol.app.domain.Calculos
import kotlinx.coroutines.launch
import org.osmdroid.config.Configuration
import org.osmdroid.events.MapEventsReceiver
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.MapEventsOverlay
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline
import java.io.File

/** Mapa de OpenStreetMap. Cada tramo de `segmentos` se dibuja por separado (sin unir cortes de señal). */
@Composable
fun MapaOsm(
    modifier: Modifier,
    marcadores: List<Pair<GeoPoint, String>>,
    segmentos: List<List<GeoPoint>>,
    centrar: GeoPoint?,
    onTap: ((GeoPoint) -> Unit)? = null
) {
    val ctx = LocalContext.current
    val tap = rememberUpdatedState(onTap)
    val map = remember {
        Configuration.getInstance().apply {
            userAgentValue = "MiControl/0.2"
            osmdroidBasePath = File(ctx.filesDir, "osmdroid")
            osmdroidTileCache = File(ctx.filesDir, "osmdroid/tiles")
        }
        MapView(ctx).apply {
            setTileSource(TileSourceFactory.MAPNIK)
            setMultiTouchControls(true)
            controller.setZoom(5.0)
            controller.setCenter(GeoPoint(-34.6, -64.0))
            overlays.add(MapEventsOverlay(object : MapEventsReceiver {
                override fun singleTapConfirmedHelper(p: GeoPoint): Boolean {
                    val f = tap.value ?: return false
                    f(p)
                    return true
                }
                override fun longPressHelper(p: GeoPoint): Boolean = false
            }))
        }
    }

    val lifecycle = LocalLifecycleOwner.current.lifecycle
    DisposableEffect(lifecycle) {
        val obs = LifecycleEventObserver { _, e ->
            when (e) {
                Lifecycle.Event.ON_RESUME -> map.onResume()
                Lifecycle.Event.ON_PAUSE -> map.onPause()
                else -> {}
            }
        }
        lifecycle.addObserver(obs)
        onDispose { lifecycle.removeObserver(obs); map.onDetach() }
    }

    LaunchedEffect(centrar) {
        centrar?.let { map.controller.setZoom(15.0); map.controller.setCenter(it) }
    }

    AndroidView(factory = { map }, modifier = modifier, update = { m ->
        m.overlays.removeAll { it is Marker || it is Polyline }
        segmentos.filter { it.size > 1 }.forEach { seg ->
            m.overlays.add(Polyline().apply {
                setPoints(seg)
                outlinePaint.color = 0xFF0D2B52.toInt()
                outlinePaint.strokeWidth = 8f
            })
        }
        marcadores.forEach { (p, t) ->
            m.overlays.add(Marker(m).apply {
                position = p
                title = t
                setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
            })
        }
        m.invalidate()
    })
}

/** Pantalla completa para elegir una ubicación: buscar una dirección o tocar el mapa. */
@Composable
fun SelectorUbicacion(titulo: String, onDismiss: () -> Unit, onElegido: (String, Double, Double) -> Unit) {
    val scope = rememberCoroutineScope()
    var q by remember { mutableStateOf("") }
    var resultados by remember { mutableStateOf<List<Geo.Lugar>>(emptyList()) }
    var punto by remember { mutableStateOf<GeoPoint?>(null) }
    var texto by remember { mutableStateOf("") }
    var centro by remember { mutableStateOf<GeoPoint?>(null) }
    var buscando by remember { mutableStateOf(false) }
    var sinResultados by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(titulo, style = MaterialTheme.typography.titleLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(q, { q = it }, Modifier.weight(1f), label = { Text("Buscar dirección o lugar") }, singleLine = true)
                    Button({
                        scope.launch {
                            buscando = true
                            resultados = Geo.buscar(q)
                            sinResultados = resultados.isEmpty()
                            buscando = false
                        }
                    }, enabled = q.isNotBlank() && !buscando) { Text("Buscar") }
                }
                if (sinResultados) Text("No se encontró nada (hace falta internet). Podés tocar el mapa.", style = MaterialTheme.typography.bodySmall)
                resultados.forEach { l ->
                    TextButton({
                        punto = GeoPoint(l.lat, l.lng); texto = l.nombre; centro = punto
                        resultados = emptyList(); sinResultados = false
                    }) { Text(l.nombre, maxLines = 2) }
                }
                MapaOsm(
                    Modifier.weight(1f).fillMaxWidth(),
                    marcadores = listOfNotNull(punto?.let { it to "Elegido" }),
                    segmentos = emptyList(),
                    centrar = centro,
                    onTap = { p ->
                        punto = p
                        texto = "%.5f, %.5f".format(p.latitude, p.longitude)
                        scope.launch { Geo.direccion(p.latitude, p.longitude)?.let { if (punto == p) texto = it } }
                    }
                )
                Text(if (punto == null) "Tocá el mapa para marcar el lugar." else texto, maxLines = 3)
                Button(
                    { onElegido(texto, punto!!.latitude, punto!!.longitude) },
                    Modifier.fillMaxWidth().height(52.dp), enabled = punto != null,
                    colors = ButtonDefaults.buttonColors(containerColor = Verde)
                ) { Text("Usar esta ubicación") }
                TextButton(onDismiss, Modifier.fillMaxWidth()) { Text("Cancelar") }
            }
        }
    }
}

/** Mapa del viaje: origen, destino y recorrido GPS registrado. */
@Composable
fun MapaRecorrido(v: Viaje, puntos: List<PuntoGps>, onDismiss: () -> Unit) {
    val marc = mutableListOf<Pair<GeoPoint, String>>()
    val oLat = v.origenLat; val oLng = v.origenLng
    val dLat = v.destinoLat; val dLng = v.destinoLng
    if (oLat != null && oLng != null) marc.add(GeoPoint(oLat, oLng) to "Origen: ${v.origen}")
    if (dLat != null && dLng != null) marc.add(GeoPoint(dLat, dLng) to "Destino: ${v.destino}")
    puntos.lastOrNull()?.let { marc.add(GeoPoint(it.lat, it.lng) to "Última posición registrada") }
    val segs = Calculos.segmentos(puntos).map { s -> s.map { GeoPoint(it.lat, it.lng) } }
    val centro = puntos.lastOrNull()?.let { GeoPoint(it.lat, it.lng) } ?: marc.firstOrNull()?.first

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Recorrido GPS registrado", style = MaterialTheme.typography.titleLarge)
                MapaOsm(Modifier.weight(1f).fillMaxWidth(), marc, segs, centro)
                Text(
                    "Sin internet no se ven los mapas, pero los puntos igual se guardan. " +
                        "Donde se perdió la señal GPS el recorrido queda cortado.",
                    style = MaterialTheme.typography.bodySmall
                )
                Button(onDismiss, Modifier.fillMaxWidth().height(52.dp)) { Text("Cerrar") }
            }
        }
    }
}
