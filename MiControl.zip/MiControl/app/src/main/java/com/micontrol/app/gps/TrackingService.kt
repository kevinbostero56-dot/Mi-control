package com.micontrol.app.gps

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.micontrol.app.data.AppDatabase
import com.micontrol.app.data.PuntoGps
import com.micontrol.app.ui.MainActivity
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow

/** Registra el recorrido GPS en segundo plano (servicio en primer plano, con notificación). */
class TrackingService : Service() {

    companion object {
        const val EXTRA = "viajeId"
        const val EXTRA_PERFIL = "perfilId"
        private const val CANAL = "gps"
        /** Id del viaje que se está siguiendo, o null si no hay seguimiento. */
        val siguiendo = MutableStateFlow<String?>(null)
    }

    private var lm: LocationManager? = null
    private var viajeId: String? = null
    private var perfilId: String? = null
    private var ultimo: Location? = null
    private var despierto: PowerManager.WakeLock? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val listener = object : LocationListener {
        override fun onLocationChanged(l: Location) {
            val id = viajeId ?: return
            val perfil = perfilId ?: return
            if (l.hasAccuracy() && l.accuracy > 100f) return   // señal mala: se descarta
            // Puntos repetidos: misma posición que el anterior, no se guarda
            ultimo?.let { u -> if (u.latitude == l.latitude && u.longitude == l.longitude) return }
            ultimo = l
            scope.launch {
                try {
                    // Siempre en la base del perfil que inició el seguimiento (aunque se cambie de perfil)
                    AppDatabase.get(applicationContext, perfil).puntoDao().insertar(
                        PuntoGps(viajeId = id, lat = l.latitude, lng = l.longitude, precisionM = l.accuracy, tiempo = l.time)
                    )
                } catch (e: Exception) {
                    // si falla un punto no se corta el seguimiento
                }
            }
        }
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
        @Deprecated("Deprecated in Java")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val prefs = getSharedPreferences(Gps.PREFS, Context.MODE_PRIVATE)
        val id = intent?.getStringExtra(EXTRA) ?: prefs.getString(Gps.KEY_VIAJE, null)
        if (id == null) { stopSelf(); return START_NOT_STICKY }
        viajeId = id
        val perfil = intent?.getStringExtra(EXTRA_PERFIL) ?: prefs.getString(Gps.KEY_PERFIL, null) ?: com.micontrol.app.data.Perfiles.activoId(this)
        perfilId = perfil
        prefs.edit().putString(Gps.KEY_VIAJE, id).putString(Gps.KEY_PERFIL, perfil).apply()

        val canal = NotificationChannel(CANAL, "Seguimiento GPS", NotificationManager.IMPORTANCE_LOW)
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(canal)
        val abrir = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val notif = NotificationCompat.Builder(this, CANAL)
            .setContentTitle("Mi Control")
            .setContentText("Registrando el recorrido GPS del viaje")
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setOngoing(true)
            .setContentIntent(abrir)
            .build()
        try {
            startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
        } catch (e: Exception) {
            stopSelf(); return START_NOT_STICKY
        }

        // Mantiene el procesador despierto con la pantalla apagada (máximo 14 horas por si se olvida de detener)
        try {
            if (despierto == null) {
                val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
                despierto = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "MiControl:gps").apply { acquire(14L * 3600 * 1000) }
            }
        } catch (e: Exception) {
            // sin wake lock igual funciona
        }

        lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        try {
            lm?.removeUpdates(listener)
            lm?.requestLocationUpdates(LocationManager.GPS_PROVIDER, 15_000L, 25f, listener, Looper.getMainLooper())
        } catch (e: SecurityException) {
            stopSelf(); return START_NOT_STICKY
        }
        siguiendo.value = id
        return START_STICKY
    }

    override fun onDestroy() {
        try { despierto?.takeIf { it.isHeld }?.release() } catch (e: Exception) { /* nada */ }
        despierto = null
        lm?.removeUpdates(listener)
        siguiendo.value = null
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
