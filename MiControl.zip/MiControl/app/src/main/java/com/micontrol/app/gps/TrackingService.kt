package com.micontrol.app.gps

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import com.micontrol.app.data.AppDatabase
import com.micontrol.app.data.PuntoGps
import com.micontrol.app.ui.MainActivity
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow

/** Registra el recorrido GPS en segundo plano (servicio en primer plano, con notificación). */
class TrackingService : Service() {

    companion object {
        const val EXTRA = "viajeId"
        private const val CANAL = "gps"
        /** Id del viaje que se está siguiendo, o null si no hay seguimiento. */
        val siguiendo = MutableStateFlow<String?>(null)
    }

    private var lm: LocationManager? = null
    private var viajeId: String? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val listener = object : LocationListener {
        override fun onLocationChanged(l: Location) {
            val id = viajeId ?: return
            if (l.hasAccuracy() && l.accuracy > 100f) return   // señal mala: se descarta
            scope.launch {
                try {
                    AppDatabase.get(applicationContext).puntoDao().insertar(
                        PuntoGps(viajeId = id, lat = l.latitude, lng = l.longitude, precisionM = l.accuracy, tiempo = l.time)
                    )
                } catch (e: Exception) {
                    // si falla un punto no se corta el seguimiento
                }
            }
        }
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
        @Deprecated("Deprecated in Java")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val prefs = getSharedPreferences(Gps.PREFS, Context.MODE_PRIVATE)
        val id = intent?.getStringExtra(EXTRA) ?: prefs.getString(Gps.KEY_VIAJE, null)
        if (id == null) { stopSelf(); return START_NOT_STICKY }
        viajeId = id
        prefs.edit().putString(Gps.KEY_VIAJE, id).apply()

        val canal = NotificationChannel(CANAL, "Seguimiento GPS", NotificationManager.IMPORTANCE_LOW)
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(canal)
        val abrir = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val notif = NotificationCompat.Builder(this, CANAL)
            .setContentTitle("Mi Control")
            .setContentText("Registrando el recorrido GPS del viaje")
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setOngoing(true)
            .setContentIntent(abrir)
            .build()
        try {
            startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
        } catch (e: Exception) {
            stopSelf(); return START_NOT_STICKY
        }

        lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        try {
            lm?.removeUpdates(listener)
            lm?.requestLocationUpdates(LocationManager.GPS_PROVIDER, 15_000L, 25f, listener, Looper.getMainLooper())
        } catch (e: SecurityException) {
            stopSelf(); return START_NOT_STICKY
        }
        siguiendo.value = id
        return START_STICKY
    }

    override fun onDestroy() {
        lm?.removeUpdates(listener)
        siguiendo.value = null
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
