package com.micontrol.app.ui

import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavController
import com.micontrol.app.data.Exportar
import com.micontrol.app.data.Perfiles
import com.micontrol.app.pdf.InformePdf
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import com.micontrol.app.data.Adelanto
import com.micontrol.app.data.Gasto
import com.micontrol.app.data.Jornada
import com.micontrol.app.data.Viaje
import com.micontrol.app.domain.Calculos
import java.time.Instant
import java.time.YearMonth
import java.time.ZoneId
import java.time.format.TextStyle
import java.util.Locale
import kotlin.math.abs

private fun mesDe(ms: Long): YearMonth = YearMonth.from(Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()))

/** Resumen del mes en Inicio (con selector de mes) y los últimos tres viajes con sus km, gastos y plata recibida. */
@Composable
fun ResumenMesInicio(
    viajes: List<Viaje>, jornadas: List<Jornada>, gastos: List<Gasto>, adelantos: List<Adelanto>, nav: NavController
) {
    var mes by remember { mutableStateOf(YearMonth.now()) }
    val viajesMes = viajes.filter { mesDe(it.inicio) == mes }
    val jornadasMes = jornadas.filter { runCatching { YearMonth.parse(it.fecha.take(7)) }.getOrNull() == mes }
    val gastosMes = gastos.filter { mesDe(it.fechaHora) == mes }
    val adelantosMes = adelantos.filter { mesDe(it.fechaHora) == mes }
    val kmMes = viajesMes.filter { it.estado == Viaje.Estado.FINALIZADO }.sumOf { Calculos.kmDecimas(it) ?: 0L }
    val trabajados = jornadasMes.sumOf { Calculos.minutosTrabajados(it) }
    val extras = Calculos.extrasTotales(jornadasMes)
    val gastado = gastosMes.sumOf { it.importeCentavos }
    val recibido = adelantosMes.sumOf { it.importeCentavos }
    val saldo = recibido - gastado
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var pdfListo by remember { mutableStateOf<File?>(null) }
    var generando by remember { mutableStateOf(false) }
    val nombreMes = mes.month.getDisplayName(TextStyle.FULL, Locale("es", "AR")).replaceFirstChar { it.uppercase() } + " " + mes.year

    @Composable
    fun Fila(t: String, v: String) {
        Row(Modifier.fillMaxWidth()) { Text(t, Modifier.weight(1f)); Text(v, fontWeight = FontWeight.Bold) }
    }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton({ mes = mes.minusMonths(1) }) { Text("◀") }
                Text(nombreMes, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                TextButton({ mes = mes.plusMonths(1) }, enabled = mes < YearMonth.now()) { Text("▶") }
            }
            Fila("Kilómetros (odómetro)", Calculos.decimasTxt(kmMes) + " km")
            Fila("Horas trabajadas", Calculos.hhmm(trabajados) + " h")
            Fila("Horas extras", Calculos.hhmm(extras) + " h")
            Fila("Gastos", Calculos.pesos(gastado))
            Fila("Plata recibida", Calculos.pesos(recibido))
            Fila("Viajes", "${viajesMes.size}")
            Divider(Modifier.padding(vertical = 4.dp))
            Text(
                when {
                    saldo > 0 -> "A devolver a la empresa: ${Calculos.pesos(saldo)}"
                    saldo < 0 -> "La empresa te debe: ${Calculos.pesos(abs(saldo))}"
                    else -> "Estás a mano con la empresa"
                },
                fontWeight = FontWeight.Bold,
                color = when { saldo > 0 -> Ambar; saldo < 0 -> Verde; else -> MaterialTheme.colorScheme.onSurfaceVariant }
            )
            if (viajesMes.isNotEmpty()) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    BotonSec({
                        if (generando) return@BotonSec
                        generando = true
                        scope.launch {
                            try {
                                pdfListo = withContext(Dispatchers.IO) {
                                    InformePdf.generarMes(ctx, mes, viajesMes, jornadasMes, gastosMes, adelantosMes, Perfiles.activo(ctx))
                                }
                            } catch (e: Exception) {
                                Toast.makeText(ctx, "No se pudo generar el informe.", Toast.LENGTH_LONG).show()
                            }
                            generando = false
                        }
                    }, Modifier.weight(1f)) { Text(if (generando) "Generando…" else "📄 Informe del mes", maxLines = 1) }
                    BotonSec({
                        try {
                            Exportar.compartir(ctx, Exportar.viajes(ctx, "${mes.year}-${"%02d".format(mes.monthValue)}", viajesMes, gastosMes))
                        } catch (e: Exception) {
                            Toast.makeText(ctx, "No se pudo exportar.", Toast.LENGTH_LONG).show()
                        }
                    }, Modifier.weight(1f)) { Text("📊 Excel", maxLines = 1) }
                }
            }
        }
    }

    pdfListo?.let { f ->
        AlertDialog(
            onDismissRequest = { pdfListo = null },
            title = { Text("Informe de $nombreMes") },
            text = { Text("Primera página con la tabla de viajes y los totales; después una sección por cada viaje.") },
            confirmButton = {
                Column(horizontalAlignment = Alignment.End) {
                    TextButton({ InformePdf.compartir(ctx, f); pdfListo = null }) { Text("Compartir PDF") }
                    TextButton({ InformePdf.compartirWhatsApp(ctx, f); pdfListo = null }) { Text("💬 Mandar por WhatsApp") }
                    TextButton({
                        val ok = InformePdf.guardarEnDescargas(ctx, f)
                        Toast.makeText(ctx, if (ok) "Guardado en Descargas" else "No se pudo guardar", Toast.LENGTH_LONG).show()
                        pdfListo = null
                    }) { Text("Guardar en Descargas") }
                }
            },
            dismissButton = { TextButton({ pdfListo = null }) { Text("Cerrar") } }
        )
    }

    if (viajes.isNotEmpty()) {
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Últimos viajes", style = MaterialTheme.typography.titleMedium)
                viajes.take(3).forEach { v ->
                    val g = gastos.filter { it.viajeId == v.id }.sumOf { it.importeCentavos }
                    val a = adelantos.filter { it.viajeId == v.id }.sumOf { it.importeCentavos }
                    Column(Modifier.fillMaxWidth().clickable { nav.navigate("viaje/${v.id}") }.padding(vertical = 4.dp)) {
                        Text(v.nombre, fontWeight = FontWeight.Bold, maxLines = 1)
                        Text(
                            (Calculos.kmViajeTxt(v)?.let { "$it km" } ?: "en curso") + " · gastos ${Calculos.pesos(g)} · recibido ${Calculos.pesos(a)}",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }
    }
}
