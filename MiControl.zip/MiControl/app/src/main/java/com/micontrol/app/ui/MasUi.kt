package com.micontrol.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

private class OpcionMas(val icono: String, val titulo: String, val detalle: String, val ruta: String)

/** Pestaña "Más": lo que no se usa todos los días, ordenado y con letra grande. */
@Composable
fun MasScreen(vm: MainViewModel, nav: NavController) {
    val opciones = listOf(
        OpcionMas("📊", "Resumen del mes", "Viajes, km, horas extras, gastos, combustible y saldo. PDF y Excel para la empresa.", "resumen"),
        OpcionMas("🔧", "Control del camión", "Mantenimientos y vencimientos (VTV, seguro, licencia).", "camion"),
        OpcionMas("🤖", "Asistente", "Consejos, hoteles con cochera cerca y carga rápida escribiendo.", "asistente"),
        OpcionMas("⚙️", "Ajustes", "Perfil, aspecto, copias de seguridad, ver desde la computadora, compartir la app y permisos.", "ajustes")
    )
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Más", style = MaterialTheme.typography.headlineSmall, color = Color.White)
        opciones.forEach { o ->
            Card(Modifier.fillMaxWidth().clickable { nav.navigate(o.ruta) }) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text(o.icono, fontSize = 30.sp)
                    Column(Modifier.weight(1f)) {
                        Text(o.titulo, style = MaterialTheme.typography.titleMedium, color = Color.White)
                        Text(o.detalle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text("›", fontSize = 28.sp, color = MaterialTheme.colorScheme.primary)
                }
            }
        }
    }
}
