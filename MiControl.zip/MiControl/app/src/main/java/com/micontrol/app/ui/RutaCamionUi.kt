package com.micontrol.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.micontrol.app.data.Ajustes
import com.micontrol.app.data.RutaCamion
import org.osmdroid.util.GeoPoint

private sealed interface EstadoRuta {
    object Cargando : EstadoRuta
    data class Error(val msg: String, val faltaClave: Boolean) : EstadoRuta
    data class Ok(val r: RutaCamion.Resultado) : EstadoRuta
}

private fun duracion(seg: Double): String {
    val h = (seg / 3600).toInt()
    val m = ((seg % 3600) / 60).toInt()
    return if (h > 0) "$h h $m min" else "$m min"
}

private fun distancia(m: Double): String = if (m >= 1000) "%.1f km".format(m / 1000) else "%.0f m".format(m)

/** Calcula y muestra la ruta para camión pasando por todos los puntos (origen, paradas, destino). */
@Composable
fun RutaCamionDialog(puntos: List<Pair<String, GeoPoint>>, onDismiss: () -> Unit, onAjustes: () -> Unit) {
    val ctx = LocalContext.current
    val clave = remember { Ajustes.claveOrs(ctx) }
    val alto = remember { Ajustes.alturaCamion(ctx) }
    val largo = remember { Ajustes.largoCamion(ctx) }
    var estado by remember { mutableStateOf<EstadoRuta>(EstadoRuta.Cargando) }
    var verPasos by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        estado = if (clave.isBlank()) {
            EstadoRuta.Error("Falta cargar la clave de OpenRouteService.", true)
        } else {
            try {
                EstadoRuta.Ok(RutaCamion.calcular(clave, alto, largo, puntos.map { it.second.latitude to it.second.longitude }))
            } catch (e: RutaCamion.ErrorRuta) {
                EstadoRuta.Error(e.mensaje, false)
            }
        }
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Ruta para camión", style = MaterialTheme.typography.titleLarge)
                Text("Para ${"%.2f".format(alto)} m de alto y ${"%.2f".format(largo)} m de largo", style = MaterialTheme.typography.bodySmall)

                when (val e = estado) {
                    is EstadoRuta.Cargando -> {
                        Spacer(Modifier.height(24.dp))
                        CircularProgressIndicator()
                        Text("Calculando la ruta…")
                        Spacer(Modifier.weight(1f))
                    }
                    is EstadoRuta.Error -> {
                        Text(e.msg, color = MaterialTheme.colorScheme.error)
                        if (e.faltaClave) Button(onAjustes, Modifier.fillMaxWidth().height(52.dp)) { Text("Ir a Configuración") }
                        Spacer(Modifier.weight(1f))
                    }
                    is EstadoRuta.Ok -> {
                        val ruta = remember(e) { e.r.puntos.map { GeoPoint(it.first, it.second) } }
                        val marc = remember(e) {
                            puntos.mapIndexed { i, par ->
                                val rol = when (i) { 0 -> "Origen"; puntos.lastIndex -> "Destino"; else -> "Parada $i" }
                                par.second to "$rol: ${par.first}"
                            }
                        }
                        Text("${distancia(e.r.metros)} · ${duracion(e.r.segundos)}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        e.r.avisos.forEach { Text("Aviso: $it", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                        OutlinedButton({ verPasos = !verPasos }, Modifier.fillMaxWidth()) {
                            Text(if (verPasos) "Ver mapa" else "Ver indicaciones paso a paso")
                        }
                        if (verPasos) {
                            LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                itemsIndexed(e.r.pasos) { i, p -> Text("${i + 1}. ${p.texto} (${distancia(p.metros)})") }
                            }
                        } else {
                            MapaOsm(Modifier.weight(1f).fillMaxWidth(), marc, listOf(ruta), null, ajustar = ruta)
                        }
                    }
                }

                Text(
                    "Es una sugerencia: si el mapa no tiene cargadas las restricciones de altura de un puente o túnel, " +
                        "puede no avisarte. Respetá siempre los carteles.",
                    style = MaterialTheme.typography.bodySmall
                )
                Button(onDismiss, Modifier.fillMaxWidth().height(52.dp)) { Text("Cerrar") }
            }
        }
    }
}
