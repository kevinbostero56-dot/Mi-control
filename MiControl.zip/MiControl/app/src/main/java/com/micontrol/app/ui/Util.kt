package com.micontrol.app.ui

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast

/** Abre el punto en la app de Google Maps (para comparar). Si no está instalada, lo abre en el navegador. */
fun abrirEnGoogleMaps(ctx: Context, lat: Double, lng: Double) {
    val uri = Uri.parse("https://www.google.com/maps/search/?api=1&query=${"%.7f".format(java.util.Locale.US, lat)},${"%.7f".format(java.util.Locale.US, lng)}")
    try {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, uri).setPackage("com.google.android.apps.maps"))
    } catch (e: ActivityNotFoundException) {
        try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (e2: Exception) {
            Toast.makeText(ctx, "No se pudo abrir Google Maps.", Toast.LENGTH_LONG).show()
        }
    }
}

/** Pide al sistema que no limite la batería de Mi Control (así el GPS no se corta en viajes largos). */
fun pedirBateriaSinRestricciones(ctx: Context) {
    val paquete = Uri.parse("package:${ctx.packageName}")
    try {
        ctx.startActivity(Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, paquete).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        try {
            ctx.startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, paquete).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e2: Exception) {
            Toast.makeText(ctx, "No se pudo abrir los ajustes de batería.", Toast.LENGTH_LONG).show()
        }
    }
}
