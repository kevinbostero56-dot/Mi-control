package com.micontrol.app.ui

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast

/** Abre el punto en la app de Google Maps (para comparar). Si no está instalada, lo abre en el navegador. */
fun abrirEnGoogleMaps(ctx: Context, lat: Double, lng: Double) {
    val uri = Uri.parse("https://www.google.com/maps/search/?api=1&query=${"%.7f".format(java.util.Locale.US, lat)},${"%.7f".format(java.util.Locale.US, lng)}")
    try {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, uri).setPackage("com.google.android.apps.maps"))
    } catch (e: ActivityNotFoundException) {
        try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (e2: Exception) {
            Toast.makeText(ctx, "No se pudo abrir Google Maps.", Toast.LENGTH_LONG).show()
        }
    }
}

/** Pide al sistema que no limite la batería de Mi Control (así el GPS no se corta en viajes largos). */
fun pedirBateriaSinRestricciones(ctx: Context) {
    val paquete = Uri.parse("package:${ctx.packageName}")
    try {
        ctx.startActivity(Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, paquete).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        try {
            ctx.startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, paquete).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e2: Exception) {
            Toast.makeText(ctx, "No se pudo abrir los ajustes de batería.", Toast.LENGTH_LONG).show()
        }
    }
}

/** Google Maps acepta origen + 9 paradas + destino: 11 puntos por tramo. Cada tramo empieza donde terminó el anterior. */
private const val PUNTOS_POR_TRAMO = 11

fun cantidadTramos(cantidadPuntos: Int): Int =
    if (cantidadPuntos <= PUNTOS_POR_TRAMO) 1 else ((cantidadPuntos - 1) + (PUNTOS_POR_TRAMO - 2)) / (PUNTOS_POR_TRAMO - 1)

/**
 * Abre un recorrido con varias paradas en Google Maps (sin API paga). Si hay más de 9 paradas intermedias, el recorrido se
 * parte en tramos: `tramo` es el número de tramo (0 = el primero) y el siguiente arranca donde terminó el anterior.
 */
fun abrirRecorridoEnGoogleMaps(ctx: Context, puntosTodos: List<Pair<Double, Double>>, tramo: Int = 0) {
    if (puntosTodos.isEmpty()) {
        Toast.makeText(ctx, "No hay paradas para abrir.", Toast.LENGTH_SHORT).show()
        return
    }
    val total = cantidadTramos(puntosTodos.size)
    val t = tramo.coerceIn(0, total - 1)
    val desde = t * (PUNTOS_POR_TRAMO - 1)
    val puntos = puntosTodos.subList(desde, minOf(desde + PUNTOS_POR_TRAMO, puntosTodos.size))
    fun p(x: Pair<Double, Double>) = "%.6f,%.6f".format(java.util.Locale.US, x.first, x.second)
    val destino = puntos.last()
    val resto = puntos.dropLast(1)
    val origen = resto.firstOrNull()
    val medio = if (resto.size > 1) resto.drop(1) else emptyList()
    val sb = StringBuilder("https://www.google.com/maps/dir/?api=1&travelmode=driving&destination=${p(destino)}")
    if (origen != null) sb.append("&origin=${p(origen)}")
    if (medio.isNotEmpty()) sb.append("&waypoints=").append(medio.joinToString("%7C") { p(it) })
    if (total > 1) Toast.makeText(ctx, "Tramo ${t + 1} de $total", Toast.LENGTH_SHORT).show()
    val uri = Uri.parse(sb.toString())
    try {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, uri).setPackage("com.google.android.apps.maps"))
    } catch (e: ActivityNotFoundException) {
        try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (e2: Exception) {
            Toast.makeText(ctx, "No se pudo abrir Google Maps.", Toast.LENGTH_LONG).show()
        }
    }
}
