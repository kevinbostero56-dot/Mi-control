package com.micontrol.app.work

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.micontrol.app.data.Ajustes
import com.micontrol.app.data.AppDatabase
import com.micontrol.app.data.Perfiles
import com.micontrol.app.data.Respaldo
import com.micontrol.app.domain.Avisos
import com.micontrol.app.ui.MainActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

/** Tarea diaria: copia de seguridad semanal y avisos (vencimientos, service, gastos sin cargar). */
object Tareas {
    private const val CANAL = "avisos"

    fun programar(ctx: Context) {
        val pedido = PeriodicWorkRequestBuilder<TareaDiaria>(24, TimeUnit.HOURS).build()
        WorkManager.getInstance(ctx.applicationContext)
            .enqueueUniquePeriodicWork("mi_control_diaria", ExistingPeriodicWorkPolicy.KEEP, pedido)
    }

    /** Hace lo que corresponda ahora: copia automática si toca y aviso si hay algo importante. */
    suspend fun correr(ctx: Context) = withContext(Dispatchers.IO) {
        try { Respaldo.automatica(ctx) } catch (e: Exception) { /* se reintenta mañana */ }
        try { avisarSiHaceFalta(ctx) } catch (e: Exception) { /* sin aviso */ }
    }

    private suspend fun avisarSiHaceFalta(ctx: Context) {
        if (!Ajustes.avisosActivos(ctx)) return
        if (System.currentTimeMillis() - Ajustes.ultimoAviso(ctx) < 20L * 3600 * 1000) return
        val lineas = ArrayList<String>()
        for (perfil in Perfiles.todos(ctx)) {
            val db = AppDatabase.get(ctx, perfil.id)
            val avisos = Avisos.calcular(
                db.viajeDao().todos().first(), db.gastoDao().todos().first(),
                db.mantenimientoDao().todos().first(), db.vencimientoDao().todos().first(),
                Ajustes.ultimaCopia(ctx, perfil.id)
            ).filter { it.grave }
            avisos.forEach { lineas.add(if (Perfiles.todos(ctx).size > 1) "${perfil.nombre}: ${it.texto}" else it.texto) }
        }
        if (lineas.isEmpty()) return
        if (Build_SDK_33() && ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return

        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CANAL, "Avisos de Mi Control", NotificationManager.IMPORTANCE_DEFAULT))
        val abrir = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val notif = NotificationCompat.Builder(ctx, CANAL)
            .setContentTitle("Mi Control: ${lineas.size} aviso(s) importante(s)")
            .setContentText(lineas.first())
            .setStyle(NotificationCompat.BigTextStyle().bigText(lineas.joinToString("\n")))
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(abrir)
            .setAutoCancel(true)
            .build()
        nm.notify(2, notif)
        Ajustes.marcarAviso(ctx)
    }

    @Suppress("FunctionName")
    private fun Build_SDK_33() = android.os.Build.VERSION.SDK_INT >= 33
}

class TareaDiaria(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        Tareas.correr(applicationContext)
        return Result.success()
    }
}
