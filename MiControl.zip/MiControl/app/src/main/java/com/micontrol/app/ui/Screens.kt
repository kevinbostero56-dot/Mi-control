package com.micontrol.app.ui

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import com.micontrol.app.R
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.border
import androidx.activity.result.PickVisualMediaRequest
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.micontrol.app.data.*
import com.micontrol.app.domain.Avisos
import com.micontrol.app.domain.Calculos
import com.micontrol.app.domain.Recorrido
import com.micontrol.app.gps.Gps
import com.micontrol.app.gps.TrackingService
import com.micontrol.app.pdf.InformePdf
import org.osmdroid.util.GeoPoint
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.abs
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.flowOf
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

private val fmt = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("es", "AR"))
private val fechaUi = DateTimeFormatter.ofPattern("dd/MM/yyyy")
private fun fechaHora(ms: Long) = fmt.format(ms)
private val horaSola = SimpleDateFormat("HH:mm", Locale("es", "AR"))
private fun horaCorta(ms: Long) = horaSola.format(ms)

/** Precio por litro de la última carga de combustible con litros cargados (sirve para calcular los litros solos). */
private fun precioPorLitro(gastos: List<Gasto>): Double? =
    gastos.filter { it.categoria == "Combustible" && (it.litros ?: 0.0) > 0.0 && it.importeCentavos > 0 }
        .maxByOrNull { it.fechaHora }?.let { (it.importeCentavos / 100.0) / (it.litros ?: 1.0) }

@Composable
private fun Tarjeta(titulo: String, valor: String, modifier: Modifier = Modifier) {
    Card(modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(titulo, style = MaterialTheme.typography.labelLarge)
            Text(valor, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun BotonGrande(texto: String, enabled: Boolean = true, verde: Boolean = false, onClick: () -> Unit) {
    BotonP(
        onClick, Modifier.fillMaxWidth().height(56.dp), enabled = enabled,
        colors = if (verde) ButtonDefaults.buttonColors(containerColor = Verde) else ButtonDefaults.buttonColors()
    ) { Text(texto) }
}

@Composable
private fun Campo(valor: String, onChange: (String) -> Unit, etiqueta: String, numerico: Boolean = false, modifier: Modifier = Modifier) {
    OutlinedTextField(
        valor, onChange, modifier.fillMaxWidth(), label = { Text(etiqueta) }, shape = RoundedCornerShape(14.dp),
        keyboardOptions = KeyboardOptions(keyboardType = if (numerico) KeyboardType.Number else KeyboardType.Text)
    )
}

/** Explica para qué se usa la ubicación, pide los permisos y arranca el seguimiento GPS del viaje. */
@Composable
internal fun SolicitudGps(viajeId: String?, onFin: () -> Unit) {
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (viajeId != null && Gps.tienePermiso(ctx)) Gps.iniciar(ctx, viajeId)
        else Toast.makeText(ctx, "Sin permiso de ubicación no se registra el recorrido.", Toast.LENGTH_LONG).show()
        onFin()
    }
    if (viajeId != null) AlertDialog(
        onDismissRequest = onFin,
        title = { Text("Registrar recorrido GPS") },
        text = {
            Text(
                "Mi Control va a guardar tu ubicación durante el viaje, también con la pantalla apagada, " +
                    "y vas a ver una notificación mientras esté activo. Los datos quedan solo en tu teléfono."
            )
        },
        confirmButton = {
            TextButton({
                if (Gps.tienePermiso(ctx)) { Gps.iniciar(ctx, viajeId); onFin() }
                else launcher.launch(Gps.permisos())
            }) { Text("Aceptar") }
        },
        dismissButton = { TextButton(onFin) { Text("Ahora no") } }
    )
}

/** Crea un viaje igual a otro (o su vuelta) y abre el nuevo. */
private fun repetirViaje(ctx: Context, vm: MainViewModel, nav: NavController, v: Viaje, alReves: Boolean) {
    vm.repetirViaje(v, alReves) { nuevoId ->
        if (nuevoId == null) {
            Toast.makeText(ctx, "Ya hay un viaje en curso. Terminalo antes de empezar otro.", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(ctx, if (alReves) "Viaje de vuelta creado. Revisá el odómetro." else "Viaje creado. Revisá el odómetro.", Toast.LENGTH_LONG).show()
            nav.navigate("viaje/$nuevoId")
        }
    }
}

// ---------------- HOME ----------------
@Composable
private fun Dato(icono: Int, titulo: String, valor: String, modifier: Modifier = Modifier) {
    Card(modifier) {
        Column(
            Modifier.fillMaxWidth().padding(vertical = 14.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Image(painterResource(icono), contentDescription = null, modifier = Modifier.size(76.dp))
            Text(titulo, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(
                valor, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold,
                color = Color.White, maxLines = 1, softWrap = false
            )
        }
    }
}

/** Botón grande de la pantalla de inicio. */
@Composable
private fun BotonHero(texto: String, onClick: () -> Unit) {
    val forma = RoundedCornerShape(50)
    Row(
        Modifier.fillMaxWidth().height(86.dp)
            .clip(forma)
            .background(Brush.verticalGradient(listOf(Color(0xFF28282D), Color(0xFF0C0C0E))), forma)
            .border(1.5.dp, Brush.linearGradient(listOf(Rojo, Color(0x44FFFFFF), Rojo)), forma)
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Image(painterResource(R.drawable.ic_hero_ruta), contentDescription = null, modifier = Modifier.size(64.dp))
        Box(Modifier.padding(horizontal = 14.dp).width(1.dp).height(44.dp).background(Rojo))
        Text(
            texto, Modifier.weight(1f), style = MaterialTheme.typography.titleLarge,
            fontStyle = FontStyle.Italic, color = Color.White, textAlign = TextAlign.Center
        )
        Box(Modifier.size(46.dp).border(2.dp, Rojo, CircleShape), contentAlignment = Alignment.Center) {
            Text("▶", color = Rojo, fontSize = 18.sp)
        }
    }
}

@Composable
fun HomeScreen(vm: MainViewModel, nav: NavController) {
    val viajes by vm.viajes.collectAsStateWithLifecycle()
    val jornadas by vm.todasJornadas.collectAsStateWithLifecycle()
    val gastos by vm.todosGastos.collectAsStateWithLifecycle()
    val activo = viajes.firstOrNull { it.estado == Viaje.Estado.EN_CURSO }
    val ultimo = viajes.firstOrNull { it.estado == Viaje.Estado.FINALIZADO }
    val ctx = LocalContext.current
    val perfil by vm.perfil.collectAsStateWithLifecycle()
    var perfilesVisible by remember { mutableStateOf(false) }
    var gastoRapido by remember { mutableStateOf<Gasto?>(null) }
    val jornadasActivo by remember(activo?.id) { activo?.let { vm.jornadas(it.id) } ?: flowOf(emptyList<Jornada>()) }
        .collectAsStateWithLifecycle(emptyList())
    val mants by vm.mantenimientos.collectAsStateWithLifecycle()
    val venc by vm.vencimientos.collectAsStateWithLifecycle()
    val avisos = remember(viajes, gastos, mants, venc, perfil.id) {
        Avisos.calcular(viajes, gastos, mants, venc, Ajustes.ultimaCopia(ctx, perfil.id))
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Box {
            Image(
                painterResource(R.drawable.bg_header), contentDescription = null,
                modifier = Modifier.fillMaxWidth(), contentScale = ContentScale.FillWidth
            )
            Box(
                Modifier.matchParentSize().background(
                    Brush.verticalGradient(0f to Fondo, 0.07f to Color.Transparent, 0.9f to Color.Transparent, 1f to Fondo)
                )
            )
        }
        Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(
                Modifier.fillMaxWidth().clickable { perfilesVisible = true },
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Avatar(perfil.inicial, 40.dp, perfil.id)
                Column(Modifier.weight(1f)) {
                    Text("Hola, ${perfil.nombre}", style = MaterialTheme.typography.titleMedium, color = Color.White)
                    val detalle = listOf(perfil.camion, perfil.empresa).filter { it.isNotBlank() }.joinToString(" · ")
                    if (detalle.isNotBlank()) Text(detalle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                TextButton({ perfilesVisible = true }) { Text("Cambiar") }
            }
            if (perfilesVisible) PerfilesDialog(vm) { perfilesVisible = false }
            gastoRapido?.let { g ->
                DialogoGasto(g, onDismiss = { gastoRapido = null }, onBorrar = { gastoRapido = null }, precioLitroUltimo = precioPorLitro(gastos)) {
                    vm.guardarGasto(it); gastoRapido = null
                }
            }
            if (activo != null) BotonHero("Viaje en curso") { nav.navigate("viaje/${activo.id}") }

            if (activo != null) {
                Text("${activo.nombre} · desde ${fechaHora(activo.inicio)}", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            RecorridoInicio(vm, nav, activo)
            if (activo != null) {
                val abierta = jornadasActivo.firstOrNull { it.finMin == Calculos.ABIERTA }
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("⚡ Carga rápida", style = MaterialTheme.typography.titleMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(Triple("Combustible", "⛽", "Nafta"), Triple("Peajes", "🚧", "Peaje"), Triple("Comida", "🍽️", "Comida")).forEach { (cat, ico, nombre) ->
                                BotonSec({
                                    val ultimoImporte = gastos.filter { it.categoria == cat }.maxByOrNull { it.fechaHora }?.importeCentavos ?: 0L
                                    gastoRapido = Gasto(viajeId = activo.id, fechaHora = System.currentTimeMillis(), categoria = cat, importeCentavos = ultimoImporte)
                                }, Modifier.weight(1f)) { Text("$ico $nombre", maxLines = 1) }
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            BotonSec({
                                val ultimoImporte = gastos.filter { it.categoria == "Alojamiento" }.maxByOrNull { it.fechaHora }?.importeCentavos ?: 0L
                                gastoRapido = Gasto(viajeId = activo.id, fechaHora = System.currentTimeMillis(), categoria = "Alojamiento", importeCentavos = ultimoImporte)
                            }, Modifier.weight(1f)) { Text("🏨 Hotel", maxLines = 1) }
                            BotonSec({
                                val cat = gastos.maxByOrNull { it.fechaHora }?.categoria ?: "Otros"
                                gastoRapido = Gasto(viajeId = activo.id, fechaHora = System.currentTimeMillis(), categoria = cat, importeCentavos = 0L)
                            }, Modifier.weight(1f)) { Text("➕ Otro gasto", maxLines = 1) }
                        }
                        if (abierta != null) {
                            BotonSec({ vm.finalizarJornada(abierta) }, Modifier.fillMaxWidth()) {
                                Text("⏹ Terminar la jornada (empezó ${Calculos.hhmm(abierta.inicioMin)})")
                            }
                        } else {
                            BotonSec({ vm.iniciarJornada(activo.id) }, Modifier.fillMaxWidth()) { Text("▶ Empezar una jornada nueva") }
                        }
                    }
                }
            }
            if (avisos.isNotEmpty()) {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("⚠️ Para tener en cuenta", style = MaterialTheme.typography.titleMedium)
                        avisos.take(6).forEach { a ->
                            Text(
                                "• ${a.texto}",
                                Modifier.fillMaxWidth().clickable { nav.navigate(a.destino) },
                                color = if (a.grave) MaterialTheme.colorScheme.error else Ambar,
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                        if (avisos.size > 6) Text("y ${avisos.size - 6} más…", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            val adelantosTodos by vm.todosAdelantos.collectAsStateWithLifecycle()
            ResumenMesInicio(viajes, jornadas, gastos, adelantosTodos, nav)
            BotonSec({
                val cb = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                val txt = cb.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(ctx)?.toString().orEmpty()
                if (txt.isBlank()) {
                    Toast.makeText(ctx, "Primero copiá la ubicación en WhatsApp (mantené apretado el mensaje y tocá Copiar).", Toast.LENGTH_LONG).show()
                } else {
                    vm.recibirUbicacion(txt)
                }
            }, Modifier.fillMaxWidth().height(52.dp)) { Text("📍 Pegar ubicación de WhatsApp") }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                BotonSec({ nav.navigate("asistente") }, Modifier.weight(1f).height(52.dp)) { Text("🤖 Asistente", maxLines = 1) }
                BotonSec({ nav.navigate("camion") }, Modifier.weight(1f).height(52.dp)) { Text("🔧 Camión", maxLines = 1) }
                BotonSec({ nav.navigate("resumen") }, Modifier.weight(1f).height(52.dp)) { Text("📊 Resumen", maxLines = 1) }
            }
        }
        Box(Modifier.padding(top = 8.dp)) {
            Image(
                painterResource(R.drawable.bg_footer), contentDescription = null,
                modifier = Modifier.fillMaxWidth(), contentScale = ContentScale.FillWidth
            )
            Box(
                Modifier.matchParentSize().background(
                    Brush.verticalGradient(0f to Fondo, 0.12f to Color.Transparent, 0.9f to Color.Transparent, 1f to Fondo)
                )
            )
        }
    }
}

// ---------------- NUEVO VIAJE ----------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NuevoViajeScreen(vm: MainViewModel, nav: NavController) {
    val clientes by vm.clientes.collectAsStateWithLifecycle()
    val viajesPrevios by vm.viajes.collectAsStateWithLifecycle()
    val ctxIni = LocalContext.current
    val origenIni = remember { Ajustes.origenFijo(ctxIni) }
    var cliente by remember { mutableStateOf(Ajustes.empresaViaje(ctxIni)) }
    var nombre by remember { mutableStateOf("") }
    var nombreManual by remember { mutableStateOf(false) }
    var origen by remember { mutableStateOf(origenIni.first) }
    var destino by remember { mutableStateOf("") }
    var oLat by remember { mutableStateOf(origenIni.second) }
    var oLng by remember { mutableStateOf(origenIni.third) }
    var eligiendoClientes by remember { mutableStateOf(false) }
    val cacheLocalidad = remember { mutableStateMapOf<String, String>() }
    var dLat by remember { mutableStateOf<Double?>(null) }
    var dLng by remember { mutableStateOf<Double?>(null) }
    val paradas = remember { mutableStateListOf<Parada>() }
    var odo by remember { mutableStateOf("") }
    var obs by remember { mutableStateOf("") }
    var selector by remember { mutableStateOf<String?>(null) }
    var gpsPendiente by remember { mutableStateOf<String?>(null) }
    var variasVisible by remember { mutableStateOf(false) }
    val ctxNuevo = LocalContext.current
    val odoSugerido = remember(viajesPrevios) { Avisos.odometroActual(viajesPrevios)?.toString() }
    LaunchedEffect(odoSugerido) { if (odo.isBlank() && odoSugerido != null) odo = odoSugerido }
    // La salida es siempre donde estás ahora (GPS). Si no hay GPS, se usa la salida guardada de siempre.
    var salidaGps by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        val gps = Gps.ultimaUbicacion(ctxNuevo)
        if (gps != null) {
            oLat = gps.latitude; oLng = gps.longitude; salidaGps = true
            origen = "Mi ubicación"
            Geo.direccion(gps.latitude, gps.longitude)?.let { origen = it.take(120) }
        } else if (oLat == null && origen.isNotBlank()) {
            val l = Geo.geocodificar(origen, Ajustes.claveMapTiler(ctxNuevo))
            if (l != null && oLat == null) {
                oLat = l.lat; oLng = l.lng
                Ajustes.guardarOrigenFijo(ctxNuevo, origen, l.lat, l.lng)
            }
        }
    }
    // El nombre del viaje son las localidades por donde pasa (paradas y destino), en orden
    val claveNombre = paradas.joinToString("|") { "%.4f,%.4f".format(java.util.Locale.US, it.lat, it.lng) } + "#" + dLat + "," + dLng
    LaunchedEffect(claveNombre) {
        if (nombreManual) return@LaunchedEffect
        val dl = dLat; val dn = dLng
        val pts = paradas.map { it.lat to it.lng } + (if (dl != null && dn != null) listOf(dl to dn) else emptyList())
        if (pts.isEmpty()) return@LaunchedEffect
        val nombres = ArrayList<String>()
        for (p in pts) {
            val k = "%.3f,%.3f".format(java.util.Locale.US, p.first, p.second)
            var loc = cacheLocalidad[k]
            if (loc == null) {
                loc = Geo.localidad(p.first, p.second)
                if (loc != null) cacheLocalidad[k] = loc
                delay(1100)
            }
            if (loc != null) nombres.add(loc)
        }
        if (nombreManual) return@LaunchedEffect
        if (nombres.isNotEmpty()) nombre = Orden.nombreViaje(nombres)
        else if (nombre.isBlank()) nombre = Orden.nombreViaje(paradas.map { it.nombre.substringBefore(',') } + destino.substringBefore(','))
    }

    /** Ordena todos los puntos (paradas + destino) por el camino más corto desde el origen; el último queda como destino. */
    fun ordenar(extra: List<Cliente> = emptyList()) {
        val dl = dLat; val dn = dLng
        val todos = ArrayList<Parada>()
        todos.addAll(paradas)
        if (dl != null && dn != null) todos.add(Parada(viajeId = "", orden = 0, nombre = destino.ifBlank { "Destino" }, lat = dl, lng = dn))
        extra.forEach { c ->
            val la = c.lat; val lo = c.lng
            if (la != null && lo != null && todos.none { Math.abs(it.lat - la) < 0.0002 && Math.abs(it.lng - lo) < 0.0002 }) {
                todos.add(Parada(viajeId = "", orden = 0, nombre = c.nombre, lat = la, lng = lo))
            }
        }
        if (todos.isEmpty()) return
        val ol = oLat; val og = oLng
        val desde = if (ol != null && og != null) ol to og
        else Gps.ultimaUbicacion(ctxNuevo)?.let { it.latitude to it.longitude } ?: (todos[0].lat to todos[0].lng)
        val idx = Orden.camino(desde, todos.map { it.lat to it.lng })
        val ordenados = idx.map { todos[it] }
        val ultimo = ordenados.last()
        paradas.clear()
        ordenados.dropLast(1).forEachIndexed { i, p -> paradas.add(p.copy(orden = i)) }
        destino = ultimo.nombre; dLat = ultimo.lat; dLng = ultimo.lng
    }
    val recientes = remember(viajesPrevios) {
        viajesPrevios.filter { it.destinoLat != null && it.destinoLng != null && it.destino.isNotBlank() }
            .distinctBy { it.destino.trim().lowercase() }.take(5)
    }
    val odoNum = Calculos.parseOdometro(odo)
    val sugeridos = clientes.filter { (cliente.isBlank() || it.nombre.contains(cliente, true)) && !it.nombre.equals(cliente, true) }

    SolicitudGps(gpsPendiente) { nav.popBackStack() }

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Iniciar viaje", style = MaterialTheme.typography.headlineSmall)
        Text("La hora de inicio se guarda sola al iniciar.", style = MaterialTheme.typography.bodySmall)
        Campo(cliente, { cliente = it }, "Cliente o empresa")
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            sugeridos.forEach { c ->
                AssistChip(onClick = {
                    cliente = c.nombre
                    if (destino.isBlank() && c.lat != null && c.lng != null) {
                        destino = c.direccion ?: c.nombre; dLat = c.lat; dLng = c.lng
                    }
                }, label = { Text(c.nombre) })
            }
        }
        Campo(nombre, { nombre = it; nombreManual = true }, "Nombre del viaje (se arma solo con las paradas)")
        Text(
            if (salidaGps) "📍 Salís desde donde estás ahora." else if (oLat != null) "📍 Salís desde tu lugar de siempre (no encuentro el GPS)." else "📍 Esperando tu ubicación…",
            style = MaterialTheme.typography.bodySmall
        )
        BotonP({ eligiendoClientes = true }, Modifier.fillMaxWidth().height(52.dp)) { Text("👥 Elegir clientes de mi lista") }
        Text("Paradas", style = MaterialTheme.typography.titleSmall)
        paradas.forEachIndexed { i, p ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${i + 1}. ${p.nombre}", Modifier.weight(1f), maxLines = 2)
                TextButton({ paradas.removeAt(i) }) { Text("Quitar") }
            }
        }
        BotonSec({ selector = "parada" }, Modifier.fillMaxWidth()) { Text("Agregar parada en el mapa") }
        BotonP({ variasVisible = true }, Modifier.fillMaxWidth()) { Text("📋 Pegar varias ubicaciones (arma el recorrido)") }
        if (paradas.isNotEmpty() || dLat != null) {
            BotonSec({ ordenar(); Toast.makeText(ctxNuevo, "Ordenado por el camino más corto desde la salida.", Toast.LENGTH_SHORT).show() }, Modifier.fillMaxWidth()) {
                Text("🔀 Ordenar por el camino más corto")
            }
            val ol = oLat; val og = oLng; val dl = dLat; val dn = dLng
            val puntosKm = listOfNotNull(if (ol != null && og != null) ol to og else null) + paradas.map { it.lat to it.lng } +
                listOfNotNull(if (dl != null && dn != null) dl to dn else null)
            if (puntosKm.size >= 2) {
                Text(
                    "Recorrido estimado: unos ${"%.0f".format(Orden.kmLinea(puntosKm) * 1.3)} km (calculado en línea recta; la ruta real la ves en el mapa de Inicio).",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
        if (recientes.isNotEmpty()) {
            Text("Destinos recientes", style = MaterialTheme.typography.bodySmall)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                recientes.forEach { r ->
                    AssistChip(onClick = {
                        ordenar(listOf(Cliente(nombre = r.destino, lat = r.destinoLat, lng = r.destinoLng)))
                    }, label = { Text(r.destino.take(28)) })
                }
            }
        }
        if (destino.isNotBlank()) Text("🏁 Llegada: $destino (la última parada)", style = MaterialTheme.typography.bodyMedium)
        Campo(odo, { odo = it.filter { c -> c.isDigit() || c == ',' || c == '.' } }, "Odómetro inicial (km)", numerico = true)
        if (odoSugerido != null && odo == odoSugerido) {
            Text("Es el último odómetro que cargaste. Revisalo con el tablero del camión.", style = MaterialTheme.typography.bodySmall)
        }
        val ultimoOdo = odoSugerido?.toLongOrNull()
        if (ultimoOdo != null && odoNum != null && odo != odoSugerido) {
            if (odoNum < ultimoOdo) {
                Text("Es menor que el último odómetro que cargaste ($ultimoOdo). Revisá que esté bien.", color = Ambar, style = MaterialTheme.typography.bodySmall)
            } else if (odoNum - ultimoOdo > 3000) {
                Text("Hay ${odoNum - ultimoOdo} km más que en el último viaje. Revisá que no te hayas pasado de un número.", color = Ambar, style = MaterialTheme.typography.bodySmall)
            }
        }
        Campo(obs, { obs = it }, "Observaciones")
        Text("La hora de salida queda registrada cuando confirmás el recorrido con este botón.", style = MaterialTheme.typography.bodySmall)
        BotonGrande("Confirmar recorrido e iniciar viaje", enabled = nombre.isNotBlank() && odoNum != null, verde = true) {
            Ajustes.guardarEmpresaViaje(ctxNuevo, cliente.trim())
            // La salida se toma justo ahora, al confirmar
            Gps.ultimaUbicacion(ctxNuevo)?.let { oLat = it.latitude; oLng = it.longitude }
            val v = Viaje(
                cliente = cliente.trim(), nombre = nombre.trim(), origen = origen.trim(), destino = destino.trim(),
                inicio = System.currentTimeMillis(), observaciones = obs.trim(), odometroInicial = odoNum!!,
                origenLat = oLat, origenLng = oLng, destinoLat = dLat, destinoLng = dLng
            )
            vm.iniciarViaje(v, paradas.mapIndexed { i, p -> p.copy(viajeId = v.id, orden = i) })
            gpsPendiente = v.id
        }
        TextButton(onClick = { nav.popBackStack() }) { Text("Cancelar") }
    }


    if (eligiendoClientes) ElegirClientesViajeDialog(vm, onDismiss = { eligiendoClientes = false }) { elegidos ->
        eligiendoClientes = false
        ordenar(elegidos)
    }

    if (variasVisible) {
        val la0 = oLat; val ln0 = oLng
        val inicio = if (la0 != null && ln0 != null) la0 to ln0
        else Gps.ultimaUbicacion(ctxNuevo)?.let { it.latitude to it.longitude }
        VariasUbicacionesDialog(inicio, onDismiss = { variasVisible = false }) { lista ->
            lista.forEachIndexed { i, x ->
                if (i == lista.lastIndex && dLat == null) { destino = x.nombre; dLat = x.lat; dLng = x.lng }
                else paradas.add(Parada(viajeId = "", orden = paradas.size, nombre = x.nombre, lat = x.lat, lng = x.lng))
            }
            variasVisible = false
        }
    }

    selector?.let { tipo ->
        SelectorUbicacion(
            when (tipo) { "origen" -> "Elegí el origen"; "parada" -> "Elegí la parada"; else -> "Elegí el destino" },
            onDismiss = { selector = null }
        ) { txt, la, lo ->
            when (tipo) {
                "origen" -> { origen = txt; oLat = la; oLng = lo }
                "parada" -> paradas.add(Parada(viajeId = "", orden = paradas.size, nombre = txt, lat = la, lng = lo))
                else -> { destino = txt; dLat = la; dLng = lo }
            }
            selector = null
        }
    }
}

// ---------------- HISTORIAL ----------------
@Composable
fun HistorialScreen(vm: MainViewModel, nav: NavController) {
    val viajes by vm.viajes.collectAsStateWithLifecycle()
    var filtro by remember { mutableStateOf("") }
    val lista = viajes.filter {
        filtro.isBlank() || it.cliente.contains(filtro, true) || it.nombre.contains(filtro, true) ||
            it.estado.contains(filtro, true) || fechaHora(it.inicio).contains(filtro) ||
            it.origen.contains(filtro, true) || it.destino.contains(filtro, true) || it.observaciones.contains(filtro, true)
    }
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Historial de viajes", style = MaterialTheme.typography.headlineSmall)
        Campo(filtro, { filtro = it }, "Buscar (cliente, lugar, estado, mes/año…)")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
            items(lista, key = { it.id }) { v ->
                Card(Modifier.fillMaxWidth().clickable { nav.navigate("viaje/${v.id}") }) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(v.nombre, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                            EstadoChip(v.estado)
                        }
                        Text(v.cliente.ifBlank { "Sin cliente" })
                        Text(fechaHora(v.inicio), style = MaterialTheme.typography.bodySmall)
                        Calculos.kmViajeTxt(v)?.let { Text("🛣️ $it km (odómetro)") }
                        if (v.estado == Viaje.Estado.FINALIZADO) {
                            Row {
                                TextButton({ repetirViaje(ctx, vm, nav, v, false) }) { Text("🔁 Repetir") }
                                TextButton({ repetirViaje(ctx, vm, nav, v, true) }) { Text("↩ Hacer la vuelta") }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---------------- DETALLE ----------------
@Composable
fun DetalleViajeScreen(vm: MainViewModel, nav: NavController, id: String) {
    val ctx = LocalContext.current
    val viaje by vm.viaje(id).collectAsStateWithLifecycle(null)
    val jornadas by vm.jornadas(id).collectAsStateWithLifecycle(emptyList())
    val gastos by vm.gastos(id).collectAsStateWithLifecycle(emptyList())
    val puntos by vm.puntos(id).collectAsStateWithLifecycle(emptyList())
    val paradas by vm.paradas(id).collectAsStateWithLifecycle(emptyList())
    val adelantos by vm.adelantos(id).collectAsStateWithLifecycle(emptyList())
    val gastosTodos by vm.todosGastos.collectAsStateWithLifecycle()
    val siguiendo by TrackingService.siguiendo.collectAsStateWithLifecycle()

    var dialogoFin by remember { mutableStateOf(false) }
    var jornadaEdit by remember { mutableStateOf<Jornada?>(null) }
    var gastoEdit by remember { mutableStateOf<Gasto?>(null) }
    var borrarViaje by remember { mutableStateOf(false) }
    var gpsPendiente by remember { mutableStateOf<String?>(null) }
    var verMapa by remember { mutableStateOf(false) }
    var masGps by remember { mutableStateOf(false) }
    var tramoDetalle by remember { mutableStateOf(0) }
    var corrigiendoOdo by remember { mutableStateOf(false) }
    var verParadas by remember { mutableStateOf(false) }
    var selectorParada by remember { mutableStateOf(false) }
    var variasVisible by remember { mutableStateOf(false) }
    var pendienteAuto by remember { mutableStateOf(false) }
    var adelantoEdit by remember { mutableStateOf<Adelanto?>(null) }
    var gpsOn by remember { mutableStateOf(Gps.gpsActivo(ctx)) }
    LaunchedEffect(Unit) { while (true) { gpsOn = Gps.gpsActivo(ctx); delay(3000) } }

    val scope = rememberCoroutineScope()
    SolicitudGps(gpsPendiente) { gpsPendiente = null }
    val v = viaje ?: return
    fun conPdf(accion: (File) -> Unit) {
        scope.launch {
            try {
                val f = withContext(Dispatchers.IO) { InformePdf.generar(ctx, v, jornadas, gastos, puntos, adelantos, Perfiles.activo(ctx)) }
                accion(f)
            } catch (e: Exception) {
                Toast.makeText(ctx, "No se pudo generar el PDF.", Toast.LENGTH_LONG).show()
            }
        }
    }
    val abierta = jornadas.firstOrNull { it.finMin < 0 }
    val enCurso = v.estado == Viaje.Estado.EN_CURSO
    var verGps by remember { mutableStateOf(enCurso) }
    val objetivos = remember(paradas, v.destinoLat, v.destinoLng, v.destino) {
        buildList<Pair<String, GeoPoint>> {
            paradas.forEachIndexed { i, pa -> add("Parada ${i + 1}: ${pa.nombre}" to GeoPoint(pa.lat, pa.lng)) }
            val dl = v.destinoLat
            val dn = v.destinoLng
            if (dl != null && dn != null) add("Destino: ${v.destino.ifBlank { "Destino" }}" to GeoPoint(dl, dn))
        }
    }

    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Box(
                Modifier.fillMaxWidth()
                    .background(Brush.linearGradient(listOf(AzulProfundo, AzulMedio)), RoundedCornerShape(24.dp))
                    .padding(18.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    EstadoChip(v.estado)
                    Text(v.nombre, style = MaterialTheme.typography.headlineSmall, color = Color.White)
                    Text(v.cliente.ifBlank { "Sin cliente" }, color = Color.White.copy(alpha = 0.85f))
                    Text("${v.origen.ifBlank { "—" }} → ${v.destino.ifBlank { "—" }}", color = Color.White.copy(alpha = 0.85f))
                    Text("Inicio: ${fechaHora(v.inicio)}", color = Color.White.copy(alpha = 0.85f))
                    v.fin?.let { Text("Fin: ${fechaHora(it)}", color = Color.White.copy(alpha = 0.85f)) }
                    Text(
                        "Odómetro: ${Calculos.decimasTxt(Calculos.odoDecimas(v.odometroInicial, v.odoInicialDec))}" + (v.odometroFinal?.let { " → ${Calculos.decimasTxt(Calculos.odoDecimas(it, v.odoFinalDec))}" } ?: "") + " km",
                        color = Color.White.copy(alpha = 0.85f)
                    )
                }
            }
        }
        item {
            Tarjeta("Kilómetros oficiales (odómetro)",
                Calculos.kmViajeTxt(v)?.let { "$it km" } ?: "Se calcula al finalizar")
            TextButton({ corrigiendoOdo = true }) { Text("✏️ Corregir odómetro") }
        }
        item { ResumenRendicion(adelantos, gastos) }
        item {
            ConsumoCard(Calculos.consumo(gastos, Calculos.kmDecimas(v)?.let { it / 10.0 }, Calculos.distanciaGpsKm(puntos)))
        }
        if (enCurso && objetivos.isNotEmpty()) item { CercaniaCard(objetivos) }

        // ----- GPS -----
        item {
            TextButton({ verGps = !verGps }, Modifier.fillMaxWidth()) {
                Text("📍 Recorrido y GPS  ${if (verGps) "▴" else "▾"}", style = MaterialTheme.typography.titleMedium, modifier = Modifier.fillMaxWidth())
            }
            if (verGps) {
            if (enCurso) {
                if (siguiendo == v.id) {
                    Text("GPS activo: registrando el recorrido.", color = Verde)
                    puntos.lastOrNull()?.let { u ->
                        val min = (System.currentTimeMillis() - u.tiempo) / 60000
                        if (min >= 5) Text("Último punto registrado hace $min min (sin señal o sin moverte).", style = MaterialTheme.typography.bodySmall, color = Ambar)
                    }
                    if (!gpsOn) Text("Atención: el GPS del teléfono está apagado. Encendelo para registrar.", color = MaterialTheme.colorScheme.error)
                    BotonSec({ Gps.detener(ctx) }, Modifier.fillMaxWidth()) { Text("Detener seguimiento") }
                } else {
                    Text("Seguimiento detenido: no se está registrando el recorrido.", color = MaterialTheme.colorScheme.error)
                    BotonGrande("Iniciar seguimiento GPS", verde = true) { gpsPendiente = id }
                }
                TextButton({ masGps = !masGps }) { Text(if (masGps) "Menos ▴" else "Más opciones del GPS ▾") }
                if (masGps) {
                    Text("Para viajes largos, en Ajustes de la app poné la batería en \"Sin restricciones\".", style = MaterialTheme.typography.bodySmall)
                    TextButton({ pedirBateriaSinRestricciones(ctx) }) { Text("🔋 Que la batería no corte el GPS") }
                    TextButton({
                        ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")))
                    }) { Text("Abrir ajustes de la app") }
                }
            }
            Text("Distancia GPS (solo referencia, no oficial): ${"%.1f".format(Calculos.distanciaGpsKm(puntos))} km · ${puntos.size} puntos", style = MaterialTheme.typography.bodySmall)
            BotonP({
                val pts = mutableListOf<Pair<Double, Double>>()
                if (enCurso) Gps.ultimaUbicacion(ctx)?.let { pts.add(it.latitude to it.longitude) }
                if (pts.isEmpty()) {
                    val oL = v.origenLat; val oN = v.origenLng
                    if (oL != null && oN != null) pts.add(oL to oN)
                }
                paradas.forEach { pts.add(it.lat to it.lng) }
                val dl = v.destinoLat; val dn = v.destinoLng
                if (dl != null && dn != null) pts.add(dl to dn)
                if (pts.size >= 2) {
                    abrirRecorridoEnGoogleMaps(ctx, pts, tramoDetalle)
                    tramoDetalle = (tramoDetalle + 1) % cantidadTramos(pts.size)
                }
                else if (pts.size == 1) abrirEnGoogleMaps(ctx, pts[0].first, pts[0].second)
                else Toast.makeText(ctx, "Este viaje todavía no tiene paradas ni destino.", Toast.LENGTH_LONG).show()
            }, Modifier.fillMaxWidth()) { Text("🧭 Abrir en Google Maps") }
            if (puntos.size >= 2) {
                Seccion("Por dónde pasaste")
                var pos by remember(puntos.size) { mutableStateOf(0f) }
                val sel = puntos[pos.toInt().coerceIn(0, puntos.lastIndex)]
                Slider(value = pos, onValueChange = { pos = it }, valueRange = 0f..puntos.lastIndex.toFloat())
                Text("Pasaste por ahí el ${fechaHora(sel.tiempo)}", style = MaterialTheme.typography.titleSmall)
                BotonSec({ abrirEnGoogleMaps(ctx, sel.lat, sel.lng) }, Modifier.fillMaxWidth()) { Text("🗺️ Ver este punto en Google Maps") }
            }
            }
        }

        // ----- Paradas -----
        item {
            TextButton({ verParadas = !verParadas }, Modifier.fillMaxWidth()) {
                Text("🅿️ Paradas (${paradas.size})  ${if (verParadas) "▴" else "▾"}", style = MaterialTheme.typography.titleMedium, modifier = Modifier.fillMaxWidth())
            }
        }
        if (verParadas) items(paradas, key = { "p${it.id}" }) { p ->
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("${paradas.indexOf(p) + 1}. ${p.nombre}", Modifier.weight(1f))
                    TextButton({ vm.borrarParada(p) }) { Text("Quitar") }
                }
            }
        }
        if (verParadas) item {
            BotonSec({ selectorParada = true }, Modifier.fillMaxWidth()) { Text("Agregar parada en el mapa") }
            BotonP({ variasVisible = true }, Modifier.fillMaxWidth()) { Text("📋 Pegar varias ubicaciones (arma el recorrido)") }
        }

        // ----- Jornadas -----
        item { Seccion("Jornadas") }
        items(jornadas, key = { "j${it.id}" }) { j ->
            val t = Calculos.minutosTrabajados(j)
            Card(Modifier.fillMaxWidth().clickable { jornadaEdit = j }) {
                Column(Modifier.padding(12.dp)) {
                    Text(LocalDate.parse(j.fecha).format(fechaUi), fontWeight = FontWeight.Bold)
                    if (j.finMin < 0) {
                        Text("En curso desde ${Calculos.hhmm(j.inicioMin)}")
                    } else {
                        Text("${Calculos.hhmm(j.inicioMin)}–${Calculos.hhmm(j.finMin)} · pausa ${j.pausaMin} min" +
                            if (j.descuentaPausa) " (descontada)" else " (no descontada)")
                        Text("Total ${Calculos.hhmm(t)} · normales ${Calculos.hhmm(Calculos.normales(t))} · extras ${Calculos.hhmm(Calculos.extras(t))}")
                        Text("😴 Parado y descansando desde las ${Calculos.hhmm(j.finMin)}", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
        item {
            Text("Horas extras del viaje: ${Calculos.hhmm(Calculos.extrasTotales(jornadas))} h", fontWeight = FontWeight.Bold)
            if (enCurso) {
                if (abierta != null) BotonGrande("Finalizar jornada de hoy") { vm.finalizarJornada(abierta) }
                else BotonSec({ vm.iniciarJornada(id) }, Modifier.fillMaxWidth()) { Text("Iniciar nueva jornada") }
            }
            BotonSec({ jornadaEdit = Jornada(viajeId = id, fecha = LocalDate.now().toString(), inicioMin = 8 * 60, finMin = 18 * 60) },
                Modifier.fillMaxWidth()) { Text("Agregar jornada manual") }
        }

        // ----- Gastos -----
        item { Seccion("Plata recibida de la empresa") }
        items(adelantos, key = { "a${it.id}" }) { a ->
            Card(Modifier.fillMaxWidth().clickable { adelantoEdit = a }) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(Calculos.pesos(a.importeCentavos), fontWeight = FontWeight.Bold)
                        Text("${fechaHora(a.fechaHora)} ${a.descripcion}", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
        item {
            BotonSec({ adelantoEdit = Adelanto(viajeId = id, fechaHora = System.currentTimeMillis(), importeCentavos = 0) },
                Modifier.fillMaxWidth()) { Text("Registrar plata recibida") }
        }
        item { Seccion("Gastos") }
        items(gastos, key = { "g${it.id}" }) { g ->
            val mini = remember(g.fotoPath) { g.fotoPath?.let { Fotos.cargar(it, 160)?.asImageBitmap() } }
            Card(Modifier.fillMaxWidth().clickable { gastoEdit = g }) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    if (mini != null) {
                        Image(mini, contentDescription = "Ticket", modifier = Modifier.size(56.dp).clip(RoundedCornerShape(10.dp)), contentScale = ContentScale.Crop)
                    }
                    Column(Modifier.weight(1f)) {
                        Text("${g.categoria} · ${Calculos.pesos(g.importeCentavos)}", fontWeight = FontWeight.Bold)
                        Text("${fechaHora(g.fechaHora)} ${g.descripcion}")
                        g.litros?.let { Text("${"%.1f".format(Locale("es", "AR"), it)} litros", style = MaterialTheme.typography.bodySmall) }
                        if (g.fotoPath != null && mini == null) Text("Foto del ticket no disponible", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
        item {
            CATEGORIAS_GASTO.forEach { cat ->
                val total = gastos.filter { it.categoria == cat }.sumOf { it.importeCentavos }
                if (total > 0) Text("$cat: ${Calculos.pesos(total)}")
            }
            Text("Total general: ${Calculos.pesos(gastos.sumOf { it.importeCentavos })}", fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(Triple("Combustible", "⛽", "Nafta"), Triple("Peajes", "🚧", "Peaje"), Triple("Comida", "🍽️", "Comida")).forEach { (cat, ico, nombre) ->
                    BotonSec({
                        val ultimo = gastosTodos.filter { it.categoria == cat }.maxByOrNull { it.fechaHora }?.importeCentavos ?: 0L
                        gastoEdit = Gasto(viajeId = id, fechaHora = System.currentTimeMillis(), categoria = cat, importeCentavos = ultimo)
                    }, Modifier.weight(1f)) { Text("$ico $nombre", maxLines = 1) }
                }
            }
            BotonSec({ gastoEdit = Gasto(viajeId = id, fechaHora = System.currentTimeMillis(), categoria = CATEGORIAS_GASTO[0], importeCentavos = 0) },
                Modifier.fillMaxWidth()) { Text("Agregar otro gasto") }
        }
        item {
            Seccion("Informe PDF")
            BotonSec({ conPdf { InformePdf.compartir(ctx, it) } }, Modifier.fillMaxWidth()) { Text("Compartir informe PDF") }
            BotonSec({ conPdf { InformePdf.compartirWhatsApp(ctx, it) } }, Modifier.fillMaxWidth()) { Text("💬 Mandar el informe por WhatsApp") }
            BotonSec({
                conPdf {
                    val ok = InformePdf.guardarEnDescargas(ctx, it)
                    Toast.makeText(ctx, if (ok) "Guardado en Descargas" else "No se pudo guardar", Toast.LENGTH_LONG).show()
                }
            }, Modifier.fillMaxWidth()) { Text("Guardar PDF en Descargas") }
        }
        item {
            if (enCurso) BotonGrande("Finalizar viaje", verde = true) { dialogoFin = true }
            if (!enCurso) {
                Seccion("Viajes repetidos")
                BotonSec({ repetirViaje(ctx, vm, nav, v, false) }, Modifier.fillMaxWidth()) { Text("🔁 Repetir este viaje") }
                BotonSec({ repetirViaje(ctx, vm, nav, v, true) }, Modifier.fillMaxWidth()) { Text("↩ Hacer la vuelta (al revés)") }
            }
            TextButton({ borrarViaje = true }) { Text("Eliminar viaje") }
            TextButton({ nav.popBackStack() }) { Text("Volver") }
        }
    }

    if (variasVisible) {
        val oL = v.origenLat; val oN = v.origenLng
        val inicio = if (oL != null && oN != null) oL to oN
        else Gps.ultimaUbicacion(ctx)?.let { it.latitude to it.longitude }
        VariasUbicacionesDialog(inicio, onDismiss = { variasVisible = false }) { lista ->
            val sinDestino = v.destinoLat == null
            vm.agregarParadas(id, if (sinDestino) lista.dropLast(1) else lista)
            if (sinDestino) lista.lastOrNull()?.let {
                vm.actualizarViaje(v.copy(destino = it.nombre, destinoLat = it.lat, destinoLng = it.lng))
            }
            variasVisible = false
            Toast.makeText(ctx, "Recorrido armado: ${lista.size} lugares", Toast.LENGTH_LONG).show()
        }
    }
    if (selectorParada) SelectorUbicacion("Elegí la parada", onDismiss = { selectorParada = false }) { txt, la, lo ->
        vm.agregarParada(Parada(viajeId = id, orden = paradas.size, nombre = txt, lat = la, lng = lo))
        selectorParada = false
    }
    if (corrigiendoOdo) {
        fun txtOdo(km: Long, dec: Int) = km.toString() + if (dec != 0) ",$dec" else ""
        var oi by remember { mutableStateOf(txtOdo(v.odometroInicial, v.odoInicialDec)) }
        var of by remember { mutableStateOf(v.odometroFinal?.let { txtOdo(it, v.odoFinalDec) } ?: "") }
        val pi = Calculos.parseOdometroDec(oi)
        val pf = if (of.isBlank()) null else Calculos.parseOdometroDec(of)
        val ni = pi?.let { Calculos.odoDecimas(it.first, it.second) }
        val nf = pf?.let { Calculos.odoDecimas(it.first, it.second) }
        val ok = ni != null && (v.odometroFinal == null || (nf != null && nf >= ni))
        AlertDialog(
            onDismissRequest = { corrigiendoOdo = false },
            title = { Text("Corregir odómetro") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Escribilo como el tablero, con la décima: 101.857,7.", style = MaterialTheme.typography.bodySmall)
                    Campo(oi, { oi = it.filter { c -> c.isDigit() || c == ',' || c == '.' } }, "Odómetro inicial", numerico = true)
                    if (v.odometroFinal != null) {
                        Campo(of, { of = it.filter { c -> c.isDigit() || c == ',' || c == '.' } }, "Odómetro final", numerico = true)
                    }
                    if (ni != null && nf != null && nf >= ni) Text("Kilómetros oficiales: ${Calculos.decimasTxt(nf - ni)} km")
                    if (nf != null && ni != null && nf < ni) Text("El final no puede ser menor al inicial.", color = MaterialTheme.colorScheme.error)
                }
            },
            confirmButton = {
                TextButton({
                    vm.actualizarViaje(
                        v.copy(
                            odometroInicial = pi!!.first, odoInicialDec = pi.second,
                            odometroFinal = if (v.odometroFinal != null) pf!!.first else null,
                            odoFinalDec = if (v.odometroFinal != null) pf!!.second else 0
                        )
                    )
                    corrigiendoOdo = false
                }, enabled = ok) { Text("Guardar") }
            },
            dismissButton = { TextButton({ corrigiendoOdo = false }) { Text("Cancelar") } }
        )
    }
    if (dialogoFin) DialogoFinalizar(v, gastos, onDismiss = { dialogoFin = false }) { odo, dec ->
        if (TrackingService.siguiendo.value == v.id) Gps.detener(ctx)
        vm.finalizarViaje(v, odo, dec)
        pendienteAuto = true
        dialogoFin = false
    }
    jornadaEdit?.let { j -> DialogoJornada(j, onDismiss = { jornadaEdit = null },
        onBorrar = { vm.borrarJornada(j); jornadaEdit = null }) { vm.guardarJornada(it); jornadaEdit = null } }
    adelantoEdit?.let { a -> DialogoAdelanto(a, onDismiss = { adelantoEdit = null },
        onBorrar = { vm.borrarAdelanto(a); adelantoEdit = null }) { vm.guardarAdelanto(it); adelantoEdit = null } }
    gastoEdit?.let { g -> DialogoGasto(g, onDismiss = { gastoEdit = null },
        onBorrar = { vm.borrarGasto(g); gastoEdit = null }, precioLitroUltimo = precioPorLitro(gastosTodos)) { vm.guardarGasto(it); gastoEdit = null } }
    if (borrarViaje) AlertDialog(
        onDismissRequest = { borrarViaje = false },
        title = { Text("¿Eliminar viaje?") },
        text = { Text("Se borrarán también sus jornadas, gastos y recorrido GPS. No se puede deshacer.") },
        confirmButton = {
            TextButton({
                if (TrackingService.siguiendo.value == v.id) Gps.detener(ctx)
                vm.borrarViaje(v); borrarViaje = false; nav.popBackStack()
            }) { Text("Eliminar") }
        },
        dismissButton = { TextButton({ borrarViaje = false }) { Text("Cancelar") } }
    )
}

@Composable
private fun DialogoFinalizar(v: Viaje, gastos: List<Gasto>, onDismiss: () -> Unit, onOk: (Long, Int) -> Unit) {
    var odo by remember { mutableStateOf("") }
    val par = Calculos.parseOdometroDec(odo)
    val n = par?.let { Calculos.odoDecimas(it.first, it.second) }
    val iniDec = Calculos.odoDecimas(v.odometroInicial, v.odoInicialDec)
    val error = n != null && n < iniDec
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Finalizar viaje") },
        text = {
            Column {
                Text("Se guarda la hora de fin, se cierra la jornada y se calculan las horas extras.", style = MaterialTheme.typography.bodySmall)
                Campo(odo, { odo = it.filter { c -> c.isDigit() || c == ',' || c == '.' } }, "Odómetro final (como dice el tablero, ej. 101.857,7)", numerico = true)
                if (error) Text("No puede ser menor al inicial (${Calculos.decimasTxt(iniDec)}).", color = MaterialTheme.colorScheme.error)
                else if (n != null) Text("Kilómetros oficiales: ${Calculos.decimasTxt(n - iniDec)} km")
                if (n != null && !error && n - iniDec > 50000) {
                    Text("Son más de 5.000 km en un viaje. Revisá que el número esté bien.", color = Ambar, style = MaterialTheme.typography.bodySmall)
                }
                if (gastos.isEmpty()) {
                    Text("Todavía no cargaste gastos de este viaje. Podés cargarlos después.", color = Ambar, style = MaterialTheme.typography.bodySmall)
                } else if (gastos.any { it.categoria == "Combustible" && it.litros == null }) {
                    Text("Hay cargas de combustible sin litros: sin eso no se calcula el consumo.", color = Ambar, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = { TextButton({ onOk(par!!.first, par.second) }, enabled = par != null && !error) { Text("Confirmar y cerrar") } },
        dismissButton = { TextButton(onDismiss) { Text("Cancelar") } }
    )
}

@Composable
private fun DialogoJornada(j: Jornada, onDismiss: () -> Unit, onBorrar: () -> Unit, onOk: (Jornada) -> Unit) {
    var fecha by remember { mutableStateOf(LocalDate.parse(j.fecha).format(fechaUi)) }
    var ini by remember { mutableStateOf(Calculos.hhmm(j.inicioMin).padStart(5, '0')) }
    var fin by remember {
        mutableStateOf(Calculos.hhmm(if (j.finMin < 0) Calculos.minutoActual() else j.finMin).padStart(5, '0'))
    }
    var pausa by remember { mutableStateOf(j.pausaMin.toString()) }
    var descuenta by remember { mutableStateOf(j.descuentaPausa) }
    var obs by remember { mutableStateOf(j.observaciones) }
    val f = runCatching { LocalDate.parse(fecha, fechaUi) }.getOrNull()
    val i = Calculos.parseHora(ini); val e = Calculos.parseHora(fin); val p = pausa.toIntOrNull()
    val valido = f != null && i != null && e != null && p != null
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (j.id == 0L) "Nueva jornada" else "Editar jornada") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Campo(fecha, { fecha = it }, "Fecha (dd/mm/aaaa)")
                Campo(ini, { ini = it }, "Inicio (HH:mm)")
                Campo(fin, { fin = it }, "Fin (HH:mm)")
                Campo(pausa, { pausa = it.filter(Char::isDigit) }, "Pausas (minutos)", numerico = true)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(descuenta, { descuenta = it }); Text("Descontar pausas del total")
                }
                Campo(obs, { obs = it }, "Observaciones")
                if (valido) {
                    val t = Calculos.minutosTrabajados(Jornada(viajeId = "", fecha = "", inicioMin = i!!, finMin = e!!, pausaMin = p!!, descuentaPausa = descuenta))
                    Text("Total ${Calculos.hhmm(t)} · extras ${Calculos.hhmm(Calculos.extras(t))}")
                }
            }
        },
        confirmButton = {
            TextButton({ onOk(j.copy(fecha = f.toString(), inicioMin = i!!, finMin = e!!, pausaMin = p!!, descuentaPausa = descuenta, observaciones = obs)) },
                enabled = valido) { Text("Guardar") }
        },
        dismissButton = {
            Row { if (j.id != 0L) TextButton(onBorrar) { Text("Borrar") }; TextButton(onDismiss) { Text("Cancelar") } }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DialogoGasto(g: Gasto, onDismiss: () -> Unit, onBorrar: () -> Unit, precioLitroUltimo: Double? = null, onOk: (Gasto) -> Unit) {
    val ctx = LocalContext.current
    var cat by remember { mutableStateOf(g.categoria) }
    var importe by remember { mutableStateOf(if (g.importeCentavos == 0L) "" else (g.importeCentavos / 100.0).toString().replace('.', ',')) }
    var desc by remember { mutableStateOf(g.descripcion) }
    var obs by remember { mutableStateOf(g.observaciones) }
    var foto by remember { mutableStateOf(g.fotoPath) }
    var litros by remember { mutableStateOf(g.litros?.toString()?.replace('.', ',') ?: "") }
    var pendiente by remember { mutableStateOf<File?>(null) }
    val c = Calculos.parseImporte(importe)
    // Combustible: si no escribís los litros, se calculan con el precio por litro de la última carga
    var litrosAMano by remember { mutableStateOf(litros.isNotBlank()) }
    LaunchedEffect(importe, cat) {
        if (cat == "Combustible" && !litrosAMano && precioLitroUltimo != null && c != null && c > 0) {
            litros = "%.1f".format(java.util.Locale.US, (c / 100.0) / precioLitroUltimo).replace('.', ',')
        }
    }

    val camara = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val f = pendiente
        if (ok && f != null) foto = f.path else f?.delete()
        pendiente = null
    }
    val galeria = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            val f = Fotos.copiarDesde(ctx, uri)
            if (f != null) foto = f.path else Toast.makeText(ctx, "No se pudo cargar la foto.", Toast.LENGTH_LONG).show()
        }
    }
    val imagen = remember(foto) { foto?.let { Fotos.cargar(it, 900)?.asImageBitmap() } }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (g.id == 0L) "Nuevo gasto" else "Editar gasto") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    CATEGORIAS_GASTO.forEach { FilterChip(cat == it, { cat = it }, label = { Text(it) }) }
                }
                Campo(importe, { importe = it }, "Importe (ARS)", numerico = true)
                if (cat == "Combustible") Campo(litros, { litros = it; litrosAMano = true }, if (!litrosAMano && litros.isNotBlank()) "Litros (calculados solos, corregilos si hace falta)" else "Litros cargados (para ver el consumo)", numerico = true)
                Campo(desc, { desc = it }, "Descripción")
                Campo(obs, { obs = it }, "Observaciones")
                Text("Foto del ticket", style = MaterialTheme.typography.titleSmall)
                if (imagen != null) {
                    Image(imagen, contentDescription = "Ticket", modifier = Modifier.fillMaxWidth().heightIn(max = 220.dp), contentScale = ContentScale.Fit)
                }
                BotonSec({
                    val f = Fotos.nuevoArchivo(ctx)
                    pendiente = f
                    camara.launch(Fotos.uri(ctx, f))
                }, Modifier.fillMaxWidth()) { Text(if (foto == null) "📷 Sacar foto del ticket" else "📷 Sacar otra foto") }
                BotonSec({
                    galeria.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }, Modifier.fillMaxWidth()) { Text("🖼️ Elegir de la galería") }
                if (foto != null) TextButton({
                    if (foto != g.fotoPath) foto?.let { File(it).delete() }
                    foto = null
                }) { Text("Quitar foto") }
            }
        },
        confirmButton = {
            TextButton({ onOk(g.copy(categoria = cat, importeCentavos = c!!, descripcion = desc, observaciones = obs, fotoPath = foto,
                litros = if (cat == "Combustible") litros.trim().replace(',', '.').toDoubleOrNull()?.takeIf { it > 0 } else null)) },
                enabled = c != null && c > 0) { Text("Guardar") }
        },
        dismissButton = { Row { if (g.id != 0L) TextButton(onBorrar) { Text("Borrar") }; TextButton(onDismiss) { Text("Cancelar") } } }
    )
}

@Composable
private fun DialogoAdelanto(a: Adelanto, onDismiss: () -> Unit, onBorrar: () -> Unit, onOk: (Adelanto) -> Unit) {
    var importe by remember { mutableStateOf(if (a.id == 0L) "" else (a.importeCentavos / 100.0).toString().replace('.', ',')) }
    var desc by remember { mutableStateOf(a.descripcion) }
    val c = Calculos.parseImporte(importe)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (a.id == 0L) "Plata recibida de la empresa" else "Editar plata recibida") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Anotá lo que te dio la empresa para el viaje (adelanto, viáticos).", style = MaterialTheme.typography.bodySmall)
                Campo(importe, { importe = it }, "Importe (ARS)", numerico = true)
                Campo(desc, { desc = it }, "Descripción (ej. adelanto, viáticos)")
            }
        },
        confirmButton = {
            TextButton({ onOk(a.copy(importeCentavos = c!!, descripcion = desc)) }, enabled = c != null && c > 0) { Text("Guardar") }
        },
        dismissButton = { Row { if (a.id != 0L) TextButton(onBorrar) { Text("Borrar") }; TextButton(onDismiss) { Text("Cancelar") } } }
    )
}

/** Cuánta plata recibiste, cuánto gastaste y cuánto hay que devolver a la empresa. */
@Composable
private fun ConsumoCard(c: Calculos.Consumo?) {
    val ar = Locale("es", "AR")
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("Consumo de combustible", style = MaterialTheme.typography.titleMedium)
            if (c == null) {
                Text(
                    "Cuando cargues nafta, anotá el gasto en \"Combustible\" y completá los litros. Acá vas a ver cuánto gasta el camión.",
                    style = MaterialTheme.typography.bodySmall
                )
            } else {
                Row { Text("Litros cargados", Modifier.weight(1f)); Text("${"%.1f".format(ar, c.litros)} L", fontWeight = FontWeight.Bold) }
                Row { Text("Gasto en combustible", Modifier.weight(1f)); Text(Calculos.pesos(c.costoCentavos), fontWeight = FontWeight.Bold) }
                if (c.lPor100 != null && c.kmPorLitro != null) {
                    Divider(Modifier.padding(vertical = 4.dp))
                    Text("${"%.1f".format(ar, c.lPor100)} L cada 100 km", style = MaterialTheme.typography.headlineSmall, color = Verde)
                    Text("${"%.2f".format(ar, c.kmPorLitro)} km por litro")
                    c.centavosPorKm?.let { Text("Combustible por km: ${Calculos.pesos(Math.round(it))}") }
                    c.centavosPorLitro?.let { Text("Precio promedio del litro: ${Calculos.pesos(Math.round(it))}") }
                    Text("Calculado con los km del odómetro: ${"%.0f".format(ar, c.km)} km.", style = MaterialTheme.typography.bodySmall)
                } else {
                    Text("Consumo pendiente: se calcula con los km del odómetro cuando finalizás el viaje.", style = MaterialTheme.typography.titleSmall)
                }
                Text("Para que sea exacto, cargá los litros de todas las cargas del viaje.", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun ResumenRendicion(adelantos: List<Adelanto>, gastos: List<Gasto>) {
    val recibido = adelantos.sumOf { it.importeCentavos }
    val gastado = gastos.sumOf { it.importeCentavos }
    val saldo = Calculos.saldoEmpresa(adelantos, gastos)
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("Rendición con la empresa", style = MaterialTheme.typography.titleMedium)
            Row { Text("Plata recibida", Modifier.weight(1f)); Text(Calculos.pesos(recibido), fontWeight = FontWeight.Bold) }
            Row { Text("Total de gastos", Modifier.weight(1f)); Text(Calculos.pesos(gastado), fontWeight = FontWeight.Bold) }
            Divider(Modifier.padding(vertical = 6.dp))
            Text(
                when {
                    saldo > 0 -> "A devolver a la empresa"
                    saldo < 0 -> "La empresa te debe"
                    else -> "Estás a mano"
                },
                style = MaterialTheme.typography.labelLarge
            )
            Text(
                if (saldo == 0L) "$ 0,00" else Calculos.pesos(abs(saldo)),
                style = MaterialTheme.typography.headlineSmall,
                color = when { saldo > 0 -> Ambar; saldo < 0 -> Verde; else -> MaterialTheme.colorScheme.onSurfaceVariant }
            )
        }
    }
}
