package com.micontrol.app.ui

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.activity.result.PickVisualMediaRequest
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.micontrol.app.data.*
import com.micontrol.app.domain.Calculos
import com.micontrol.app.gps.Gps
import com.micontrol.app.gps.TrackingService
import com.micontrol.app.pdf.InformePdf
import org.osmdroid.util.GeoPoint
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.abs
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

private val fmt = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("es", "AR"))
private val fechaUi = DateTimeFormatter.ofPattern("dd/MM/yyyy")
private fun fechaHora(ms: Long) = fmt.format(ms)

@Composable
private fun Tarjeta(titulo: String, valor: String, modifier: Modifier = Modifier) {
    Card(modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(titulo, style = MaterialTheme.typography.labelLarge)
            Text(valor, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun BotonGrande(texto: String, enabled: Boolean = true, verde: Boolean = false, onClick: () -> Unit) {
    BotonP(
        onClick, Modifier.fillMaxWidth().height(56.dp), enabled = enabled,
        colors = if (verde) ButtonDefaults.buttonColors(containerColor = Verde) else ButtonDefaults.buttonColors()
    ) { Text(texto) }
}

@Composable
private fun Campo(valor: String, onChange: (String) -> Unit, etiqueta: String, numerico: Boolean = false, modifier: Modifier = Modifier) {
    OutlinedTextField(
        valor, onChange, modifier.fillMaxWidth(), label = { Text(etiqueta) }, shape = RoundedCornerShape(14.dp),
        keyboardOptions = KeyboardOptions(keyboardType = if (numerico) KeyboardType.Number else KeyboardType.Text)
    )
}

/** Explica para qué se usa la ubicación, pide los permisos y arranca el seguimiento GPS del viaje. */
@Composable
private fun SolicitudGps(viajeId: String?, onFin: () -> Unit) {
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (viajeId != null && Gps.tienePermiso(ctx)) Gps.iniciar(ctx, viajeId)
        else Toast.makeText(ctx, "Sin permiso de ubicación no se registra el recorrido.", Toast.LENGTH_LONG).show()
        onFin()
    }
    if (viajeId != null) AlertDialog(
        onDismissRequest = onFin,
        title = { Text("Registrar recorrido GPS") },
        text = {
            Text(
                "Mi Control va a guardar tu ubicación durante el viaje, también con la pantalla apagada, " +
                    "y vas a ver una notificación mientras esté activo. Los datos quedan solo en tu teléfono."
            )
        },
        confirmButton = {
            TextButton({
                if (Gps.tienePermiso(ctx)) { Gps.iniciar(ctx, viajeId); onFin() }
                else launcher.launch(Gps.permisos())
            }) { Text("Aceptar") }
        },
        dismissButton = { TextButton(onFin) { Text("Ahora no") } }
    )
}

// ---------------- HOME ----------------
@Composable
private fun Dato(emoji: String, titulo: String, valor: String, modifier: Modifier = Modifier) {
    Card(modifier) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(emoji, fontSize = 22.sp)
            Text(titulo, style = MaterialTheme.typography.labelMedium)
            Text(valor, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun HomeScreen(vm: MainViewModel, nav: NavController) {
    val viajes by vm.viajes.collectAsStateWithLifecycle()
    val jornadas by vm.todasJornadas.collectAsStateWithLifecycle()
    val gastos by vm.todosGastos.collectAsStateWithLifecycle()
    val activo = viajes.firstOrNull { it.estado == Viaje.Estado.EN_CURSO }
    val ultimo = viajes.firstOrNull { it.estado == Viaje.Estado.FINALIZADO }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Box(
            Modifier.fillMaxWidth()
                .background(Brush.linearGradient(listOf(AzulProfundo, AzulMedio)), RoundedCornerShape(bottomStart = 32.dp, bottomEnd = 32.dp))
                .padding(horizontal = 20.dp, vertical = 24.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Mi Control", style = MaterialTheme.typography.headlineLarge, color = Color.White)
                Text("Tu libreta de viaje, siempre al día", color = Color.White.copy(alpha = 0.8f))
                Spacer(Modifier.height(8.dp))
                if (activo != null) {
                    Surface(color = Color.White.copy(alpha = 0.15f), contentColor = Color.White, shape = RoundedCornerShape(20.dp)) {
                        Column(Modifier.padding(16.dp).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            EstadoChip(Viaje.Estado.EN_CURSO)
                            Text(activo.nombre, style = MaterialTheme.typography.titleLarge)
                            Text("Desde ${fechaHora(activo.inicio)}", color = Color.White.copy(alpha = 0.85f))
                            Spacer(Modifier.height(6.dp))
                            BotonP(
                                { nav.navigate("viaje/${activo.id}") }, Modifier.fillMaxWidth().height(52.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = AzulProfundo)
                            ) { Text("Abrir viaje en curso") }
                        }
                    }
                } else {
                    BotonP(
                        { nav.navigate("nuevo") }, Modifier.fillMaxWidth().height(56.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Verde)
                    ) { Text("🚛  Iniciar viaje") }
                }
            }
        }
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Dato("🛣️", "Km último viaje",
                    ultimo?.let { Calculos.kmOficiales(it.odometroInicial, it.odometroFinal)?.let { k -> "$k km" } } ?: "—",
                    Modifier.weight(1f))
                Dato("⏱️", "Horas extras", Calculos.hhmm(Calculos.extrasTotales(jornadas)) + " h", Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Dato("💵", "Gastos", Calculos.pesos(gastos.sumOf { it.importeCentavos }), Modifier.weight(1f))
                Dato("📋", "Viajes", "${viajes.size}", Modifier.weight(1f))
            }
        }
    }
}

// ---------------- NUEVO VIAJE ----------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NuevoViajeScreen(vm: MainViewModel, nav: NavController) {
    val clientes by vm.clientes.collectAsStateWithLifecycle()
    var cliente by remember { mutableStateOf("") }
    var nombre by remember { mutableStateOf("") }
    var origen by remember { mutableStateOf("") }
    var destino by remember { mutableStateOf("") }
    var oLat by remember { mutableStateOf<Double?>(null) }
    var oLng by remember { mutableStateOf<Double?>(null) }
    var dLat by remember { mutableStateOf<Double?>(null) }
    var dLng by remember { mutableStateOf<Double?>(null) }
    val paradas = remember { mutableStateListOf<Parada>() }
    var odo by remember { mutableStateOf("") }
    var obs by remember { mutableStateOf("") }
    var selector by remember { mutableStateOf<String?>(null) }
    var gpsPendiente by remember { mutableStateOf<String?>(null) }
    var rutaVisible by remember { mutableStateOf(false) }
    val odoNum = odo.toLongOrNull()
    val sugeridos = clientes.filter { (cliente.isBlank() || it.nombre.contains(cliente, true)) && !it.nombre.equals(cliente, true) }

    SolicitudGps(gpsPendiente) { nav.popBackStack() }

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Iniciar viaje", style = MaterialTheme.typography.headlineSmall)
        Text("La hora de inicio se guarda sola al iniciar.", style = MaterialTheme.typography.bodySmall)
        Campo(cliente, { cliente = it }, "Cliente o empresa")
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            sugeridos.forEach { c ->
                AssistChip(onClick = {
                    cliente = c.nombre
                    if (destino.isBlank() && c.lat != null && c.lng != null) {
                        destino = c.direccion ?: c.nombre; dLat = c.lat; dLng = c.lng
                    }
                }, label = { Text(c.nombre) })
            }
        }
        Campo(nombre, { nombre = it }, "Nombre del viaje")
        Campo(origen, { origen = it }, "Dirección de origen")
        BotonSec({ selector = "origen" }, Modifier.fillMaxWidth()) {
            Text(if (oLat == null) "Elegir origen en el mapa" else "Origen marcado en el mapa (cambiar)")
        }
        Text("Paradas", style = MaterialTheme.typography.titleSmall)
        paradas.forEachIndexed { i, p ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${i + 1}. ${p.nombre}", Modifier.weight(1f), maxLines = 2)
                TextButton({ paradas.removeAt(i) }) { Text("Quitar") }
            }
        }
        BotonSec({ selector = "parada" }, Modifier.fillMaxWidth()) { Text("Agregar parada en el mapa") }
        Campo(destino, { destino = it }, "Dirección de destino")
        BotonSec({ selector = "destino" }, Modifier.fillMaxWidth()) {
            Text(if (dLat == null) "Elegir destino en el mapa" else "Destino marcado en el mapa (cambiar)")
        }
        BotonSec({ rutaVisible = true }, Modifier.fillMaxWidth(), enabled = oLat != null && dLat != null) {
            Text("Calcular ruta para camión")
        }
        if (oLat == null || dLat == null) Text("Para calcular la ruta marcá origen y destino en el mapa.", style = MaterialTheme.typography.bodySmall)
        Campo(odo, { odo = it.filter(Char::isDigit) }, "Odómetro inicial (km)", numerico = true)
        Campo(obs, { obs = it }, "Observaciones")
        BotonGrande("Iniciar viaje", enabled = nombre.isNotBlank() && odoNum != null, verde = true) {
            val v = Viaje(
                cliente = cliente.trim(), nombre = nombre.trim(), origen = origen.trim(), destino = destino.trim(),
                inicio = System.currentTimeMillis(), observaciones = obs.trim(), odometroInicial = odoNum!!,
                origenLat = oLat, origenLng = oLng, destinoLat = dLat, destinoLng = dLng
            )
            vm.iniciarViaje(v, paradas.mapIndexed { i, p -> p.copy(viajeId = v.id, orden = i) })
            gpsPendiente = v.id
        }
        TextButton(onClick = { nav.popBackStack() }) { Text("Cancelar") }
    }

    if (rutaVisible && oLat != null && oLng != null && dLat != null && dLng != null) {
        val pts = buildList<Pair<String, GeoPoint>> {
            add(origen.ifBlank { "Origen" } to GeoPoint(oLat!!, oLng!!))
            paradas.forEach { add(it.nombre to GeoPoint(it.lat, it.lng)) }
            add(destino.ifBlank { "Destino" } to GeoPoint(dLat!!, dLng!!))
        }
        RutaCamionDialog(pts, onDismiss = { rutaVisible = false }, onAjustes = { rutaVisible = false; nav.navigate("ajustes") })
    }

    selector?.let { tipo ->
        SelectorUbicacion(
            when (tipo) { "origen" -> "Elegí el origen"; "parada" -> "Elegí la parada"; else -> "Elegí el destino" },
            onDismiss = { selector = null }
        ) { txt, la, lo ->
            when (tipo) {
                "origen" -> { origen = txt; oLat = la; oLng = lo }
                "parada" -> paradas.add(Parada(viajeId = "", orden = paradas.size, nombre = txt, lat = la, lng = lo))
                else -> { destino = txt; dLat = la; dLng = lo }
            }
            selector = null
        }
    }
}

// ---------------- HISTORIAL ----------------
@Composable
fun HistorialScreen(vm: MainViewModel, nav: NavController) {
    val viajes by vm.viajes.collectAsStateWithLifecycle()
    var filtro by remember { mutableStateOf("") }
    val lista = viajes.filter {
        filtro.isBlank() || it.cliente.contains(filtro, true) || it.nombre.contains(filtro, true) ||
            it.estado.contains(filtro, true) || fechaHora(it.inicio).contains(filtro)
    }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Historial de viajes", style = MaterialTheme.typography.headlineSmall)
        Campo(filtro, { filtro = it }, "Buscar (cliente, estado, mes/año…)")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
            items(lista, key = { it.id }) { v ->
                Card(Modifier.fillMaxWidth().clickable { nav.navigate("viaje/${v.id}") }) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(v.nombre, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                            EstadoChip(v.estado)
                        }
                        Text(v.cliente.ifBlank { "Sin cliente" })
                        Text(fechaHora(v.inicio), style = MaterialTheme.typography.bodySmall)
                        Calculos.kmOficiales(v.odometroInicial, v.odometroFinal)?.let { Text("🛣️ $it km (odómetro)") }
                    }
                }
            }
        }
    }
}

// ---------------- DETALLE ----------------
@Composable
fun DetalleViajeScreen(vm: MainViewModel, nav: NavController, id: String) {
    val ctx = LocalContext.current
    val viaje by vm.viaje(id).collectAsStateWithLifecycle(null)
    val jornadas by vm.jornadas(id).collectAsStateWithLifecycle(emptyList())
    val gastos by vm.gastos(id).collectAsStateWithLifecycle(emptyList())
    val puntos by vm.puntos(id).collectAsStateWithLifecycle(emptyList())
    val paradas by vm.paradas(id).collectAsStateWithLifecycle(emptyList())
    val adelantos by vm.adelantos(id).collectAsStateWithLifecycle(emptyList())
    val siguiendo by TrackingService.siguiendo.collectAsStateWithLifecycle()

    var dialogoFin by remember { mutableStateOf(false) }
    var jornadaEdit by remember { mutableStateOf<Jornada?>(null) }
    var gastoEdit by remember { mutableStateOf<Gasto?>(null) }
    var borrarViaje by remember { mutableStateOf(false) }
    var gpsPendiente by remember { mutableStateOf<String?>(null) }
    var verMapa by remember { mutableStateOf(false) }
    var selectorParada by remember { mutableStateOf(false) }
    var pendienteAuto by remember { mutableStateOf(false) }
    var adelantoEdit by remember { mutableStateOf<Adelanto?>(null) }
    var rutaPuntos by remember { mutableStateOf<List<Pair<String, GeoPoint>>?>(null) }
    var gpsOn by remember { mutableStateOf(Gps.gpsActivo(ctx)) }
    LaunchedEffect(Unit) { while (true) { gpsOn = Gps.gpsActivo(ctx); delay(3000) } }

    val scope = rememberCoroutineScope()
    SolicitudGps(gpsPendiente) { gpsPendiente = null }
    val v = viaje ?: return
    fun conPdf(accion: (File) -> Unit) {
        scope.launch {
            try {
                val f = withContext(Dispatchers.IO) { InformePdf.generar(ctx, v, jornadas, gastos, puntos, adelantos) }
                accion(f)
            } catch (e: Exception) {
                Toast.makeText(ctx, "No se pudo generar el PDF.", Toast.LENGTH_LONG).show()
            }
        }
    }
    val abierta = jornadas.firstOrNull { it.finMin < 0 }
    val enCurso = v.estado == Viaje.Estado.EN_CURSO
    LaunchedEffect(pendienteAuto, enCurso) { if (pendienteAuto && !enCurso) verMapa = true }

    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Box(
                Modifier.fillMaxWidth()
                    .background(Brush.linearGradient(listOf(AzulProfundo, AzulMedio)), RoundedCornerShape(24.dp))
                    .padding(18.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    EstadoChip(v.estado)
                    Text(v.nombre, style = MaterialTheme.typography.headlineSmall, color = Color.White)
                    Text(v.cliente.ifBlank { "Sin cliente" }, color = Color.White.copy(alpha = 0.85f))
                    Text("${v.origen.ifBlank { "—" }} → ${v.destino.ifBlank { "—" }}", color = Color.White.copy(alpha = 0.85f))
                    Text("Inicio: ${fechaHora(v.inicio)}", color = Color.White.copy(alpha = 0.85f))
                    v.fin?.let { Text("Fin: ${fechaHora(it)}", color = Color.White.copy(alpha = 0.85f)) }
                    Text(
                        "Odómetro: ${v.odometroInicial}" + (v.odometroFinal?.let { " → $it" } ?: "") + " km",
                        color = Color.White.copy(alpha = 0.85f)
                    )
                }
            }
        }
        item {
            Tarjeta("Kilómetros oficiales (odómetro)",
                Calculos.kmOficiales(v.odometroInicial, v.odometroFinal)?.let { "$it km" } ?: "Se calcula al finalizar")
        }
        item { ResumenRendicion(adelantos, gastos) }

        // ----- GPS -----
        item {
            Seccion("Seguimiento GPS")
            if (enCurso) {
                if (siguiendo == v.id) {
                    Text("GPS activo: registrando el recorrido.", color = Verde)
                    if (!gpsOn) Text("Atención: el GPS del teléfono está apagado. Encendelo para registrar.", color = MaterialTheme.colorScheme.error)
                    BotonSec({ Gps.detener(ctx) }, Modifier.fillMaxWidth()) { Text("Detener seguimiento") }
                } else {
                    Text("Seguimiento detenido: no se está registrando el recorrido.", color = MaterialTheme.colorScheme.error)
                    BotonGrande("Iniciar seguimiento GPS", verde = true) { gpsPendiente = id }
                }
                Text("Para viajes largos, en Ajustes de la app poné la batería en \"Sin restricciones\".", style = MaterialTheme.typography.bodySmall)
                TextButton({
                    ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")))
                }) { Text("Abrir ajustes de la app") }
            }
            Text("Puntos GPS registrados: ${puntos.size}")
            Text("Distancia GPS (solo referencia, no oficial): ${"%.1f".format(Calculos.distanciaGpsKm(puntos))} km")
            BotonSec({ verMapa = true }, Modifier.fillMaxWidth()) { Text(if (enCurso) "Mapa en vivo (seguir mi recorrido)" else "Ver mapa del recorrido") }
        }

        // ----- Paradas -----
        item { Seccion("Paradas") }
        items(paradas, key = { "p${it.id}" }) { p ->
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("${paradas.indexOf(p) + 1}. ${p.nombre}", Modifier.weight(1f))
                    TextButton({ vm.borrarParada(p) }) { Text("Quitar") }
                }
            }
        }
        item {
            BotonSec({ selectorParada = true }, Modifier.fillMaxWidth()) { Text("Agregar parada en el mapa") }
            BotonSec({
                val oL = v.origenLat; val oN = v.origenLng; val dL = v.destinoLat; val dN = v.destinoLng
                val origenPunto = if (oL != null && oN != null) GeoPoint(oL, oN)
                else Gps.ultimaUbicacion(ctx)?.let { GeoPoint(it.latitude, it.longitude) }
                if (origenPunto == null || dL == null || dN == null) {
                    Toast.makeText(ctx, "Falta marcar el destino en el mapa (y el origen, o tener la ubicación del teléfono).", Toast.LENGTH_LONG).show()
                } else {
                    rutaPuntos = buildList<Pair<String, GeoPoint>> {
                        add("Origen" to origenPunto)
                        paradas.forEach { add(it.nombre to GeoPoint(it.lat, it.lng)) }
                        add("Destino" to GeoPoint(dL, dN))
                    }
                }
            }, Modifier.fillMaxWidth()) { Text("Calcular ruta para camión") }
        }

        // ----- Jornadas -----
        item { Seccion("Jornadas") }
        items(jornadas, key = { "j${it.id}" }) { j ->
            val t = Calculos.minutosTrabajados(j)
            Card(Modifier.fillMaxWidth().clickable { jornadaEdit = j }) {
                Column(Modifier.padding(12.dp)) {
                    Text(LocalDate.parse(j.fecha).format(fechaUi), fontWeight = FontWeight.Bold)
                    if (j.finMin < 0) {
                        Text("En curso desde ${Calculos.hhmm(j.inicioMin)}")
                    } else {
                        Text("${Calculos.hhmm(j.inicioMin)}–${Calculos.hhmm(j.finMin)} · pausa ${j.pausaMin} min" +
                            if (j.descuentaPausa) " (descontada)" else " (no descontada)")
                        Text("Total ${Calculos.hhmm(t)} · normales ${Calculos.hhmm(Calculos.normales(t))} · extras ${Calculos.hhmm(Calculos.extras(t))}")
                    }
                }
            }
        }
        item {
            Text("Horas extras del viaje: ${Calculos.hhmm(Calculos.extrasTotales(jornadas))} h", fontWeight = FontWeight.Bold)
            if (enCurso) {
                if (abierta != null) BotonGrande("Finalizar jornada de hoy") { vm.finalizarJornada(abierta) }
                else BotonSec({ vm.iniciarJornada(id) }, Modifier.fillMaxWidth()) { Text("Iniciar nueva jornada") }
            }
            BotonSec({ jornadaEdit = Jornada(viajeId = id, fecha = LocalDate.now().toString(), inicioMin = 8 * 60, finMin = 18 * 60) },
                Modifier.fillMaxWidth()) { Text("Agregar jornada manual") }
        }

        // ----- Gastos -----
        item { Seccion("Plata recibida de la empresa") }
        items(adelantos, key = { "a${it.id}" }) { a ->
            Card(Modifier.fillMaxWidth().clickable { adelantoEdit = a }) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(Calculos.pesos(a.importeCentavos), fontWeight = FontWeight.Bold)
                        Text("${fechaHora(a.fechaHora)} ${a.descripcion}", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
        item {
            BotonSec({ adelantoEdit = Adelanto(viajeId = id, fechaHora = System.currentTimeMillis(), importeCentavos = 0) },
                Modifier.fillMaxWidth()) { Text("Registrar plata recibida") }
        }
        item { Seccion("Gastos") }
        items(gastos, key = { "g${it.id}" }) { g ->
            val mini = remember(g.fotoPath) { g.fotoPath?.let { Fotos.cargar(it, 160)?.asImageBitmap() } }
            Card(Modifier.fillMaxWidth().clickable { gastoEdit = g }) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    if (mini != null) {
                        Image(mini, contentDescription = "Ticket", modifier = Modifier.size(56.dp).clip(RoundedCornerShape(10.dp)), contentScale = ContentScale.Crop)
                    }
                    Column(Modifier.weight(1f)) {
                        Text("${g.categoria} · ${Calculos.pesos(g.importeCentavos)}", fontWeight = FontWeight.Bold)
                        Text("${fechaHora(g.fechaHora)} ${g.descripcion}")
                        if (g.fotoPath != null && mini == null) Text("Foto del ticket no disponible", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
        item {
            CATEGORIAS_GASTO.forEach { cat ->
                val total = gastos.filter { it.categoria == cat }.sumOf { it.importeCentavos }
                if (total > 0) Text("$cat: ${Calculos.pesos(total)}")
            }
            Text("Total general: ${Calculos.pesos(gastos.sumOf { it.importeCentavos })}", fontWeight = FontWeight.Bold)
            BotonSec({ gastoEdit = Gasto(viajeId = id, fechaHora = System.currentTimeMillis(), categoria = CATEGORIAS_GASTO[0], importeCentavos = 0) },
                Modifier.fillMaxWidth()) { Text("Agregar gasto") }
        }
        item {
            Seccion("Informe PDF")
            Text("Incluye datos del viaje, odómetro, horas, gastos y recorrido. Funciona sin internet.", style = MaterialTheme.typography.bodySmall)
            BotonSec({ conPdf { InformePdf.compartir(ctx, it) } }, Modifier.fillMaxWidth()) { Text("Compartir informe PDF") }
            BotonSec({
                conPdf {
                    val ok = InformePdf.guardarEnDescargas(ctx, it)
                    Toast.makeText(ctx, if (ok) "Guardado en Descargas" else "No se pudo guardar", Toast.LENGTH_LONG).show()
                }
            }, Modifier.fillMaxWidth()) { Text("Guardar PDF en Descargas") }
        }
        item {
            if (enCurso) BotonGrande("Finalizar viaje", verde = true) { dialogoFin = true }
            TextButton({ borrarViaje = true }) { Text("Eliminar viaje") }
            TextButton({ nav.popBackStack() }) { Text("Volver") }
        }
    }

    if (verMapa) MapaRecorrido(v, paradas, puntos, enCurso, siguiendo == v.id, pendienteAuto, { pendienteAuto = false }) {
        verMapa = false; pendienteAuto = false
    }
    rutaPuntos?.let { pts ->
        RutaCamionDialog(pts, onDismiss = { rutaPuntos = null }, onAjustes = { rutaPuntos = null; nav.navigate("ajustes") })
    }
    if (selectorParada) SelectorUbicacion("Elegí la parada", onDismiss = { selectorParada = false }) { txt, la, lo ->
        vm.agregarParada(Parada(viajeId = id, orden = paradas.size, nombre = txt, lat = la, lng = lo))
        selectorParada = false
    }
    if (dialogoFin) DialogoFinalizar(v, onDismiss = { dialogoFin = false }) { odo ->
        if (TrackingService.siguiendo.value == v.id) Gps.detener(ctx)
        vm.finalizarViaje(v, odo)
        pendienteAuto = true
        dialogoFin = false
    }
    jornadaEdit?.let { j -> DialogoJornada(j, onDismiss = { jornadaEdit = null },
        onBorrar = { vm.borrarJornada(j); jornadaEdit = null }) { vm.guardarJornada(it); jornadaEdit = null } }
    adelantoEdit?.let { a -> DialogoAdelanto(a, onDismiss = { adelantoEdit = null },
        onBorrar = { vm.borrarAdelanto(a); adelantoEdit = null }) { vm.guardarAdelanto(it); adelantoEdit = null } }
    gastoEdit?.let { g -> DialogoGasto(g, onDismiss = { gastoEdit = null },
        onBorrar = { vm.borrarGasto(g); gastoEdit = null }) { vm.guardarGasto(it); gastoEdit = null } }
    if (borrarViaje) AlertDialog(
        onDismissRequest = { borrarViaje = false },
        title = { Text("¿Eliminar viaje?") },
        text = { Text("Se borrarán también sus jornadas, gastos y recorrido GPS. No se puede deshacer.") },
        confirmButton = {
            TextButton({
                if (TrackingService.siguiendo.value == v.id) Gps.detener(ctx)
                vm.borrarViaje(v); borrarViaje = false; nav.popBackStack()
            }) { Text("Eliminar") }
        },
        dismissButton = { TextButton({ borrarViaje = false }) { Text("Cancelar") } }
    )
}

@Composable
private fun DialogoFinalizar(v: Viaje, onDismiss: () -> Unit, onOk: (Long) -> Unit) {
    var odo by remember { mutableStateOf("") }
    val n = odo.toLongOrNull()
    val error = n != null && n < v.odometroInicial
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Finalizar viaje") },
        text = {
            Column {
                Text("Se guarda la hora de fin, se cierra la jornada y se calculan las horas extras.", style = MaterialTheme.typography.bodySmall)
                Campo(odo, { odo = it.filter(Char::isDigit) }, "Odómetro final (km)", numerico = true)
                if (error) Text("No puede ser menor al inicial (${v.odometroInicial}).", color = MaterialTheme.colorScheme.error)
                else if (n != null) Text("Kilómetros oficiales: ${n - v.odometroInicial} km")
            }
        },
        confirmButton = { TextButton({ onOk(n!!) }, enabled = n != null && !error) { Text("Confirmar y cerrar") } },
        dismissButton = { TextButton(onDismiss) { Text("Cancelar") } }
    )
}

@Composable
private fun DialogoJornada(j: Jornada, onDismiss: () -> Unit, onBorrar: () -> Unit, onOk: (Jornada) -> Unit) {
    var fecha by remember { mutableStateOf(LocalDate.parse(j.fecha).format(fechaUi)) }
    var ini by remember { mutableStateOf(Calculos.hhmm(j.inicioMin).padStart(5, '0')) }
    var fin by remember {
        mutableStateOf(Calculos.hhmm(if (j.finMin < 0) Calculos.minutoActual() else j.finMin).padStart(5, '0'))
    }
    var pausa by remember { mutableStateOf(j.pausaMin.toString()) }
    var descuenta by remember { mutableStateOf(j.descuentaPausa) }
    var obs by remember { mutableStateOf(j.observaciones) }
    val f = runCatching { LocalDate.parse(fecha, fechaUi) }.getOrNull()
    val i = Calculos.parseHora(ini); val e = Calculos.parseHora(fin); val p = pausa.toIntOrNull()
    val valido = f != null && i != null && e != null && p != null
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (j.id == 0L) "Nueva jornada" else "Editar jornada") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Campo(fecha, { fecha = it }, "Fecha (dd/mm/aaaa)")
                Campo(ini, { ini = it }, "Inicio (HH:mm)")
                Campo(fin, { fin = it }, "Fin (HH:mm)")
                Campo(pausa, { pausa = it.filter(Char::isDigit) }, "Pausas (minutos)", numerico = true)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(descuenta, { descuenta = it }); Text("Descontar pausas del total")
                }
                Campo(obs, { obs = it }, "Observaciones")
                if (valido) {
                    val t = Calculos.minutosTrabajados(Jornada(viajeId = "", fecha = "", inicioMin = i!!, finMin = e!!, pausaMin = p!!, descuentaPausa = descuenta))
                    Text("Total ${Calculos.hhmm(t)} · extras ${Calculos.hhmm(Calculos.extras(t))}")
                }
            }
        },
        confirmButton = {
            TextButton({ onOk(j.copy(fecha = f.toString(), inicioMin = i!!, finMin = e!!, pausaMin = p!!, descuentaPausa = descuenta, observaciones = obs)) },
                enabled = valido) { Text("Guardar") }
        },
        dismissButton = {
            Row { if (j.id != 0L) TextButton(onBorrar) { Text("Borrar") }; TextButton(onDismiss) { Text("Cancelar") } }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DialogoGasto(g: Gasto, onDismiss: () -> Unit, onBorrar: () -> Unit, onOk: (Gasto) -> Unit) {
    val ctx = LocalContext.current
    var cat by remember { mutableStateOf(g.categoria) }
    var importe by remember { mutableStateOf(if (g.id == 0L) "" else (g.importeCentavos / 100.0).toString().replace('.', ',')) }
    var desc by remember { mutableStateOf(g.descripcion) }
    var obs by remember { mutableStateOf(g.observaciones) }
    var foto by remember { mutableStateOf(g.fotoPath) }
    var pendiente by remember { mutableStateOf<File?>(null) }
    val c = Calculos.parseImporte(importe)

    val camara = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val f = pendiente
        if (ok && f != null) foto = f.path else f?.delete()
        pendiente = null
    }
    val galeria = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            val f = Fotos.copiarDesde(ctx, uri)
            if (f != null) foto = f.path else Toast.makeText(ctx, "No se pudo cargar la foto.", Toast.LENGTH_LONG).show()
        }
    }
    val imagen = remember(foto) { foto?.let { Fotos.cargar(it, 900)?.asImageBitmap() } }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (g.id == 0L) "Nuevo gasto" else "Editar gasto") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    CATEGORIAS_GASTO.forEach { FilterChip(cat == it, { cat = it }, label = { Text(it) }) }
                }
                Campo(importe, { importe = it }, "Importe (ARS)", numerico = true)
                Campo(desc, { desc = it }, "Descripción")
                Campo(obs, { obs = it }, "Observaciones")
                Text("Foto del ticket", style = MaterialTheme.typography.titleSmall)
                if (imagen != null) {
                    Image(imagen, contentDescription = "Ticket", modifier = Modifier.fillMaxWidth().heightIn(max = 220.dp), contentScale = ContentScale.Fit)
                }
                BotonSec({
                    val f = Fotos.nuevoArchivo(ctx)
                    pendiente = f
                    camara.launch(Fotos.uri(ctx, f))
                }, Modifier.fillMaxWidth()) { Text(if (foto == null) "📷 Sacar foto del ticket" else "📷 Sacar otra foto") }
                BotonSec({
                    galeria.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }, Modifier.fillMaxWidth()) { Text("🖼️ Elegir de la galería") }
                if (foto != null) TextButton({
                    if (foto != g.fotoPath) foto?.let { File(it).delete() }
                    foto = null
                }) { Text("Quitar foto") }
            }
        },
        confirmButton = {
            TextButton({ onOk(g.copy(categoria = cat, importeCentavos = c!!, descripcion = desc, observaciones = obs, fotoPath = foto)) },
                enabled = c != null && c > 0) { Text("Guardar") }
        },
        dismissButton = { Row { if (g.id != 0L) TextButton(onBorrar) { Text("Borrar") }; TextButton(onDismiss) { Text("Cancelar") } } }
    )
}

@Composable
private fun DialogoAdelanto(a: Adelanto, onDismiss: () -> Unit, onBorrar: () -> Unit, onOk: (Adelanto) -> Unit) {
    var importe by remember { mutableStateOf(if (a.id == 0L) "" else (a.importeCentavos / 100.0).toString().replace('.', ',')) }
    var desc by remember { mutableStateOf(a.descripcion) }
    val c = Calculos.parseImporte(importe)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (a.id == 0L) "Plata recibida de la empresa" else "Editar plata recibida") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Anotá lo que te dio la empresa para el viaje (adelanto, viáticos).", style = MaterialTheme.typography.bodySmall)
                Campo(importe, { importe = it }, "Importe (ARS)", numerico = true)
                Campo(desc, { desc = it }, "Descripción (ej. adelanto, viáticos)")
            }
        },
        confirmButton = {
            TextButton({ onOk(a.copy(importeCentavos = c!!, descripcion = desc)) }, enabled = c != null && c > 0) { Text("Guardar") }
        },
        dismissButton = { Row { if (a.id != 0L) TextButton(onBorrar) { Text("Borrar") }; TextButton(onDismiss) { Text("Cancelar") } } }
    )
}

/** Cuánta plata recibiste, cuánto gastaste y cuánto hay que devolver a la empresa. */
@Composable
private fun ResumenRendicion(adelantos: List<Adelanto>, gastos: List<Gasto>) {
    val recibido = adelantos.sumOf { it.importeCentavos }
    val gastado = gastos.sumOf { it.importeCentavos }
    val saldo = Calculos.saldoEmpresa(adelantos, gastos)
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("Rendición con la empresa", style = MaterialTheme.typography.titleMedium)
            Row { Text("Plata recibida", Modifier.weight(1f)); Text(Calculos.pesos(recibido), fontWeight = FontWeight.Bold) }
            Row { Text("Total de gastos", Modifier.weight(1f)); Text(Calculos.pesos(gastado), fontWeight = FontWeight.Bold) }
            Divider(Modifier.padding(vertical = 6.dp))
            Text(
                when {
                    saldo > 0 -> "A devolver a la empresa"
                    saldo < 0 -> "La empresa te debe"
                    else -> "Estás a mano"
                },
                style = MaterialTheme.typography.labelLarge
            )
            Text(
                if (saldo == 0L) "$ 0,00" else Calculos.pesos(abs(saldo)),
                style = MaterialTheme.typography.headlineSmall,
                color = when { saldo > 0 -> Ambar; saldo < 0 -> Verde; else -> MaterialTheme.colorScheme.onSurfaceVariant }
            )
        }
    }
}
