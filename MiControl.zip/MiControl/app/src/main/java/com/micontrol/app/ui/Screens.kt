package com.micontrol.app.ui

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.micontrol.app.data.*
import com.micontrol.app.domain.Calculos
import com.micontrol.app.gps.Gps
import com.micontrol.app.gps.TrackingService
import com.micontrol.app.pdf.InformePdf
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

private val fmt = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("es", "AR"))
private val fechaUi = DateTimeFormatter.ofPattern("dd/MM/yyyy")
private fun fechaHora(ms: Long) = fmt.format(ms)

@Composable
private fun Tarjeta(titulo: String, valor: String, modifier: Modifier = Modifier) {
    Card(modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(titulo, style = MaterialTheme.typography.labelLarge)
            Text(valor, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun BotonGrande(texto: String, enabled: Boolean = true, verde: Boolean = false, onClick: () -> Unit) {
    Button(
        onClick, Modifier.fillMaxWidth().height(56.dp), enabled = enabled,
        colors = if (verde) ButtonDefaults.buttonColors(containerColor = Verde) else ButtonDefaults.buttonColors()
    ) { Text(texto) }
}

@Composable
private fun Campo(valor: String, onChange: (String) -> Unit, etiqueta: String, numerico: Boolean = false, modifier: Modifier = Modifier) {
    OutlinedTextField(
        valor, onChange, modifier.fillMaxWidth(), label = { Text(etiqueta) },
        keyboardOptions = KeyboardOptions(keyboardType = if (numerico) KeyboardType.Number else KeyboardType.Text)
    )
}

/** Explica para qué se usa la ubicación, pide los permisos y arranca el seguimiento GPS del viaje. */
@Composable
private fun SolicitudGps(viajeId: String?, onFin: () -> Unit) {
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (viajeId != null && Gps.tienePermiso(ctx)) Gps.iniciar(ctx, viajeId)
        else Toast.makeText(ctx, "Sin permiso de ubicación no se registra el recorrido.", Toast.LENGTH_LONG).show()
        onFin()
    }
    if (viajeId != null) AlertDialog(
        onDismissRequest = onFin,
        title = { Text("Registrar recorrido GPS") },
        text = {
            Text(
                "Mi Control va a guardar tu ubicación durante el viaje, también con la pantalla apagada, " +
                    "y vas a ver una notificación mientras esté activo. Los datos quedan solo en tu teléfono."
            )
        },
        confirmButton = {
            TextButton({
                if (Gps.tienePermiso(ctx)) { Gps.iniciar(ctx, viajeId); onFin() }
                else launcher.launch(Gps.permisos())
            }) { Text("Aceptar") }
        },
        dismissButton = { TextButton(onFin) { Text("Ahora no") } }
    )
}

// ---------------- HOME ----------------
@Composable
fun HomeScreen(vm: MainViewModel, nav: NavController) {
    val viajes by vm.viajes.collectAsStateWithLifecycle()
    val jornadas by vm.todasJornadas.collectAsStateWithLifecycle()
    val gastos by vm.todosGastos.collectAsStateWithLifecycle()
    val activo = viajes.firstOrNull { it.estado == Viaje.Estado.EN_CURSO }
    val ultimo = viajes.firstOrNull { it.estado == Viaje.Estado.FINALIZADO }

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Mi Control", style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        Tarjeta("Viaje activo", activo?.nombre ?: "Ninguno")
        Tarjeta("Km del último viaje (odómetro)",
            ultimo?.let { Calculos.kmOficiales(it.odometroInicial, it.odometroFinal)?.let { k -> "$k km" } } ?: "—")
        Tarjeta("Horas extras acumuladas", Calculos.hhmm(Calculos.extrasTotales(jornadas)) + " h")
        Tarjeta("Gastos registrados", Calculos.pesos(gastos.sumOf { it.importeCentavos }))
        if (activo == null) BotonGrande("Iniciar viaje", verde = true) { nav.navigate("nuevo") }
        else BotonGrande("Viaje en curso") { nav.navigate("viaje/${activo.id}") }
        BotonGrande("Historial de viajes") { nav.navigate("historial") }
        BotonGrande("Clientes y destinos") { nav.navigate("clientes") }
        BotonGrande("Configuración") { nav.navigate("ajustes") }
        Text("Próximamente: rutas para camión.", style = MaterialTheme.typography.bodySmall)
    }
}

// ---------------- NUEVO VIAJE ----------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NuevoViajeScreen(vm: MainViewModel, nav: NavController) {
    val clientes by vm.clientes.collectAsStateWithLifecycle()
    var cliente by remember { mutableStateOf("") }
    var nombre by remember { mutableStateOf("") }
    var origen by remember { mutableStateOf("") }
    var destino by remember { mutableStateOf("") }
    var oLat by remember { mutableStateOf<Double?>(null) }
    var oLng by remember { mutableStateOf<Double?>(null) }
    var dLat by remember { mutableStateOf<Double?>(null) }
    var dLng by remember { mutableStateOf<Double?>(null) }
    val paradas = remember { mutableStateListOf<Parada>() }
    var odo by remember { mutableStateOf("") }
    var obs by remember { mutableStateOf("") }
    var selector by remember { mutableStateOf<String?>(null) }
    var gpsPendiente by remember { mutableStateOf<String?>(null) }
    val odoNum = odo.toLongOrNull()
    val sugeridos = clientes.filter { (cliente.isBlank() || it.nombre.contains(cliente, true)) && !it.nombre.equals(cliente, true) }

    SolicitudGps(gpsPendiente) { nav.popBackStack() }

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Iniciar viaje", style = MaterialTheme.typography.headlineSmall)
        Text("La hora de inicio se guarda sola al iniciar.", style = MaterialTheme.typography.bodySmall)
        Campo(cliente, { cliente = it }, "Cliente o empresa")
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            sugeridos.forEach { c ->
                AssistChip(onClick = {
                    cliente = c.nombre
                    if (destino.isBlank() && c.lat != null && c.lng != null) {
                        destino = c.direccion ?: c.nombre; dLat = c.lat; dLng = c.lng
                    }
                }, label = { Text(c.nombre) })
            }
        }
        Campo(nombre, { nombre = it }, "Nombre del viaje")
        Campo(origen, { origen = it }, "Dirección de origen")
        OutlinedButton({ selector = "origen" }, Modifier.fillMaxWidth()) {
            Text(if (oLat == null) "Elegir origen en el mapa" else "Origen marcado en el mapa (cambiar)")
        }
        Text("Paradas", style = MaterialTheme.typography.titleSmall)
        paradas.forEachIndexed { i, p ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${i + 1}. ${p.nombre}", Modifier.weight(1f), maxLines = 2)
                TextButton({ paradas.removeAt(i) }) { Text("Quitar") }
            }
        }
        OutlinedButton({ selector = "parada" }, Modifier.fillMaxWidth()) { Text("Agregar parada en el mapa") }
        Campo(destino, { destino = it }, "Dirección de destino")
        OutlinedButton({ selector = "destino" }, Modifier.fillMaxWidth()) {
            Text(if (dLat == null) "Elegir destino en el mapa" else "Destino marcado en el mapa (cambiar)")
        }
        Campo(odo, { odo = it.filter(Char::isDigit) }, "Odómetro inicial (km)", numerico = true)
        Campo(obs, { obs = it }, "Observaciones")
        BotonGrande("Iniciar viaje", enabled = nombre.isNotBlank() && odoNum != null, verde = true) {
            val v = Viaje(
                cliente = cliente.trim(), nombre = nombre.trim(), origen = origen.trim(), destino = destino.trim(),
                inicio = System.currentTimeMillis(), observaciones = obs.trim(), odometroInicial = odoNum!!,
                origenLat = oLat, origenLng = oLng, destinoLat = dLat, destinoLng = dLng
            )
            vm.iniciarViaje(v, paradas.mapIndexed { i, p -> p.copy(viajeId = v.id, orden = i) })
            gpsPendiente = v.id
        }
        TextButton(onClick = { nav.popBackStack() }) { Text("Cancelar") }
    }

    selector?.let { tipo ->
        SelectorUbicacion(
            when (tipo) { "origen" -> "Elegí el origen"; "parada" -> "Elegí la parada"; else -> "Elegí el destino" },
            onDismiss = { selector = null }
        ) { txt, la, lo ->
            when (tipo) {
                "origen" -> { origen = txt; oLat = la; oLng = lo }
                "parada" -> paradas.add(Parada(viajeId = "", orden = paradas.size, nombre = txt, lat = la, lng = lo))
                else -> { destino = txt; dLat = la; dLng = lo }
            }
            selector = null
        }
    }
}

// ---------------- HISTORIAL ----------------
@Composable
fun HistorialScreen(vm: MainViewModel, nav: NavController) {
    val viajes by vm.viajes.collectAsStateWithLifecycle()
    var filtro by remember { mutableStateOf("") }
    val lista = viajes.filter {
        filtro.isBlank() || it.cliente.contains(filtro, true) || it.nombre.contains(filtro, true) ||
            it.estado.contains(filtro, true) || fechaHora(it.inicio).contains(filtro)
    }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Historial de viajes", style = MaterialTheme.typography.headlineSmall)
        Campo(filtro, { filtro = it }, "Buscar (cliente, estado, mes/año…)")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
            items(lista, key = { it.id }) { v ->
                Card(Modifier.fillMaxWidth().clickable { nav.navigate("viaje/${v.id}") }) {
                    Column(Modifier.padding(16.dp)) {
                        Text(v.nombre, fontWeight = FontWeight.Bold)
                        Text("${v.cliente} · ${v.estado}")
                        Text(fechaHora(v.inicio))
                        Calculos.kmOficiales(v.odometroInicial, v.odometroFinal)?.let { Text("$it km (odómetro)") }
                    }
                }
            }
        }
    }
}

// ---------------- DETALLE ----------------
@Composable
fun DetalleViajeScreen(vm: MainViewModel, nav: NavController, id: String) {
    val ctx = LocalContext.current
    val viaje by vm.viaje(id).collectAsStateWithLifecycle(null)
    val jornadas by vm.jornadas(id).collectAsStateWithLifecycle(emptyList())
    val gastos by vm.gastos(id).collectAsStateWithLifecycle(emptyList())
    val puntos by vm.puntos(id).collectAsStateWithLifecycle(emptyList())
    val paradas by vm.paradas(id).collectAsStateWithLifecycle(emptyList())
    val siguiendo by TrackingService.siguiendo.collectAsStateWithLifecycle()

    var dialogoFin by remember { mutableStateOf(false) }
    var jornadaEdit by remember { mutableStateOf<Jornada?>(null) }
    var gastoEdit by remember { mutableStateOf<Gasto?>(null) }
    var borrarViaje by remember { mutableStateOf(false) }
    var gpsPendiente by remember { mutableStateOf<String?>(null) }
    var verMapa by remember { mutableStateOf(false) }
    var selectorParada by remember { mutableStateOf(false) }
    var gpsOn by remember { mutableStateOf(Gps.gpsActivo(ctx)) }
    LaunchedEffect(Unit) { while (true) { gpsOn = Gps.gpsActivo(ctx); delay(3000) } }

    val scope = rememberCoroutineScope()
    SolicitudGps(gpsPendiente) { gpsPendiente = null }
    val v = viaje ?: return
    fun conPdf(accion: (File) -> Unit) {
        scope.launch {
            try {
                val f = withContext(Dispatchers.IO) { InformePdf.generar(ctx, v, jornadas, gastos, puntos) }
                accion(f)
            } catch (e: Exception) {
                Toast.makeText(ctx, "No se pudo generar el PDF.", Toast.LENGTH_LONG).show()
            }
        }
    }
    val abierta = jornadas.firstOrNull { it.finMin < 0 }
    val enCurso = v.estado == Viaje.Estado.EN_CURSO

    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Text(v.nombre, style = MaterialTheme.typography.headlineSmall)
            Text("${v.cliente} · ${v.estado}")
            Text("${v.origen} → ${v.destino}")
            Text("Inicio: ${fechaHora(v.inicio)}")
            v.fin?.let { Text("Fin: ${fechaHora(it)}") }
            Text("Odómetro inicial: ${v.odometroInicial} km")
            v.odometroFinal?.let { Text("Odómetro final: $it km") }
        }
        item {
            Tarjeta("Kilómetros oficiales (odómetro)",
                Calculos.kmOficiales(v.odometroInicial, v.odometroFinal)?.let { "$it km" } ?: "Se calcula al finalizar")
        }

        // ----- GPS -----
        item {
            Text("Seguimiento GPS", style = MaterialTheme.typography.titleMedium)
            if (enCurso) {
                if (siguiendo == v.id) {
                    Text("GPS activo: registrando el recorrido.", color = Verde)
                    if (!gpsOn) Text("Atención: el GPS del teléfono está apagado. Encendelo para registrar.", color = MaterialTheme.colorScheme.error)
                    OutlinedButton({ Gps.detener(ctx) }, Modifier.fillMaxWidth()) { Text("Detener seguimiento") }
                } else {
                    Text("Seguimiento detenido: no se está registrando el recorrido.", color = MaterialTheme.colorScheme.error)
                    BotonGrande("Iniciar seguimiento GPS", verde = true) { gpsPendiente = id }
                }
                Text("Para viajes largos, en Ajustes de la app poné la batería en \"Sin restricciones\".", style = MaterialTheme.typography.bodySmall)
                TextButton({
                    ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")))
                }) { Text("Abrir ajustes de la app") }
            }
            Text("Puntos GPS registrados: ${puntos.size}")
            Text("Distancia GPS (solo referencia, no oficial): ${"%.1f".format(Calculos.distanciaGpsKm(puntos))} km")
            OutlinedButton({ verMapa = true }, Modifier.fillMaxWidth()) { Text("Ver mapa del recorrido") }
        }

        // ----- Paradas -----
        item { Text("Paradas", style = MaterialTheme.typography.titleMedium) }
        items(paradas, key = { "p${it.id}" }) { p ->
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("${paradas.indexOf(p) + 1}. ${p.nombre}", Modifier.weight(1f))
                    TextButton({ vm.borrarParada(p) }) { Text("Quitar") }
                }
            }
        }
        item {
            OutlinedButton({ selectorParada = true }, Modifier.fillMaxWidth()) { Text("Agregar parada en el mapa") }
        }

        // ----- Jornadas -----
        item { Text("Jornadas", style = MaterialTheme.typography.titleMedium) }
        items(jornadas, key = { "j${it.id}" }) { j ->
            val t = Calculos.minutosTrabajados(j)
            Card(Modifier.fillMaxWidth().clickable { jornadaEdit = j }) {
                Column(Modifier.padding(12.dp)) {
                    Text(LocalDate.parse(j.fecha).format(fechaUi), fontWeight = FontWeight.Bold)
                    if (j.finMin < 0) {
                        Text("En curso desde ${Calculos.hhmm(j.inicioMin)}")
                    } else {
                        Text("${Calculos.hhmm(j.inicioMin)}–${Calculos.hhmm(j.finMin)} · pausa ${j.pausaMin} min" +
                            if (j.descuentaPausa) " (descontada)" else " (no descontada)")
                        Text("Total ${Calculos.hhmm(t)} · normales ${Calculos.hhmm(Calculos.normales(t))} · extras ${Calculos.hhmm(Calculos.extras(t))}")
                    }
                }
            }
        }
        item {
            Text("Horas extras del viaje: ${Calculos.hhmm(Calculos.extrasTotales(jornadas))} h", fontWeight = FontWeight.Bold)
            if (enCurso) {
                if (abierta != null) BotonGrande("Finalizar jornada de hoy") { vm.finalizarJornada(abierta) }
                else OutlinedButton({ vm.iniciarJornada(id) }, Modifier.fillMaxWidth()) { Text("Iniciar nueva jornada") }
            }
            OutlinedButton({ jornadaEdit = Jornada(viajeId = id, fecha = LocalDate.now().toString(), inicioMin = 8 * 60, finMin = 18 * 60) },
                Modifier.fillMaxWidth()) { Text("Agregar jornada manual") }
        }

        // ----- Gastos -----
        item { Text("Gastos", style = MaterialTheme.typography.titleMedium) }
        items(gastos, key = { "g${it.id}" }) { g ->
            Card(Modifier.fillMaxWidth().clickable { gastoEdit = g }) {
                Column(Modifier.padding(12.dp)) {
                    Text("${g.categoria} · ${Calculos.pesos(g.importeCentavos)}", fontWeight = FontWeight.Bold)
                    Text("${fechaHora(g.fechaHora)} ${g.descripcion}")
                }
            }
        }
        item {
            CATEGORIAS_GASTO.forEach { cat ->
                val total = gastos.filter { it.categoria == cat }.sumOf { it.importeCentavos }
                if (total > 0) Text("$cat: ${Calculos.pesos(total)}")
            }
            Text("Total general: ${Calculos.pesos(gastos.sumOf { it.importeCentavos })}", fontWeight = FontWeight.Bold)
            OutlinedButton({ gastoEdit = Gasto(viajeId = id, fechaHora = System.currentTimeMillis(), categoria = CATEGORIAS_GASTO[0], importeCentavos = 0) },
                Modifier.fillMaxWidth()) { Text("Agregar gasto") }
        }
        item {
            Text("Informe PDF", style = MaterialTheme.typography.titleMedium)
            Text("Incluye datos del viaje, odómetro, horas, gastos y recorrido. Funciona sin internet.", style = MaterialTheme.typography.bodySmall)
            OutlinedButton({ conPdf { InformePdf.compartir(ctx, it) } }, Modifier.fillMaxWidth()) { Text("Compartir informe PDF") }
            OutlinedButton({
                conPdf {
                    val ok = InformePdf.guardarEnDescargas(ctx, it)
                    Toast.makeText(ctx, if (ok) "Guardado en Descargas" else "No se pudo guardar", Toast.LENGTH_LONG).show()
                }
            }, Modifier.fillMaxWidth()) { Text("Guardar PDF en Descargas") }
        }
        item {
            if (enCurso) BotonGrande("Finalizar viaje", verde = true) { dialogoFin = true }
            TextButton({ borrarViaje = true }) { Text("Eliminar viaje") }
            TextButton({ nav.popBackStack() }) { Text("Volver") }
        }
    }

    if (verMapa) MapaRecorrido(v, paradas, puntos) { verMapa = false }
    if (selectorParada) SelectorUbicacion("Elegí la parada", onDismiss = { selectorParada = false }) { txt, la, lo ->
        vm.agregarParada(Parada(viajeId = id, orden = paradas.size, nombre = txt, lat = la, lng = lo))
        selectorParada = false
    }
    if (dialogoFin) DialogoFinalizar(v, onDismiss = { dialogoFin = false }) { odo ->
        if (TrackingService.siguiendo.value == v.id) Gps.detener(ctx)
        vm.finalizarViaje(v, odo)
        dialogoFin = false
    }
    jornadaEdit?.let { j -> DialogoJornada(j, onDismiss = { jornadaEdit = null },
        onBorrar = { vm.borrarJornada(j); jornadaEdit = null }) { vm.guardarJornada(it); jornadaEdit = null } }
    gastoEdit?.let { g -> DialogoGasto(g, onDismiss = { gastoEdit = null },
        onBorrar = { vm.borrarGasto(g); gastoEdit = null }) { vm.guardarGasto(it); gastoEdit = null } }
    if (borrarViaje) AlertDialog(
        onDismissRequest = { borrarViaje = false },
        title = { Text("¿Eliminar viaje?") },
        text = { Text("Se borrarán también sus jornadas, gastos y recorrido GPS. No se puede deshacer.") },
        confirmButton = {
            TextButton({
                if (TrackingService.siguiendo.value == v.id) Gps.detener(ctx)
                vm.borrarViaje(v); borrarViaje = false; nav.popBackStack()
            }) { Text("Eliminar") }
        },
        dismissButton = { TextButton({ borrarViaje = false }) { Text("Cancelar") } }
    )
}

@Composable
private fun DialogoFinalizar(v: Viaje, onDismiss: () -> Unit, onOk: (Long) -> Unit) {
    var odo by remember { mutableStateOf("") }
    val n = odo.toLongOrNull()
    val error = n != null && n < v.odometroInicial
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Finalizar viaje") },
        text = {
            Column {
                Text("Se guarda la hora de fin, se cierra la jornada y se calculan las horas extras.", style = MaterialTheme.typography.bodySmall)
                Campo(odo, { odo = it.filter(Char::isDigit) }, "Odómetro final (km)", numerico = true)
                if (error) Text("No puede ser menor al inicial (${v.odometroInicial}).", color = MaterialTheme.colorScheme.error)
                else if (n != null) Text("Kilómetros oficiales: ${n - v.odometroInicial} km")
            }
        },
        confirmButton = { TextButton({ onOk(n!!) }, enabled = n != null && !error) { Text("Confirmar y cerrar") } },
        dismissButton = { TextButton(onDismiss) { Text("Cancelar") } }
    )
}

@Composable
private fun DialogoJornada(j: Jornada, onDismiss: () -> Unit, onBorrar: () -> Unit, onOk: (Jornada) -> Unit) {
    var fecha by remember { mutableStateOf(LocalDate.parse(j.fecha).format(fechaUi)) }
    var ini by remember { mutableStateOf(Calculos.hhmm(j.inicioMin).padStart(5, '0')) }
    var fin by remember {
        mutableStateOf(Calculos.hhmm(if (j.finMin < 0) Calculos.minutoActual() else j.finMin).padStart(5, '0'))
    }
    var pausa by remember { mutableStateOf(j.pausaMin.toString()) }
    var descuenta by remember { mutableStateOf(j.descuentaPausa) }
    var obs by remember { mutableStateOf(j.observaciones) }
    val f = runCatching { LocalDate.parse(fecha, fechaUi) }.getOrNull()
    val i = Calculos.parseHora(ini); val e = Calculos.parseHora(fin); val p = pausa.toIntOrNull()
    val valido = f != null && i != null && e != null && p != null
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (j.id == 0L) "Nueva jornada" else "Editar jornada") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Campo(fecha, { fecha = it }, "Fecha (dd/mm/aaaa)")
                Campo(ini, { ini = it }, "Inicio (HH:mm)")
                Campo(fin, { fin = it }, "Fin (HH:mm)")
                Campo(pausa, { pausa = it.filter(Char::isDigit) }, "Pausas (minutos)", numerico = true)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(descuenta, { descuenta = it }); Text("Descontar pausas del total")
                }
                Campo(obs, { obs = it }, "Observaciones")
                if (valido) {
                    val t = Calculos.minutosTrabajados(Jornada(viajeId = "", fecha = "", inicioMin = i!!, finMin = e!!, pausaMin = p!!, descuentaPausa = descuenta))
                    Text("Total ${Calculos.hhmm(t)} · extras ${Calculos.hhmm(Calculos.extras(t))}")
                }
            }
        },
        confirmButton = {
            TextButton({ onOk(j.copy(fecha = f.toString(), inicioMin = i!!, finMin = e!!, pausaMin = p!!, descuentaPausa = descuenta, observaciones = obs)) },
                enabled = valido) { Text("Guardar") }
        },
        dismissButton = {
            Row { if (j.id != 0L) TextButton(onBorrar) { Text("Borrar") }; TextButton(onDismiss) { Text("Cancelar") } }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DialogoGasto(g: Gasto, onDismiss: () -> Unit, onBorrar: () -> Unit, onOk: (Gasto) -> Unit) {
    var cat by remember { mutableStateOf(g.categoria) }
    var importe by remember { mutableStateOf(if (g.id == 0L) "" else (g.importeCentavos / 100.0).toString().replace('.', ',')) }
    var desc by remember { mutableStateOf(g.descripcion) }
    var obs by remember { mutableStateOf(g.observaciones) }
    val c = Calculos.parseImporte(importe)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (g.id == 0L) "Nuevo gasto" else "Editar gasto") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    CATEGORIAS_GASTO.forEach { FilterChip(cat == it, { cat = it }, label = { Text(it) }) }
                }
                Campo(importe, { importe = it }, "Importe (ARS)", numerico = true)
                Campo(desc, { desc = it }, "Descripción")
                Campo(obs, { obs = it }, "Observaciones")
            }
        },
        confirmButton = { TextButton({ onOk(g.copy(categoria = cat, importeCentavos = c!!, descripcion = desc, observaciones = obs)) }, enabled = c != null && c > 0) { Text("Guardar") } },
        dismissButton = { Row { if (g.id != 0L) TextButton(onBorrar) { Text("Borrar") }; TextButton(onDismiss) { Text("Cancelar") } } }
    )
}
