package com.micontrol.app.data

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.micontrol.app.domain.Calculos
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * "Ver desde la computadora": manda los viajes, gastos, jornadas y la ubicación en vivo a una planilla de Google
 * de la propia persona (con un script gratis de Google Apps Script). No usa servidores pagos.
 */
object Compu {
    private val ar = Locale("es", "AR")
    private fun p(ctx: Context) = ctx.getSharedPreferences("compu", Context.MODE_PRIVATE)
    private fun hora(ms: Long) = SimpleDateFormat("dd/MM/yyyy HH:mm", ar).format(Date(ms))

    /** Link de la página: el que pegó la persona, o el que viene incluido en la app (el de la empresa). */
    fun url(ctx: Context): String {
        val propio = p(ctx).getString("url", "")?.trim() ?: ""
        if (propio == "off") return ""
        return propio.ifBlank { com.micontrol.app.BuildConfig.COMPU_URL.trim() }
    }
    fun guardarUrl(ctx: Context, v: String) { p(ctx).edit().putString("url", v.trim()).apply() }
    fun desconectar(ctx: Context) { p(ctx).edit().putString("url", "off").apply() }
    fun incluido(): Boolean = com.micontrol.app.BuildConfig.COMPU_URL.startsWith("https://script.google.com/")
    fun usaIncluido(ctx: Context): Boolean = incluido() && url(ctx) == com.micontrol.app.BuildConfig.COMPU_URL.trim()
    fun activo(ctx: Context): Boolean = url(ctx).startsWith("https://script.google.com/")

    /** Identificador de este teléfono + perfil, para que la página separe a cada chofer. */
    fun idChofer(ctx: Context, perfilId: String): String =
        "${dispositivo(ctx)}-${perfilId.replace(Regex("[^A-Za-z0-9_-]"), "").take(20)}"

    /** El que comparte sus lugares con los demás choferes (el administrador). */
    fun adminLugares(ctx: Context): Boolean = p(ctx).getBoolean("admin_lugares", false)
    fun guardarAdminLugares(ctx: Context, v: Boolean) { p(ctx).edit().putBoolean("admin_lugares", v).apply() }
    fun horaLugares(ctx: Context): String = p(ctx).getString("hora_lugares", "") ?: ""

    /** La página de Google todavía es la versión vieja (no guarda el recorrido de los viajes). */
    fun paginaVieja(ctx: Context): Boolean = p(ctx).getBoolean("pagina_vieja", false)

    fun enVivo(ctx: Context): Boolean = p(ctx).getBoolean("vivo", true)
    fun guardarEnVivo(ctx: Context, v: Boolean) { p(ctx).edit().putBoolean("vivo", v).apply() }

    fun ultimoEnvio(ctx: Context): Long = p(ctx).getLong("ult_envio", 0L)

    /** Código para pegar en script.google.com. */
    fun script(ctx: Context): String =
        ctx.resources.openRawResource(com.micontrol.app.R.raw.compu_script).bufferedReader().use { it.readText() }

    // ---------- Identidad del celular ----------
    /** ID de este celular (se crea al instalar). */
    fun dispositivo(ctx: Context): String {
        var inst = p(ctx).getString("inst", null)
        if (inst == null) {
            inst = java.util.UUID.randomUUID().toString().replace("-", "").take(10)
            p(ctx).edit().putString("inst", inst).apply()
        }
        return inst
    }

    /** Clave secreta de este celular: nunca sale del teléfono salvo hacia tu Google. Si copian el APK, otro celular tiene otra clave. */
    private fun token(ctx: Context): String {
        var t = p(ctx).getString("tk", null)
        if (t == null) {
            val b = ByteArray(24)
            java.security.SecureRandom().nextBytes(b)
            t = b.joinToString("") { "%02x".format(it) }
            p(ctx).edit().putString("tk", t).apply()
        }
        return t
    }

    /** Estado de este celular según el administrador: "autorizado", "pendiente", "revocado" o "" si no se sabe. */
    fun estadoCelular(ctx: Context): String = p(ctx).getString("estado_cel", "") ?: ""
    fun soyAdmin(ctx: Context): Boolean = p(ctx).getBoolean("soy_admin", false)
    fun hayAdmin(ctx: Context): Boolean = p(ctx).getBoolean("hay_admin", false)
    private fun recordarEstado(ctx: Context, r: JSONObject?) {
        if (r == null) return
        val e = p(ctx).edit()
        if (r.has("estado")) e.putString("estado_cel", r.optString("estado"))
        if (r.has("admin")) e.putBoolean("soy_admin", r.optBoolean("admin", false))
        if (r.has("hayAdmin")) e.putBoolean("hay_admin", r.optBoolean("hayAdmin", false))
        e.apply()
    }

    /** Manda un JSON al script y devuelve la respuesta (null si no hubo conexión). */
    private fun mandarLeer(ctx: Context, o: JSONObject): JSONObject? {
        val u = url(ctx)
        if (!u.startsWith("https://script.google.com/")) return null
        o.put("dev", dispositivo(ctx)).put("tk", token(ctx))
        if (!o.has("chofer")) o.put("chofer", try { Perfiles.activo(ctx).nombre } catch (e: Exception) { "" })
        val c = URL(u).openConnection() as HttpURLConnection
        return try {
            c.requestMethod = "POST"
            c.doOutput = true
            c.instanceFollowRedirects = true   // Google contesta con una redirección donde está la respuesta
            c.connectTimeout = 15000
            c.readTimeout = 40000
            c.setRequestProperty("Content-Type", "text/plain; charset=utf-8")
            c.outputStream.use { it.write(o.toString().toByteArray(Charsets.UTF_8)) }
            if (c.responseCode !in 200..299) return null
            val txt = c.inputStream.bufferedReader().use { it.readText() }.trim()
            val r = if (txt.startsWith("{")) JSONObject(txt) else JSONObject().put("ok", txt == "ok")
            recordarEstado(ctx, r)
            r
        } catch (e: Exception) {
            null
        } finally {
            c.disconnect()
        }
    }

    /** Manda un JSON al script. Devuelve true si Google lo recibió y lo aceptó. */
    private fun mandar(ctx: Context, o: JSONObject): Boolean = mandarLeer(ctx, o)?.optBoolean("ok", false) == true

    /** Pregunta a Google si este celular está autorizado. */
    suspend fun consultarEstado(ctx: Context): JSONObject? = withContext(Dispatchers.IO) { mandarLeer(ctx, JSONObject().put("tipo", "estado")) }

    /** El dueño se identifica con su clave de administrador (la primera vez la crea). */
    suspend fun reclamarAdmin(ctx: Context, clave: String): JSONObject? = withContext(Dispatchers.IO) {
        mandarLeer(ctx, JSONObject().put("tipo", "admin_reclamar").put("clave", clave))
    }

    /** Lista de celulares (solo el administrador). Con objetivo/estado cambia uno. */
    suspend fun dispositivos(ctx: Context, objetivo: String? = null, estado: String? = null): JSONObject? = withContext(Dispatchers.IO) {
        val o = JSONObject().put("tipo", if (objetivo == null) "admin_dispositivos" else "admin_cambiar")
        if (objetivo != null) o.put("objetivo", objetivo).put("estado", estado ?: "autorizado")
        mandarLeer(ctx, o)
    }

    /** Para que los hoteles usen la misma conexión segura. */
    internal fun pedir(ctx: Context, o: JSONObject): JSONObject? = mandarLeer(ctx, o)

    // ---------- Ubicación en vivo (la manda el GPS durante el viaje) ----------
    private var ultimaUbicacion = 0L

    /** Al arrancar el GPS de un viaje, la primera ubicación se manda enseguida (sin esperar los 2 minutos). */
    fun reiniciarUbicacion() { ultimaUbicacion = 0L }

    /** Se llama con cada punto del GPS; manda como máximo uno cada 2 minutos. */
    suspend fun ubicacion(ctx: Context, perfilId: String, viajeId: String, lat: Double, lng: Double, velMs: Float?, tiempo: Long) {
        if (!activo(ctx) || !enVivo(ctx)) return
        val ahora = System.currentTimeMillis()
        if (ahora - ultimaUbicacion < 2 * 60_000L) return
        ultimaUbicacion = ahora
        try {
            val perfil = Perfiles.todos(ctx).firstOrNull { it.id == perfilId }
            val chofer = perfil?.nombre ?: ""
            val viaje = AppDatabase.get(ctx, perfilId).viajeDao().porId(viajeId).first()?.nombre ?: ""
            val o = JSONObject()
                .put("tipo", "ubicacion").put("id", idChofer(ctx, perfilId)).put("camion", perfil?.camion ?: "").put("chofer", chofer).put("viaje", viaje).put("hora", hora(tiempo)).put("t", tiempo)
                .put("lat", "%.6f".format(Locale.US, lat).toDouble()).put("lng", "%.6f".format(Locale.US, lng).toDouble())
                .put("vel", velMs?.let { Math.round(it * 3.6f) } ?: "")
            if (!mandar(ctx, o)) ultimaUbicacion = 0L   // si no hay señal, prueba con el próximo punto
        } catch (e: Exception) {
            ultimaUbicacion = 0L
        }
    }

    /** Avisa que terminó el seguimiento (la página muestra "Viaje terminado"). */
    fun finViaje(ctx: Context, perfilId: String) {
        if (!activo(ctx) || !enVivo(ctx)) return
        try {
            mandar(ctx, JSONObject().put("tipo", "fin").put("id", idChofer(ctx, perfilId)).put("hora", hora(System.currentTimeMillis())))
        } catch (e: Exception) { }
    }

    // ---------- Datos (viajes, gastos, jornadas, resumen) ----------
    private fun fila(vararg v: Any?): JSONArray = JSONArray().apply { v.forEach { put(it ?: "") } }
    private fun pesos(c: Long): Double = c / 100.0
    private fun horas(min: Int): String = Calculos.hhmm(min)

    /** Junta los datos del perfil activo y los manda. Devuelve true si salió bien. */
    suspend fun enviarDatos(ctx: Context): Boolean = withContext(Dispatchers.IO) {
        if (!activo(ctx)) return@withContext false
        try {
            val perfil = Perfiles.activo(ctx)
            val db = AppDatabase.get(ctx, perfil.id)
            val viajes = db.viajeDao().todos().first().sortedByDescending { it.inicio }
            val gastos = db.gastoDao().todos().first()
            val jornadas = db.jornadaDao().todas().first()
            val adelantos = db.adelantoDao().todos().first()
            val porId = viajes.associateBy { it.id }

            val tViajes = JSONArray().put(
                fila("Inicio", "Fin", "Viaje", "Cliente", "Estado", "Km", "Horas trabajadas", "Horas extras", "Gastos ($)", "Plata recibida ($)", "Saldo con la empresa ($)", "Litros", "Consumo (L/100 km)")
            )
            viajes.forEach { v ->
                val js = jornadas.filter { it.viajeId == v.id }
                val gs = gastos.filter { it.viajeId == v.id }
                val ad = adelantos.filter { it.viajeId == v.id }
                val estado = when (v.estado) {
                    Viaje.Estado.EN_CURSO -> "En curso"
                    Viaje.Estado.FINALIZADO -> "Terminado"
                    else -> "Pendiente"
                }
                tViajes.put(
                    fila(
                        hora(v.inicio), v.fin?.let { hora(it) }, v.nombre, v.cliente, estado,
                        Calculos.kmDecimas(v)?.let { it / 10.0 },
                        horas(js.sumOf { Calculos.minutosTrabajados(it) }), horas(Calculos.extrasTotales(js)),
                        pesos(Calculos.dinero(gs).sumOf { it.importeCentavos }), pesos(ad.sumOf { it.importeCentavos }),
                        pesos(Calculos.saldoEmpresa(ad, gs)),
                        Calculos.consumo(gs, Calculos.kmDecimas(v)?.let { it / 10.0 }, 0.0)?.litros?.let { Math.round(it * 10) / 10.0 },
                        Calculos.consumo(gs, Calculos.kmDecimas(v)?.let { it / 10.0 }, 0.0)?.lPor100?.let { Math.round(it * 10) / 10.0 }
                    )
                )
            }

            val tGastos = JSONArray().put(fila("Fecha", "Viaje", "Categoría", "Importe ($)", "Litros", "Descripción"))
            gastos.sortedByDescending { it.fechaHora }.forEach { g ->
                tGastos.put(fila(hora(g.fechaHora), porId[g.viajeId]?.nombre, g.categoria, pesos(g.importeCentavos), g.litros, g.descripcion))
            }

            val tJornadas = JSONArray().put(fila("Fecha", "Viaje", "Inicio", "Fin", "Pausa", "Trabajadas"))
            jornadas.sortedWith(compareByDescending<Jornada> { it.fecha }.thenByDescending { it.inicioMin }).forEach { j ->
                val fecha = j.fecha.split("-").let { if (it.size == 3) "${it[2]}/${it[1]}/${it[0]}" else j.fecha }
                tJornadas.put(
                    fila(
                        fecha, porId[j.viajeId]?.nombre, horas(j.inicioMin),
                        if (j.finMin < 0) "en curso" else horas(j.finMin),
                        if (j.pausaMin > 0) horas(j.pausaMin) else "", horas(Calculos.minutosTrabajados(j))
                    )
                )
            }

            val tResumen = JSONArray().put(
                fila("Mes", "Viajes", "Km", "Horas trabajadas", "Horas extras", "Gastos ($)", "Plata recibida ($)", "Saldo con la empresa ($)", "Litros")
            )
            val mesFmt = SimpleDateFormat("yyyy-MM", ar)
            viajes.groupBy { mesFmt.format(Date(it.inicio)) }.toSortedMap(compareByDescending<String> { it }).forEach { (mes, vs) ->
                val ids = vs.map { it.id }.toSet()
                val js = jornadas.filter { it.viajeId in ids }
                val gs = gastos.filter { it.viajeId in ids }
                val ad = adelantos.filter { it.viajeId in ids }
                val (a, m) = mes.split("-")
                tResumen.put(
                    fila(
                        "$m/$a", vs.size, vs.mapNotNull { Calculos.kmDecimas(it) }.sum() / 10.0,
                        horas(js.sumOf { Calculos.minutosTrabajados(it) }),
                        horas(vs.sumOf { v -> Calculos.extrasTotales(js.filter { it.viajeId == v.id }) }),
                        pesos(Calculos.dinero(gs).sumOf { it.importeCentavos }), pesos(ad.sumOf { it.importeCentavos }),
                        pesos(Calculos.saldoEmpresa(ad, gs)),
                        Math.round(Calculos.cargas(gs).sumOf { it.litros ?: 0.0 } * 10) / 10.0
                    )
                )
            }

            val o = JSONObject().put("tipo", "datos").put("id", idChofer(ctx, perfil.id)).put("chofer", perfil.nombre).put("camion", perfil.camion).put("hora", hora(System.currentTimeMillis()))
                .put("viajes", tViajes).put("gastos", tGastos).put("jornadas", tJornadas).put("resumen", tResumen)
            val ok = mandar(ctx, o)
            if (ok) p(ctx).edit().putLong("ult_envio", System.currentTimeMillis()).apply()
            // Recorrido de cada viaje (solo los que cambiaron desde el último envío)
            if (ok) try { enviarRutas(ctx, perfil.id, db, viajes) } catch (e: Exception) { }
            // Lugares: el administrador los sube; los demás los bajan
            try {
                if (adminLugares(ctx) && (soyAdmin(ctx) || !hayAdmin(ctx))) subirLugares(ctx) else bajarLugares(ctx)
            } catch (e: Exception) { }
            try { HotelesSync.sincronizar(ctx) } catch (e: Exception) { }
            ok
        } catch (e: Exception) {
            false
        }
    }

    // ---------- Recorrido de cada viaje (para verlo en el panel al tocar el viaje) ----------
    private fun red(x: Double): Double = Math.round(x * 100000.0) / 100000.0

    private fun metros(a: PuntoGps, b: PuntoGps): Float {
        val r = FloatArray(1)
        android.location.Location.distanceBetween(a.lat, a.lng, b.lat, b.lng, r)
        return r[0]
    }

    /** Se queda con un punto cada [umbral] metros (más el último), para que el recorrido pese poco. */
    private fun simplificar(pts: List<PuntoGps>, umbral: Double): List<PuntoGps> {
        if (pts.size <= 2) return pts
        val out = mutableListOf(pts.first())
        for (i in 1 until pts.size - 1) if (metros(out.last(), pts[i]) >= umbral) out.add(pts[i])
        out.add(pts.last())
        return out
    }

    /** Recorrido del viaje: línea, clientes (paradas) y lugares donde estuvo parado 30 min o más. */
    fun rutaJson(v: Viaje, puntos: List<PuntoGps>, paradas: List<Parada>): JSONObject {
        val pts = puntos.filter { it.precisionM <= 100f }.ifEmpty { puntos }.sortedBy { it.tiempo }
        var umbral = 150.0
        var r = simplificar(pts, umbral)
        while (r.size > 700 && umbral < 10000.0) { umbral *= 2; r = simplificar(pts, umbral) }
        val linea = JSONArray()
        r.forEach { linea.put(JSONArray().put(red(it.lat)).put(red(it.lng))) }
        // El GPS no anota puntos si el camión no se mueve: un hueco de 30 min o más es una parada larga
        val detenido = JSONArray()
        for (i in 1 until pts.size) {
            val hueco = pts[i].tiempo - pts[i - 1].tiempo
            if (hueco >= 30 * 60_000L && detenido.length() < 80) {
                detenido.put(
                    JSONArray().put(red(pts[i - 1].lat)).put(red(pts[i - 1].lng))
                        .put(hora(pts[i - 1].tiempo)).put(horas((hueco / 60_000L).toInt()))
                )
            }
        }
        val clientes = JSONArray()
        paradas.sortedBy { it.orden }.filter { it.lat != 0.0 || it.lng != 0.0 }.forEach {
            clientes.put(JSONArray().put(red(it.lat)).put(red(it.lng)).put(it.nombre))
        }
        return JSONObject().put("r", linea).put("d", detenido).put("c", clientes)
            .put("i", hora(v.inicio)).put("f", v.fin?.let { hora(it) } ?: "")
    }

    /** Manda el recorrido de los viajes de los últimos 60 días que cambiaron desde la última vez. */
    private suspend fun enviarRutas(ctx: Context, perfilId: String, db: AppDatabase, viajes: List<Viaje>) {
        val desde = System.currentTimeMillis() - 60L * 24 * 3600_000L
        val pr = p(ctx)
        viajes.filter { it.inicio >= desde }.take(30).forEach { v ->
            val puntos = db.puntoDao().porViaje(v.id).first()
            val paradas = db.paradaDao().porViaje(v.id).first()
            if (puntos.isEmpty() && paradas.isEmpty()) return@forEach
            val firma = "${puntos.size}|${puntos.lastOrNull()?.tiempo ?: 0}|${paradas.size}|${v.fin ?: 0}|${v.nombre}"
            val k = "ruta_${perfilId}_${v.id}"
            if (pr.getString(k, null) == firma) return@forEach
            val o = JSONObject().put("tipo", "ruta").put("id", idChofer(ctx, perfilId))
                .put("clave", hora(v.inicio) + "|" + v.nombre)
                .put("ruta", rutaJson(v, puntos, paradas).toString())
            // Solo se marca como enviado si la página ya es la versión 5 (sabe guardar recorridos)
            val resp = mandarLeer(ctx, o) ?: return
            val nueva = resp.optBoolean("ruta", false)
            pr.edit().putBoolean("pagina_vieja", !nueva).apply()
            if (nueva) pr.edit().putString(k, firma).apply() else return
        }
    }

    // ---------- Lugares compartidos ----------
    private fun num(o: Any?): Double? = when (o) {
        is Number -> o.toDouble()
        is String -> o.trim().replace(',', '.').toDoubleOrNull()
        else -> null
    }

    /** El administrador sube todos sus lugares (clientes, hoteles, etc.). */
    suspend fun subirLugares(ctx: Context): Boolean = withContext(Dispatchers.IO) {
        if (!activo(ctx)) return@withContext false
        val perfil = Perfiles.activo(ctx)
        val lugares = AppDatabase.get(ctx, perfil.id).clienteDao().todos().first()
        val t = JSONArray().put(fila("Nombre", "Dirección", "Latitud", "Longitud", "Tipo", "Lista", "Link Google"))
        lugares.sortedBy { it.nombre.lowercase() }.forEach { c ->
            t.put(fila(c.nombre, c.direccion, c.lat, c.lng, c.tipo, c.lista, c.url))
        }
        val ahora = hora(System.currentTimeMillis())
        val ok = mandar(ctx, JSONObject().put("tipo", "lugares").put("hora", ahora).put("lugares", t))
        if (ok) p(ctx).edit().putString("hora_lugares", ahora).apply()
        ok
    }

    /**
     * Los demás choferes bajan los lugares compartidos y se agregan a los suyos (no se borra nada propio).
     * Devuelve cuántos lugares nuevos o corregidos hubo, o -1 si no se pudo.
     */
    suspend fun bajarLugares(ctx: Context, forzar: Boolean = false): Int = withContext(Dispatchers.IO) {
        val u = url(ctx)
        if (!u.startsWith("https://script.google.com/")) return@withContext -1
        val c = URL(u + (if (u.contains("?")) "&" else "?") + "lugares=1&dev=" + dispositivo(ctx) + "&tk=" + token(ctx)).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 15000
            c.readTimeout = 30000
            c.instanceFollowRedirects = true
            if (c.responseCode != 200) return@withContext -1
            val o = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
            if (o.has("ok") && !o.optBoolean("ok")) return@withContext -1
            val hora = o.optString("hora")
            if (!forzar && hora.isNotBlank() && hora == horaLugares(ctx)) return@withContext 0
            val filas = o.optJSONArray("lugares") ?: return@withContext -1
            if (filas.length() < 2) return@withContext 0
            val cab = filas.getJSONArray(0)
            fun col(n: String): Int { for (i in 0 until cab.length()) if (cab.optString(i) == n) return i; return -1 }
            val iN = col("Nombre"); val iD = col("Dirección"); val iLa = col("Latitud"); val iLo = col("Longitud")
            val iT = col("Tipo"); val iL = col("Lista"); val iU = col("Link Google")
            if (iN < 0) return@withContext -1
            val dao = AppDatabase.get(ctx, Perfiles.activoId(ctx)).clienteDao()
            val mios = dao.todos().first().associateBy { it.nombre.trim().lowercase() }
            var cambios = 0
            for (i in 1 until filas.length()) {
                val r = filas.getJSONArray(i)
                fun txt(k: Int): String = if (k < 0) "" else r.opt(k)?.toString()?.trim().orEmpty()
                val nombre = txt(iN)
                if (nombre.isBlank()) continue
                val lat = if (iLa < 0) null else num(r.opt(iLa))
                val lng = if (iLo < 0) null else num(r.opt(iLo))
                val tipo = txt(iT).ifBlank { "Cliente" }
                val existe = mios[nombre.lowercase()]
                if (existe == null) {
                    dao.insertar(Cliente(nombre = nombre, direccion = txt(iD).ifBlank { null }, lat = lat, lng = lng, lista = txt(iL), tipo = tipo, url = txt(iU)))
                    cambios++
                } else if (lat != null && lng != null && (existe.lat != lat || existe.lng != lng)) {
                    // El administrador corrigió la ubicación: se actualiza
                    dao.actualizar(existe.copy(lat = lat, lng = lng, direccion = txt(iD).ifBlank { existe.direccion }))
                    cambios++
                }
            }
            p(ctx).edit().putString("hora_lugares", hora).apply()
            cambios
        } catch (e: Exception) {
            -1
        } finally {
            c.disconnect()
        }
    }

    /** Programa el envío de datos para cuando haya internet (se llama al salir de la app). */
    fun programarEnvio(ctx: Context) {
        if (!activo(ctx)) return
        val pedido = OneTimeWorkRequestBuilder<EnvioCompu>()
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .setInitialDelay(5, TimeUnit.SECONDS)
            .build()
        WorkManager.getInstance(ctx.applicationContext).enqueueUniqueWork("mi_control_compu", ExistingWorkPolicy.REPLACE, pedido)
    }
}

class EnvioCompu(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result =
        if (Compu.enviarDatos(applicationContext)) Result.success()
        else if (runAttemptCount < 3) Result.retry() else Result.failure()
}
