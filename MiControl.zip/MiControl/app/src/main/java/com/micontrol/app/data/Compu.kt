package com.micontrol.app.data

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.micontrol.app.domain.Calculos
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * "Ver desde la computadora": manda los viajes, gastos, jornadas y la ubicación en vivo a una planilla de Google
 * de la propia persona (con un script gratis de Google Apps Script). No usa servidores pagos.
 */
object Compu {
    private val ar = Locale("es", "AR")
    private fun p(ctx: Context) = ctx.getSharedPreferences("compu", Context.MODE_PRIVATE)
    private fun hora(ms: Long) = SimpleDateFormat("dd/MM/yyyy HH:mm", ar).format(Date(ms))

    fun url(ctx: Context): String = p(ctx).getString("url", "")?.trim() ?: ""
    fun guardarUrl(ctx: Context, v: String) { p(ctx).edit().putString("url", v.trim()).apply() }
    fun activo(ctx: Context): Boolean = url(ctx).startsWith("https://script.google.com/")

    fun enVivo(ctx: Context): Boolean = p(ctx).getBoolean("vivo", true)
    fun guardarEnVivo(ctx: Context, v: Boolean) { p(ctx).edit().putBoolean("vivo", v).apply() }

    fun ultimoEnvio(ctx: Context): Long = p(ctx).getLong("ult_envio", 0L)

    /** Código para pegar en script.google.com. */
    fun script(ctx: Context): String =
        ctx.resources.openRawResource(com.micontrol.app.R.raw.compu_script).bufferedReader().use { it.readText() }

    /** Manda un JSON al script. Devuelve true si Google lo recibió. */
    private fun mandar(ctx: Context, o: JSONObject): Boolean {
        val u = url(ctx)
        if (!u.startsWith("https://script.google.com/")) return false
        val c = URL(u).openConnection() as HttpURLConnection
        return try {
            c.requestMethod = "POST"
            c.doOutput = true
            c.instanceFollowRedirects = false   // Google contesta con una redirección: el dato ya quedó guardado
            c.connectTimeout = 15000
            c.readTimeout = 30000
            c.setRequestProperty("Content-Type", "text/plain; charset=utf-8")
            c.outputStream.use { it.write(o.toString().toByteArray(Charsets.UTF_8)) }
            c.responseCode in 200..399
        } catch (e: Exception) {
            false
        } finally {
            c.disconnect()
        }
    }

    // ---------- Ubicación en vivo (la manda el GPS durante el viaje) ----------
    private var ultimaUbicacion = 0L

    /** Se llama con cada punto del GPS; manda como máximo uno cada 2 minutos. */
    suspend fun ubicacion(ctx: Context, perfilId: String, viajeId: String, lat: Double, lng: Double, velMs: Float?, tiempo: Long) {
        if (!activo(ctx) || !enVivo(ctx)) return
        val ahora = System.currentTimeMillis()
        if (ahora - ultimaUbicacion < 2 * 60_000L) return
        ultimaUbicacion = ahora
        try {
            val chofer = Perfiles.todos(ctx).firstOrNull { it.id == perfilId }?.nombre ?: ""
            val viaje = AppDatabase.get(ctx, perfilId).viajeDao().porId(viajeId).first()?.nombre ?: ""
            val o = JSONObject()
                .put("tipo", "ubicacion").put("chofer", chofer).put("viaje", viaje).put("hora", hora(tiempo))
                .put("lat", "%.6f".format(Locale.US, lat).toDouble()).put("lng", "%.6f".format(Locale.US, lng).toDouble())
                .put("vel", velMs?.let { Math.round(it * 3.6f) } ?: "")
            if (!mandar(ctx, o)) ultimaUbicacion = 0L   // si no hay señal, prueba con el próximo punto
        } catch (e: Exception) {
            ultimaUbicacion = 0L
        }
    }

    /** Avisa que terminó el seguimiento (la página muestra "Viaje terminado"). */
    fun finViaje(ctx: Context) {
        if (!activo(ctx) || !enVivo(ctx)) return
        try { mandar(ctx, JSONObject().put("tipo", "fin").put("hora", hora(System.currentTimeMillis()))) } catch (e: Exception) { }
    }

    // ---------- Datos (viajes, gastos, jornadas, resumen) ----------
    private fun fila(vararg v: Any?): JSONArray = JSONArray().apply { v.forEach { put(it ?: "") } }
    private fun pesos(c: Long): Double = c / 100.0
    private fun horas(min: Int): String = Calculos.hhmm(min)

    /** Junta los datos del perfil activo y los manda. Devuelve true si salió bien. */
    suspend fun enviarDatos(ctx: Context): Boolean = withContext(Dispatchers.IO) {
        if (!activo(ctx)) return@withContext false
        try {
            val perfil = Perfiles.activo(ctx)
            val db = AppDatabase.get(ctx, perfil.id)
            val viajes = db.viajeDao().todos().first().sortedByDescending { it.inicio }
            val gastos = db.gastoDao().todos().first()
            val jornadas = db.jornadaDao().todas().first()
            val adelantos = db.adelantoDao().todos().first()
            val porId = viajes.associateBy { it.id }

            val tViajes = JSONArray().put(
                fila("Inicio", "Fin", "Viaje", "Cliente", "Estado", "Km", "Horas trabajadas", "Horas extras", "Gastos ($)", "Plata recibida ($)", "Saldo con la empresa ($)")
            )
            viajes.forEach { v ->
                val js = jornadas.filter { it.viajeId == v.id }
                val gs = gastos.filter { it.viajeId == v.id }
                val ad = adelantos.filter { it.viajeId == v.id }
                val estado = when (v.estado) {
                    Viaje.Estado.EN_CURSO -> "En curso"
                    Viaje.Estado.FINALIZADO -> "Terminado"
                    else -> "Pendiente"
                }
                tViajes.put(
                    fila(
                        hora(v.inicio), v.fin?.let { hora(it) }, v.nombre, v.cliente, estado,
                        Calculos.kmDecimas(v)?.let { it / 10.0 },
                        horas(js.sumOf { Calculos.minutosTrabajados(it) }), horas(Calculos.extrasTotales(js)),
                        pesos(gs.sumOf { it.importeCentavos }), pesos(ad.sumOf { it.importeCentavos }),
                        pesos(Calculos.saldoEmpresa(ad, gs))
                    )
                )
            }

            val tGastos = JSONArray().put(fila("Fecha", "Viaje", "Categoría", "Importe ($)", "Litros", "Descripción"))
            gastos.sortedByDescending { it.fechaHora }.forEach { g ->
                tGastos.put(fila(hora(g.fechaHora), porId[g.viajeId]?.nombre, g.categoria, pesos(g.importeCentavos), g.litros, g.descripcion))
            }

            val tJornadas = JSONArray().put(fila("Fecha", "Viaje", "Inicio", "Fin", "Pausa", "Trabajadas"))
            jornadas.sortedWith(compareByDescending<Jornada> { it.fecha }.thenByDescending { it.inicioMin }).forEach { j ->
                val fecha = j.fecha.split("-").let { if (it.size == 3) "${it[2]}/${it[1]}/${it[0]}" else j.fecha }
                tJornadas.put(
                    fila(
                        fecha, porId[j.viajeId]?.nombre, horas(j.inicioMin),
                        if (j.finMin < 0) "en curso" else horas(j.finMin),
                        if (j.pausaMin > 0) horas(j.pausaMin) else "", horas(Calculos.minutosTrabajados(j))
                    )
                )
            }

            val tResumen = JSONArray().put(
                fila("Mes", "Viajes", "Km", "Horas trabajadas", "Horas extras", "Gastos ($)", "Plata recibida ($)", "Saldo con la empresa ($)")
            )
            val mesFmt = SimpleDateFormat("yyyy-MM", ar)
            viajes.groupBy { mesFmt.format(Date(it.inicio)) }.toSortedMap(compareByDescending<String> { it }).forEach { (mes, vs) ->
                val ids = vs.map { it.id }.toSet()
                val js = jornadas.filter { it.viajeId in ids }
                val gs = gastos.filter { it.viajeId in ids }
                val ad = adelantos.filter { it.viajeId in ids }
                val (a, m) = mes.split("-")
                tResumen.put(
                    fila(
                        "$m/$a", vs.size, vs.mapNotNull { Calculos.kmDecimas(it) }.sum() / 10.0,
                        horas(js.sumOf { Calculos.minutosTrabajados(it) }),
                        horas(vs.sumOf { v -> Calculos.extrasTotales(js.filter { it.viajeId == v.id }) }),
                        pesos(gs.sumOf { it.importeCentavos }), pesos(ad.sumOf { it.importeCentavos }),
                        pesos(Calculos.saldoEmpresa(ad, gs))
                    )
                )
            }

            val o = JSONObject().put("tipo", "datos").put("chofer", perfil.nombre).put("hora", hora(System.currentTimeMillis()))
                .put("viajes", tViajes).put("gastos", tGastos).put("jornadas", tJornadas).put("resumen", tResumen)
            val ok = mandar(ctx, o)
            if (ok) p(ctx).edit().putLong("ult_envio", System.currentTimeMillis()).apply()
            ok
        } catch (e: Exception) {
            false
        }
    }

    /** Programa el envío de datos para cuando haya internet (se llama al salir de la app). */
    fun programarEnvio(ctx: Context) {
        if (!activo(ctx)) return
        val pedido = OneTimeWorkRequestBuilder<EnvioCompu>()
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .setInitialDelay(5, TimeUnit.SECONDS)
            .build()
        WorkManager.getInstance(ctx.applicationContext).enqueueUniqueWork("mi_control_compu", ExistingWorkPolicy.REPLACE, pedido)
    }
}

class EnvioCompu(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result =
        if (Compu.enviarDatos(applicationContext)) Result.success()
        else if (runAttemptCount < 3) Result.retry() else Result.failure()
}
