package com.micontrol.app.domain

import com.micontrol.app.data.Gasto
import com.micontrol.app.data.Mantenimiento
import com.micontrol.app.data.Vencimiento
import com.micontrol.app.data.Viaje
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import kotlin.math.max

/** Cosas que conviene que el chofer vea: vencimientos, service, copia de seguridad, gastos sin cargar. */
object Avisos {
    data class Aviso(val texto: String, val grave: Boolean, val destino: String)

    private val fechaUi = DateTimeFormatter.ofPattern("dd/MM/yyyy")
    private const val DIA_MS = 24L * 3600 * 1000

    /** Último odómetro conocido (el más alto cargado en los viajes), o null si no hay viajes. */
    fun odometroActual(viajes: List<Viaje>): Long? =
        viajes.maxOfOrNull { max(it.odometroInicial, it.odometroFinal ?: 0L) }

    /** Kilómetros que faltan para el próximo mantenimiento (negativo = ya se pasó). */
    fun kmRestantes(m: Mantenimiento, odometro: Long): Long = m.ultimoKm + m.cadaKm - odometro

    /** Días que faltan para un vencimiento (negativo = ya venció), o null si la fecha no se puede leer. */
    fun diasPara(v: Vencimiento, hoy: LocalDate): Long? =
        runCatching { ChronoUnit.DAYS.between(hoy, LocalDate.parse(v.fecha)) }.getOrNull()

    fun calcular(
        viajes: List<Viaje>, gastos: List<Gasto>, mants: List<Mantenimiento>, venc: List<Vencimiento>,
        ultimaCopiaMs: Long, ahoraMs: Long = System.currentTimeMillis(), hoy: LocalDate = LocalDate.now()
    ): List<Aviso> {
        val out = ArrayList<Aviso>()

        // Vencimientos
        venc.forEach { v ->
            val d = diasPara(v, hoy) ?: return@forEach
            val fecha = runCatching { LocalDate.parse(v.fecha).format(fechaUi) }.getOrDefault(v.fecha)
            when {
                d < 0 -> out.add(Aviso("VENCIDO: ${v.nombre} (venció el $fecha)", true, "camion"))
                d == 0L -> out.add(Aviso("${v.nombre} vence HOY", true, "camion"))
                d <= v.avisarDias -> out.add(Aviso("${v.nombre} vence en $d días ($fecha)", d <= 7, "camion"))
            }
        }

        // Mantenimiento por kilómetros
        val odo = odometroActual(viajes)
        if (odo != null) {
            mants.forEach { m ->
                val resta = kmRestantes(m, odo)
                val margen = max(500L, m.cadaKm / 10)
                when {
                    resta <= 0 -> out.add(Aviso("${m.tipo}: te pasaste ${-resta} km", true, "camion"))
                    resta <= margen -> out.add(Aviso("${m.tipo}: faltan $resta km", false, "camion"))
                }
            }
        }

        // Gastos del último viaje terminado
        val ultimo = viajes.filter { it.estado == Viaje.Estado.FINALIZADO }.maxByOrNull { it.fin ?: it.inicio }
        if (ultimo != null && gastos.none { it.viajeId == ultimo.id } &&
            ahoraMs - (ultimo.fin ?: ultimo.inicio) < 14 * DIA_MS
        ) {
            out.add(Aviso("Todavía no cargaste gastos de «${ultimo.nombre}»", false, "viaje/${ultimo.id}"))
        }

        // Litros sin cargar
        val sinLitros = gastos.count { it.categoria == "Combustible" && it.litros == null && ahoraMs - it.fechaHora < 45 * DIA_MS }
        if (sinLitros > 0) {
            out.add(Aviso("Falta cargar los litros de $sinLitros carga(s) de combustible (para ver el consumo)", false, "historial"))
        }

        // Copia de seguridad
        if (viajes.isNotEmpty()) {
            if (ultimaCopiaMs <= 0L) out.add(Aviso("Todavía no hiciste ninguna copia de seguridad", false, "ajustes"))
            else if (ahoraMs - ultimaCopiaMs > 30 * DIA_MS) out.add(Aviso("Hace más de 30 días que no hacés una copia de seguridad", false, "ajustes"))
        }

        return out.sortedByDescending { it.grave }
    }
}
