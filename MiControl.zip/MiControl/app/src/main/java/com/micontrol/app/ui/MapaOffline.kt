package com.micontrol.app.ui

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.ui.unit.dp
import com.micontrol.app.data.RutaCamion
import org.osmdroid.util.GeoPoint
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import org.osmdroid.tileprovider.cachemanager.CacheManager
import org.osmdroid.views.MapView

/**
 * Guarda en el teléfono los mapas de la zona que se está viendo (y un poco más cerca), para usarlos sin señal.
 * Es poca cantidad: equivale a lo que cargarías mirando y acercando esa misma zona.
 */
@Composable
fun BotonGuardarZona(mapView: MapView?, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    var ocupado by remember { mutableStateOf(false) }
    BotonSec({
        val m = mapView
        if (m == null) {
            Toast.makeText(ctx, "Esperá a que cargue el mapa.", Toast.LENGTH_SHORT).show()
        } else if (!hayInternet(ctx)) {
            Toast.makeText(ctx, "Necesitás internet para guardar la zona.", Toast.LENGTH_LONG).show()
        } else {
            try {
                val bb = m.boundingBox
                val z0 = m.zoomLevelDouble.toInt().coerceIn(3, 17)
                val z1 = (z0 + 2).coerceAtMost(17)
                val cm = CacheManager(m)
                val total = cm.possibleTilesInArea(bb, z0, z1)
                if (total > 900) {
                    Toast.makeText(ctx, "La zona es muy grande. Acercá el mapa y probá de nuevo.", Toast.LENGTH_LONG).show()
                } else {
                    ocupado = true
                    cm.downloadAreaAsync(ctx, bb, z0, z1, object : CacheManager.CacheManagerCallback {
                        override fun onTaskComplete() {
                            ocupado = false
                            Toast.makeText(ctx, "Zona guardada: ya la podés ver sin señal.", Toast.LENGTH_LONG).show()
                        }
                        override fun onTaskFailed(errors: Int) {
                            ocupado = false
                            Toast.makeText(ctx, "Se guardó parte de la zona (faltaron $errors mapas).", Toast.LENGTH_LONG).show()
                        }
                        override fun updateProgress(progress: Int, currentZoomLevel: Int, zoomMin: Int, zoomMax: Int) {}
                        override fun downloadStarted() {}
                        override fun setPossibleTilesInArea(total: Int) {}
                    })
                }
            } catch (e: Exception) {
                ocupado = false
                Toast.makeText(ctx, "Este mapa no permite guardar zonas. Cargá una clave de MapTiler en Ajustes.", Toast.LENGTH_LONG).show()
            }
        }
    }, modifier, enabled = !ocupado) { Text(if (ocupado) "Guardando…" else "💾 Zona sin señal", maxLines = 1) }
}

/**
 * Mapa del viaje sin señal: guarda en el teléfono el dibujo del recorrido y los mapas a lo largo de la ruta
 * (más detalle alrededor de cada parada). Se hace solo, una vez por viaje, cuando hay internet.
 */
object RutaOffline {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("ruta_offline", Context.MODE_PRIVATE)
    private fun archivo(ctx: Context, clave: String): java.io.File {
        val dir = java.io.File(ctx.filesDir, "rutas").apply { mkdirs() }
        return java.io.File(dir, Integer.toHexString(clave.hashCode()) + ".json")
    }

    /** Guarda el dibujo del recorrido (para verlo y calcular km sin señal). */
    fun guardar(ctx: Context, clave: String, r: RutaCamion.Resultado) {
        try {
            val pts = org.json.JSONArray()
            // Se guarda aligerado: alcanza para dibujarlo
            val paso = (r.puntos.size / 3000) + 1
            r.puntos.forEachIndexed { i, p -> if (i % paso == 0 || i == r.puntos.lastIndex) pts.put(org.json.JSONArray().put(p.first).put(p.second)) }
            val o = org.json.JSONObject().put("metros", r.metros).put("segundos", r.segundos).put("puntos", pts)
            archivo(ctx, clave).writeText(o.toString())
        } catch (e: Exception) { }
    }

    fun cargar(ctx: Context, clave: String): RutaCamion.Resultado? = try {
        val f = archivo(ctx, clave)
        if (!f.exists()) null else {
            val o = org.json.JSONObject(f.readText())
            val a = o.getJSONArray("puntos")
            val pts = (0 until a.length()).map { val p = a.getJSONArray(it); p.getDouble(0) to p.getDouble(1) }
            RutaCamion.Resultado(pts, o.getDouble("metros"), o.getDouble("segundos"), emptyList(), emptyList())
        }
    } catch (e: Exception) { null }

    fun mapaGuardado(ctx: Context, clave: String): Boolean = prefs(ctx).getBoolean("z_" + clave.hashCode(), false)

    /** true si la persona eligió el camino a mano (entonces no se recalcula solo). */
    fun elegida(ctx: Context, clave: String): Boolean = prefs(ctx).getBoolean("e_" + clave.hashCode(), false)
    fun olvidarElegida(ctx: Context, clave: String) {
        prefs(ctx).edit().remove("e_" + clave.hashCode()).remove("z_" + clave.hashCode()).remove("v_" + clave.hashCode()).apply()
    }

    /** Guarda el camino elegido y baja los mapas de ese camino. */
    fun usarCamino(ctx: Context, clave: String, r: RutaCamion.Resultado, paradas: List<GeoPoint>) {
        guardar(ctx, clave, r)
        prefs(ctx).edit().putBoolean("e_" + clave.hashCode(), true).remove("z_" + clave.hashCode()).apply()
        descargarSiFalta(ctx, clave, r.puntos.map { GeoPoint(it.first, it.second) }, paradas)
    }

    /** Puntos de paso ("pasar por acá") del recorrido. */
    fun vias(ctx: Context, clave: String): List<GeoPoint> = try {
        val a = org.json.JSONArray(prefs(ctx).getString("v_" + clave.hashCode(), "[]"))
        (0 until a.length()).map { val p = a.getJSONArray(it); GeoPoint(p.getDouble(0), p.getDouble(1)) }
    } catch (e: Exception) { emptyList() }
    fun guardarVias(ctx: Context, clave: String, v: List<GeoPoint>) {
        val a = org.json.JSONArray()
        v.forEach { a.put(org.json.JSONArray().put(it.latitude).put(it.longitude)) }
        prefs(ctx).edit().putString("v_" + clave.hashCode(), a.toString()).apply()
    }

    /** Mete cada punto de paso en el tramo donde menos desvía. */
    fun conVias(puntos: List<GeoPoint>, vias: List<GeoPoint>): List<GeoPoint> {
        val out = puntos.toMutableList()
        for (v in vias) {
            if (out.size < 2) { out.add(v); continue }
            var mejor = 0; var costo = Double.MAX_VALUE
            for (i in 0 until out.size - 1) {
                val c = out[i].distanceToAsDouble(v) + v.distanceToAsDouble(out[i + 1]) - out[i].distanceToAsDouble(out[i + 1])
                if (c < costo) { costo = c; mejor = i }
            }
            out.add(mejor + 1, v)
        }
        return out
    }

    var descargando by mutableStateOf(false)
        private set

    /** Baja los mapas a lo largo del recorrido. Corre solo una vez por recorrido. */
    fun descargarSiFalta(ctx: Context, clave: String, ruta: List<GeoPoint>, paradas: List<GeoPoint>) {
        if (descargando || mapaGuardado(ctx, clave) || ruta.size < 2 || !hayInternet(ctx)) return
        try {
            configurarMapas(ctx)
            val fuente = fuenteMapaPublica(ctx, modoOscuroActual(ctx))
            val cm = CacheManager(fuente, org.osmdroid.tileprovider.modules.SqlTileWriter(), 0, 19)
            // Tareas: la ruta entera con poco detalle, y cada parada con mucho detalle
            val camino = ArrayList(aligerarRuta(ruta, 400))
            val tareas = ArrayList<(CacheManager.CacheManagerCallback) -> Unit>()
            tareas.add { cb -> cm.downloadAreaAsyncNoUI(ctx, camino, 6, 13, cb) }
            paradas.take(30).forEach { p ->
                val d = 0.015
                val bb = org.osmdroid.util.BoundingBox(p.latitude + d, p.longitude + d, p.latitude - d, p.longitude - d)
                tareas.add { cb -> cm.downloadAreaAsyncNoUI(ctx, bb, 13, 16, cb) }
            }
            descargando = true
            var errores = 0
            fun siguiente(i: Int) {
                if (i >= tareas.size) {
                    descargando = false
                    if (errores < 30) prefs(ctx).edit().putBoolean("z_" + clave.hashCode(), true).apply()
                    return
                }
                tareas[i](object : CacheManager.CacheManagerCallback {
                    override fun onTaskComplete() { siguiente(i + 1) }
                    override fun onTaskFailed(errors: Int) { errores += errors; siguiente(i + 1) }
                    override fun updateProgress(progress: Int, currentZoomLevel: Int, zoomMin: Int, zoomMax: Int) {}
                    override fun downloadStarted() {}
                    override fun setPossibleTilesInArea(total: Int) {}
                })
            }
            siguiente(0)
        } catch (e: Exception) {
            descargando = false   // por ejemplo: el mapa básico sin clave no permite guardar zonas
        }
    }

    private fun aligerarRuta(seg: List<GeoPoint>, maximo: Int): List<GeoPoint> {
        if (seg.size <= maximo) return seg
        val paso = seg.size / maximo + 1
        val out = ArrayList<GeoPoint>()
        var i = 0
        while (i < seg.size) { out.add(seg[i]); i += paso }
        if (out.last() != seg.last()) out.add(seg.last())
        return out
    }
}

/** Mapa del recorrido a pantalla completa (si se guardó, se ve sin señal). */
@Composable
fun MapaRecorridoDialog(
    titulo: String,
    marcadores: List<Pair<GeoPoint, String>>,
    segmentos: List<List<GeoPoint>>,
    onDismiss: () -> Unit
) {
    androidx.compose.ui.window.Dialog(onDismiss, androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)) {
        androidx.compose.material3.Surface(androidx.compose.ui.Modifier.fillMaxSize()) {
            androidx.compose.foundation.layout.Column(androidx.compose.ui.Modifier.fillMaxSize()) {
                androidx.compose.foundation.layout.Row(
                    androidx.compose.ui.Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                ) {
                    Text(titulo, androidx.compose.ui.Modifier.weight(1f), style = androidx.compose.material3.MaterialTheme.typography.titleMedium, maxLines = 1)
                    androidx.compose.material3.TextButton(onDismiss) { Text("Cerrar ✕") }
                }
                MapaOsm(
                    androidx.compose.ui.Modifier.fillMaxWidth().weight(1f),
                    marcadores = marcadores, segmentos = segmentos, centrar = null, miUbicacion = true,
                    ajustar = segmentos.flatten().ifEmpty { marcadores.map { it.first } }
                )
            }
        }
    }
}


private fun horasTexto(seg: Double): String {
    val m = (seg / 60).toInt()
    return if (m >= 60) "${m / 60} h ${m % 60} min" else "$m min"
}

/**
 * Mapa a pantalla completa para elegir el camino: muestra hasta 3 caminos distintos, deja tocar el mapa
 * para "pasar por acá", y guarda el camino elegido con sus mapas para usarlo sin señal.
 */
@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun ElegirCaminoDialog(
    titulo: String,
    clave: String,
    puntos: List<Pair<String, GeoPoint>>,
    onDismiss: () -> Unit,
    onListo: (RutaCamion.Resultado) -> Unit
) {
    val ctx = LocalContext.current
    var vias by remember { mutableStateOf(RutaOffline.vias(ctx, clave)) }
    var opciones by remember { mutableStateOf<List<RutaCamion.Resultado>>(emptyList()) }
    var elegido by remember { mutableStateOf(0) }
    var calculando by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var marcando by remember { mutableStateOf(false) }
    val velMax = remember { com.micontrol.app.data.Ajustes.velocidadMaxima(ctx) }

    LaunchedEffect(vias) {
        calculando = true; error = null; elegido = 0
        val coords = RutaOffline.conVias(puntos.map { it.second }, vias).map { it.latitude to it.longitude }
        try {
            val clv = com.micontrol.app.data.Ajustes.claveOrs(ctx)
            val alto = com.micontrol.app.data.Ajustes.alturaCamion(ctx)
            val largo = com.micontrol.app.data.Ajustes.largoCamion(ctx)
            val peso = com.micontrol.app.data.Ajustes.pesoCamion(ctx)
            opciones = if (coords.size == 2) RutaCamion.alternativas(clv, alto, largo, coords, peso)
            else listOf(RutaCamion.calcular(clv, alto, largo, coords, peso))
        } catch (e: Exception) {
            val g = RutaOffline.cargar(ctx, clave)
            if (g != null) { opciones = listOf(g); error = "📴 Sin señal: se muestra el camino guardado." }
            else { opciones = emptyList(); error = (e as? RutaCamion.ErrorRuta)?.mensaje ?: "No se pudo calcular el camino." }
        }
        calculando = false
    }

    androidx.compose.ui.window.Dialog(onDismiss, androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)) {
        androidx.compose.material3.Surface(Modifier.fillMaxSize()) {
            androidx.compose.foundation.layout.Column(Modifier.fillMaxSize()) {
                androidx.compose.foundation.layout.Row(
                    Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                ) {
                    Text(titulo, Modifier.weight(1f), style = androidx.compose.material3.MaterialTheme.typography.titleMedium, maxLines = 1)
                    androidx.compose.material3.TextButton(onDismiss) { Text("Cerrar ✕") }
                }
                val sel = opciones.getOrNull(elegido)
                val linea = sel?.puntos?.map { GeoPoint(it.first, it.second) } ?: emptyList()
                val marcas = puntos.mapIndexed { i, par -> par.second to ((if (i == 0) "Salida: " else "Parada $i: ") + par.first) } +
                    vias.mapIndexed { i, v -> v to "Pasar por ${i + 1}" }
                MapaOsm(
                    Modifier.fillMaxWidth().weight(1f),
                    marcadores = marcas,
                    segmentos = if (linea.isNotEmpty()) listOf(linea) else emptyList(),
                    centrar = null, miUbicacion = true,
                    ajustar = linea.ifEmpty { puntos.map { it.second } },
                    onTap = { g -> if (marcando) { marcando = false; val n = vias + g; vias = n; RutaOffline.guardarVias(ctx, clave, n) } }
                )
                androidx.compose.foundation.layout.Column(
                    Modifier.fillMaxWidth().padding(12.dp),
                    verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(6.dp)
                ) {
                    if (calculando) androidx.compose.material3.LinearProgressIndicator(Modifier.fillMaxWidth())
                    error?.let { Text(it, style = androidx.compose.material3.MaterialTheme.typography.bodySmall) }
                    if (opciones.size > 1) {
                        Text("Elegí el camino:", style = androidx.compose.material3.MaterialTheme.typography.labelLarge)
                        androidx.compose.foundation.layout.Row(horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(6.dp)) {
                            opciones.forEachIndexed { i, r ->
                                androidx.compose.material3.FilterChip(
                                    selected = i == elegido, onClick = { elegido = i },
                                    label = {
                                        Text(
                                            "Camino ${i + 1}\n%.0f km · %s".format(r.metros / 1000, horasTexto(RutaCamion.segundosCargado(r.metros, r.segundos, velMax))),
                                            style = androidx.compose.material3.MaterialTheme.typography.bodySmall
                                        )
                                    },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    } else if (sel != null) {
                        Text(
                            "%.0f km · %s".format(sel.metros / 1000, horasTexto(RutaCamion.segundosCargado(sel.metros, sel.segundos, velMax))),
                            style = androidx.compose.material3.MaterialTheme.typography.titleMedium
                        )
                    }
                    if (marcando) {
                        Text("👆 Tocá en el mapa por dónde querés pasar (un pueblo, una ruta).", color = androidx.compose.material3.MaterialTheme.colorScheme.primary)
                    }
                    androidx.compose.foundation.layout.Row(horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(6.dp)) {
                        BotonSec({ marcando = !marcando }, Modifier.weight(1f)) { Text(if (marcando) "Cancelar" else "📍 Pasar por…", maxLines = 1) }
                        if (vias.isNotEmpty()) {
                            BotonSec({ vias = emptyList(); RutaOffline.guardarVias(ctx, clave, emptyList()) }, Modifier.weight(1f)) {
                                Text("Borrar puntos de paso", maxLines = 1)
                            }
                        }
                    }
                    BotonP({
                        val r = sel ?: return@BotonP
                        RutaOffline.usarCamino(ctx, clave, r, puntos.map { it.second })
                        Toast.makeText(ctx, "Camino guardado. Se están bajando los mapas para usarlo sin señal.", Toast.LENGTH_LONG).show()
                        onListo(r)
                    }, Modifier.fillMaxWidth(), enabled = sel != null && !calculando) {
                        Text("💾 Usar este camino y guardarlo sin señal")
                    }
                    Text(
                        if (RutaOffline.descargando) "⏳ Bajando los mapas del camino…"
                        else if (RutaOffline.mapaGuardado(ctx, clave)) "✔ Este camino ya está guardado para usarlo sin señal."
                        else "Necesitás internet para guardarlo. Después se ve aunque no tengas señal.",
                        style = androidx.compose.material3.MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }
}
