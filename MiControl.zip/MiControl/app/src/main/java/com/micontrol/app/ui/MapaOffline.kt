package com.micontrol.app.ui

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.ui.unit.dp
import com.micontrol.app.data.RutaCamion
import org.osmdroid.util.GeoPoint
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import org.osmdroid.tileprovider.cachemanager.CacheManager
import org.osmdroid.views.MapView

/**
 * Guarda en el teléfono los mapas de la zona que se está viendo (y un poco más cerca), para usarlos sin señal.
 * Es poca cantidad: equivale a lo que cargarías mirando y acercando esa misma zona.
 */
@Composable
fun BotonGuardarZona(mapView: MapView?, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    var ocupado by remember { mutableStateOf(false) }
    BotonSec({
        val m = mapView
        if (m == null) {
            Toast.makeText(ctx, "Esperá a que cargue el mapa.", Toast.LENGTH_SHORT).show()
        } else if (!hayInternet(ctx)) {
            Toast.makeText(ctx, "Necesitás internet para guardar la zona.", Toast.LENGTH_LONG).show()
        } else {
            try {
                val bb = m.boundingBox
                val z0 = m.zoomLevelDouble.toInt().coerceIn(3, 17)
                val z1 = (z0 + 2).coerceAtMost(17)
                val cm = CacheManager(m)
                val total = cm.possibleTilesInArea(bb, z0, z1)
                if (total > 900) {
                    Toast.makeText(ctx, "La zona es muy grande. Acercá el mapa y probá de nuevo.", Toast.LENGTH_LONG).show()
                } else {
                    ocupado = true
                    cm.downloadAreaAsync(ctx, bb, z0, z1, object : CacheManager.CacheManagerCallback {
                        override fun onTaskComplete() {
                            ocupado = false
                            Toast.makeText(ctx, "Zona guardada: ya la podés ver sin señal.", Toast.LENGTH_LONG).show()
                        }
                        override fun onTaskFailed(errors: Int) {
                            ocupado = false
                            Toast.makeText(ctx, "Se guardó parte de la zona (faltaron $errors mapas).", Toast.LENGTH_LONG).show()
                        }
                        override fun updateProgress(progress: Int, currentZoomLevel: Int, zoomMin: Int, zoomMax: Int) {}
                        override fun downloadStarted() {}
                        override fun setPossibleTilesInArea(total: Int) {}
                    })
                }
            } catch (e: Exception) {
                ocupado = false
                Toast.makeText(ctx, "Este mapa no permite guardar zonas. Cargá una clave de MapTiler en Ajustes.", Toast.LENGTH_LONG).show()
            }
        }
    }, modifier, enabled = !ocupado) { Text(if (ocupado) "Guardando…" else "💾 Zona sin señal", maxLines = 1) }
}

/**
 * Mapa del viaje sin señal: guarda en el teléfono el dibujo del recorrido y los mapas a lo largo de la ruta
 * (más detalle alrededor de cada parada). Se hace solo, una vez por viaje, cuando hay internet.
 */
object RutaOffline {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("ruta_offline", Context.MODE_PRIVATE)
    private fun archivo(ctx: Context, clave: String): java.io.File {
        val dir = java.io.File(ctx.filesDir, "rutas").apply { mkdirs() }
        return java.io.File(dir, Integer.toHexString(clave.hashCode()) + ".json")
    }

    /** Guarda el dibujo del recorrido (para verlo y calcular km sin señal). */
    fun guardar(ctx: Context, clave: String, r: RutaCamion.Resultado) {
        try {
            val pts = org.json.JSONArray()
            // Se guarda aligerado: alcanza para dibujarlo
            val paso = (r.puntos.size / 3000) + 1
            r.puntos.forEachIndexed { i, p -> if (i % paso == 0 || i == r.puntos.lastIndex) pts.put(org.json.JSONArray().put(p.first).put(p.second)) }
            val o = org.json.JSONObject().put("metros", r.metros).put("segundos", r.segundos).put("puntos", pts)
            archivo(ctx, clave).writeText(o.toString())
        } catch (e: Exception) { }
    }

    fun cargar(ctx: Context, clave: String): RutaCamion.Resultado? = try {
        val f = archivo(ctx, clave)
        if (!f.exists()) null else {
            val o = org.json.JSONObject(f.readText())
            val a = o.getJSONArray("puntos")
            val pts = (0 until a.length()).map { val p = a.getJSONArray(it); p.getDouble(0) to p.getDouble(1) }
            RutaCamion.Resultado(pts, o.getDouble("metros"), o.getDouble("segundos"), emptyList(), emptyList())
        }
    } catch (e: Exception) { null }

    fun mapaGuardado(ctx: Context, clave: String): Boolean = prefs(ctx).getBoolean("z_" + clave.hashCode(), false)

    var descargando by mutableStateOf(false)
        private set

    /** Baja los mapas a lo largo del recorrido. Corre solo una vez por recorrido. */
    fun descargarSiFalta(ctx: Context, clave: String, ruta: List<GeoPoint>, paradas: List<GeoPoint>) {
        if (descargando || mapaGuardado(ctx, clave) || ruta.size < 2 || !hayInternet(ctx)) return
        try {
            configurarMapas(ctx)
            val fuente = fuenteMapaPublica(ctx, modoOscuroActual(ctx))
            val cm = CacheManager(fuente, org.osmdroid.tileprovider.modules.SqlTileWriter(), 0, 19)
            // Tareas: la ruta entera con poco detalle, y cada parada con mucho detalle
            val camino = ArrayList(aligerarRuta(ruta, 400))
            val tareas = ArrayList<(CacheManager.CacheManagerCallback) -> Unit>()
            tareas.add { cb -> cm.downloadAreaAsyncNoUI(ctx, camino, 6, 13, cb) }
            paradas.take(30).forEach { p ->
                val d = 0.015
                val bb = org.osmdroid.util.BoundingBox(p.latitude + d, p.longitude + d, p.latitude - d, p.longitude - d)
                tareas.add { cb -> cm.downloadAreaAsyncNoUI(ctx, bb, 13, 16, cb) }
            }
            descargando = true
            var errores = 0
            fun siguiente(i: Int) {
                if (i >= tareas.size) {
                    descargando = false
                    if (errores < 30) prefs(ctx).edit().putBoolean("z_" + clave.hashCode(), true).apply()
                    return
                }
                tareas[i](object : CacheManager.CacheManagerCallback {
                    override fun onTaskComplete() { siguiente(i + 1) }
                    override fun onTaskFailed(errors: Int) { errores += errors; siguiente(i + 1) }
                    override fun updateProgress(progress: Int, currentZoomLevel: Int, zoomMin: Int, zoomMax: Int) {}
                    override fun downloadStarted() {}
                    override fun setPossibleTilesInArea(total: Int) {}
                })
            }
            siguiente(0)
        } catch (e: Exception) {
            descargando = false   // por ejemplo: el mapa básico sin clave no permite guardar zonas
        }
    }

    private fun aligerarRuta(seg: List<GeoPoint>, maximo: Int): List<GeoPoint> {
        if (seg.size <= maximo) return seg
        val paso = seg.size / maximo + 1
        val out = ArrayList<GeoPoint>()
        var i = 0
        while (i < seg.size) { out.add(seg[i]); i += paso }
        if (out.last() != seg.last()) out.add(seg.last())
        return out
    }
}

/** Mapa del recorrido a pantalla completa (si se guardó, se ve sin señal). */
@Composable
fun MapaRecorridoDialog(
    titulo: String,
    marcadores: List<Pair<GeoPoint, String>>,
    segmentos: List<List<GeoPoint>>,
    onDismiss: () -> Unit
) {
    androidx.compose.ui.window.Dialog(onDismiss, androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)) {
        androidx.compose.material3.Surface(androidx.compose.ui.Modifier.fillMaxSize()) {
            androidx.compose.foundation.layout.Column(androidx.compose.ui.Modifier.fillMaxSize()) {
                androidx.compose.foundation.layout.Row(
                    androidx.compose.ui.Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                ) {
                    Text(titulo, androidx.compose.ui.Modifier.weight(1f), style = androidx.compose.material3.MaterialTheme.typography.titleMedium, maxLines = 1)
                    androidx.compose.material3.TextButton(onDismiss) { Text("Cerrar ✕") }
                }
                MapaOsm(
                    androidx.compose.ui.Modifier.fillMaxWidth().weight(1f),
                    marcadores = marcadores, segmentos = segmentos, centrar = null, miUbicacion = true,
                    ajustar = segmentos.flatten().ifEmpty { marcadores.map { it.first } }
                )
            }
        }
    }
}
