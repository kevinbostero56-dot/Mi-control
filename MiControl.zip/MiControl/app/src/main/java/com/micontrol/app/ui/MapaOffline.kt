package com.micontrol.app.ui

import android.widget.Toast
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import org.osmdroid.tileprovider.cachemanager.CacheManager
import org.osmdroid.views.MapView

/**
 * Guarda en el teléfono los mapas de la zona que se está viendo (y un poco más cerca), para usarlos sin señal.
 * Es poca cantidad: equivale a lo que cargarías mirando y acercando esa misma zona.
 */
@Composable
fun BotonGuardarZona(mapView: MapView?, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    var ocupado by remember { mutableStateOf(false) }
    BotonSec({
        val m = mapView
        if (m == null) {
            Toast.makeText(ctx, "Esperá a que cargue el mapa.", Toast.LENGTH_SHORT).show()
        } else if (!hayInternet(ctx)) {
            Toast.makeText(ctx, "Necesitás internet para guardar la zona.", Toast.LENGTH_LONG).show()
        } else {
            try {
                val bb = m.boundingBox
                val z0 = m.zoomLevelDouble.toInt().coerceIn(3, 17)
                val z1 = (z0 + 2).coerceAtMost(17)
                val cm = CacheManager(m)
                val total = cm.possibleTilesInArea(bb, z0, z1)
                if (total > 900) {
                    Toast.makeText(ctx, "La zona es muy grande. Acercá el mapa y probá de nuevo.", Toast.LENGTH_LONG).show()
                } else {
                    ocupado = true
                    cm.downloadAreaAsync(ctx, bb, z0, z1, object : CacheManager.CacheManagerCallback {
                        override fun onTaskComplete() {
                            ocupado = false
                            Toast.makeText(ctx, "Zona guardada: ya la podés ver sin señal.", Toast.LENGTH_LONG).show()
                        }
                        override fun onTaskFailed(errors: Int) {
                            ocupado = false
                            Toast.makeText(ctx, "Se guardó parte de la zona (faltaron $errors mapas).", Toast.LENGTH_LONG).show()
                        }
                        override fun updateProgress(progress: Int, currentZoomLevel: Int, zoomMin: Int, zoomMax: Int) {}
                        override fun downloadStarted() {}
                        override fun setPossibleTilesInArea(total: Int) {}
                    })
                }
            } catch (e: Exception) {
                ocupado = false
                Toast.makeText(ctx, "Este mapa no permite guardar zonas. Cargá una clave de MapTiler en Ajustes.", Toast.LENGTH_LONG).show()
            }
        }
    }, modifier, enabled = !ocupado) { Text(if (ocupado) "Guardando…" else "💾 Zona sin señal", maxLines = 1) }
}
