package com.micontrol.app.data

import com.micontrol.app.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Busca versiones nuevas publicadas en GitHub (Releases del repositorio). */
object Actualizaciones {
    data class Nueva(val codigo: Int, val nombre: String, val notas: String, val url: String)

    sealed interface Resultado {
        data class Hay(val n: Nueva) : Resultado
        object AlDia : Resultado
        object Error : Resultado
    }

    suspend fun buscar(): Resultado = withContext(Dispatchers.IO) {
        val repo = BuildConfig.REPO
        if (repo.isBlank()) return@withContext Resultado.Error
        try {
            val c = URL("https://api.github.com/repos/$repo/releases/latest").openConnection() as HttpURLConnection
            try {
                c.connectTimeout = 8000
                c.readTimeout = 8000
                c.setRequestProperty("Accept", "application/vnd.github+json")
                c.setRequestProperty("User-Agent", "MiControl")
                if (c.responseCode != 200) return@withContext Resultado.Error
                val o = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
                val codigo = Regex("""(\d+)$""").find(o.optString("tag_name"))?.groupValues?.get(1)?.toIntOrNull()
                    ?: return@withContext Resultado.Error
                if (codigo <= BuildConfig.VERSION_CODE) return@withContext Resultado.AlDia
                var url = ""
                val assets = o.optJSONArray("assets")
                if (assets != null) {
                    for (i in 0 until assets.length()) {
                        val a = assets.getJSONObject(i)
                        if (a.optString("name").endsWith(".apk")) { url = a.optString("browser_download_url"); break }
                    }
                }
                if (url.isBlank()) url = o.optString("html_url")
                Resultado.Hay(Nueva(codigo, o.optString("name", "Versión nueva"), o.optString("body"), url))
            } finally {
                c.disconnect()
            }
        } catch (e: Exception) {
            Resultado.Error
        }
    }
}
