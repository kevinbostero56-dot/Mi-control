package com.micontrol.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

/** Título de pantalla con flecha para volver. */
@Composable
fun Encabezado(titulo: String, onBack: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        if (onBack != null) IconButton(onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Volver") }
        Text(titulo, style = MaterialTheme.typography.headlineSmall)
    }
}

@Composable
fun Seccion(titulo: String) {
    Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Box(Modifier.width(4.dp).height(18.dp).clip(RoundedCornerShape(2.dp)).background(MaterialTheme.colorScheme.primary))
        Text(titulo, style = MaterialTheme.typography.titleMedium)
    }
}

@Composable
fun Pastilla(texto: String, fondo: Color, contenido: Color) {
    Surface(shape = RoundedCornerShape(50), color = fondo) {
        Text(texto, Modifier.padding(horizontal = 10.dp, vertical = 4.dp), color = contenido,
            style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun IconoCirculo(icono: ImageVector, color: Color) {
    Box(Modifier.size(44.dp).clip(CircleShape).background(color.copy(alpha = 0.14f)), contentAlignment = Alignment.Center) {
        Icon(icono, contentDescription = null, tint = color)
    }
}

@Composable
fun StatTile(icono: ImageVector, color: Color, titulo: String, valor: String, modifier: Modifier = Modifier) {
    Card(
        modifier, shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            IconoCirculo(icono, color)
            Text(valor, style = MaterialTheme.typography.titleLarge, maxLines = 1)
            Text(titulo, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun FilaMenu(icono: ImageVector, titulo: String, subtitulo: String, onClick: () -> Unit) {
    Card(
        Modifier.fillMaxWidth().clickable(onClick = onClick), shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            IconoCirculo(icono, MaterialTheme.colorScheme.primary)
            Column(Modifier.weight(1f)) {
                Text(titulo, style = MaterialTheme.typography.titleMedium)
                Text(subtitulo, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Icon(Icons.Default.KeyboardArrowRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

fun estadoTexto(e: String) = when (e) { "EN_CURSO" -> "EN CURSO"; "FINALIZADO" -> "FINALIZADO"; else -> "PENDIENTE" }
fun estadoColor(e: String) = when (e) { "EN_CURSO" -> Verde; "FINALIZADO" -> Azul; else -> Ambar }

/** Tarjeta degradada con los datos principales del viaje. */
@Composable
fun HeroViaje(
    nombre: String, estado: String, cliente: String, ruta: String,
    inicio: String, fin: String?, kmOficiales: String?, odometro: String
) {
    Box(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp))
            .background(Brush.linearGradient(listOf(AzulOscuro, Azul))).padding(20.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Pastilla(estadoTexto(estado), if (estado == "EN_CURSO") Color(0xFF22C55E) else Color.White.copy(alpha = 0.2f), Color.White)
            Text(nombre, style = MaterialTheme.typography.titleLarge, color = Color.White)
            if (cliente.isNotBlank()) Text(cliente, color = Color.White.copy(alpha = 0.85f))
            Text(ruta, color = Color.White.copy(alpha = 0.85f))
            Text("Inicio: $inicio" + (fin?.let { "  ·  Fin: $it" } ?: ""), style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = 0.7f))
            Spacer(Modifier.height(6.dp))
            Text(kmOficiales ?: "—", style = MaterialTheme.typography.headlineLarge, color = Color.White)
            Text("Kilómetros oficiales (odómetro)", style = MaterialTheme.typography.labelMedium, color = Color.White.copy(alpha = 0.7f))
            Text(odometro, style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = 0.7f))
        }
    }
}
