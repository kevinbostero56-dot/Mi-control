package com.micontrol.app.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max

/** Fotos de tickets: se guardan en el teléfono, dentro de la app. */
object Fotos {
    private fun carpeta(ctx: Context) = File(ctx.filesDir, "tickets").apply { mkdirs() }

    fun nuevoArchivo(ctx: Context): File = File(carpeta(ctx), "ticket_${System.currentTimeMillis()}.jpg")

    fun uri(ctx: Context, f: File): Uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)

    /** Copia una foto elegida de la galería a la carpeta de la app. */
    fun copiarDesde(ctx: Context, origen: Uri): File? {
        return try {
            val f = nuevoArchivo(ctx)
            val entrada = ctx.contentResolver.openInputStream(origen) ?: return null
            entrada.use { i -> FileOutputStream(f).use { o -> i.copyTo(o) } }
            f
        } catch (e: Exception) {
            null
        }
    }

    /** Carga la foto achicada (para no gastar memoria) y derecha, aunque el celular la haya girado. */
    fun cargar(path: String, maxLado: Int): Bitmap? {
        val medidas = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, medidas)
        if (medidas.outWidth <= 0) return null
        var escala = 1
        while (max(medidas.outWidth, medidas.outHeight) / (escala * 2) >= maxLado) escala *= 2
        val bmp = BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = escala }) ?: return null
        val giro = try {
            when (ExifInterface(path).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
        } catch (e: Exception) {
            0f
        }
        return if (giro == 0f) bmp
        else Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(giro) }, true)
    }
}
