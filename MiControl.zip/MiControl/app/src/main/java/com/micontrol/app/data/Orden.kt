package com.micontrol.app.data

/** Orden de paradas por cercanía y nombre automático del viaje. */
object Orden {
    fun metros(a: Pair<Double, Double>, b: Pair<Double, Double>): Double {
        val r = 6371000.0
        val f1 = Math.toRadians(a.first); val f2 = Math.toRadians(b.first)
        val df = f2 - f1; val dl = Math.toRadians(b.second - a.second)
        val h = Math.sin(df / 2).let { it * it } + Math.cos(f1) * Math.cos(f2) * Math.sin(dl / 2).let { it * it }
        return 2 * r * Math.asin(Math.sqrt(h))
    }

    /** Largo en km (en línea recta) de pasar por los puntos en el orden dado. */
    fun kmLinea(puntos: List<Pair<Double, Double>>): Double =
        puntos.zipWithNext().sumOf { (a, b) -> metros(a, b) } / 1000.0

    /**
     * Orden del recorrido más corto que sale del origen y pasa por todos los puntos (termina donde convenga).
     * Primero va siempre al más cercano y después mejora el orden (2-opt). Devuelve los índices de `puntos`.
     */
    fun camino(origen: Pair<Double, Double>, puntos: List<Pair<Double, Double>>): List<Int> {
        val n = puntos.size
        if (n <= 1) return puntos.indices.toList()
        // Vecino más cercano
        val libres = puntos.indices.toMutableList()
        var orden = mutableListOf<Int>()
        var actual = origen
        while (libres.isNotEmpty()) {
            val sig = libres.minByOrNull { metros(actual, puntos[it]) } ?: break
            orden.add(sig); libres.remove(sig); actual = puntos[sig]
        }
        fun costo(o: List<Int>): Double {
            var t = metros(origen, puntos[o[0]])
            for (i in 1 until o.size) t += metros(puntos[o[i - 1]], puntos[o[i]])
            return t
        }
        // Mejora: invertir tramos mientras el recorrido se acorte
        var mejora = true
        var vueltas = 0
        while (mejora && vueltas < 50) {
            mejora = false
            vueltas++
            for (i in 0 until n - 1) {
                for (j in i + 1 until n) {
                    val nuevo = orden.toMutableList()
                    nuevo.subList(i, j + 1).reverse()
                    if (costo(nuevo) + 1.0 < costo(orden)) {
                        orden = nuevo
                        mejora = true
                    }
                }
            }
        }
        return orden
    }

    /** "Tucumán" / "La Rioja y Tucumán" / "La Rioja, Catamarca y Tucumán" (sin repetir seguidos). */
    fun nombreViaje(lugares: List<String>): String {
        val l = ArrayList<String>()
        lugares.map { it.trim() }.filter { it.isNotBlank() }.forEach { if (l.lastOrNull()?.equals(it, true) != true) l.add(it) }
        return when {
            l.isEmpty() -> ""
            l.size == 1 -> l[0]
            else -> l.dropLast(1).joinToString(", ") + " y " + l.last()
        }
    }
}
