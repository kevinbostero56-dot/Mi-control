package com.micontrol.app.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.micontrol.app.data.Ajustes
import com.micontrol.app.data.Cliente
import com.micontrol.app.data.ImportarGoogle
import com.micontrol.app.data.UbicacionLink
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Importa todos los lugares guardados de Google Maps (archivo de Google Takeout) como clientes y destinos. */
@Composable
fun ImportarGoogleDialog(vm: MainViewModel, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var items by remember { mutableStateOf<List<ImportarGoogle.Item>?>(null) }
    var leyendo by remember { mutableStateOf(false) }
    var buscarFaltantes by remember { mutableStateOf(true) }
    var progreso by remember { mutableStateOf<String?>(null) }
    var resultado by remember { mutableStateOf<String?>(null) }
    var errorLectura by remember { mutableStateOf(false) }
    var enlace by remember { mutableStateOf("") }
    var avisoEnlace by remember { mutableStateOf<String?>(null) }

    val elegir = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            leyendo = true
            errorLectura = false
            scope.launch {
                val lista = withContext(Dispatchers.IO) {
                    try { ImportarGoogle.leer(ctx, uri) } catch (e: Exception) { emptyList() }
                }
                items = lista
                errorLectura = lista.isEmpty()
                leyendo = false
            }
        }
    }

    val lista = items
    val conCoord = lista?.count { it.lat != null } ?: 0
    val sinCoord = (lista?.size ?: 0) - conCoord
    val trabajando = progreso != null

    AlertDialog(
        onDismissRequest = { if (!trabajando) onDismiss() },
        title = { Text("Importar lugares de Google Maps") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (resultado != null) {
                    Text(resultado!!)
                } else if (lista == null || errorLectura) {
                    Text(
                        "1) Entrá a takeout.google.com desde el navegador del teléfono.\n" +
                            "2) Deseleccionar todo y marcá solo \"Guardados\" (o \"Mapas (tus lugares)\").\n" +
                            "3) Crear exportación y, cuando te llegue el mail, descargá el archivo.\n" +
                            "4) Volvé acá y elegí ese archivo (.zip, .json, .csv o .kml).",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    if (errorLectura) {
                        Text(
                            "No encontré lugares en ese archivo. Probá con el .zip completo o con un archivo de la carpeta \"Guardados\".",
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                    if (leyendo) Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        CircularProgressIndicator(Modifier.size(24.dp)); Text("Leyendo…")
                    }
                    BotonP({ elegir.launch(arrayOf("*/*")) }, Modifier.fillMaxWidth(), enabled = !leyendo) { Text("📂 Elegir el archivo de Google") }
                    Text("¿Tenés el enlace de una lista compartida?", style = MaterialTheme.typography.titleSmall)
                    OutlinedTextField(
                        enlace, { enlace = it; avisoEnlace = null }, Modifier.fillMaxWidth(),
                        label = { Text("Pegá el enlace acá") }, singleLine = true
                    )
                    BotonSec({
                        avisoEnlace = when {
                            enlace.isBlank() -> "Pegá primero el enlace."
                            ImportarGoogle.esEnlaceDeLista(enlace) ->
                                "Google no permite bajar una lista desde su enlace: no hay una forma oficial y no quiero inventarte lugares. " +
                                    "Para traer la lista completa usá Takeout (pasos de arriba) y elegí el archivo. " +
                                    "Si es un solo lugar, usá Pegar ubicación en Inicio."
                            else -> "Ese texto no parece un enlace de Google Maps."
                        }
                    }, Modifier.fillMaxWidth()) { Text("Probar enlace") }
                    avisoEnlace?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error) }
                } else {
                    Text("Encontré ${lista.size} lugares.", style = MaterialTheme.typography.titleMedium)
                    val porLista = lista.groupBy { it.lista.ifBlank { "Sin lista" } }
                    Text("Listas: " + porLista.entries.joinToString(", ") { "${it.key} (${it.value.size})" }, style = MaterialTheme.typography.bodySmall)
                    Text("• $conCoord con ubicación exacta de Google\n• $sinCoord sin coordenadas")
                    if (sinCoord > 0) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(buscarFaltantes, { buscarFaltantes = it }, enabled = !trabajando)
                            Text("Buscar la ubicación de los que no traen coordenadas (necesita internet y puede tardar). Pueden quedar aproximadas.", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    Text("Los lugares que ya tenés (mismo nombre o mismo punto en el mapa) no se repiten: así podés volver a importar una lista actualizada.", style = MaterialTheme.typography.bodySmall)
                    progreso?.let {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            CircularProgressIndicator(Modifier.size(24.dp)); Text(it)
                        }
                    }
                }
            }
        },
        confirmButton = {
            when {
                resultado != null -> TextButton(onDismiss) { Text("Listo") }
                lista != null && !errorLectura -> TextButton({
                    scope.launch {
                        val clave = Ajustes.claveMapTiler(ctx)
                        val nuevos = ArrayList<Cliente>()
                        var aproximadas = 0
                        var sinUbicacion = 0
                        lista.forEachIndexed { i, it ->
                            if (it.lat != null && it.lng != null) {
                                nuevos.add(Cliente(nombre = it.nombre, direccion = it.direccion, lat = it.lat, lng = it.lng, lista = it.lista))
                            } else if (buscarFaltantes) {
                                progreso = "Buscando ${i + 1} de ${lista.size}…"
                                val p = try {
                                    UbicacionLink.resolver(it.url ?: (it.nombre + " " + (it.direccion ?: "")), clave)
                                } catch (e: Exception) { null }
                                if (p != null) {
                                    if (p.aproximada) aproximadas++
                                    val dir = p.direccion ?: it.direccion
                                    nuevos.add(
                                        Cliente(
                                            nombre = it.nombre,
                                            direccion = if (p.aproximada) "⚠ Ubicación aproximada, revisar. ${dir ?: ""}".trim() else dir,
                                            lat = p.lat, lng = p.lng, lista = it.lista
                                        )
                                    )
                                } else {
                                    sinUbicacion++
                                    nuevos.add(Cliente(nombre = it.nombre, direccion = it.direccion, lista = it.lista))
                                }
                            } else {
                                sinUbicacion++
                                nuevos.add(Cliente(nombre = it.nombre, direccion = it.direccion, lista = it.lista))
                            }
                        }
                        progreso = "Guardando…"
                        vm.importarClientes(nuevos) { agregados ->
                            progreso = null
                            resultado = "Encontrados: ${lista.size}\nImportados: $agregados" +
                                (if (nuevos.size - agregados > 0) "\nOmitidos por repetidos: ${nuevos.size - agregados} (ya estaban cargados; si no tenían lista, se les puso la de esta importación)." else "") +
                                (if (aproximadas > 0) "\n$aproximadas quedaron con ubicación aproximada (dicen \"revisar\" en la dirección): abrilos en Clientes y ajustalos en el mapa." else "") +
                                (if (sinUbicacion > 0) "\n$sinUbicacion quedaron sin ubicación en el mapa: elegila a mano cuando los uses." else "")
                        }
                    }
                }, enabled = !trabajando) { Text("Importar ${lista.size}") }
                else -> {}
            }
        },
        dismissButton = {
            if (resultado == null) TextButton({ if (!trabajando) onDismiss() }, enabled = !trabajando) { Text("Cancelar") }
        }
    )
}
