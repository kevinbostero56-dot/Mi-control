package com.micontrol.app.ui

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.micontrol.app.data.Ajustes
import com.micontrol.app.data.Cliente
import com.micontrol.app.data.Geo
import com.micontrol.app.data.Orden
import com.micontrol.app.data.Parada
import com.micontrol.app.data.RutaCamion
import com.micontrol.app.data.Viaje
import com.micontrol.app.domain.Avisos
import com.micontrol.app.domain.Calculos
import com.micontrol.app.gps.Gps
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.flowOf
import org.osmdroid.util.GeoPoint

private fun tiempoTexto(seg: Double): String {
    val h = (seg / 3600).toInt()
    val m = ((seg % 3600) / 60).toInt()
    return if (h > 0) "$h h $m min" else "$m min"
}

/**
 * Mapa de la pantalla principal con el recorrido: elegís los clientes, se ordenan solos del más cerca al más lejos
 * y con un toque se inicia el viaje y se abre Google Maps. Lo técnico queda escondido en "Más opciones".
 */
@Composable
fun RecorridoInicio(vm: MainViewModel, nav: NavController, activo: Viaje?) {
    val ctx = LocalContext.current
    val clientes by vm.clientes.collectAsStateWithLifecycle()
    val viajes by vm.viajes.collectAsStateWithLifecycle()
    val paradasBd by remember(activo?.id) { activo?.let { vm.paradas(it.id) } ?: flowOf(emptyList<Parada>()) }
        .collectAsStateWithLifecycle(emptyList())
    val libres = remember { mutableStateListOf<Parada>() }
    val paradas: List<Parada> = if (activo != null) paradasBd else libres.toList()

    var agregando by remember { mutableStateOf(false) }
    var eligiendo by remember { mutableStateOf(false) }
    var navegando by remember { mutableStateOf(false) }
    var masOpciones by remember { mutableStateOf(false) }
    var editando by remember { mutableStateOf(false) }
    var iniciando by remember { mutableStateOf(false) }
    var guardandoNombre by remember { mutableStateOf(false) }
    var gpsPendiente by remember { mutableStateOf<String?>(null) }
    var mapsPendiente by remember { mutableStateOf<List<Pair<Double, Double>>?>(null) }
    var resultado by remember { mutableStateOf<RutaCamion.Resultado?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var calculando by remember { mutableStateOf(false) }
    var nombreViaje by remember { mutableStateOf("") }
    val cacheLocalidad = remember { mutableStateMapOf<String, String>() }
    val pendiente by vm.recorridoPendiente.collectAsStateWithLifecycle()

    val clave = remember { Ajustes.claveOrs(ctx) }
    val velMax = remember { Ajustes.velocidadMaxima(ctx) }

    // Puntos del recorrido, en orden (la salida es siempre donde estás)
    val puntos: List<Pair<String, GeoPoint>> = run {
        val lista = mutableListOf<Pair<String, GeoPoint>>()
        if (activo != null) {
            val oLat = activo.origenLat; val oLng = activo.origenLng
            if (oLat != null && oLng != null) lista.add("Salida" to GeoPoint(oLat, oLng))
            else Gps.ultimaUbicacion(ctx)?.let { lista.add("Mi ubicación" to GeoPoint(it.latitude, it.longitude)) }
            paradas.forEach { lista.add(it.nombre to GeoPoint(it.lat, it.lng)) }
            val dLat = activo.destinoLat; val dLng = activo.destinoLng
            if (dLat != null && dLng != null) lista.add("Destino" to GeoPoint(dLat, dLng))
        } else {
            Gps.ultimaUbicacion(ctx)?.let { lista.add("Mi ubicación" to GeoPoint(it.latitude, it.longitude)) }
            paradas.forEach { lista.add(it.nombre to GeoPoint(it.lat, it.lng)) }
        }
        lista
    }
    val clavePuntos = puntos.joinToString("|") { "%.5f,%.5f".format(java.util.Locale.US, it.second.latitude, it.second.longitude) }

    LaunchedEffect(clavePuntos) {
        resultado = null; error = null
        if (puntos.size < 2) return@LaunchedEffect
        if (clave.isBlank()) { error = "Falta la clave de rutas (Ajustes, Avanzado). Se muestra una estimación."; return@LaunchedEffect }
        calculando = true
        try {
            resultado = RutaCamion.calcular(
                clave, Ajustes.alturaCamion(ctx), Ajustes.largoCamion(ctx),
                puntos.map { it.second.latitude to it.second.longitude }, Ajustes.pesoCamion(ctx)
            )
        } catch (e: RutaCamion.ErrorRuta) {
            error = e.mensaje
        }
        calculando = false
    }

    // Nombre del viaje = localidades por donde pasa (solo hace falta cuando todavía no hay viaje)
    LaunchedEffect(clavePuntos, activo == null) {
        if (activo != null || paradas.isEmpty()) return@LaunchedEffect
        val nombres = ArrayList<String>()
        for (p in paradas) {
            val k = "%.3f,%.3f".format(java.util.Locale.US, p.lat, p.lng)
            var loc = cacheLocalidad[k]
            if (loc == null) {
                loc = Geo.localidad(p.lat, p.lng)
                if (loc != null) cacheLocalidad[k] = loc
                delay(1100)
            }
            if (loc != null) nombres.add(loc)
        }
        nombreViaje = if (nombres.isNotEmpty()) Orden.nombreViaje(nombres)
        else Orden.nombreViaje(paradas.map { it.nombre.substringBefore(',') })
    }

    /** Ordena el recorrido libre del más cerca al más lejos desde donde estás. */
    fun ordenarLibres(lista: List<Parada>) {
        if (lista.isEmpty()) { libres.clear(); return }
        val gps = Gps.ultimaUbicacion(ctx)
        val desde = if (gps != null) gps.latitude to gps.longitude else lista[0].lat to lista[0].lng
        val idx = Orden.camino(desde, lista.map { it.lat to it.lng })
        libres.clear()
        libres.addAll(idx.mapIndexed { i, j -> lista[j].copy(id = 0, viajeId = "", orden = i) })
    }
    fun guardarOrden(nueva: List<Parada>) {
        if (activo != null) vm.reordenarParadas(nueva)
        else { libres.clear(); libres.addAll(nueva.mapIndexed { i, p -> p.copy(orden = i) }) }
    }
    fun agregarVarias(nuevas: List<Parada>) {
        if (activo != null) {
            nuevas.forEachIndexed { i, p -> vm.agregarParada(Parada(viajeId = activo.id, orden = paradas.size + i, nombre = p.nombre, lat = p.lat, lng = p.lng)) }
        } else {
            val todas = libres.toMutableList()
            nuevas.forEach { n -> if (todas.none { Math.abs(it.lat - n.lat) < 0.0002 && Math.abs(it.lng - n.lng) < 0.0002 }) todas.add(n) }
            ordenarLibres(todas)
        }
    }
    fun borrar(p: Parada) {
        if (activo != null) vm.borrarParada(p) else ordenarLibres(libres.filter { it != p })
    }

    // Recorrido que dejó la pantalla Lugares o un recorrido guardado
    LaunchedEffect(pendiente) {
        val pnd = pendiente ?: return@LaunchedEffect
        agregarVarias(pnd)
        vm.recorridoPendiente.value = null
    }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(if (activo != null) "🗺️ Recorrido del viaje" else "🗺️ Armar recorrido (se abre en Google Maps)", style = MaterialTheme.typography.titleMedium)

            val ruta = resultado?.puntos?.map { GeoPoint(it.first, it.second) } ?: emptyList()
            val marcadores = if (puntos.size >= 2 || activo != null || libres.isNotEmpty()) {
                puntos.mapIndexed { i, par ->
                    val rol = when {
                        i == 0 -> "Salida"
                        activo != null && i == puntos.lastIndex && activo.destinoLat != null -> "Destino"
                        else -> "Parada $i"
                    }
                    par.second to "$rol: ${par.first}"
                }
            } else {
                clientes.filter { it.lat != null && it.lng != null }.map { GeoPoint(it.lat!!, it.lng!!) to it.nombre }
            }
            val segmentos = when {
                ruta.isNotEmpty() -> listOf(ruta)
                puntos.size >= 2 -> listOf(puntos.map { it.second })
                else -> emptyList()
            }
            if (puntos.size >= 2) {
                val r = resultado
                val metros = r?.metros ?: (1.3 * puntos.zipWithNext().sumOf { (a, b) ->
                    Orden.metros(a.second.latitude to a.second.longitude, b.second.latitude to b.second.longitude)
                })
                val seg = RutaCamion.segundosCargado(metros, r?.segundos ?: 0.0, velMax)
                Text(
                    (if (r == null) "≈ " else "") + "%.0f km · %s".format(metros / 1000, tiempoTexto(seg)),
                    style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold
                )
            } else {
                Text(
                    if (activo != null) "Agregá paradas para ver el recorrido."
                    else "Elegí tus clientes y se arma el recorrido, del más cerca al más lejos.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
            if (calculando) LinearProgressIndicator(Modifier.fillMaxWidth())
            error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }

            paradas.forEachIndexed { i, p ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("${i + 1}. ${p.nombre}", Modifier.weight(1f), maxLines = 2)
                    if (editando) {
                        TextButton({ if (i > 0) guardarOrden(paradas.toMutableList().also { val x = it.removeAt(i); it.add(i - 1, x) }) }, enabled = i > 0) { Text("↑") }
                        TextButton({ if (i < paradas.lastIndex) guardarOrden(paradas.toMutableList().also { val x = it.removeAt(i); it.add(i + 1, x) }) }, enabled = i < paradas.lastIndex) { Text("↓") }
                        TextButton({ borrar(p) }) { Text("🗑") }
                    }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                BotonSec({ agregando = true }, Modifier.weight(1f)) { Text("➕ Parada", maxLines = 1) }
                BotonSec({ eligiendo = true }, Modifier.weight(1f)) { Text("👥 Clientes", maxLines = 1) }
            }

            if (activo == null && paradas.isNotEmpty()) {
                BotonP({ iniciando = true }, Modifier.fillMaxWidth().height(56.dp)) { Text("🚛 Iniciar viaje y abrir Google Maps") }
            } else if (activo != null && puntos.isNotEmpty()) {
                BotonP({ abrirRecorridoEnGoogleMaps(ctx, puntos.map { it.second.latitude to it.second.longitude }) }, Modifier.fillMaxWidth().height(56.dp)) {
                    Text("🧭 Abrir en Google Maps")
                }
            }

            TextButton({ masOpciones = !masOpciones }) { Text(if (masOpciones) "Menos opciones ▴" else "Más opciones ▾") }
            if (masOpciones) {
                if (paradas.isNotEmpty()) {
                    BotonSec({ editando = !editando }, Modifier.fillMaxWidth()) { Text(if (editando) "Listo con las paradas" else "✏️ Editar paradas (orden y borrar)") }
                }
                if (paradas.size >= 2) {
                    BotonSec({
                        val gps = Gps.ultimaUbicacion(ctx)
                        val desde = if (gps != null) gps.latitude to gps.longitude else paradas.first().lat to paradas.first().lng
                        guardarOrden(Orden.camino(desde, paradas.map { it.lat to it.lng }).map { paradas[it] })
                        Toast.makeText(ctx, "Ordenado del más cerca al más lejos.", Toast.LENGTH_SHORT).show()
                    }, Modifier.fillMaxWidth()) { Text("🔀 Ordenar del más cerca al más lejos") }
                }
                BotonSec({ guardandoNombre = true }, Modifier.fillMaxWidth(), enabled = paradas.isNotEmpty()) { Text("💾 Guardar este recorrido") }
                if (activo == null && libres.isNotEmpty()) {
                    TextButton({ libres.clear() }) { Text("Limpiar recorrido") }
                }
                if (error != null && clave.isBlank()) {
                    BotonSec({ nav.navigate("ajustes") }, Modifier.fillMaxWidth()) { Text("Cargar la clave en Ajustes") }
                }
            }
        }
    }

    if (agregando) SelectorUbicacion("Buscá o marcá la parada", onDismiss = { agregando = false }) { txt, la, lo ->
        agregarVarias(listOf(Parada(viajeId = "", orden = 0, nombre = txt.ifBlank { "Parada ${paradas.size + 1}" }, lat = la, lng = lo)))
        agregando = false
    }
    if (eligiendo) ElegirClientesViajeDialog(vm, onDismiss = { eligiendo = false }) { elegidos ->
        eligiendo = false
        val nuevas = elegidos.mapNotNull { c ->
            val la = c.lat; val lo = c.lng
            if (la != null && lo != null) Parada(viajeId = "", orden = 0, nombre = c.nombre, lat = la, lng = lo) else null
        }
        agregarVarias(nuevas)
    }

    if (iniciando) {
        val sugerido = remember(viajes) { Calculos.odometroActualTxt(viajes) ?: "" }
        var odo by remember { mutableStateOf(sugerido) }
        AlertDialog(
            onDismissRequest = { iniciando = false },
            title = { Text("Iniciar viaje") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        (if (nombreViaje.isNotBlank()) "Viaje: $nombreViaje\n" else "") + "Salís desde donde estás ahora.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    OutlinedTextField(
                        odo, { odo = it.filter { c -> c.isDigit() || c == ',' || c == '.' } }, Modifier.fillMaxWidth(),
                        label = { Text("Odómetro inicial (como dice el tablero)") }, singleLine = true
                    )
                    if (sugerido.isNotBlank() && odo == sugerido) {
                        Text("Es el último que cargaste. Fijate que coincida con el tablero.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            },
            confirmButton = {
                TextButton({
                    val odoPar = Calculos.parseOdometroDec(odo)
                    val destino = paradas.lastOrNull()
                    if (odoPar == null || destino == null) return@TextButton
                    val salida = puntos.firstOrNull()?.second
                    val v = Viaje(
                        cliente = Ajustes.empresaViaje(ctx), nombre = nombreViaje.ifBlank { destino.nombre.substringBefore(',') },
                        origen = "Mi ubicación", destino = destino.nombre,
                        inicio = System.currentTimeMillis(), odometroInicial = odoPar.first, odoInicialDec = odoPar.second,
                        origenLat = salida?.latitude, origenLng = salida?.longitude,
                        destinoLat = destino.lat, destinoLng = destino.lng
                    )
                    val medio = paradas.dropLast(1).mapIndexed { i, p -> p.copy(id = 0, viajeId = v.id, orden = i) }
                    vm.iniciarViaje(v, medio)
                    mapsPendiente = puntos.map { it.second.latitude to it.second.longitude }
                    gpsPendiente = v.id
                    libres.clear()
                    iniciando = false
                }, enabled = Calculos.parseOdometroDec(odo) != null) { Text("Salir") }
            },
            dismissButton = { TextButton({ iniciando = false }) { Text("Cancelar") } }
        )
    }
    // Pide el permiso del GPS y, al terminar, abre Google Maps con el recorrido
    SolicitudGps(gpsPendiente) {
        gpsPendiente = null
        mapsPendiente?.let { abrirRecorridoEnGoogleMaps(ctx, it) }
        mapsPendiente = null
    }

    if (guardandoNombre) {
        var nombreRec by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { guardandoNombre = false },
            title = { Text("Guardar recorrido") },
            text = { OutlinedTextField(nombreRec, { nombreRec = it }, Modifier.fillMaxWidth(), label = { Text("Nombre (ej. Reparto lunes)") }, singleLine = true) },
            confirmButton = {
                TextButton({
                    vm.guardarRecorrido(nombreRec, paradas)
                    Toast.makeText(ctx, "Recorrido guardado (lo ves en Lugares).", Toast.LENGTH_LONG).show()
                    guardandoNombre = false
                }, enabled = nombreRec.isNotBlank()) { Text("Guardar") }
            },
            dismissButton = { TextButton({ guardandoNombre = false }) { Text("Cancelar") } }
        )
    }
    val r = resultado
    if (navegando && r != null) NavegacionDialog(puntos, r) { navegando = false }
}
