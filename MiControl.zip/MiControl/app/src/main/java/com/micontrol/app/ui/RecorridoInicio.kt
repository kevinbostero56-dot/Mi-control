package com.micontrol.app.ui

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.micontrol.app.data.Ajustes
import com.micontrol.app.data.Cliente
import com.micontrol.app.data.Parada
import com.micontrol.app.data.RutaCamion
import com.micontrol.app.data.Viaje
import com.micontrol.app.gps.Gps
import kotlinx.coroutines.flow.flowOf
import org.osmdroid.util.GeoPoint

private fun metrosEntre(a: Pair<Double, Double>, b: Pair<Double, Double>): Double {
    val r = 6371000.0
    val f1 = Math.toRadians(a.first); val f2 = Math.toRadians(b.first)
    val df = f2 - f1; val dl = Math.toRadians(b.second - a.second)
    val h = Math.sin(df / 2).let { it * it } + Math.cos(f1) * Math.cos(f2) * Math.sin(dl / 2).let { it * it }
    return 2 * r * Math.asin(Math.sqrt(h))
}

private fun tiempoTexto(seg: Double): String {
    val h = (seg / 3600).toInt()
    val m = ((seg % 3600) / 60).toInt()
    return if (h > 0) "$h h $m min" else "$m min"
}

/** Ordena las paradas de la más cercana a la más lejana desde `desde`. */
private fun ordenarCercania(desde: Pair<Double, Double>, paradas: List<Parada>): List<Parada> {
    val resto = paradas.toMutableList()
    val res = mutableListOf<Parada>()
    var actual = desde
    while (resto.isNotEmpty()) {
        val sig = resto.minByOrNull { metrosEntre(actual, it.lat to it.lng) } ?: break
        res.add(sig); resto.remove(sig); actual = sig.lat to sig.lng
    }
    return res
}

/**
 * Mapa de la pantalla principal con el recorrido armado: origen, paradas con número y destino.
 * Con un viaje en curso usa sus paradas; sin viaje se arma un recorrido libre eligiendo clientes.
 */
@Composable
fun RecorridoInicio(vm: MainViewModel, nav: NavController, activo: Viaje?) {
    val ctx = LocalContext.current
    val clientes by vm.clientes.collectAsStateWithLifecycle()
    val paradasBd by remember(activo?.id) { activo?.let { vm.paradas(it.id) } ?: flowOf(emptyList<Parada>()) }
        .collectAsStateWithLifecycle(emptyList())
    val libres = remember { mutableStateListOf<Parada>() }
    val paradas: List<Parada> = if (activo != null) paradasBd else libres.toList()

    var agregando by remember { mutableStateOf(false) }
    var eligiendo by remember { mutableStateOf(false) }
    var navegando by remember { mutableStateOf(false) }
    var resultado by remember { mutableStateOf<RutaCamion.Resultado?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var calculando by remember { mutableStateOf(false) }

    val clave = remember { Ajustes.claveOrs(ctx) }
    val velMax = remember { Ajustes.velocidadMaxima(ctx) }

    // Puntos del recorrido, en orden
    val puntos: List<Pair<String, GeoPoint>> = run {
        val lista = mutableListOf<Pair<String, GeoPoint>>()
        if (activo != null) {
            val oLat = activo.origenLat; val oLng = activo.origenLng
            if (oLat != null && oLng != null) lista.add("Origen" to GeoPoint(oLat, oLng))
            else Gps.ultimaUbicacion(ctx)?.let { lista.add("Mi ubicación" to GeoPoint(it.latitude, it.longitude)) }
            paradas.forEach { lista.add(it.nombre to GeoPoint(it.lat, it.lng)) }
            val dLat = activo.destinoLat; val dLng = activo.destinoLng
            if (dLat != null && dLng != null) lista.add("Destino" to GeoPoint(dLat, dLng))
        } else {
            Gps.ultimaUbicacion(ctx)?.let { lista.add("Mi ubicación" to GeoPoint(it.latitude, it.longitude)) }
            paradas.forEach { lista.add(it.nombre to GeoPoint(it.lat, it.lng)) }
        }
        lista
    }
    val clavePuntos = puntos.joinToString("|") { "%.5f,%.5f".format(java.util.Locale.US, it.second.latitude, it.second.longitude) }

    LaunchedEffect(clavePuntos) {
        resultado = null; error = null
        if (puntos.size < 2) return@LaunchedEffect
        if (clave.isBlank()) { error = "Falta la clave de rutas (Ajustes). Mientras tanto se muestra una estimación en línea recta."; return@LaunchedEffect }
        calculando = true
        try {
            resultado = RutaCamion.calcular(
                clave, Ajustes.alturaCamion(ctx), Ajustes.largoCamion(ctx),
                puntos.map { it.second.latitude to it.second.longitude }, Ajustes.pesoCamion(ctx)
            )
        } catch (e: RutaCamion.ErrorRuta) {
            error = e.mensaje
        }
        calculando = false
    }

    fun guardarOrden(nueva: List<Parada>) {
        if (activo != null) vm.reordenarParadas(nueva)
        else { libres.clear(); libres.addAll(nueva.mapIndexed { i, p -> p.copy(orden = i) }) }
    }
    fun agregar(nombre: String, lat: Double, lng: Double) {
        if (activo != null) vm.agregarParada(Parada(viajeId = activo.id, orden = paradas.size, nombre = nombre, lat = lat, lng = lng))
        else libres.add(Parada(viajeId = "", orden = libres.size, nombre = nombre, lat = lat, lng = lng))
    }
    fun borrar(p: Parada) {
        if (activo != null) vm.borrarParada(p) else libres.remove(p)
    }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(if (activo != null) "🗺️ Recorrido del viaje" else "🗺️ Armar recorrido", style = MaterialTheme.typography.titleMedium)

            val ruta = resultado?.puntos?.map { GeoPoint(it.first, it.second) } ?: emptyList()
            val marcadores = if (puntos.size >= 2 || activo != null || libres.isNotEmpty()) {
                puntos.mapIndexed { i, par ->
                    val rol = when {
                        i == 0 -> "Salida"
                        activo != null && i == puntos.lastIndex && activo.destinoLat != null -> "Destino"
                        else -> "Parada $i"
                    }
                    par.second to "$rol: ${par.first}"
                }
            } else {
                clientes.filter { it.lat != null && it.lng != null }.map { GeoPoint(it.lat!!, it.lng!!) to it.nombre }
            }
            val segmentos = when {
                ruta.isNotEmpty() -> listOf(ruta)
                puntos.size >= 2 -> listOf(puntos.map { it.second })
                else -> emptyList()
            }
            MapaOsm(
                Modifier.fillMaxWidth().height(260.dp), marcadores, segmentos, null,
                ajustar = if (ruta.isNotEmpty()) ruta else marcadores.map { it.first }
            )

            if (puntos.size >= 2) {
                val r = resultado
                val metros = r?.metros ?: (1.3 * puntos.zipWithNext().sumOf { (a, b) -> metrosEntre(a.second.latitude to a.second.longitude, b.second.latitude to b.second.longitude) })
                val seg = RutaCamion.segundosCargado(metros, r?.segundos ?: 0.0, velMax)
                Text(
                    (if (r == null) "≈ " else "") + "%.0f km · %s".format(metros / 1000, tiempoTexto(seg)),
                    style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold
                )
                Text(
                    "Camión cargado (${"%.0f".format(Ajustes.pesoCamion(ctx))} t), máximo ${"%.0f".format(velMax)} km/h. Sin contar paradas ni descansos.",
                    style = MaterialTheme.typography.bodySmall
                )
            } else {
                Text(
                    if (activo != null) "Marcá el destino del viaje o agregá paradas para ver el recorrido."
                    else "Elegí tus clientes y te armo el recorrido. Parte desde donde estás.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
            if (calculando) { LinearProgressIndicator(Modifier.fillMaxWidth()) }
            error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            resultado?.avisos?.forEach { Text("Aviso: $it", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }

            paradas.forEachIndexed { i, p ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("${i + 1}. ${p.nombre}", Modifier.weight(1f), maxLines = 2)
                    TextButton({ if (i > 0) guardarOrden(paradas.toMutableList().also { val x = it.removeAt(i); it.add(i - 1, x) }) }, enabled = i > 0) { Text("↑") }
                    TextButton({ if (i < paradas.lastIndex) guardarOrden(paradas.toMutableList().also { val x = it.removeAt(i); it.add(i + 1, x) }) }, enabled = i < paradas.lastIndex) { Text("↓") }
                    TextButton({ borrar(p) }) { Text("🗑") }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                BotonSec({ agregando = true }, Modifier.weight(1f)) { Text("➕ Parada", maxLines = 1) }
                BotonSec({ eligiendo = true }, Modifier.weight(1f)) { Text("👥 Clientes", maxLines = 1) }
            }
            if (paradas.size >= 3 || (activo == null && paradas.size >= 2)) {
                BotonSec({
                    val desde = puntos.firstOrNull()?.second?.let { it.latitude to it.longitude } ?: (paradas.first().lat to paradas.first().lng)
                    guardarOrden(ordenarCercania(desde, paradas))
                    Toast.makeText(ctx, "Paradas ordenadas de la más cercana a la más lejana.", Toast.LENGTH_SHORT).show()
                }, Modifier.fillMaxWidth()) { Text("🔀 Ordenar de la más cercana a la más lejana") }
            }
            if (resultado != null) {
                BotonP({ navegando = true }, Modifier.fillMaxWidth().height(52.dp)) { Text("🧭 Iniciar navegación") }
            }
            if (activo == null && libres.isNotEmpty()) {
                TextButton({ libres.clear() }) { Text("Limpiar recorrido") }
            }
            if (error != null && clave.isBlank()) {
                BotonSec({ nav.navigate("ajustes") }, Modifier.fillMaxWidth()) { Text("Cargar la clave en Ajustes") }
            }
        }
    }

    if (agregando) SelectorUbicacion("Buscá o marcá la parada", onDismiss = { agregando = false }) { txt, la, lo ->
        agregar(txt.ifBlank { "Parada ${paradas.size + 1}" }, la, lo)
        agregando = false
    }
    if (eligiendo) ElegirClientesDialog(clientes, onDismiss = { eligiendo = false }) { elegidos ->
        elegidos.forEach { c -> agregar(c.nombre, c.lat ?: 0.0, c.lng ?: 0.0) }
        eligiendo = false
        if (elegidos.isNotEmpty()) Toast.makeText(ctx, "${elegidos.size} clientes agregados", Toast.LENGTH_SHORT).show()
    }
    val r = resultado
    if (navegando && r != null) NavegacionDialog(puntos, r) { navegando = false }
}

@Composable
private fun ElegirClientesDialog(clientes: List<Cliente>, onDismiss: () -> Unit, onOk: (List<Cliente>) -> Unit) {
    val conUbicacion = clientes.filter { it.lat != null && it.lng != null }
    val marcados = remember { mutableStateListOf<Long>() }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Elegí los clientes") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                if (conUbicacion.isEmpty()) Text("Todavía no tenés clientes con ubicación. Guardalos desde Clientes.")
                conUbicacion.forEach { c ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(c.id in marcados, { if (it) marcados.add(c.id) else marcados.remove(c.id) })
                        Text(c.nombre, Modifier.weight(1f))
                    }
                }
            }
        },
        confirmButton = { TextButton({ onOk(conUbicacion.filter { it.id in marcados }) }, enabled = marcados.isNotEmpty()) { Text("Agregar") } },
        dismissButton = { TextButton(onDismiss) { Text("Cancelar") } }
    )
}
