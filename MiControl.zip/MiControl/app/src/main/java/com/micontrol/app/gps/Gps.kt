package com.micontrol.app.gps

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.os.Build
import androidx.core.content.ContextCompat

object Gps {
    const val PREFS = "gps"
    const val KEY_VIAJE = "viajeId"

    fun permisos(): Array<String> {
        val l = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
        return l.toTypedArray()
    }

    fun tienePermiso(ctx: Context) =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    fun gpsActivo(ctx: Context): Boolean =
        (ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager).isProviderEnabled(LocationManager.GPS_PROVIDER)

    fun iniciar(ctx: Context, viajeId: String) {
        ContextCompat.startForegroundService(
            ctx, Intent(ctx, TrackingService::class.java).putExtra(TrackingService.EXTRA, viajeId)
        )
    }

    fun detener(ctx: Context) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY_VIAJE).apply()
        ctx.stopService(Intent(ctx, TrackingService::class.java))
    }
}
