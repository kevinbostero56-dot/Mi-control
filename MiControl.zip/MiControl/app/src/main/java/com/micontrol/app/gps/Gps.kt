package com.micontrol.app.gps

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.os.Build
import androidx.core.content.ContextCompat

object Gps {
    const val PREFS = "gps"
    const val KEY_VIAJE = "viajeId"
    const val KEY_PERFIL = "perfilId"
    /** Viaje en el que el chofer apretó "Detener seguimiento" a propósito (no se vuelve a prender solo). */
    private const val KEY_PAUSADO = "pausadoManual"

    fun pausarManual(ctx: Context, viajeId: String) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_PAUSADO, viajeId).apply()
        detener(ctx)
    }

    fun pausadoManual(ctx: Context, viajeId: String): Boolean =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_PAUSADO, null) == viajeId

    /** Viaje que estaba registrando el GPS cuando se cortó (actualización, reinicio del teléfono), o null. */
    fun viajeQueSeguia(ctx: Context): String? = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_VIAJE, null)

    fun permisos(): Array<String> {
        val l = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
        return l.toTypedArray()
    }

    fun tienePermiso(ctx: Context) =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    fun tieneUbicacion(ctx: Context) =
        tienePermiso(ctx) ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    /** Última ubicación conocida del teléfono (GPS, red o pasiva), o null. */
    fun ultimaUbicacion(ctx: Context): android.location.Location? {
        if (!tieneUbicacion(ctx)) return null
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)
            .mapNotNull { try { lm.getLastKnownLocation(it) } catch (e: Exception) { null } }
            .maxByOrNull { it.time }
    }

    fun gpsActivo(ctx: Context): Boolean =
        (ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager).isProviderEnabled(LocationManager.GPS_PROVIDER)

    fun iniciar(ctx: Context, viajeId: String) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY_PAUSADO).apply()
        ContextCompat.startForegroundService(
            ctx, Intent(ctx, TrackingService::class.java)
                .putExtra(TrackingService.EXTRA, viajeId)
                .putExtra(TrackingService.EXTRA_PERFIL, com.micontrol.app.data.Perfiles.activoId(ctx))
        )
    }

    fun detener(ctx: Context) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY_VIAJE).remove(KEY_PERFIL).apply()
        ctx.stopService(Intent(ctx, TrackingService::class.java))
    }
}
