package com.micontrol.app.ui

import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.micontrol.app.data.Ajustes
import com.micontrol.app.data.UbicacionLink
import com.micontrol.app.domain.Recorrido
import kotlinx.coroutines.launch
import org.osmdroid.util.GeoPoint
import java.util.Locale

private data class LugarItem(
    val entrada: String,
    val lugar: Recorrido.Lugar?,
    val aproximada: Boolean,
    val zona: Boolean,
    val fuente: String = "",
    val vista: Boolean = false
)

private fun leerPortapapeles(ctx: Context): String {
    val cb = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    return cb.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(ctx)?.toString().orEmpty()
}

/**
 * Pegás varias ubicaciones juntas (links de Google Maps / WhatsApp o direcciones) y la app las busca,
 * las ordena desde la más cercana al punto de partida hasta la última, y te deja ajustar las dudosas.
 */
@Composable
fun VariasUbicacionesDialog(
    inicio: Pair<Double, Double>?,
    onDismiss: () -> Unit,
    onListo: (List<Recorrido.Lugar>) -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var texto by remember { mutableStateOf(leerPortapapeles(ctx)) }
    val items = remember { mutableStateListOf<LugarItem>() }
    var buscando by remember { mutableStateOf(false) }
    var hecho by remember { mutableStateOf(false) }
    var progreso by remember { mutableStateOf("") }
    var ajustando by remember { mutableStateOf<Int?>(null) }

    val encontrados = items.filter { it.lugar != null }
    val noEncontrados = items.filter { it.lugar == null }
    val ordenados = Recorrido.ordenarCercano(inicio, encontrados, { it.lugar!!.lat }, { it.lugar!!.lng })
    val lugaresOrdenados = ordenados.map { it.lugar!! }
    val aAjustar = ordenados.count { it.aproximada }

    fun buscar() {
        scope.launch {
            buscando = true
            hecho = false
            items.clear()
            val entradas = Recorrido.dividir(texto)
            val clave = Ajustes.claveMapTiler(ctx)
            entradas.forEachIndexed { i, e ->
                progreso = "Buscando ${i + 1} de ${entradas.size}…"
                val p = try { UbicacionLink.resolver(e, clave) } catch (ex: Exception) { null }
                items.add(
                    if (p == null) LugarItem(e, null, false, false)
                    else {
                        val nombre = p.nombre?.takeIf { it.isNotBlank() }
                            ?: p.direccion?.split(",")?.firstOrNull()?.trim()?.takeIf { it.isNotBlank() }
                            ?: "Lugar ${i + 1}"
                        LugarItem(e, Recorrido.Lugar(nombre, p.lat, p.lng), p.aproximada, p.zona, p.fuente, p.vista)
                    }
                )
            }
            buscando = false
            hecho = true
        }
    }

    ajustando?.let { i ->
        val it0 = items.getOrNull(i)
        val l = it0?.lugar
        if (it0 != null && l != null) {
            SelectorUbicacion(
                "Ajustá: ${l.nombre}", onDismiss = { ajustando = null },
                inicial = GeoPoint(l.lat, l.lng), textoInicial = l.nombre,
                zoomInicial = if (it0.zona) 14.0 else 18.0
            ) { _, la, lo ->
                items[i] = it0.copy(lugar = l.copy(lat = la, lng = lo), aproximada = false, zona = false, fuente = "Ajustada a mano en el mapa", vista = false)
                ajustando = null
            }
        }
    }

    AlertDialog(
        onDismissRequest = { if (!buscando) onDismiss() },
        title = { Text("Armar recorrido") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!hecho) {
                    Text(
                        "Pegá todas las ubicaciones juntas: links de Google Maps o de WhatsApp, o direcciones. " +
                            "Ponelas una abajo de otra o separadas por un renglón en blanco.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    OutlinedTextField(
                        texto, { texto = it }, Modifier.fillMaxWidth(),
                        minLines = 5, maxLines = 10, label = { Text("Ubicaciones") }
                    )
                    BotonSec({ texto = leerPortapapeles(ctx) }, Modifier.fillMaxWidth()) { Text("📋 Pegar lo que copié") }
                    if (buscando) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            CircularProgressIndicator(Modifier.size(24.dp))
                            Text(progreso)
                        }
                    }
                    BotonP({ buscar() }, Modifier.fillMaxWidth(), enabled = texto.isNotBlank() && !buscando) {
                        Text("Buscar y ordenar")
                    }
                } else {
                    Text(
                        if (inicio != null) "Orden: arranca por el lugar más cercano a tu punto de partida y sigue siempre al más cercano."
                        else "No tengo tu punto de partida: se respeta el primero de la lista y se sigue por cercanía.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    if (lugaresOrdenados.isNotEmpty()) {
                        val km = Recorrido.distanciaRectaKm(inicio, lugaresOrdenados)
                        Text(
                            "Distancia en línea recta: ${"%.0f".format(Locale("es", "AR"), km)} km (la ruta real por calle es mayor).",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    ordenados.forEachIndexed { n, it0 ->
                        val l = it0.lugar!!
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text("${n + 1}. ${l.nombre}", style = MaterialTheme.typography.titleSmall)
                                if (it0.aproximada) {
                                    Text(
                                        if (it0.zona) "Solo encontré la zona. Ajustala en el mapa." else "Aproximada. Conviene ajustarla en el mapa.",
                                        color = Ambar, style = MaterialTheme.typography.bodySmall
                                    )
                                } else {
                                    Text("✔ " + it0.fuente.ifBlank { "Ubicación exacta" }, color = Verde, style = MaterialTheme.typography.bodySmall)
                                    if (it0.vista) Text("Centro del mapa del link: puede diferir unos metros del pin. Compará.", color = Ambar, style = MaterialTheme.typography.bodySmall)
                                }
                                Text("%.7f, %.7f".format(Locale.US, l.lat, l.lng), style = MaterialTheme.typography.bodySmall)
                                Row {
                                    TextButton({ ajustando = items.indexOf(it0) }) { Text("Ajustar") }
                                    TextButton({ abrirEnGoogleMaps(ctx, l.lat, l.lng) }) { Text("Ver en Google") }
                                    TextButton({ items.remove(it0) }) { Text("Quitar") }
                                }
                            }
                        }
                    }
                    if (noEncontrados.isNotEmpty()) {
                        Text("No pude ubicar:", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.error)
                        noEncontrados.forEach { it0 ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(it0.entrada.take(80), Modifier.weight(1f), style = MaterialTheme.typography.bodySmall, maxLines = 2)
                                TextButton({ items.remove(it0) }) { Text("Quitar") }
                            }
                        }
                    }
                    if (aAjustar > 0) {
                        Text("Hay $aAjustar ubicación(es) aproximada(s). Si no las ajustás, pueden quedar a varias cuadras.", color = Ambar, style = MaterialTheme.typography.bodySmall)
                    }
                    TextButton({ hecho = false }) { Text("← Editar el texto") }
                }
            }
        },
        confirmButton = {
            if (hecho) TextButton({ onListo(lugaresOrdenados) }, enabled = lugaresOrdenados.isNotEmpty()) {
                Text("Armar recorrido (${lugaresOrdenados.size})")
            }
        },
        dismissButton = { TextButton({ if (!buscando) onDismiss() }) { Text("Cancelar") } }
    )
}
