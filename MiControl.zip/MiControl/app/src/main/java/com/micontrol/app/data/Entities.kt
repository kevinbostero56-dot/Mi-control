package com.micontrol.app.data

import androidx.room.*
import java.util.UUID

@Entity(tableName = "clientes", indices = [Index(value = ["nombre"], unique = true)])
data class Cliente(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val nombre: String,
    val direccion: String? = null,
    val lat: Double? = null,
    val lng: Double? = null
)

@Entity(tableName = "viajes")
data class Viaje(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val cliente: String,
    val nombre: String,
    val origen: String,
    val destino: String,
    val inicio: Long,
    val fin: Long? = null,
    val estado: String = Estado.EN_CURSO, // PENDIENTE, EN_CURSO, FINALIZADO
    val observaciones: String = "",
    val odometroInicial: Long,
    val odometroFinal: Long? = null,
    val origenLat: Double? = null,
    val origenLng: Double? = null,
    val destinoLat: Double? = null,
    val destinoLng: Double? = null
) {
    object Estado {
        const val PENDIENTE = "PENDIENTE"
        const val EN_CURSO = "EN_CURSO"
        const val FINALIZADO = "FINALIZADO"
    }
}

@Entity(
    tableName = "jornadas",
    foreignKeys = [ForeignKey(Viaje::class, ["id"], ["viajeId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("viajeId")]
)
data class Jornada(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val viajeId: String,
    val fecha: String,          // ISO yyyy-MM-dd
    val inicioMin: Int,         // minutos desde 00:00
    val finMin: Int,
    val pausaMin: Int = 0,
    val descuentaPausa: Boolean = true,
    val observaciones: String = ""
)

@Entity(
    tableName = "gastos",
    foreignKeys = [ForeignKey(Viaje::class, ["id"], ["viajeId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("viajeId")]
)
data class Gasto(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val viajeId: String,
    val fechaHora: Long,
    val categoria: String,
    val importeCentavos: Long,  // ARS en centavos
    val descripcion: String = "",
    val observaciones: String = "",
    val fotoPath: String? = null     // foto del ticket guardada en el teléfono
)

val CATEGORIAS_GASTO = listOf("Peajes", "Comida", "Alojamiento", "Combustible", "Reparaciones", "Otros")

@Entity(
    tableName = "puntos_gps",
    foreignKeys = [ForeignKey(Viaje::class, ["id"], ["viajeId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("viajeId")]
)
data class PuntoGps(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val viajeId: String,
    val lat: Double,
    val lng: Double,
    val precisionM: Float,
    val tiempo: Long
)

@Entity(
    tableName = "paradas",
    foreignKeys = [ForeignKey(Viaje::class, ["id"], ["viajeId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("viajeId")]
)
data class Parada(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val viajeId: String,
    val orden: Int,
    val nombre: String,
    val lat: Double,
    val lng: Double
)

/** Plata que la empresa le da al chofer para el viaje (adelantos, viáticos). */
@Entity(
    tableName = "adelantos",
    foreignKeys = [ForeignKey(Viaje::class, ["id"], ["viajeId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("viajeId")]
)
data class Adelanto(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val viajeId: String,
    val fechaHora: Long,
    val importeCentavos: Long,
    val descripcion: String = ""
)
