package com.micontrol.app.data

import androidx.room.*
import java.util.UUID

@Entity(tableName = "clientes", indices = [Index(value = ["nombre"], unique = true)])
data class Cliente(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val nombre: String
)

@Entity(tableName = "viajes")
data class Viaje(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val cliente: String,
    val nombre: String,
    val origen: String,
    val destino: String,
    val inicio: Long,
    val fin: Long? = null,
    val estado: String = Estado.EN_CURSO, // PENDIENTE, EN_CURSO, FINALIZADO
    val observaciones: String = "",
    val odometroInicial: Long,
    val odometroFinal: Long? = null
) {
    object Estado {
        const val PENDIENTE = "PENDIENTE"
        const val EN_CURSO = "EN_CURSO"
        const val FINALIZADO = "FINALIZADO"
    }
}

@Entity(
    tableName = "jornadas",
    foreignKeys = [ForeignKey(Viaje::class, ["id"], ["viajeId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("viajeId")]
)
data class Jornada(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val viajeId: String,
    val fecha: String,          // ISO yyyy-MM-dd
    val inicioMin: Int,         // minutos desde 00:00
    val finMin: Int,
    val pausaMin: Int = 0,
    val descuentaPausa: Boolean = true,
    val observaciones: String = ""
)

@Entity(
    tableName = "gastos",
    foreignKeys = [ForeignKey(Viaje::class, ["id"], ["viajeId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("viajeId")]
)
data class Gasto(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val viajeId: String,
    val fechaHora: Long,
    val categoria: String,
    val importeCentavos: Long,  // ARS en centavos
    val descripcion: String = "",
    val observaciones: String = ""
)

val CATEGORIAS_GASTO = listOf("Peajes", "Comida", "Alojamiento", "Combustible", "Reparaciones", "Otros")
