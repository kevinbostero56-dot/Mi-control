package com.micontrol.app.domain

import android.location.Location

/** Arma un recorrido a partir de varias ubicaciones pegadas (links de Google Maps / WhatsApp o direcciones). */
object Recorrido {
    data class Lugar(val nombre: String, val lat: Double, val lng: Double)

    private val enlace = Regex("""(?:https?://|geo:)[^\s"'<>]+""")
    private val prefijoWsp = Regex("""^\[[^\]]{4,40}\]\s*[^:]{1,60}:\s*""")
    private val prefijoWsp2 = Regex("""^\d{1,2}/\d{1,2}/\d{2,4},?\s+\d{1,2}:\d{2}[^-]*-\s*[^:]{1,60}:\s*""")

    private fun limpiarLinea(l: String): String =
        l.trim().replace(prefijoWsp, "").replace(prefijoWsp2, "").trim()

    /**
     * Separa el texto en lugares. Reglas:
     * - Un renglón en blanco separa lugares.
     * - Si un bloque trae varios links, cada link es un lugar.
     * - Si un bloque trae un solo link, el bloque entero es un lugar (el nombre y la dirección acompañan al link).
     * - Si no trae links, cada renglón es un lugar (dirección o coordenadas).
     */
    fun dividir(texto: String): List<String> {
        val out = LinkedHashSet<String>()
        for (bloque in texto.replace("\r", "").split(Regex("""\n\s*\n"""))) {
            val lineas = bloque.lines().map { limpiarLinea(it) }.filter { it.isNotBlank() }
            if (lineas.isEmpty()) continue
            val junto = lineas.joinToString("\n")
            val enlaces = enlace.findAll(junto).map { it.value.trimEnd('.', ',') }.toList()
            when {
                enlaces.size > 1 -> enlaces.forEach { out.add(it) }
                enlaces.size == 1 -> out.add(junto)
                else -> lineas.forEach { out.add(it) }
            }
        }
        return out.toList()
    }

    private fun metros(aLat: Double, aLng: Double, bLat: Double, bLng: Double): Float {
        val r = FloatArray(1)
        Location.distanceBetween(aLat, aLng, bLat, bLng, r)
        return r[0]
    }

    /**
     * Ordena empezando por el lugar más cercano al punto de partida y, desde ahí, siempre el más cercano
     * al que se acaba de visitar. Si no hay punto de partida, el primero de la lista queda primero.
     */
    fun <T> ordenarCercano(inicio: Pair<Double, Double>?, lista: List<T>, lat: (T) -> Double, lng: (T) -> Double): List<T> {
        if (lista.size < 2) return lista
        val resto = lista.toMutableList()
        val out = mutableListOf<T>()
        var aLat: Double
        var aLng: Double
        if (inicio != null) {
            aLat = inicio.first; aLng = inicio.second
        } else {
            val p = resto.removeAt(0)
            out.add(p); aLat = lat(p); aLng = lng(p)
        }
        while (resto.isNotEmpty()) {
            val cerca = resto.minByOrNull { metros(aLat, aLng, lat(it), lng(it)) }!!
            resto.remove(cerca)
            out.add(cerca)
            aLat = lat(cerca); aLng = lng(cerca)
        }
        return out
    }

    /** Distancia en línea recta pasando por todos los lugares en orden (la ruta real por calle es mayor). */
    fun distanciaRectaKm(inicio: Pair<Double, Double>?, lugares: List<Lugar>): Double {
        var total = 0.0
        var aLat = inicio?.first
        var aLng = inicio?.second
        for (l in lugares) {
            if (aLat != null && aLng != null) total += metros(aLat, aLng, l.lat, l.lng)
            aLat = l.lat; aLng = l.lng
        }
        return total / 1000.0
    }
}
