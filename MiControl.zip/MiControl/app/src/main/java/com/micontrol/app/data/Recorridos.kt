package com.micontrol.app.data

import org.json.JSONArray
import org.json.JSONObject

/** Convierte las paradas de un recorrido guardado a texto y de vuelta. */
object RecorridosJson {
    fun codificar(paradas: List<Parada>): String {
        val a = JSONArray()
        paradas.forEach { p ->
            a.put(JSONObject().put("n", p.nombre).put("la", p.lat).put("lo", p.lng))
        }
        return a.toString()
    }

    fun decodificar(texto: String): List<Parada> = try {
        val a = JSONArray(texto)
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            Parada(viajeId = "", orden = i, nombre = o.optString("n"), lat = o.getDouble("la"), lng = o.getDouble("lo"))
        }
    } catch (e: Exception) {
        emptyList()
    }
}
