package com.micontrol.app.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.micontrol.app.data.Cliente
import com.micontrol.app.data.Parada
import com.micontrol.app.data.RecorridosJson
import com.micontrol.app.data.TIPOS_LUGAR
import com.micontrol.app.gps.Gps
import kotlinx.coroutines.delay
import org.osmdroid.util.GeoPoint
import kotlin.math.roundToInt

@Composable
fun ClientesScreen(vm: MainViewModel, nav: NavController) {
    val ctx = LocalContext.current
    val clientes by vm.clientes.collectAsStateWithLifecycle()
    val recorridos by vm.recorridos.collectAsStateWithLifecycle()
    var edit by remember { mutableStateOf<Cliente?>(null) }
    var importar by remember { mutableStateOf(false) }
    var busqueda by remember { mutableStateOf("") }
    var filtroLista by remember { mutableStateOf<String?>(null) }
    var filtroTipo by remember { mutableStateOf<String?>(null) }
    var seleccionando by remember { mutableStateOf(false) }
    var seleccion by remember { mutableStateOf(setOf<Long>()) }
    var pidiendoLista by remember { mutableStateOf(false) }
    var pidiendoTipo by remember { mutableStateOf(false) }
    var confirmarBorrar by remember { mutableStateOf(false) }

    val listas = clientes.map { it.lista }.filter { it.isNotBlank() }.distinct().sorted()
    val visibles = clientes.filter { c ->
        (filtroLista == null || c.lista == filtroLista) &&
            (filtroTipo == null || c.tipo == filtroTipo) &&
            (busqueda.isBlank() || c.nombre.contains(busqueda, true) || (c.direccion ?: "").contains(busqueda, true))
    }
    val elegidos = clientes.filter { it.id in seleccion }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Lugares", style = MaterialTheme.typography.headlineSmall)
        Text("Clientes, proveedores y destinos con su ubicación. Elegí varios para armar un recorrido.", style = MaterialTheme.typography.bodySmall)
        OutlinedTextField(busqueda, { busqueda = it }, Modifier.fillMaxWidth(), label = { Text("Buscar por nombre o dirección") }, singleLine = true)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            AssistChip({ filtroLista = null; filtroTipo = null }, { Text(if (filtroLista == null && filtroTipo == null) "✔ Todos (${clientes.size})" else "Todos") })
            TIPOS_LUGAR.forEach { t ->
                AssistChip({ filtroTipo = if (filtroTipo == t) null else t }, { Text(if (filtroTipo == t) "✔ $t" else t) })
            }
            listas.forEach { l ->
                AssistChip({ filtroLista = if (filtroLista == l) null else l }, { Text((if (filtroLista == l) "✔ " else "📁 ") + l + " (${clientes.count { it.lista == l }})", maxLines = 1) })
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            BotonP({ edit = Cliente(nombre = "") }, Modifier.weight(1f).height(48.dp)) { Text("➕ Agregar", maxLines = 1) }
            BotonSec({ importar = true }, Modifier.weight(1f).height(48.dp)) { Text("📥 Importar", maxLines = 1) }
            BotonSec({ seleccionando = !seleccionando; seleccion = emptySet() }, Modifier.weight(1f).height(48.dp)) {
                Text(if (seleccionando) "Listo" else "☑ Elegir", maxLines = 1)
            }
        }
        if (seleccionando) {
            Text("${seleccion.size} elegidos", style = MaterialTheme.typography.labelLarge)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                AssistChip({ seleccion = visibles.map { it.id }.toSet() }, { Text("Todos los de la lista") })
                AssistChip({
                    val paradas = elegidos.filter { it.lat != null && it.lng != null }
                        .map { Parada(viajeId = "", orden = 0, nombre = it.nombre, lat = it.lat!!, lng = it.lng!!) }
                    if (paradas.isEmpty()) {
                        Toast.makeText(ctx, "Elegí lugares que tengan ubicación en el mapa.", Toast.LENGTH_LONG).show()
                    } else {
                        vm.recorridoPendiente.value = paradas
                        seleccionando = false; seleccion = emptySet()
                        nav.navigate("home") { popUpTo("home"); launchSingleTop = true }
                    }
                }, { Text("🗺️ Armar recorrido") })
                AssistChip({
                    if (elegidos.isEmpty()) return@AssistChip
                    val texto = elegidos.joinToString("\n\n") { c ->
                        val enlace = if (c.lat != null && c.lng != null)
                            "\nhttps://www.google.com/maps/search/?api=1&query=${"%.6f,%.6f".format(java.util.Locale.US, c.lat, c.lng)}" else ""
                        c.nombre + (c.direccion?.let { " — $it" } ?: "") + enlace
                    }
                    val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, texto) }
                    ctx.startActivity(Intent.createChooser(i, "Compartir lugares").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }, { Text("📤 Compartir") })
                AssistChip({ if (elegidos.isNotEmpty()) pidiendoLista = true }, { Text("📁 Lista") })
                AssistChip({ if (elegidos.isNotEmpty()) pidiendoTipo = true }, { Text("🏷 Tipo") })
                AssistChip({ if (elegidos.isNotEmpty()) confirmarBorrar = true }, { Text("🗑 Borrar") })
            }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
            if (visibles.isEmpty()) item { Text("No hay lugares con ese filtro.", style = MaterialTheme.typography.bodyMedium) }
            items(visibles, key = { it.id }) { c ->
                Card(Modifier.fillMaxWidth().clickable {
                    if (seleccionando) seleccion = if (c.id in seleccion) seleccion - c.id else seleccion + c.id else edit = c
                }) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        if (seleccionando) Checkbox(c.id in seleccion, { seleccion = if (it) seleccion + c.id else seleccion - c.id })
                        Column(Modifier.weight(1f)) {
                            Text(c.nombre, fontWeight = FontWeight.Bold)
                            Text(c.direccion ?: "Sin dirección")
                            val etiqueta = listOf(c.tipo, c.lista).filter { it.isNotBlank() }.joinToString(" · ")
                            Text(
                                etiqueta + if (c.lat != null) " · 📍 con ubicación" else " · sin ubicación en el mapa",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }
            if (recorridos.isNotEmpty()) {
                item { Text("Recorridos guardados", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 8.dp)) }
                items(recorridos, key = { "r${it.id}" }) { r ->
                    val paradas = remember(r.paradas) { RecorridosJson.decodificar(r.paradas) }
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(r.nombre, fontWeight = FontWeight.Bold)
                            Text("${paradas.size} paradas", style = MaterialTheme.typography.bodySmall)
                            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                AssistChip({
                                    vm.recorridoPendiente.value = paradas
                                    nav.navigate("home") { popUpTo("home"); launchSingleTop = true }
                                }, { Text("🗺️ Abrir en el mapa") })
                                AssistChip({ abrirRecorridoEnGoogleMaps(ctx, paradas.map { it.lat to it.lng }) }, { Text("Google Maps") })
                                AssistChip({ vm.borrarRecorrido(r) }, { Text("🗑") })
                            }
                        }
                    }
                }
            }
        }
    }

    if (importar) ImportarGoogleDialog(vm) { importar = false }

    if (pidiendoLista) {
        var nombreLista by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { pidiendoLista = false },
            title = { Text("Pasar ${elegidos.size} lugares a una lista") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(nombreLista, { nombreLista = it }, Modifier.fillMaxWidth(), label = { Text("Nombre de la lista") }, singleLine = true)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listas.forEach { l -> AssistChip({ nombreLista = l }, { Text(l, maxLines = 1) }) }
                    }
                    Text("Dejalo vacío para sacarlos de la lista.", style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = {
                TextButton({
                    vm.cambiarListaClientes(elegidos.map { it.id }, nombreLista)
                    pidiendoLista = false; seleccionando = false; seleccion = emptySet()
                }) { Text("Aplicar") }
            },
            dismissButton = { TextButton({ pidiendoLista = false }) { Text("Cancelar") } }
        )
    }
    if (pidiendoTipo) {
        AlertDialog(
            onDismissRequest = { pidiendoTipo = false },
            title = { Text("Tipo para ${elegidos.size} lugares") },
            text = {
                Column {
                    TIPOS_LUGAR.forEach { t ->
                        TextButton({
                            vm.cambiarTipoClientes(elegidos.map { it.id }, t)
                            pidiendoTipo = false; seleccionando = false; seleccion = emptySet()
                        }, Modifier.fillMaxWidth()) { Text(t) }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton({ pidiendoTipo = false }) { Text("Cancelar") } }
        )
    }
    if (confirmarBorrar) {
        AlertDialog(
            onDismissRequest = { confirmarBorrar = false },
            title = { Text("¿Borrar ${elegidos.size} lugares?") },
            text = { Text("Los viajes ya hechos no se tocan. Esto no se puede deshacer.") },
            confirmButton = {
                TextButton({
                    vm.borrarClientes(elegidos.map { it.id })
                    confirmarBorrar = false; seleccionando = false; seleccion = emptySet()
                }) { Text("Borrar") }
            },
            dismissButton = { TextButton({ confirmarBorrar = false }) { Text("Cancelar") } }
        )
    }

    edit?.let { c -> DialogoCliente(c, onDismiss = { edit = null },
        onBorrar = { vm.borrarCliente(c); edit = null }) { vm.guardarCliente(it); edit = null } }
}

@Composable
private fun DialogoCliente(c: Cliente, onDismiss: () -> Unit, onBorrar: () -> Unit, onOk: (Cliente) -> Unit) {
    val ctx = LocalContext.current
    var nombre by remember { mutableStateOf(c.nombre) }
    var direccion by remember { mutableStateOf(c.direccion ?: "") }
    var tipo by remember { mutableStateOf(c.tipo) }
    var lista by remember { mutableStateOf(c.lista) }
    var lat by remember { mutableStateOf(c.lat) }
    var lng by remember { mutableStateOf(c.lng) }
    var mapa by remember { mutableStateOf(false) }
    var midiendo by remember { mutableStateOf(false) }
    var mejor by remember { mutableStateOf<Location?>(null) }
    var permiso by remember { mutableStateOf(Gps.tieneUbicacion(ctx)) }
    val pedir = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        permiso = Gps.tieneUbicacion(ctx)
    }

    fun terminar() {
        val m = mejor
        if (m != null) {
            lat = m.latitude
            lng = m.longitude
            if (direccion.isBlank()) direccion = "Medida en el lugar (±${m.accuracy.roundToInt()} m)"
            Toast.makeText(ctx, "Ubicación guardada con el GPS (±${m.accuracy.roundToInt()} m)", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(ctx, "No se pudo medir. Salí a cielo abierto e intentá de nuevo.", Toast.LENGTH_LONG).show()
        }
        midiendo = false
    }

    // Mide con el GPS hasta tener buena precisión (o 25 segundos)
    DisposableEffect(midiendo) {
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val oyente = object : LocationListener {
            override fun onLocationChanged(l: Location) {
                val m = mejor
                if (m == null || l.accuracy < m.accuracy) mejor = l
            }
            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}
            @Deprecated("Deprecated in Java")
            override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        }
        if (midiendo) {
            mejor = null
            try {
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 500L, 0f, oyente, Looper.getMainLooper())
            } catch (e: SecurityException) {
                // sin permiso
            }
        }
        onDispose { lm.removeUpdates(oyente) }
    }
    LaunchedEffect(mejor) {
        if (midiendo && (mejor?.accuracy ?: 999f) <= 12f) terminar()
    }
    LaunchedEffect(midiendo) {
        if (midiendo) {
            delay(25_000)
            if (midiendo) terminar()
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (c.id == 0L) "Nuevo cliente" else "Editar cliente") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(nombre, { nombre = it }, Modifier.fillMaxWidth(), label = { Text("Nombre del cliente") })
                OutlinedTextField(direccion, { direccion = it }, Modifier.fillMaxWidth(), label = { Text("Dirección") })
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TIPOS_LUGAR.forEach { t -> AssistChip({ tipo = t }, { Text(if (tipo == t) "✔ $t" else t) }) }
                }
                OutlinedTextField(lista, { lista = it }, Modifier.fillMaxWidth(), label = { Text("Lista (opcional)") }, singleLine = true)
                BotonSec({ mapa = true }, Modifier.fillMaxWidth()) {
                    Text(if (lat == null) "Elegir en el mapa" else "Ubicación marcada (ajustar)")
                }
                BotonSec({
                    if (!permiso) pedir.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
                    else midiendo = true
                }, Modifier.fillMaxWidth(), enabled = !midiendo) {
                    Text(
                        if (midiendo) "Midiendo… ±${mejor?.accuracy?.roundToInt() ?: "--"} m"
                        else "📍 Estoy en el lugar: medir con el GPS"
                    )
                }
                Text(
                    "Para máxima precisión, medí parado en la entrada del cliente y a cielo abierto. Así la próxima vez la ubicación es exacta.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        },
        confirmButton = {
            TextButton({ onOk(c.copy(nombre = nombre.trim(), direccion = direccion.trim().ifBlank { null }, lat = lat, lng = lng, tipo = tipo, lista = lista.trim())) },
                enabled = nombre.isNotBlank() && !midiendo) { Text("Guardar") }
        },
        dismissButton = {
            Row { if (c.id != 0L) TextButton(onBorrar) { Text("Borrar") }; TextButton(onDismiss) { Text("Cancelar") } }
        }
    )

    if (mapa) {
        val la = lat
        val lo = lng
        SelectorUbicacion(
            "Ubicación de ${nombre.ifBlank { "el cliente" }}", onDismiss = { mapa = false },
            inicial = if (la != null && lo != null) GeoPoint(la, lo) else null, textoInicial = direccion
        ) { txt, nla, nlo ->
            direccion = txt; lat = nla; lng = nlo; mapa = false
        }
    }
}
