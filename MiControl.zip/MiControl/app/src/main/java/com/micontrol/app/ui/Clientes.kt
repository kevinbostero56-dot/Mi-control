package com.micontrol.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.micontrol.app.data.Cliente

@Composable
fun ClientesScreen(vm: MainViewModel, nav: NavController) {
    val clientes by vm.clientes.collectAsStateWithLifecycle()
    var edit by remember { mutableStateOf<Cliente?>(null) }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Clientes y destinos", style = MaterialTheme.typography.headlineSmall)
        Text("Guardá tus clientes con su dirección en el mapa y elegilos al iniciar un viaje.", style = MaterialTheme.typography.bodySmall)
        BotonP({ edit = Cliente(nombre = "") }, Modifier.fillMaxWidth().height(52.dp)) { Text("Agregar cliente") }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
            items(clientes, key = { it.id }) { c ->
                Card(Modifier.fillMaxWidth().clickable { edit = c }) {
                    Column(Modifier.padding(14.dp)) {
                        Text(c.nombre, fontWeight = FontWeight.Bold)
                        Text(c.direccion ?: "Sin dirección")
                        if (c.lat != null) Text("Ubicación guardada en el mapa", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }

    edit?.let { c -> DialogoCliente(c, onDismiss = { edit = null },
        onBorrar = { vm.borrarCliente(c); edit = null }) { vm.guardarCliente(it); edit = null } }
}

@Composable
private fun DialogoCliente(c: Cliente, onDismiss: () -> Unit, onBorrar: () -> Unit, onOk: (Cliente) -> Unit) {
    var nombre by remember { mutableStateOf(c.nombre) }
    var direccion by remember { mutableStateOf(c.direccion ?: "") }
    var lat by remember { mutableStateOf(c.lat) }
    var lng by remember { mutableStateOf(c.lng) }
    var mapa by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (c.id == 0L) "Nuevo cliente" else "Editar cliente") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(nombre, { nombre = it }, Modifier.fillMaxWidth(), label = { Text("Nombre del cliente") },
                    keyboardOptions = KeyboardOptions())
                OutlinedTextField(direccion, { direccion = it }, Modifier.fillMaxWidth(), label = { Text("Dirección") })
                BotonSec({ mapa = true }, Modifier.fillMaxWidth()) {
                    Text(if (lat == null) "Elegir en el mapa" else "Ubicación marcada (cambiar)")
                }
            }
        },
        confirmButton = {
            TextButton({ onOk(c.copy(nombre = nombre.trim(), direccion = direccion.trim().ifBlank { null }, lat = lat, lng = lng)) },
                enabled = nombre.isNotBlank()) { Text("Guardar") }
        },
        dismissButton = {
            Row { if (c.id != 0L) TextButton(onBorrar) { Text("Borrar") }; TextButton(onDismiss) { Text("Cancelar") } }
        }
    )

    if (mapa) SelectorUbicacion("Ubicación de ${nombre.ifBlank { "el cliente" }}", onDismiss = { mapa = false }) { txt, la, lo ->
        direccion = txt; lat = la; lng = lo; mapa = false
    }
}
