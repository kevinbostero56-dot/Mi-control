package com.micontrol.app.ui

import android.Manifest
import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.micontrol.app.data.Cliente
import com.micontrol.app.gps.Gps
import kotlinx.coroutines.delay
import org.osmdroid.util.GeoPoint
import kotlin.math.roundToInt

@Composable
fun ClientesScreen(vm: MainViewModel, nav: NavController) {
    val clientes by vm.clientes.collectAsStateWithLifecycle()
    var edit by remember { mutableStateOf<Cliente?>(null) }
    var importar by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Clientes y destinos", style = MaterialTheme.typography.headlineSmall)
        Text("Guardá tus clientes con su ubicación exacta y elegilos al iniciar un viaje.", style = MaterialTheme.typography.bodySmall)
        BotonP({ edit = Cliente(nombre = "") }, Modifier.fillMaxWidth().height(52.dp)) { Text("Agregar cliente") }
        BotonSec({ importar = true }, Modifier.fillMaxWidth()) { Text("📥 Importar mis lugares de Google Maps") }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
            items(clientes, key = { it.id }) { c ->
                Card(Modifier.fillMaxWidth().clickable { edit = c }) {
                    Column(Modifier.padding(14.dp)) {
                        Text(c.nombre, fontWeight = FontWeight.Bold)
                        Text(c.direccion ?: "Sin dirección")
                        if (c.lat != null) Text("Ubicación guardada en el mapa", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }

    if (importar) ImportarGoogleDialog(vm) { importar = false }

    edit?.let { c -> DialogoCliente(c, onDismiss = { edit = null },
        onBorrar = { vm.borrarCliente(c); edit = null }) { vm.guardarCliente(it); edit = null } }
}

@Composable
private fun DialogoCliente(c: Cliente, onDismiss: () -> Unit, onBorrar: () -> Unit, onOk: (Cliente) -> Unit) {
    val ctx = LocalContext.current
    var nombre by remember { mutableStateOf(c.nombre) }
    var direccion by remember { mutableStateOf(c.direccion ?: "") }
    var lat by remember { mutableStateOf(c.lat) }
    var lng by remember { mutableStateOf(c.lng) }
    var mapa by remember { mutableStateOf(false) }
    var midiendo by remember { mutableStateOf(false) }
    var mejor by remember { mutableStateOf<Location?>(null) }
    var permiso by remember { mutableStateOf(Gps.tieneUbicacion(ctx)) }
    val pedir = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        permiso = Gps.tieneUbicacion(ctx)
    }

    fun terminar() {
        val m = mejor
        if (m != null) {
            lat = m.latitude
            lng = m.longitude
            if (direccion.isBlank()) direccion = "Medida en el lugar (±${m.accuracy.roundToInt()} m)"
            Toast.makeText(ctx, "Ubicación guardada con el GPS (±${m.accuracy.roundToInt()} m)", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(ctx, "No se pudo medir. Salí a cielo abierto e intentá de nuevo.", Toast.LENGTH_LONG).show()
        }
        midiendo = false
    }

    // Mide con el GPS hasta tener buena precisión (o 25 segundos)
    DisposableEffect(midiendo) {
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val oyente = object : LocationListener {
            override fun onLocationChanged(l: Location) {
                val m = mejor
                if (m == null || l.accuracy < m.accuracy) mejor = l
            }
            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}
            @Deprecated("Deprecated in Java")
            override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        }
        if (midiendo) {
            mejor = null
            try {
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 500L, 0f, oyente, Looper.getMainLooper())
            } catch (e: SecurityException) {
                // sin permiso
            }
        }
        onDispose { lm.removeUpdates(oyente) }
    }
    LaunchedEffect(mejor) {
        if (midiendo && (mejor?.accuracy ?: 999f) <= 12f) terminar()
    }
    LaunchedEffect(midiendo) {
        if (midiendo) {
            delay(25_000)
            if (midiendo) terminar()
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (c.id == 0L) "Nuevo cliente" else "Editar cliente") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(nombre, { nombre = it }, Modifier.fillMaxWidth(), label = { Text("Nombre del cliente") })
                OutlinedTextField(direccion, { direccion = it }, Modifier.fillMaxWidth(), label = { Text("Dirección") })
                BotonSec({ mapa = true }, Modifier.fillMaxWidth()) {
                    Text(if (lat == null) "Elegir en el mapa" else "Ubicación marcada (ajustar)")
                }
                BotonSec({
                    if (!permiso) pedir.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
                    else midiendo = true
                }, Modifier.fillMaxWidth(), enabled = !midiendo) {
                    Text(
                        if (midiendo) "Midiendo… ±${mejor?.accuracy?.roundToInt() ?: "--"} m"
                        else "📍 Estoy en el lugar: medir con el GPS"
                    )
                }
                Text(
                    "Para máxima precisión, medí parado en la entrada del cliente y a cielo abierto. Así la próxima vez la ubicación es exacta.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        },
        confirmButton = {
            TextButton({ onOk(c.copy(nombre = nombre.trim(), direccion = direccion.trim().ifBlank { null }, lat = lat, lng = lng)) },
                enabled = nombre.isNotBlank() && !midiendo) { Text("Guardar") }
        },
        dismissButton = {
            Row { if (c.id != 0L) TextButton(onBorrar) { Text("Borrar") }; TextButton(onDismiss) { Text("Cancelar") } }
        }
    )

    if (mapa) {
        val la = lat
        val lo = lng
        SelectorUbicacion(
            "Ubicación de ${nombre.ifBlank { "el cliente" }}", onDismiss = { mapa = false },
            inicial = if (la != null && lo != null) GeoPoint(la, lo) else null, textoInicial = direccion
        ) { txt, nla, nlo ->
            direccion = txt; lat = nla; lng = nlo; mapa = false
        }
    }
}
