package com.micontrol.app.domain

import com.micontrol.app.data.Jornada
import java.text.NumberFormat
import java.util.Locale

object Calculos {
    const val JORNADA_NORMAL_MIN = 9 * 60

    /** Kilómetros oficiales: SOLO odómetro final − inicial. Nunca GPS. */
    fun kmOficiales(inicial: Long, final: Long?): Long? = final?.let { it - inicial }

    fun minutosTrabajados(j: Jornada): Int {
        var d = j.finMin - j.inicioMin
        if (d < 0) d += 24 * 60               // jornada que cruza medianoche
        if (j.descuentaPausa) d -= j.pausaMin
        return d.coerceAtLeast(0)
    }

    fun normales(trabajados: Int) = minOf(trabajados, JORNADA_NORMAL_MIN)
    /** Horas extras del día = max(0, trabajadas − 9 h). Se calcula por día. */
    fun extras(trabajados: Int) = maxOf(0, trabajados - JORNADA_NORMAL_MIN)

    fun extrasTotales(jornadas: List<Jornada>) = jornadas.sumOf { extras(minutosTrabajados(it)) }

    fun hhmm(min: Int) = "%d:%02d".format(min / 60, min % 60)

    fun pesos(centavos: Long): String =
        NumberFormat.getCurrencyInstance(Locale("es", "AR")).format(centavos / 100.0)

    /** "HH:mm" -> minutos, o null si es inválido. */
    fun parseHora(s: String): Int? {
        val p = s.trim().split(":")
        if (p.size != 2) return null
        val h = p[0].toIntOrNull() ?: return null
        val m = p[1].toIntOrNull() ?: return null
        return if (h in 0..23 && m in 0..59) h * 60 + m else null
    }

    /** "1234,50" o "1234.50" -> centavos. */
    fun parseImporte(s: String): Long? {
        val t = s.trim()
        val norm = if (t.contains(',')) t.replace(".", "").replace(',', '.') else t
        val d = norm.toDoubleOrNull() ?: return null
        return if (d >= 0) Math.round(d * 100) else null
    }
}
