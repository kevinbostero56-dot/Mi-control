package com.micontrol.app.domain

import android.location.Location
import com.micontrol.app.data.Jornada
import com.micontrol.app.data.PuntoGps
import java.text.NumberFormat
import java.time.LocalTime
import java.util.Locale

object Calculos {
    const val JORNADA_NORMAL_MIN = 9 * 60
    /** Una jornada abierta (en curso) guarda finMin = -1. */
    const val ABIERTA = -1
    /** Si entre dos puntos GPS pasan más de 10 min, no se unen (no se inventan tramos). */
    const val GAP_MS = 10 * 60 * 1000L

    fun minutoActual(): Int { val t = LocalTime.now(); return t.hour * 60 + t.minute }

    /** Kilómetros oficiales: SOLO odómetro final − inicial. Nunca GPS. */
    fun kmOficiales(inicial: Long, final: Long?): Long? = final?.let { it - inicial }

    fun minutosTrabajados(j: Jornada): Int {
        if (j.finMin == ABIERTA) return 0
        var d = j.finMin - j.inicioMin
        if (d < 0) d += 24 * 60               // jornada que cruza medianoche
        if (j.descuentaPausa) d -= j.pausaMin
        return d.coerceAtLeast(0)
    }

    fun normales(trabajados: Int) = minOf(trabajados, JORNADA_NORMAL_MIN)
    /** Horas extras del día = max(0, trabajadas − 9 h). Se calcula por día. */
    fun extras(trabajados: Int) = maxOf(0, trabajados - JORNADA_NORMAL_MIN)

    fun extrasTotales(jornadas: List<Jornada>) = jornadas.sumOf { extras(minutosTrabajados(it)) }

    fun hhmm(min: Int) = "%d:%02d".format(min / 60, min % 60)

    fun pesos(centavos: Long): String =
        NumberFormat.getCurrencyInstance(Locale("es", "AR")).format(centavos / 100.0)

    fun parseHora(s: String): Int? {
        val p = s.trim().split(":")
        if (p.size != 2) return null
        val h = p[0].toIntOrNull() ?: return null
        val m = p[1].toIntOrNull() ?: return null
        return if (h in 0..23 && m in 0..59) h * 60 + m else null
    }

    fun parseImporte(s: String): Long? {
        val t = s.trim()
        val norm = if (t.contains(',')) t.replace(".", "").replace(',', '.') else t
        val d = norm.toDoubleOrNull() ?: return null
        return if (d >= 0) Math.round(d * 100) else null
    }

    /** Parte el recorrido en tramos continuos; donde se perdió la señal queda un corte. */
    fun segmentos(p: List<PuntoGps>): List<List<PuntoGps>> {
        val out = mutableListOf<MutableList<PuntoGps>>()
        for (pt in p) {
            val ult = out.lastOrNull()
            if (ult == null || pt.tiempo - ult.last().tiempo > GAP_MS) out.add(mutableListOf(pt)) else ult.add(pt)
        }
        return out
    }

    /** Distancia GPS (solo referencia, NO oficial). */
    fun distanciaGpsKm(p: List<PuntoGps>): Double {
        var m = 0.0
        val r = FloatArray(1)
        for (s in segmentos(p)) for (i in 1 until s.size) {
            Location.distanceBetween(s[i - 1].lat, s[i - 1].lng, s[i].lat, s[i].lng, r)
            m += r[0]
        }
        return m / 1000.0
    }
}
