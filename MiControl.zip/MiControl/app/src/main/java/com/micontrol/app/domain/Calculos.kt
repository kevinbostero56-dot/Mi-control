package com.micontrol.app.domain

import android.location.Location
import com.micontrol.app.data.Adelanto
import com.micontrol.app.data.Gasto
import com.micontrol.app.data.Jornada
import com.micontrol.app.data.PuntoGps
import java.text.NumberFormat
import java.time.LocalTime
import java.util.Locale

object Calculos {
    const val JORNADA_NORMAL_MIN = 9 * 60
    /** Una jornada abierta (en curso) guarda finMin = -1. */
    const val ABIERTA = -1
    /** Si entre dos puntos GPS pasan más de 10 min, no se unen (no se inventan tramos). */
    const val GAP_MS = 10 * 60 * 1000L

    fun minutoActual(): Int { val t = LocalTime.now(); return t.hour * 60 + t.minute }

    /** Kilómetros oficiales: SOLO odómetro final − inicial. Nunca GPS. */
    fun kmOficiales(inicial: Long, final: Long?): Long? = final?.let { it - inicial }

    fun minutosTrabajados(j: Jornada): Int {
        if (j.finMin == ABIERTA) return 0
        var d = j.finMin - j.inicioMin
        if (d < 0) d += 24 * 60               // jornada que cruza medianoche
        if (j.descuentaPausa) d -= j.pausaMin
        return d.coerceAtLeast(0)
    }

    fun normales(trabajados: Int) = minOf(trabajados, JORNADA_NORMAL_MIN)
    /** Horas extras del día = max(0, trabajadas − 9 h). Se calcula por día. */
    fun extras(trabajados: Int) = maxOf(0, trabajados - JORNADA_NORMAL_MIN)

    fun extrasTotales(jornadas: List<Jornada>) = jornadas.sumOf { extras(minutosTrabajados(it)) }

    /** Plata recibida de la empresa − gastos. Positivo: hay que devolver. Negativo: la empresa debe. */
    fun saldoEmpresa(adelantos: List<Adelanto>, gastos: List<Gasto>): Long =
        adelantos.sumOf { it.importeCentavos } - gastos.sumOf { it.importeCentavos }

    /** Consumo de combustible del viaje. */
    data class Consumo(
        val litros: Double,
        val km: Double,
        val kmDeGps: Boolean,
        val costoCentavos: Long,
        val lPor100: Double?,
        val kmPorLitro: Double?,
        val centavosPorKm: Double?,
        val centavosPorLitro: Double?
    )

    /** Litros y costo de las cargas de Combustible. Usa los km del odómetro; si faltan, los del GPS (referencia). */
    fun consumo(gastos: List<Gasto>, kmOficial: Long?, kmGps: Double): Consumo? {
        val comb = gastos.filter { it.categoria == "Combustible" }
        val conLitros = comb.filter { (it.litros ?: 0.0) > 0.0 }
        val litros = conLitros.sumOf { it.litros ?: 0.0 }
        if (litros <= 0.0) return null
        val deGps = kmOficial == null || kmOficial <= 0
        val km = if (deGps) kmGps else kmOficial!!.toDouble()
        val costo = comb.sumOf { it.importeCentavos }
        val costoConLitros = conLitros.sumOf { it.importeCentavos }
        val hayKm = km > 0.0
        return Consumo(
            litros = litros, km = km, kmDeGps = deGps, costoCentavos = costo,
            lPor100 = if (hayKm) litros / km * 100.0 else null,
            kmPorLitro = if (hayKm) km / litros else null,
            centavosPorKm = if (hayKm) costo / km else null,
            centavosPorLitro = costoConLitros / litros
        )
    }

    fun hhmm(min: Int) = "%d:%02d".format(min / 60, min % 60)

    fun pesos(centavos: Long): String =
        NumberFormat.getCurrencyInstance(Locale("es", "AR")).format(centavos / 100.0)

    fun parseHora(s: String): Int? {
        val p = s.trim().split(":")
        if (p.size != 2) return null
        val h = p[0].toIntOrNull() ?: return null
        val m = p[1].toIntOrNull() ?: return null
        return if (h in 0..23 && m in 0..59) h * 60 + m else null
    }

    fun parseImporte(s: String): Long? {
        val t = s.trim()
        val norm = if (t.contains(',')) t.replace(".", "").replace(',', '.') else t
        val d = norm.toDoubleOrNull() ?: return null
        return if (d >= 0) Math.round(d * 100) else null
    }

    /** Distancia en metros entre dos puntos GPS. */
    private fun dist(a: PuntoGps, b: PuntoGps): Float {
        val r = FloatArray(1)
        Location.distanceBetween(a.lat, a.lng, b.lat, b.lng, r)
        return r[0]
    }

    /** Si pasaron más de 10 min y el teléfono quedó a menos de 300 m, es una detención, no una pérdida de señal. */
    const val STOP_M = 300f

    /** Parte el recorrido en tramos continuos; donde se perdió la señal (largo tiempo y lejos) queda un corte. */
    fun segmentos(p: List<PuntoGps>): List<List<PuntoGps>> {
        val out = mutableListOf<MutableList<PuntoGps>>()
        for (pt in p) {
            val ult = out.lastOrNull()
            if (ult == null || (pt.tiempo - ult.last().tiempo > GAP_MS && dist(ult.last(), pt) > STOP_M)) out.add(mutableListOf(pt))
            else ult.add(pt)
        }
        return out
    }

    /** Distancia GPS (solo referencia, NO oficial). */
    fun distanciaGpsKm(p: List<PuntoGps>): Double {
        var m = 0.0
        for (s in segmentos(p)) for (i in 1 until s.size) m += dist(s[i - 1], s[i])
        return m / 1000.0
    }

    /** Detención: más de 10 min sin moverse. `idx` es el punto donde se quedó. */
    data class Detenido(val idx: Int, val desde: Long, val hasta: Long)

    fun detenciones(p: List<PuntoGps>): List<Detenido> {
        val out = mutableListOf<Detenido>()
        for (i in 1 until p.size) {
            val dt = p[i].tiempo - p[i - 1].tiempo
            if (dt >= GAP_MS && dist(p[i - 1], p[i]) <= STOP_M) out.add(Detenido(i - 1, p[i - 1].tiempo, p[i].tiempo))
        }
        return out
    }

    /** Kilómetros GPS recorridos en cada hora. `idx` es el primer punto de esa hora. */
    data class KmHora(val idx: Int, val horaMs: Long, val km: Double)

    fun kmPorHora(p: List<PuntoGps>): List<KmHora> {
        val mapa = LinkedHashMap<Long, DoubleArray>() // hora -> [km acumulado, idx]
        for (i in 1 until p.size) {
            val d = dist(p[i - 1], p[i])
            if (p[i].tiempo - p[i - 1].tiempo <= GAP_MS || d <= STOP_M) {
                val h = p[i].tiempo / 3_600_000L
                val e = mapa.getOrPut(h) { doubleArrayOf(0.0, i.toDouble()) }
                e[0] += d / 1000.0
            }
        }
        return mapa.map { (h, e) -> KmHora(e[1].toInt(), h * 3_600_000L, e[0]) }
    }
}
