package com.micontrol.app.domain

import android.location.Location
import com.micontrol.app.data.Adelanto
import com.micontrol.app.data.Gasto
import com.micontrol.app.data.Jornada
import com.micontrol.app.data.PuntoGps
import java.text.NumberFormat
import java.time.LocalTime
import java.util.Locale

object Calculos {
    const val JORNADA_NORMAL_MIN = 9 * 60
    /** Una jornada abierta (en curso) guarda finMin = -1. */
    const val ABIERTA = -1
    /** Si entre dos puntos GPS pasan más de 10 min, no se unen (no se inventan tramos). */
    const val GAP_MS = 10 * 60 * 1000L

    fun minutoActual(): Int { val t = LocalTime.now(); return t.hour * 60 + t.minute }

    /** Kilómetros oficiales: SOLO odómetro final − inicial. Nunca GPS. */
    fun kmOficiales(inicial: Long, final: Long?): Long? = final?.let { it - inicial }

    /** Kilómetros con puntos de mil, como en el tablero: 101.858 */
    fun kmTxt(n: Long): String = "%,d".format(Locale("es", "AR"), n)

    /**
     * Lee el odómetro como lo muestra el tablero: "101857,7", "101.857,7", "101857.7" o "101857".
     * Se guarda en km enteros (el decimal se redondea).
     */
    fun parseOdometro(s: String): Long? {
        var t = s.trim().replace(" ", "")
        if (t.isEmpty()) return null
        t = if (t.contains(',')) t.replace(".", "").replace(',', '.')
        else if (Regex("""\d{1,3}(\.\d{3})+""").matches(t)) t.replace(".", "")
        else t
        val d = t.toDoubleOrNull() ?: return null
        if (d < 0) return null
        return Math.round(d)
    }

    /** Odómetro en décimas de km (101.857,7 km = 1018577). */
    fun odoDecimas(km: Long, dec: Int): Long = km * 10 + dec.coerceIn(0, 9)

    /** Km oficiales en décimas: odómetro final − inicial, solo con el odómetro. */
    fun kmDecimas(v: com.micontrol.app.data.Viaje): Long? =
        v.odometroFinal?.let { odoDecimas(it, v.odoFinalDec) - odoDecimas(v.odometroInicial, v.odoInicialDec) }

    /** 2503 -> "250,3"; 20190 -> "2.019" (sin decimal si es cero). */
    fun decimasTxt(d: Long): String {
        val ar = Locale("es", "AR")
        val neg = d < 0
        val a = Math.abs(d)
        val ent = "%,d".format(ar, a / 10)
        return (if (neg) "-" else "") + ent + (if (a % 10 != 0L) ",${a % 10}" else "")
    }

    /** Texto de km oficiales de un viaje, por ejemplo "250,3". */
    fun kmViajeTxt(v: com.micontrol.app.data.Viaje): String? = kmDecimas(v)?.let { decimasTxt(it) }

    /** Lee "101.857,7", "101857,7", "101857.7" o "101857" y devuelve (km enteros, décima). */
    fun parseOdometroDec(s: String): Pair<Long, Int>? {
        var t = s.trim().replace(" ", "")
        if (t.isEmpty()) return null
        t = if (t.contains(',')) t.replace(".", "").replace(',', '.')
        else if (Regex("""\d{1,3}(\.\d{3})+""").matches(t)) t.replace(".", "")
        else t
        val bd = runCatching { java.math.BigDecimal(t) }.getOrNull() ?: return null
        if (bd.signum() < 0) return null
        val dec = bd.setScale(1, java.math.RoundingMode.HALF_UP).movePointRight(1).toLong()
        return (dec / 10) to (dec % 10).toInt()
    }

    /** Odómetro más alto cargado, como texto editable ("101857,7"). */
    fun odometroActualTxt(viajes: List<com.micontrol.app.data.Viaje>): String? {
        val m = viajes.maxOfOrNull {
            maxOf(odoDecimas(it.odometroInicial, it.odoInicialDec), it.odometroFinal?.let { f -> odoDecimas(f, it.odoFinalDec) } ?: 0L)
        } ?: return null
        return (m / 10).toString() + (if (m % 10 != 0L) ",${m % 10}" else "")
    }

    fun minutosTrabajados(j: Jornada): Int {
        if (j.finMin == ABIERTA) return 0
        var d = j.finMin - j.inicioMin
        if (d < 0) d += 24 * 60               // jornada que cruza medianoche
        if (j.descuentaPausa) d -= j.pausaMin
        return d.coerceAtLeast(0)
    }

    fun normales(trabajados: Int) = minOf(trabajados, JORNADA_NORMAL_MIN)
    /** Horas extras del día = max(0, trabajadas − 9 h). Se calcula por día. */
    fun extras(trabajados: Int) = maxOf(0, trabajados - JORNADA_NORMAL_MIN)

    /** Extras por día: se suman las jornadas de la misma fecha y recién ahí se descuentan las 9 horas. */
    fun extrasTotales(jornadas: List<Jornada>) =
        jornadas.groupBy { it.fecha }.values.sumOf { dia -> extras(dia.sumOf { minutosTrabajados(it) }) }

    /** Gastos que entran en la rendición: todo menos el combustible pagado con la tarjeta de la empresa
     *  (el combustible que el chofer pagó con su plata SÍ entra). */
    fun dinero(gastos: List<Gasto>): List<Gasto> = gastos.filter { it.categoria != Gasto.COMBUSTIBLE || it.pagoPropio }

    /** Gastos que no son combustible (para listarlos aparte de las cargas). */
    fun sinCombustible(gastos: List<Gasto>): List<Gasto> = gastos.filter { it.categoria != Gasto.COMBUSTIBLE }

    /** Combustible pagado con la plata del chofer. */
    fun combustiblePropio(gastos: List<Gasto>): Long =
        gastos.filter { it.categoria == Gasto.COMBUSTIBLE && it.pagoPropio }.sumOf { it.importeCentavos }

    /** Un consumo fuera de 10–80 L/100 km casi seguro es un error al cargar litros u odómetro. */
    fun consumoRaro(lPor100: Double?): Boolean = lPor100 != null && (lPor100 < 10.0 || lPor100 > 80.0)

    /** Cargas de combustible. */
    fun cargas(gastos: List<Gasto>): List<Gasto> = gastos.filter { it.categoria == Gasto.COMBUSTIBLE }

    /** Plata recibida de la empresa − gastos (sin el combustible de la tarjeta). Positivo: hay que devolver. Negativo: la empresa debe. */
    fun saldoEmpresa(adelantos: List<Adelanto>, gastos: List<Gasto>): Long =
        adelantos.sumOf { it.importeCentavos } - dinero(gastos).sumOf { it.importeCentavos }

    /** Consumo de combustible del viaje. */
    data class Consumo(
        val litros: Double,
        val km: Double,
        val kmDeGps: Boolean,
        val costoCentavos: Long,
        val lPor100: Double?,
        val kmPorLitro: Double?,
        val centavosPorKm: Double?,
        val centavosPorLitro: Double?,
        val cantidad: Int = 0,
        /** true si alguna carga no tiene litros: el consumo no es exacto. */
        val incompleto: Boolean = false
    )

    /** Litros y costo de las cargas de Combustible. Usa SOLO los km del odómetro; si faltan, el consumo queda pendiente (nunca GPS). */
    fun consumo(gastos: List<Gasto>, kmOficial: Double?, kmGps: Double): Consumo? {
        val comb = cargas(gastos)
        if (comb.isEmpty()) return null
        val conLitros = comb.filter { (it.litros ?: 0.0) > 0.0 }
        val litros = conLitros.sumOf { it.litros ?: 0.0 }
        val incompleto = conLitros.size < comb.size
        val km = if (kmOficial != null && kmOficial > 0) kmOficial else 0.0
        val costo = comb.sumOf { it.importeCentavos }
        // Precio del litro: solo con las cargas que tienen litros e importe
        val conAmbos = conLitros.filter { it.importeCentavos > 0 }
        val litrosConPrecio = conAmbos.sumOf { it.litros ?: 0.0 }
        val hayKm = km > 0.0 && litros > 0.0
        return Consumo(
            litros = litros, km = km, kmDeGps = false, costoCentavos = costo,
            lPor100 = if (hayKm) litros / km * 100.0 else null,
            kmPorLitro = if (hayKm) km / litros else null,
            centavosPorKm = if (hayKm && costo > 0 && conAmbos.size == comb.size) costo / km else null,
            centavosPorLitro = if (litrosConPrecio > 0) conAmbos.sumOf { it.importeCentavos } / litrosConPrecio else null,
            cantidad = comb.size, incompleto = incompleto
        )
    }

    fun hhmm(min: Int) = "%d:%02d".format(min / 60, min % 60)

    /** Formato argentino: $12.855,25 (punto de miles, coma decimal, siempre dos decimales). */
    fun pesos(centavos: Long): String {
        val abs = Math.abs(centavos)
        val enteros = "%,d".format(Locale("es", "AR"), abs / 100)
        return (if (centavos < 0) "-" else "") + "$" + enteros + "," + "%02d".format(abs % 100)
    }

    fun parseHora(s: String): Int? {
        val p = s.trim().split(":")
        if (p.size != 2) return null
        val h = p[0].toIntOrNull() ?: return null
        val m = p[1].toIntOrNull() ?: return null
        return if (h in 0..23 && m in 0..59) h * 60 + m else null
    }

    fun parseImporte(s: String): Long? {
        var t = s.trim().removePrefix("$").trim().replace(" ", "")
        if (t.isEmpty()) return null
        // 12.855,25 | 12855,25 | 12.855 (puntos de miles) | 1500.5 (punto decimal) | 1500
        t = when {
            t.contains(',') -> t.replace(".", "").replace(',', '.')
            Regex("""\d{1,3}(\.\d{3})+""").matches(t) -> t.replace(".", "")
            else -> t
        }
        val d = runCatching { java.math.BigDecimal(t) }.getOrNull() ?: return null
        if (d.signum() < 0) return null
        return d.multiply(java.math.BigDecimal(100)).setScale(0, java.math.RoundingMode.HALF_UP).toLong()
    }

    /** Distancia en metros entre dos puntos GPS. */
    private fun dist(a: PuntoGps, b: PuntoGps): Float {
        val r = FloatArray(1)
        Location.distanceBetween(a.lat, a.lng, b.lat, b.lng, r)
        return r[0]
    }

    /** Si pasaron más de 10 min y el teléfono quedó a menos de 300 m, es una detención, no una pérdida de señal. */
    const val STOP_M = 300f

    /** Parte el recorrido en tramos continuos; donde se perdió la señal (largo tiempo y lejos) queda un corte. */
    fun segmentos(p: List<PuntoGps>): List<List<PuntoGps>> {
        val out = mutableListOf<MutableList<PuntoGps>>()
        for (pt in p) {
            val ult = out.lastOrNull()
            if (ult == null || (pt.tiempo - ult.last().tiempo > GAP_MS && dist(ult.last(), pt) > STOP_M)) out.add(mutableListOf(pt))
            else ult.add(pt)
        }
        return out
    }

    /** Distancia GPS (solo referencia, NO oficial). */
    fun distanciaGpsKm(p: List<PuntoGps>): Double {
        var m = 0.0
        for (s in segmentos(p)) for (i in 1 until s.size) m += dist(s[i - 1], s[i])
        return m / 1000.0
    }

    /** Detención: más de 10 min sin moverse. `idx` es el punto donde se quedó. */
    data class Detenido(val idx: Int, val desde: Long, val hasta: Long)

    fun detenciones(p: List<PuntoGps>): List<Detenido> {
        val out = mutableListOf<Detenido>()
        for (i in 1 until p.size) {
            val dt = p[i].tiempo - p[i - 1].tiempo
            if (dt >= GAP_MS && dist(p[i - 1], p[i]) <= STOP_M) out.add(Detenido(i - 1, p[i - 1].tiempo, p[i].tiempo))
        }
        return out
    }

    /** Kilómetros GPS recorridos en cada hora. `idx` es el primer punto de esa hora. */
    data class KmHora(val idx: Int, val horaMs: Long, val km: Double)

    fun kmPorHora(p: List<PuntoGps>): List<KmHora> {
        val mapa = LinkedHashMap<Long, DoubleArray>() // hora -> [km acumulado, idx]
        for (i in 1 until p.size) {
            val d = dist(p[i - 1], p[i])
            if (p[i].tiempo - p[i - 1].tiempo <= GAP_MS || d <= STOP_M) {
                val h = p[i].tiempo / 3_600_000L
                val e = mapa.getOrPut(h) { doubleArrayOf(0.0, i.toDouble()) }
                e[0] += d / 1000.0
            }
        }
        return mapa.map { (h, e) -> KmHora(e[1].toInt(), h * 3_600_000L, e[0]) }
    }
}
