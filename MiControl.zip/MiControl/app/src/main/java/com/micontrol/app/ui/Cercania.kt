package com.micontrol.app.ui

import android.Manifest
import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.micontrol.app.gps.Gps
import org.osmdroid.util.GeoPoint
import kotlin.math.roundToInt

private fun metros(l: Location, g: GeoPoint): Float {
    val r = FloatArray(1)
    Location.distanceBetween(l.latitude, l.longitude, g.latitude, g.longitude, r)
    return r[0]
}

/** Dice si estás en el lugar de entrega, con la precisión que tiene el GPS en ese momento. */
@Composable
fun CercaniaCard(objetivos: List<Pair<String, GeoPoint>>) {
    val ctx = LocalContext.current
    var permiso by remember { mutableStateOf(Gps.tieneUbicacion(ctx)) }
    var pos by remember { mutableStateOf<Location?>(null) }
    val pedir = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        permiso = Gps.tieneUbicacion(ctx)
    }

    DisposableEffect(permiso) {
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val oyente = object : LocationListener {
            override fun onLocationChanged(l: Location) { pos = l }
            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}
            @Deprecated("Deprecated in Java")
            override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        }
        if (permiso) {
            try {
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000L, 0f, oyente, Looper.getMainLooper())
            } catch (e: SecurityException) {
                // sin permiso
            }
        }
        onDispose { lm.removeUpdates(oyente) }
    }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("¿Estoy cerca?", style = MaterialTheme.typography.titleMedium)
            val l = pos
            when {
                !permiso -> BotonSec({
                    pedir.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
                }) { Text("Permitir ubicación") }
                l == null -> Text("Buscando la señal del GPS…", style = MaterialTheme.typography.bodyMedium)
                else -> {
                    val acc = l.accuracy
                    Text(
                        "Precisión del GPS: ±${acc.roundToInt()} m" + if (acc > 30f) " (señal débil, la distancia puede no ser exacta)" else "",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (acc > 30f) Ambar else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    objetivos.forEach { (nombre, g) ->
                        val d = metros(l, g)
                        val (estado, color) = when {
                            d <= 30f -> "✅ LLEGASTE · ${d.roundToInt()} m" to Verde
                            d <= 30f + acc -> "🟡 Casi · ${d.roundToInt()} m (±${acc.roundToInt()})" to Ambar
                            d >= 1000f -> "%.1f km".format(d / 1000f) to Color.White
                            else -> "${d.roundToInt()} m" to Color.White
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(nombre, Modifier.weight(1f), maxLines = 2)
                            Text(estado, color = color, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
