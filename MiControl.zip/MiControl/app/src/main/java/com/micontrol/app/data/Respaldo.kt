package com.micontrol.app.data

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import java.io.BufferedOutputStream
import java.io.File
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Copia de seguridad de los datos del perfil: un archivo .zip con la base de datos y las fotos de los tickets.
 * También restaura copias viejas (archivo .db sin fotos).
 */
object Respaldo {
    /** Versión de la base de datos: tiene que ser la misma que en AppDatabase. */
    private const val VERSION_BASE = 6
    private val MAGIA = "SQLite format 3\u0000".toByteArray(Charsets.US_ASCII)
    private const val DIAS_ENTRE_COPIAS = 7

    private fun carpetaFotos(ctx: Context) = File(ctx.filesDir, "tickets").apply { mkdirs() }

    private fun nombreSeguro(perfil: Perfiles.Perfil) =
        perfil.nombre.replace(Regex("[^A-Za-z0-9]+"), "_").trim('_').ifBlank { "perfil" }

    /** Fotos de tickets que usa este perfil. */
    private fun fotosDelPerfil(db: AppDatabase): List<File> {
        val out = ArrayList<File>()
        db.query("SELECT fotoPath FROM gastos WHERE fotoPath IS NOT NULL", null).use { c ->
            while (c.moveToNext()) {
                val ruta = c.getString(0)
                if (!ruta.isNullOrBlank()) out.add(File(ruta))
            }
        }
        return out
    }

    private fun tieneDatos(db: AppDatabase): Boolean =
        db.query("SELECT COUNT(*) FROM viajes", null).use { it.moveToFirst() && it.getInt(0) > 0 }

    private fun armarZip(ctx: Context, perfil: Perfiles.Perfil, salida: OutputStream) {
        val db = AppDatabase.get(ctx, perfil.id)
        // Pasa lo pendiente del diario al archivo principal para que la copia quede completa
        db.query("PRAGMA wal_checkpoint(FULL)", null).use { it.moveToFirst() }
        val origen = ctx.getDatabasePath(AppDatabase.archivo(perfil.id))
        val fotos = fotosDelPerfil(db)
        ZipOutputStream(BufferedOutputStream(salida)).use { z ->
            z.putNextEntry(ZipEntry("datos.db"))
            origen.inputStream().use { it.copyTo(z) }
            z.closeEntry()
            fotos.distinctBy { it.name }.forEach { f ->
                if (f.exists()) {
                    z.putNextEntry(ZipEntry("tickets/${f.name}"))
                    f.inputStream().use { it.copyTo(z) }
                    z.closeEntry()
                }
            }
        }
    }

    /** Arma la copia completa en un archivo temporal y comprueba que se pueda abrir, antes de tocar Descargas. */
    private fun copiaTemporal(ctx: Context, perfil: Perfiles.Perfil): File {
        val tmp = File(ctx.cacheDir, "copia_tmp_${perfil.id}.zip")
        tmp.outputStream().use { armarZip(ctx, perfil, it) }
        java.util.zip.ZipFile(tmp).use { z ->
            if (z.getEntry("datos.db") == null) throw IllegalStateException("La copia quedó incompleta")
        }
        return tmp
    }

    /** Abre un archivo de salida en Descargas. Con `reemplazar`, pisa el que dejó esta app la vez anterior. */
    private fun salidaEnDescargas(ctx: Context, nombre: String, reemplazar: Boolean): OutputStream? {
        val cr = ctx.contentResolver
        if (reemplazar) {
            val existente: Uri? = try {
                cr.query(
                    MediaStore.Downloads.EXTERNAL_CONTENT_URI, arrayOf(MediaStore.Downloads._ID),
                    "${MediaStore.Downloads.DISPLAY_NAME} = ?", arrayOf(nombre), null
                )?.use { c ->
                    if (c.moveToFirst()) ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI, c.getLong(0)) else null
                }
            } catch (e: Exception) {
                null
            }
            if (existente != null) {
                try {
                    val o = cr.openOutputStream(existente, "wt")
                    if (o != null) return o
                } catch (e: Exception) {
                    try { cr.delete(existente, null, null) } catch (e2: Exception) { /* sigue y crea uno nuevo */ }
                }
            }
        }
        val valores = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, nombre)
            put(MediaStore.Downloads.MIME_TYPE, "application/zip")
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
        }
        val uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, valores) ?: return null
        return cr.openOutputStream(uri)
    }

    /** Guarda la copia en Descargas. Devuelve el mensaje para mostrar. */
    fun exportar(ctx: Context, perfil: Perfiles.Perfil, prefijo: String = "copia"): String {
        var tmp: File? = null
        return try {
            tmp = copiaTemporal(ctx, perfil)
            val nombre = "MiControl-$prefijo-${nombreSeguro(perfil)}-${SimpleDateFormat("yyyy-MM-dd_HHmm", Locale.US).format(Date())}.zip"
            val salida = salidaEnDescargas(ctx, nombre, false) ?: return "No se pudo crear el archivo en Descargas."
            salida.use { o -> tmp.inputStream().use { it.copyTo(o) } }
            Ajustes.marcarCopia(ctx, perfil.id)
            "Copia guardada en Descargas: $nombre"
        } catch (e: Exception) {
            "No se pudo guardar la copia."
        } finally {
            tmp?.delete()
        }
    }

    /** Copia de seguridad previa a algo que no tiene vuelta atrás (restaurar o eliminar un perfil). true si quedó guardada. */
    fun copiaPrevia(ctx: Context, perfil: Perfiles.Perfil, motivo: String): Boolean {
        var tmp: File? = null
        return try {
            val db = AppDatabase.get(ctx, perfil.id)
            if (!tieneDatos(db)) return true   // no hay nada que perder
            tmp = copiaTemporal(ctx, perfil)
            val nombre = "MiControl-antes-de-$motivo-${nombreSeguro(perfil)}-${SimpleDateFormat("yyyy-MM-dd_HHmm", Locale.US).format(Date())}.zip"
            val salida = salidaEnDescargas(ctx, nombre, false) ?: return false
            salida.use { o -> tmp.inputStream().use { it.copyTo(o) } }
            true
        } catch (e: Exception) {
            false
        } finally {
            tmp?.delete()
        }
    }

    /** Copia semanal sola, de todos los perfiles que tengan datos. Devuelve cuántas hizo. */
    fun automatica(ctx: Context): Int {
        if (!Ajustes.copiaAuto(ctx)) return 0
        var hechas = 0
        for (perfil in Perfiles.todos(ctx)) {
            var tmp: File? = null
            try {
                val ultima = Ajustes.ultimaCopia(ctx, perfil.id)
                if (System.currentTimeMillis() - ultima < DIAS_ENTRE_COPIAS * 24L * 3600 * 1000) continue
                if (!tieneDatos(AppDatabase.get(ctx, perfil.id))) continue
                // Primero se arma y comprueba la copia nueva; recién después se reemplaza la anterior
                tmp = copiaTemporal(ctx, perfil)
                val salida = salidaEnDescargas(ctx, "MiControl-copia-automatica-${nombreSeguro(perfil)}.zip", true) ?: continue
                salida.use { o -> tmp.inputStream().use { it.copyTo(o) } }
                Ajustes.marcarCopia(ctx, perfil.id)
                hechas++
            } catch (e: Exception) {
                // si falla una copia, se reintenta en la próxima pasada
            } finally {
                tmp?.delete()
            }
        }
        return hechas
    }

    /** Reemplaza los datos del perfil por los de la copia. Devuelve null si salió bien, o el motivo del error. */
    fun restaurar(ctx: Context, perfilId: String, uri: Uri): String? {
        val bruto = File(ctx.cacheDir, "restaurar.bin")
        val temporal = File(ctx.cacheDir, "restaurar.db")
        try {
            ctx.contentResolver.openInputStream(uri)?.use { entrada ->
                bruto.outputStream().use { entrada.copyTo(it) }
            } ?: return "No se pudo leer el archivo."

            val cabecera = ByteArray(16)
            val leidos = bruto.inputStream().use { it.read(cabecera) }
            val esZip = leidos >= 4 && cabecera[0] == 'P'.code.toByte() && cabecera[1] == 'K'.code.toByte()
            var fotosNuevas = 0

            if (esZip) {
                var hayDatos = false
                ZipInputStream(bruto.inputStream().buffered()).use { z ->
                    var e = z.nextEntry
                    while (e != null) {
                        val nombre = File(e.name).name
                        if (!e.isDirectory && e.name == "datos.db") {
                            temporal.outputStream().use { z.copyTo(it) }
                            hayDatos = true
                        } else if (!e.isDirectory && e.name.startsWith("tickets/") && nombre.isNotBlank()) {
                            File(carpetaFotos(ctx), nombre).outputStream().use { z.copyTo(it) }
                            fotosNuevas++
                        }
                        e = z.nextEntry
                    }
                }
                if (!hayDatos) return "El archivo no es una copia de Mi Control."
            } else {
                if (leidos < 16 || !cabecera.contentEquals(MAGIA)) return "El archivo no es una copia de Mi Control."
                bruto.copyTo(temporal, overwrite = true)
            }

            val cab2 = ByteArray(16)
            val l2 = temporal.inputStream().use { it.read(cab2) }
            if (l2 < 16 || !cab2.contentEquals(MAGIA)) return "El archivo no es una copia de Mi Control."

            val sql = SQLiteDatabase.openDatabase(temporal.path, null, SQLiteDatabase.OPEN_READONLY)
            try {
                val tieneViajes = sql.rawQuery(
                    "SELECT name FROM sqlite_master WHERE type='table' AND name='viajes'", null
                ).use { it.moveToFirst() }
                if (!tieneViajes) return "El archivo no es una copia de Mi Control."
                if (sql.version > VERSION_BASE) return "Esa copia es de una versión más nueva. Actualizá Mi Control primero."
            } finally {
                sql.close()
            }

            AppDatabase.cerrar(perfilId)
            val destino = ctx.getDatabasePath(AppDatabase.archivo(perfilId))
            File(destino.path + "-wal").delete()
            File(destino.path + "-shm").delete()
            File(destino.path + "-journal").delete()
            temporal.copyTo(destino, overwrite = true)

            // Las fotos quedan en la carpeta de esta app: se corrigen las rutas guardadas en los gastos
            if (fotosNuevas > 0) {
                val fotos = carpetaFotos(ctx)
                val sql2 = SQLiteDatabase.openDatabase(destino.path, null, SQLiteDatabase.OPEN_READWRITE)
                try {
                    val filas = ArrayList<Pair<Long, String>>()
                    sql2.rawQuery("SELECT id, fotoPath FROM gastos WHERE fotoPath IS NOT NULL", null).use { c ->
                        while (c.moveToNext()) filas.add(c.getLong(0) to c.getString(1))
                    }
                    filas.forEach { (id, ruta) ->
                        val nueva = File(fotos, File(ruta).name).path
                        sql2.execSQL("UPDATE gastos SET fotoPath = ? WHERE id = ?", arrayOf<Any>(nueva, id))
                    }
                } finally {
                    sql2.close()
                }
            }
            Ajustes.marcarCopia(ctx, perfilId)
            return null
        } catch (e: Exception) {
            return "No se pudo restaurar la copia."
        } finally {
            bruto.delete()
            temporal.delete()
        }
    }
}
