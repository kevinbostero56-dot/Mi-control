package com.micontrol.app.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Copia de seguridad de los datos del perfil (viajes, gastos, horas, clientes). No incluye las fotos de los tickets. */
object Respaldo {
    /** Versión de la base de datos: tiene que ser la misma que en AppDatabase. */
    private const val VERSION_BASE = 5
    private val MAGIA = "SQLite format 3\u0000".toByteArray(Charsets.US_ASCII)

    /** Guarda la copia en Descargas. Devuelve el mensaje para mostrar. */
    fun exportar(ctx: Context, perfil: Perfiles.Perfil): String {
        return try {
            val db = AppDatabase.get(ctx, perfil.id)
            // Pasa lo pendiente del diario al archivo principal para que la copia quede completa
            db.query("PRAGMA wal_checkpoint(FULL)", null).use { it.moveToFirst() }
            val origen = ctx.getDatabasePath(AppDatabase.archivo(perfil.id))
            val limpio = perfil.nombre.replace(Regex("[^A-Za-z0-9]+"), "_").trim('_').ifBlank { "perfil" }
            val nombre = "MiControl-copia-$limpio-${SimpleDateFormat("yyyy-MM-dd_HHmm", Locale.US).format(Date())}.db"
            val valores = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, nombre)
                put(MediaStore.Downloads.MIME_TYPE, "application/octet-stream")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, valores)
                ?: return "No se pudo crear el archivo en Descargas."
            ctx.contentResolver.openOutputStream(uri)?.use { salida ->
                origen.inputStream().use { it.copyTo(salida) }
            } ?: return "No se pudo escribir el archivo."
            "Copia guardada en Descargas: $nombre"
        } catch (e: Exception) {
            "No se pudo guardar la copia."
        }
    }

    /** Reemplaza los datos del perfil por los de la copia. Devuelve null si salió bien, o el motivo del error. */
    fun restaurar(ctx: Context, perfilId: String, uri: Uri): String? {
        val temporal = File(ctx.cacheDir, "restaurar.db")
        try {
            ctx.contentResolver.openInputStream(uri)?.use { entrada ->
                temporal.outputStream().use { entrada.copyTo(it) }
            } ?: return "No se pudo leer el archivo."

            val cabecera = ByteArray(16)
            val leidos = temporal.inputStream().use { it.read(cabecera) }
            if (leidos < 16 || !cabecera.contentEquals(MAGIA)) return "El archivo no es una copia de Mi Control."

            val sql = SQLiteDatabase.openDatabase(temporal.path, null, SQLiteDatabase.OPEN_READONLY)
            try {
                val tieneViajes = sql.rawQuery(
                    "SELECT name FROM sqlite_master WHERE type='table' AND name='viajes'", null
                ).use { it.moveToFirst() }
                if (!tieneViajes) return "El archivo no es una copia de Mi Control."
                if (sql.version > VERSION_BASE) return "Esa copia es de una versión más nueva. Actualizá Mi Control primero."
            } finally {
                sql.close()
            }

            AppDatabase.cerrar(perfilId)
            val destino = ctx.getDatabasePath(AppDatabase.archivo(perfilId))
            File(destino.path + "-wal").delete()
            File(destino.path + "-shm").delete()
            File(destino.path + "-journal").delete()
            temporal.copyTo(destino, overwrite = true)
            return null
        } catch (e: Exception) {
            return "No se pudo restaurar la copia."
        } finally {
            temporal.delete()
        }
    }
}
