package com.micontrol.app.ui

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.micontrol.app.data.*
import com.micontrol.app.gps.Gps
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.util.Locale

private enum class FiltroHotel(val etiqueta: String, val ok: (Hotel) -> Boolean) {
    CAMION("🚛 Camión", { it.accesoCamion }),
    ACOPLADO("🚚 Acoplado", { it.accesoAcoplado }),
    COCHERA("🅿️ Cochera", { it.cochera || it.cocheraCerrada }),
    VIGILANCIA("👮 Vigilancia", { it.vigilancia }),
    DUCHA("🚿 Ducha", { it.banoDucha }),
    COMIDA("🍽️ Restaurante", { it.restaurante })
}

/** Distancia en km de un punto a la línea del recorrido (o a un punto si no hay recorrido). */
private fun distanciaKm(h: Hotel, ruta: List<Pair<Double, Double>>, yo: Pair<Double, Double>?): Double? {
    val la = h.lat ?: return null; val lo = h.lng ?: return null
    val r = FloatArray(1)
    val pts = if (ruta.isNotEmpty()) ruta else listOfNotNull(yo)
    if (pts.isEmpty()) return null
    var min = Double.MAX_VALUE
    for (p in pts) {
        android.location.Location.distanceBetween(la, lo, p.first, p.second, r)
        if (r[0] < min) min = r[0].toDouble()
    }
    return min / 1000.0
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HotelesScreen(nav: NavController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { HotelesDb.get(ctx).dao() }
    val hoteles by dao.todos().collectAsStateWithLifecycle(emptyList())
    val opiniones by dao.opiniones().collectAsStateWithLifecycle(emptyList())
    var busca by remember { mutableStateOf("") }
    val filtros = remember { mutableStateListOf<FiltroHotel>() }
    var cercaRuta by remember { mutableStateOf(true) }
    var editando by remember { mutableStateOf<Hotel?>(null) }
    var viendo by remember { mutableStateOf<Hotel?>(null) }
    var sincronizando by remember { mutableStateOf(false) }
    var aviso by remember { mutableStateOf<String?>(null) }
    val ruta = remember { RutaOffline.ultimaRuta(ctx) }
    val yo = remember { Gps.ultimaUbicacion(ctx)?.let { it.latitude to it.longitude } }
    val admin = Compu.soyAdmin(ctx)

    fun sincronizar() {
        sincronizando = true
        scope.launch {
            aviso = HotelesSync.sincronizar(ctx)
            sincronizando = false
        }
    }
    LaunchedEffect(Unit) { sincronizar() }

    val visibles = hoteles
        .filter { h -> filtros.all { it.ok(h) } }
        .filter { h -> busca.isBlank() || (h.nombre + " " + h.localidad + " " + h.provincia + " " + h.direccion).lowercase().contains(busca.trim().lowercase()) }
        .map { it to distanciaKm(it, if (cercaRuta) ruta else emptyList(), yo) }
        .sortedBy { it.second ?: Double.MAX_VALUE }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("🏨 Hoteles y descanso", style = MaterialTheme.typography.headlineSmall, color = Color.White, modifier = Modifier.weight(1f))
            TextButton({ nav.popBackStack() }) { Text("Volver") }
        }
        Text(
            if (sincronizando) "⏳ Sincronizando con los otros celulares…"
            else aviso ?: "✔ Al día. Se ven sin señal. Los cargan todos los celulares autorizados.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        OutlinedTextField(busca, { busca = it }, Modifier.fillMaxWidth(), label = { Text("Buscar por nombre o localidad") }, singleLine = true)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            if (ruta.isNotEmpty()) FilterChip(cercaRuta, { cercaRuta = !cercaRuta }, label = { Text(if (cercaRuta) "📍 Cerca de mi recorrido" else "📍 Cerca mío") })
            FiltroHotel.values().forEach { f ->
                FilterChip(f in filtros, { if (f in filtros) filtros.remove(f) else filtros.add(f) }, label = { Text(f.etiqueta) })
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            BotonP({ editando = Hotel(lat = yo?.first, lng = yo?.second) }, Modifier.weight(1f)) { Text("➕ Agregar hotel") }
            BotonSec({ sincronizar() }, Modifier.weight(1f), enabled = !sincronizando) { Text("🔄 Actualizar") }
        }
        if (hoteles.isEmpty()) {
            BotonSec({
                scope.launch {
                    val n = importarDeLugares(ctx)
                    Toast.makeText(ctx, if (n > 0) "Se agregaron $n hoteles de tus Lugares." else "No hay hoteles en tus Lugares.", Toast.LENGTH_LONG).show()
                    if (n > 0) sincronizar()
                }
            }, Modifier.fillMaxWidth()) { Text("📥 Traer los hoteles que tengo en Lugares") }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(visibles, key = { it.first.uid }) { (h, km) ->
                val ops = opiniones.filter { it.hotelUid == h.uid }
                Card(Modifier.fillMaxWidth().clickable { viendo = h }) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(h.nombre.ifBlank { "Sin nombre" }, fontWeight = FontWeight.Bold, color = Color.White, modifier = Modifier.weight(1f))
                            km?.let { Text(if (it < 1) "${(it * 1000).toInt()} m" else "%.0f km".format(Locale("es", "AR"), it), color = MaterialTheme.colorScheme.primary) }
                        }
                        Text(listOf(h.localidad, h.provincia).filter { it.isNotBlank() }.joinToString(", "), style = MaterialTheme.typography.bodySmall)
                        Text(
                            listOfNotNull(
                                if (h.accesoAcoplado) "🚚 acoplado" else if (h.accesoCamion) "🚛 camión" else null,
                                if (h.cocheraCerrada) "🅿️ cochera cerrada" else if (h.cochera) "🅿️ cochera" else null,
                                if (h.vigilancia) "👮 vigilancia" else null,
                                if (h.telefono.isNotBlank()) "📞 ${h.telefono}" else null
                            ).joinToString(" · "),
                            style = MaterialTheme.typography.bodySmall
                        )
                        if (ops.isNotEmpty()) {
                            val prom = ops.map { it.estrellas }.average()
                            val rec = ops.count { it.recomendado }
                            Text("★ ${"%.1f".format(Locale("es", "AR"), prom)} · $rec de ${ops.size} lo recomiendan", style = MaterialTheme.typography.bodySmall, color = Ambar)
                        }
                        if (h.pendiente) Text("⏳ Falta mandarlo (sin señal)", style = MaterialTheme.typography.labelSmall)
                        if (admin && h.posibleDuplicadoDe.isNotBlank()) Text("⚠️ Posible duplicado: tocá para revisar", style = MaterialTheme.typography.labelSmall, color = Ambar)
                    }
                }
            }
        }
    }

    viendo?.let { h ->
        HotelDetalle(h, opiniones.filter { it.hotelUid == h.uid }, hoteles, admin,
            onDismiss = { viendo = null },
            onEditar = { viendo = null; editando = h },
            onAccion = { msg -> viendo = null; aviso = msg; if (msg == null) sincronizar() })
    }
    editando?.let { h ->
        HotelForm(h, hoteles, onDismiss = { editando = null }) { guardado ->
            editando = null
            scope.launch {
                dao.guardar(guardado)
                sincronizar()
            }
        }
    }
}

/** Pasa a la base compartida los lugares de tipo "Hotel / cochera" (sin duplicar). */
private suspend fun importarDeLugares(ctx: android.content.Context): Int {
    val dao = HotelesDb.get(ctx).dao()
    val lugares = AppDatabase.get(ctx, Perfiles.activoId(ctx)).clienteDao().todos().first()
    var n = 0
    val quien = Perfiles.activo(ctx).nombre
    lugares.filter { it.tipo.startsWith("Hotel") }.forEach { c ->
        val nuevo = Hotel(nombre = c.nombre, direccion = c.direccion ?: "", lat = c.lat, lng = c.lng, cochera = true, accesoCamion = true, creadoPor = quien)
        if (Antiduplicados.buscar(nuevo, dao.lista())?.second != Antiduplicados.Coincidencia.SEGURA) { dao.guardar(nuevo); n++ }
    }
    return n
}

@Composable
private fun HotelDetalle(
    h: Hotel, ops: List<Opinion>, todos: List<Hotel>, admin: Boolean,
    onDismiss: () -> Unit, onEditar: () -> Unit, onAccion: (String?) -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var opinando by remember { mutableStateOf(false) }
    var confirmarBorrar by remember { mutableStateOf(false) }
    val duplicadoDe = todos.firstOrNull { it.uid == h.posibleDuplicadoDe }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(h.nombre.ifBlank { "Hotel" }) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                listOf(h.direccion, listOf(h.localidad, h.provincia).filter { it.isNotBlank() }.joinToString(", "))
                    .filter { it.isNotBlank() }.forEach { Text(it) }
                if (h.precio.isNotBlank()) Text("💲 Precio orientativo: ${h.precio}")
                val caract = listOfNotNull(
                    if (h.accesoCamion) "Acceso para camiones" else null, if (h.accesoAcoplado) "Acceso con acoplado" else null,
                    if (h.cochera) "Cochera" else null, if (h.cocheraCerrada) "Cochera cerrada" else null,
                    if (h.vigilancia) "Vigilancia" else null, if (h.restaurante) "Restaurante" else null, if (h.banoDucha) "Baño y ducha" else null
                )
                if (caract.isNotEmpty()) Text("✔ " + caract.joinToString(" · "))
                if (h.estacionamiento.isNotBlank()) Text("🅿️ Estacionamiento: ${h.estacionamiento}")
                if (h.seguridad.isNotBlank()) Text("👮 Seguridad: ${h.seguridad}")
                if (h.observaciones.isNotBlank()) Text("📝 ${h.observaciones}")
                Text(
                    "Cargado por ${h.creadoPor.ifBlank { "—" }}" + (if (h.modificadoPor.isNotBlank()) " · modificado por ${h.modificadoPor}" else ""),
                    style = MaterialTheme.typography.labelSmall
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (h.telefono.isNotBlank()) BotonSec({
                        ctx.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + h.telefono.filter { it.isDigit() || it == '+' })))
                    }, Modifier.weight(1f)) { Text("📞 Llamar", maxLines = 1) }
                    val wa = h.whatsapp.ifBlank { h.telefono }.filter { it.isDigit() }
                    if (wa.length >= 8) BotonSec({
                        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + (if (wa.startsWith("54")) wa else "549$wa"))))
                    }, Modifier.weight(1f)) { Text("💬 WhatsApp", maxLines = 1) }
                }
                val la = h.lat; val lo = h.lng
                if (la != null && lo != null) BotonSec({ abrirEnGoogleMaps(ctx, la, lo) }, Modifier.fillMaxWidth()) { Text("🗺️ Cómo llegar") }

                Divider(Modifier.padding(vertical = 6.dp))
                Text("Experiencias (${ops.size})", style = MaterialTheme.typography.titleSmall)
                ops.forEach { o ->
                    Text("${"★".repeat(o.estrellas)}${"☆".repeat(5 - o.estrellas)} " + (if (o.recomendado) "👍 Recomendado" else "👎 No recomendado") +
                        " · ${o.autor}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                    if (o.texto.isNotBlank()) Text(o.texto, style = MaterialTheme.typography.bodySmall)
                }
                BotonSec({ opinando = true }, Modifier.fillMaxWidth()) { Text("⭐ Contar mi experiencia") }

                if (admin) {
                    Divider(Modifier.padding(vertical = 6.dp))
                    Text("Administrador", style = MaterialTheme.typography.titleSmall)
                    if (duplicadoDe != null) {
                        Text("⚠️ Puede ser el mismo que \"${duplicadoDe.nombre}\" (${duplicadoDe.localidad}).", color = Ambar)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            BotonSec({
                                scope.launch { onAccion(HotelesSync.admin(ctx, JSONObject().put("tipo", "hotel_unir").put("de", h.uid).put("en", duplicadoDe.uid))) }
                            }, Modifier.weight(1f)) { Text("Unir", maxLines = 1) }
                            BotonSec({
                                scope.launch { onAccion(HotelesSync.admin(ctx, JSONObject().put("tipo", "hotel_distintos").put("uid", h.uid))) }
                            }, Modifier.weight(1f)) { Text("Son distintos", maxLines = 1) }
                        }
                    }
                    TextButton({ confirmarBorrar = true }) { Text("🗑️ Borrar definitivamente", color = MaterialTheme.colorScheme.error) }
                }
            }
        },
        confirmButton = { TextButton(onEditar) { Text("✏️ Completar / corregir") } },
        dismissButton = { TextButton(onDismiss) { Text("Cerrar") } }
    )
    if (opinando) OpinionForm(h, onDismiss = { opinando = false }) { o ->
        opinando = false
        scope.launch {
            HotelesDb.get(ctx).dao().guardarOpinion(o)
            onAccion(null)
        }
    }
    if (confirmarBorrar) AlertDialog(
        onDismissRequest = { confirmarBorrar = false },
        title = { Text("¿Borrar \"${h.nombre}\" para todos?") },
        text = { Text("Se borra de todos los celulares. No se puede deshacer.") },
        confirmButton = {
            TextButton({
                confirmarBorrar = false
                scope.launch { onAccion(HotelesSync.admin(ctx, JSONObject().put("tipo", "hotel_borrar").put("uid", h.uid))) }
            }) { Text("Borrar") }
        },
        dismissButton = { TextButton({ confirmarBorrar = false }) { Text("Cancelar") } }
    )
}

@Composable
private fun OpinionForm(h: Hotel, onDismiss: () -> Unit, onOk: (Opinion) -> Unit) {
    val ctx = LocalContext.current
    var estrellas by remember { mutableStateOf(5) }
    var rec by remember { mutableStateOf(true) }
    var texto by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Tu experiencia en ${h.nombre}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row { (1..5).forEach { i -> TextButton({ estrellas = i }) { Text(if (i <= estrellas) "★" else "☆", style = MaterialTheme.typography.headlineSmall, color = Ambar) } } }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(rec, { rec = true }, label = { Text("👍 Recomendado") })
                    FilterChip(!rec, { rec = false }, label = { Text("👎 No recomendado") })
                }
                OutlinedTextField(texto, { texto = it }, Modifier.fillMaxWidth(), label = { Text("Comentario (opcional)") })
            }
        },
        confirmButton = {
            TextButton({ onOk(Opinion(hotelUid = h.uid, autor = Perfiles.activo(ctx).nombre, estrellas = estrellas, recomendado = rec, texto = texto.trim())) }) { Text("Guardar") }
        },
        dismissButton = { TextButton(onDismiss) { Text("Cancelar") } }
    )
}

@Composable
private fun HotelForm(h: Hotel, todos: List<Hotel>, onDismiss: () -> Unit, onOk: (Hotel) -> Unit) {
    val ctx = LocalContext.current
    val quien = remember { Perfiles.activo(ctx).nombre }
    var x by remember { mutableStateOf(h) }
    var eligiendoLugar by remember { mutableStateOf(false) }
    var coincidencia by remember { mutableStateOf<Pair<Hotel, Antiduplicados.Coincidencia>?>(null) }
    val nuevo = todos.none { it.uid == h.uid }

    fun guardar(listo: Hotel) = onOk(
        listo.copy(
            creadoPor = listo.creadoPor.ifBlank { quien },
            modificadoPor = if (nuevo) listo.modificadoPor else quien,
            editado = System.currentTimeMillis(), pendiente = true
        )
    )

    @Composable
    fun campo(v: String, et: String, tel: Boolean = false, on: (String) -> Unit) = OutlinedTextField(
        v, on, Modifier.fillMaxWidth(), label = { Text(et) }, singleLine = true,
        keyboardOptions = if (tel) KeyboardOptions(keyboardType = KeyboardType.Phone) else KeyboardOptions.Default
    )

    @Composable
    fun tilde(v: Boolean, et: String, on: (Boolean) -> Unit) = Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { on(!v) }) {
        Checkbox(v, on); Text(et)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (nuevo) "Nuevo hotel" else "Completar / corregir") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                campo(x.nombre, "Nombre") { x = x.copy(nombre = it) }
                BotonSec({ eligiendoLugar = true }, Modifier.fillMaxWidth()) {
                    Text(if (x.lat != null) "📍 Ubicación cargada (cambiar)" else "📍 Elegir la ubicación", maxLines = 1)
                }
                campo(x.direccion, "Dirección") { x = x.copy(direccion = it) }
                campo(x.localidad, "Localidad") { x = x.copy(localidad = it) }
                campo(x.provincia, "Provincia") { x = x.copy(provincia = it) }
                campo(x.telefono, "Teléfono", tel = true) { x = x.copy(telefono = it) }
                campo(x.whatsapp, "WhatsApp (si es otro número)", tel = true) { x = x.copy(whatsapp = it) }
                campo(x.precio, "Precio orientativo") { x = x.copy(precio = it) }
                tilde(x.accesoCamion, "Acceso para camiones") { x = x.copy(accesoCamion = it) }
                tilde(x.accesoAcoplado, "Acceso con acoplado") { x = x.copy(accesoAcoplado = it) }
                tilde(x.cochera, "Cochera") { x = x.copy(cochera = it) }
                tilde(x.cocheraCerrada, "Cochera cerrada") { x = x.copy(cocheraCerrada = it) }
                tilde(x.vigilancia, "Vigilancia") { x = x.copy(vigilancia = it) }
                tilde(x.restaurante, "Restaurante") { x = x.copy(restaurante = it) }
                tilde(x.banoDucha, "Baño y ducha") { x = x.copy(banoDucha = it) }
                campo(x.estacionamiento, "Estacionamiento: precio y condiciones") { x = x.copy(estacionamiento = it) }
                campo(x.seguridad, "Seguridad") { x = x.copy(seguridad = it) }
                campo(x.observaciones, "Observaciones") { x = x.copy(observaciones = it) }
            }
        },
        confirmButton = {
            TextButton({
                val c = if (nuevo) Antiduplicados.buscar(x, todos) else null
                if (c != null) coincidencia = c else guardar(x)
            }, enabled = x.nombre.isNotBlank()) { Text("Guardar") }
        },
        dismissButton = { TextButton(onDismiss) { Text("Cancelar") } }
    )
    if (eligiendoLugar) SelectorUbicacion("Ubicación del hotel", onDismiss = { eligiendoLugar = false }) { txt, la, lo ->
        x = x.copy(lat = la, lng = lo, direccion = x.direccion.ifBlank { txt })
        eligiendoLugar = false
    }
    coincidencia?.let { (ex, tipo) ->
        AlertDialog(
            onDismissRequest = { coincidencia = null },
            title = { Text(if (tipo == Antiduplicados.Coincidencia.SEGURA) "Este hotel ya está cargado" else "¿Es el mismo hotel?") },
            text = {
                Text(
                    "\"${ex.nombre}\"" + (if (ex.localidad.isNotBlank()) " en ${ex.localidad}" else "") +
                        (if (ex.telefono.isNotBlank()) " · ${ex.telefono}" else "") +
                        "\n\nNo se crea otro: se completan los datos que le falten con lo que escribiste."
                )
            },
            confirmButton = {
                TextButton({ coincidencia = null; guardar(Antiduplicados.completar(ex, x, quien)) }) { Text("Completar el existente") }
            },
            dismissButton = {
                if (tipo == Antiduplicados.Coincidencia.PROBABLE) TextButton({ coincidencia = null; guardar(x) }) { Text("Es otro distinto") }
                else TextButton({ coincidencia = null }) { Text("Volver") }
            }
        )
    }
}
