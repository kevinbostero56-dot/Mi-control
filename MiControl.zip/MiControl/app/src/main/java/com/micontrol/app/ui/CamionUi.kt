package com.micontrol.app.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.micontrol.app.data.*
import com.micontrol.app.domain.Avisos
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

private val fechaUi = DateTimeFormatter.ofPattern("dd/MM/yyyy")
private fun km(n: Long) = "%,d".format(Locale("es", "AR"), n)

@Composable
private fun CampoC(valor: String, onChange: (String) -> Unit, etiqueta: String, numerico: Boolean = false) {
    OutlinedTextField(
        valor, onChange, Modifier.fillMaxWidth(), label = { Text(etiqueta) }, shape = RoundedCornerShape(14.dp),
        keyboardOptions = KeyboardOptions(keyboardType = if (numerico) KeyboardType.Number else KeyboardType.Text)
    )
}

/** Control del camión: mantenimiento por kilómetros y vencimientos con fecha. */
@Composable
fun CamionScreen(vm: MainViewModel, nav: NavController) {
    val viajes by vm.viajes.collectAsStateWithLifecycle()
    val mants by vm.mantenimientos.collectAsStateWithLifecycle()
    val venc by vm.vencimientos.collectAsStateWithLifecycle()
    val perfil by vm.perfil.collectAsStateWithLifecycle()
    val odo = Avisos.odometroActual(viajes)
    val hoy = LocalDate.now()
    var editM by remember { mutableStateOf<Mantenimiento?>(null) }
    var editV by remember { mutableStateOf<Vencimiento?>(null) }

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Control del camión", style = MaterialTheme.typography.headlineSmall)
        val detalle = listOf(perfil.camion, perfil.empresa).filter { it.isNotBlank() }.joinToString(" · ")
        if (detalle.isNotBlank()) Text(detalle, style = MaterialTheme.typography.bodySmall)
        Text(
            if (odo != null) "Odómetro actual: ${km(odo)} km (el último que cargaste en un viaje)"
            else "Todavía no hay viajes: cuando cargues el odómetro de un viaje, acá se calculan los kilómetros.",
            style = MaterialTheme.typography.bodyMedium
        )

        // ---------- Mantenimiento ----------
        Seccion("🔧 Mantenimiento por kilómetros")
        if (mants.isEmpty()) {
            Text("Agregá lo que hay que hacerle al camión cada cierta cantidad de km (aceite, cubiertas, frenos…) y la app te avisa cuando se acerca.", style = MaterialTheme.typography.bodySmall)
        }
        mants.forEach { m ->
            val resta = odo?.let { Avisos.kmRestantes(m, it) }
            val progreso = if (odo != null && m.cadaKm > 0) ((odo - m.ultimoKm).toFloat() / m.cadaKm).coerceIn(0f, 1f) else 0f
            val color = when {
                resta == null -> MaterialTheme.colorScheme.onSurfaceVariant
                resta <= 0 -> MaterialTheme.colorScheme.error
                resta <= maxOf(500L, m.cadaKm / 10) -> Ambar
                else -> Verde
            }
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(m.tipo, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Text("Cada ${km(m.cadaKm)} km · último a los ${km(m.ultimoKm)} km" +
                        (m.ultimaFecha?.let { f -> runCatching { " (" + LocalDate.parse(f).format(fechaUi) + ")" }.getOrDefault("") } ?: ""),
                        style = MaterialTheme.typography.bodySmall)
                    if (resta != null) {
                        Text(
                            if (resta > 0) "Faltan ${km(resta)} km" else "Te pasaste ${km(-resta)} km",
                            color = color, fontWeight = FontWeight.Bold
                        )
                        LinearProgressIndicator(progress = progreso, modifier = Modifier.fillMaxWidth(), color = color)
                    }
                    if (m.nota.isNotBlank()) Text(m.nota, style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        BotonP({
                            if (odo != null) vm.guardarMantenimiento(m.copy(ultimoKm = odo, ultimaFecha = hoy.toString()))
                        }, Modifier.weight(1f), enabled = odo != null) { Text("Lo hice hoy") }
                        BotonSec({ editM = m }, Modifier.weight(1f)) { Text("Editar") }
                    }
                }
            }
        }
        BotonSec({
            editM = Mantenimiento(tipo = "", cadaKm = 10000, ultimoKm = odo ?: 0L)
        }, Modifier.fillMaxWidth()) { Text("＋ Agregar mantenimiento") }

        // ---------- Vencimientos ----------
        Seccion("📅 Vencimientos")
        if (venc.isEmpty()) {
            Text("Cargá VTV, seguro, licencia y lo que venza: la app te avisa antes de que se pasen.", style = MaterialTheme.typography.bodySmall)
        }
        venc.forEach { v ->
            val d = Avisos.diasPara(v, hoy)
            val color = when {
                d == null -> MaterialTheme.colorScheme.onSurfaceVariant
                d < 0 -> MaterialTheme.colorScheme.error
                d <= 7 -> MaterialTheme.colorScheme.error
                d <= v.avisarDias -> Ambar
                else -> Verde
            }
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(v.nombre, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Text(runCatching { LocalDate.parse(v.fecha).format(fechaUi) }.getOrDefault(v.fecha), style = MaterialTheme.typography.bodySmall)
                        Text(
                            when {
                                d == null -> "Fecha no válida"
                                d < 0 -> "Venció hace ${-d} días"
                                d == 0L -> "Vence HOY"
                                else -> "Faltan $d días"
                            },
                            color = color, fontWeight = FontWeight.Bold
                        )
                        if (v.nota.isNotBlank()) Text(v.nota, style = MaterialTheme.typography.bodySmall)
                    }
                    TextButton({ editV = v }) { Text("Editar") }
                }
            }
        }
        BotonSec({
            editV = Vencimiento(nombre = "", fecha = hoy.plusMonths(6).toString())
        }, Modifier.fillMaxWidth()) { Text("＋ Agregar vencimiento") }

        Text(
            "Los avisos importantes aparecen en Inicio y, si los permitís, también como notificación del teléfono.",
            style = MaterialTheme.typography.bodySmall
        )
        TextButton({ nav.popBackStack() }) { Text("Volver") }
    }

    editM?.let { m ->
        DialogoMantenimiento(m, odo, onDismiss = { editM = null },
            onBorrar = { vm.borrarMantenimiento(m); editM = null }) { vm.guardarMantenimiento(it); editM = null }
    }
    editV?.let { v ->
        DialogoVencimiento(v, onDismiss = { editV = null },
            onBorrar = { vm.borrarVencimiento(v); editV = null }) { vm.guardarVencimiento(it); editV = null }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DialogoMantenimiento(m: Mantenimiento, odo: Long?, onDismiss: () -> Unit, onBorrar: () -> Unit, onOk: (Mantenimiento) -> Unit) {
    var tipo by remember { mutableStateOf(m.tipo) }
    var cada by remember { mutableStateOf(m.cadaKm.toString()) }
    var ultimo by remember { mutableStateOf(m.ultimoKm.toString()) }
    var nota by remember { mutableStateOf(m.nota) }
    val cadaN = cada.toLongOrNull()
    val ultimoN = ultimo.toLongOrNull()
    val valido = tipo.isNotBlank() && cadaN != null && cadaN > 0 && ultimoN != null
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (m.id == 0L) "Nuevo mantenimiento" else "Editar mantenimiento") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TIPOS_MANTENIMIENTO.filter { it != "Otro" }.forEach { t -> FilterChip(tipo == t, { tipo = t }, label = { Text(t) }) }
                }
                CampoC(tipo, { tipo = it }, "Qué es")
                CampoC(cada, { cada = it.filter(Char::isDigit) }, "Se hace cada (km)", numerico = true)
                CampoC(ultimo, { ultimo = it.filter(Char::isDigit) }, "Odómetro cuando se hizo la última vez", numerico = true)
                if (odo != null) Text("Odómetro actual: ${km(odo)} km", style = MaterialTheme.typography.bodySmall)
                CampoC(nota, { nota = it }, "Nota (taller, marca de aceite…)")
            }
        },
        confirmButton = {
            TextButton({ onOk(m.copy(tipo = tipo.trim(), cadaKm = cadaN!!, ultimoKm = ultimoN!!, nota = nota.trim())) }, enabled = valido) { Text("Guardar") }
        },
        dismissButton = { Row { if (m.id != 0L) TextButton(onBorrar) { Text("Borrar") }; TextButton(onDismiss) { Text("Cancelar") } } }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DialogoVencimiento(v: Vencimiento, onDismiss: () -> Unit, onBorrar: () -> Unit, onOk: (Vencimiento) -> Unit) {
    var nombre by remember { mutableStateOf(v.nombre) }
    var fecha by remember { mutableStateOf(runCatching { LocalDate.parse(v.fecha).format(fechaUi) }.getOrDefault(v.fecha)) }
    var avisar by remember { mutableStateOf(v.avisarDias.toString()) }
    var nota by remember { mutableStateOf(v.nota) }
    val f = runCatching { LocalDate.parse(fecha.trim(), fechaUi) }.getOrNull()
    val a = avisar.toIntOrNull()
    val valido = nombre.isNotBlank() && f != null && a != null
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (v.id == 0L) "Nuevo vencimiento" else "Editar vencimiento") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TIPOS_VENCIMIENTO.filter { it != "Otro" }.forEach { t -> FilterChip(nombre == t, { nombre = t }, label = { Text(t) }) }
                }
                CampoC(nombre, { nombre = it }, "Qué vence")
                CampoC(fecha, { fecha = it }, "Fecha de vencimiento (dd/mm/aaaa)")
                if (f == null) Text("Escribí la fecha así: 15/03/2027", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                CampoC(avisar, { avisar = it.filter(Char::isDigit) }, "Avisarme con cuántos días de anticipación", numerico = true)
                CampoC(nota, { nota = it }, "Nota (número de póliza, etc.)")
            }
        },
        confirmButton = {
            TextButton({ onOk(v.copy(nombre = nombre.trim(), fecha = f.toString(), avisarDias = a!!, nota = nota.trim())) }, enabled = valido) { Text("Guardar") }
        },
        dismissButton = { Row { if (v.id != 0L) TextButton(onBorrar) { Text("Borrar") }; TextButton(onDismiss) { Text("Cancelar") } } }
    )
}
