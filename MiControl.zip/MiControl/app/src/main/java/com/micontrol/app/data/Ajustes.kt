package com.micontrol.app.data

import android.content.Context
import com.micontrol.app.BuildConfig

/** Ajustes guardados en el teléfono. */
object Ajustes {
    private fun p(ctx: Context) = ctx.getSharedPreferences("ajustes", Context.MODE_PRIVATE)

    /** Clave que cargó la persona (opcional). */
    fun claveMapTilerPropia(ctx: Context): String = p(ctx).getString("maptiler", "")?.trim() ?: ""
    fun guardarClaveMapTiler(ctx: Context, v: String) { p(ctx).edit().putString("maptiler", v.trim()).apply() }
    /** La propia si la hay; si no, la que viene incluida en la app. */
    fun claveMapTiler(ctx: Context): String = claveMapTilerPropia(ctx).ifBlank { BuildConfig.MAPTILER_KEY }

    fun claveOrsPropia(ctx: Context): String = p(ctx).getString("ors", "")?.trim() ?: ""
    fun guardarClaveOrs(ctx: Context, v: String) { p(ctx).edit().putString("ors", v.trim()).apply() }
    fun claveOrs(ctx: Context): String = claveOrsPropia(ctx).ifBlank { BuildConfig.ORS_KEY }

    /** Medidas del camión en metros. */
    /** Las medidas son de cada perfil (el principal usa las de siempre). */
    private fun clavePerfil(ctx: Context, base: String): String {
        val id = Perfiles.activoId(ctx)
        return if (id == Perfiles.PRINCIPAL) base else "${base}_$id"
    }
    fun alturaCamion(ctx: Context): Double = p(ctx).getFloat(clavePerfil(ctx, "alto"), 4.0f).toDouble()
    fun largoCamion(ctx: Context): Double = p(ctx).getFloat(clavePerfil(ctx, "largo"), 7.0f).toDouble()
    /** Peso total del camión en toneladas (0 = no restringir por peso). */
    fun pesoCamion(ctx: Context): Double = p(ctx).getFloat(clavePerfil(ctx, "peso"), 8f).toDouble()
    /** Velocidad máxima del camión cargado, en km/h. */
    fun velocidadMaxima(ctx: Context): Double = p(ctx).getFloat(clavePerfil(ctx, "vel_max"), 80f).toDouble()
    fun guardarVelocidad(ctx: Context, kmh: Double) { p(ctx).edit().putFloat(clavePerfil(ctx, "vel_max"), kmh.toFloat()).apply() }
    fun guardarPeso(ctx: Context, tn: Double) { p(ctx).edit().putFloat(clavePerfil(ctx, "peso"), tn.toFloat()).apply() }
    fun guardarCamion(ctx: Context, alto: Double, largo: Double) {
        p(ctx).edit().putFloat(clavePerfil(ctx, "alto"), alto.toFloat()).putFloat(clavePerfil(ctx, "largo"), largo.toFloat()).apply()
    }

    /** "auto" (como el teléfono), "claro" u "oscuro". */
    fun modoMapa(ctx: Context): String = p(ctx).getString("modo_mapa", "auto") ?: "auto"
    fun guardarModoMapa(ctx: Context, v: String) { p(ctx).edit().putString("modo_mapa", v).apply() }

    fun ultimaBusqueda(ctx: Context): Long = p(ctx).getLong("ult_busqueda", 0L)
    fun marcarBusqueda(ctx: Context) { p(ctx).edit().putLong("ult_busqueda", System.currentTimeMillis()).apply() }

    // ---- Copia de seguridad automática y avisos
    fun copiaAuto(ctx: Context): Boolean = p(ctx).getBoolean("copia_auto", true)
    fun guardarCopiaAuto(ctx: Context, v: Boolean) { p(ctx).edit().putBoolean("copia_auto", v).apply() }
    fun ultimaCopia(ctx: Context, perfilId: String): Long = p(ctx).getLong("ult_copia_$perfilId", 0L)
    fun marcarCopia(ctx: Context, perfilId: String) { p(ctx).edit().putLong("ult_copia_$perfilId", System.currentTimeMillis()).apply() }

    fun avisosActivos(ctx: Context): Boolean = p(ctx).getBoolean("avisos", true)
    fun guardarAvisosActivos(ctx: Context, v: Boolean) { p(ctx).edit().putBoolean("avisos", v).apply() }
    fun ultimoAviso(ctx: Context): Long = p(ctx).getLong("ult_aviso", 0L)
    fun marcarAviso(ctx: Context) { p(ctx).edit().putLong("ult_aviso", System.currentTimeMillis()).apply() }

    // ---- Bloqueo con PIN (se guarda solo un resumen del PIN, nunca el número)
    private fun resumenPin(pin: String, sal: String): String {
        val b = java.security.MessageDigest.getInstance("SHA-256").digest((sal + pin).toByteArray(Charsets.UTF_8))
        return b.joinToString("") { "%02x".format(it) }
    }
    fun hayPin(ctx: Context): Boolean = !p(ctx).getString("pin_hash", null).isNullOrBlank()
    fun fijarPin(ctx: Context, pin: String) {
        val sal = java.util.UUID.randomUUID().toString()
        p(ctx).edit().putString("pin_sal", sal).putString("pin_hash", resumenPin(pin, sal)).apply()
    }
    fun quitarPin(ctx: Context) { p(ctx).edit().remove("pin_sal").remove("pin_hash").apply() }
    fun pinCorrecto(ctx: Context, pin: String): Boolean {
        val sal = p(ctx).getString("pin_sal", "") ?: ""
        return resumenPin(pin, sal) == p(ctx).getString("pin_hash", "")
    }

    // Después de 5 PIN incorrectos seguidos, la app se frena un rato (30 s, 1 min, 2 min… hasta 15 min)
    fun pinBloqueadoHasta(ctx: Context): Long = p(ctx).getLong("pin_hasta", 0L)
    fun registrarFalloPin(ctx: Context): Long {
        val n = p(ctx).getInt("pin_fallos", 0) + 1
        var hasta = 0L
        if (n >= 5) {
            val segundos = minOf(30L shl (n - 5).coerceAtMost(5), 900L)
            hasta = System.currentTimeMillis() + segundos * 1000L
        }
        p(ctx).edit().putInt("pin_fallos", n).putLong("pin_hasta", hasta).apply()
        return hasta
    }
    fun pinAcertado(ctx: Context) { p(ctx).edit().remove("pin_fallos").remove("pin_hasta").apply() }

    // ---- Novedades y permisos pedidos una vez
    fun versionVista(ctx: Context): Int = p(ctx).getInt("version_vista", 0)
    fun marcarVersionVista(ctx: Context, v: Int) { p(ctx).edit().putInt("version_vista", v).apply() }
    fun notifPedido(ctx: Context): Boolean = p(ctx).getBoolean("notif_pedido", false)
    fun marcarNotifPedido(ctx: Context) { p(ctx).edit().putBoolean("notif_pedido", true).apply() }
}
