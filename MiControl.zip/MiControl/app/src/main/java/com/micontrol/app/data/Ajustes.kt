package com.micontrol.app.data

import android.content.Context

/** Ajustes guardados en el teléfono. */
object Ajustes {
    private fun p(ctx: Context) = ctx.getSharedPreferences("ajustes", Context.MODE_PRIVATE)

    fun claveMapTiler(ctx: Context): String = p(ctx).getString("maptiler", "")?.trim() ?: ""
    fun guardarClaveMapTiler(ctx: Context, v: String) { p(ctx).edit().putString("maptiler", v.trim()).apply() }

    fun claveOrs(ctx: Context): String = p(ctx).getString("ors", "")?.trim() ?: ""
    fun guardarClaveOrs(ctx: Context, v: String) { p(ctx).edit().putString("ors", v.trim()).apply() }

    /** Medidas del camión en metros. */
    fun alturaCamion(ctx: Context): Double = p(ctx).getFloat("alto", 4.0f).toDouble()
    fun largoCamion(ctx: Context): Double = p(ctx).getFloat("largo", 7.0f).toDouble()
    fun guardarCamion(ctx: Context, alto: Double, largo: Double) {
        p(ctx).edit().putFloat("alto", alto.toFloat()).putFloat("largo", largo.toFloat()).apply()
    }
}
