package com.micontrol.app.data

import android.content.Context

/** Ajustes guardados en el teléfono. */
object Ajustes {
    private fun p(ctx: Context) = ctx.getSharedPreferences("ajustes", Context.MODE_PRIVATE)

    fun claveMapTiler(ctx: Context): String = p(ctx).getString("maptiler", "")?.trim() ?: ""
    fun guardarClaveMapTiler(ctx: Context, v: String) { p(ctx).edit().putString("maptiler", v.trim()).apply() }
}
