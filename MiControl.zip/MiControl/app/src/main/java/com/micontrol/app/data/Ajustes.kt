package com.micontrol.app.data

import android.content.Context
import com.micontrol.app.BuildConfig

/** Ajustes guardados en el teléfono. */
object Ajustes {
    private fun p(ctx: Context) = ctx.getSharedPreferences("ajustes", Context.MODE_PRIVATE)

    /** Clave que cargó la persona (opcional). */
    fun claveMapTilerPropia(ctx: Context): String = p(ctx).getString("maptiler", "")?.trim() ?: ""
    fun guardarClaveMapTiler(ctx: Context, v: String) { p(ctx).edit().putString("maptiler", v.trim()).apply() }
    /** La propia si la hay; si no, la que viene incluida en la app. */
    fun claveMapTiler(ctx: Context): String = claveMapTilerPropia(ctx).ifBlank { BuildConfig.MAPTILER_KEY }

    fun claveOrsPropia(ctx: Context): String = p(ctx).getString("ors", "")?.trim() ?: ""
    fun guardarClaveOrs(ctx: Context, v: String) { p(ctx).edit().putString("ors", v.trim()).apply() }
    fun claveOrs(ctx: Context): String = claveOrsPropia(ctx).ifBlank { BuildConfig.ORS_KEY }

    /** Medidas del camión en metros. */
    fun alturaCamion(ctx: Context): Double = p(ctx).getFloat("alto", 4.0f).toDouble()
    fun largoCamion(ctx: Context): Double = p(ctx).getFloat("largo", 7.0f).toDouble()
    fun guardarCamion(ctx: Context, alto: Double, largo: Double) {
        p(ctx).edit().putFloat("alto", alto.toFloat()).putFloat("largo", largo.toFloat()).apply()
    }

    /** "auto" (como el teléfono), "claro" u "oscuro". */
    fun modoMapa(ctx: Context): String = p(ctx).getString("modo_mapa", "auto") ?: "auto"
    fun guardarModoMapa(ctx: Context, v: String) { p(ctx).edit().putString("modo_mapa", v).apply() }

    fun ultimaBusqueda(ctx: Context): Long = p(ctx).getLong("ult_busqueda", 0L)
    fun marcarBusqueda(ctx: Context) { p(ctx).edit().putLong("ult_busqueda", System.currentTimeMillis()).apply() }
}
