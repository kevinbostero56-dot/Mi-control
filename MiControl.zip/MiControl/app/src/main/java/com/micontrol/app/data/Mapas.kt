package com.micontrol.app.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File
import java.io.FileOutputStream

/** Imagen guardada del mapa con el recorrido de cada viaje (se puede ver sin internet). */
object Mapas {
    fun archivo(ctx: Context, viajeId: String): File =
        File(File(ctx.filesDir, "mapas").apply { mkdirs() }, "$viajeId.png")

    fun existe(ctx: Context, viajeId: String) = archivo(ctx, viajeId).exists()

    fun guardar(ctx: Context, viajeId: String, bmp: Bitmap) {
        FileOutputStream(archivo(ctx, viajeId)).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
    }

    fun cargar(ctx: Context, viajeId: String): Bitmap? {
        val f = archivo(ctx, viajeId)
        return if (f.exists()) BitmapFactory.decodeFile(f.absolutePath) else null
    }
}
