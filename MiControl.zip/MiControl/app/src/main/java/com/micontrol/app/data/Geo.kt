package com.micontrol.app.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Búsqueda de direcciones con OpenStreetMap (Nominatim). Requiere internet. */
object Geo {
    data class Lugar(val nombre: String, val lat: Double, val lng: Double)

    private fun get(url: String): String? = try {
        val c = URL(url).openConnection() as HttpURLConnection
        c.setRequestProperty("User-Agent", "MiControl/0.2")
        c.connectTimeout = 8000
        c.readTimeout = 8000
        c.inputStream.bufferedReader().use { it.readText() }
    } catch (e: Exception) {
        null
    }

    suspend fun buscar(consulta: String): List<Lugar> = withContext(Dispatchers.IO) {
        val q = URLEncoder.encode(consulta, "UTF-8")
        val r = get("https://nominatim.openstreetmap.org/search?format=json&limit=5&countrycodes=ar&q=$q")
            ?: return@withContext emptyList<Lugar>()
        runCatching {
            val a = JSONArray(r)
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                Lugar(o.getString("display_name"), o.getString("lat").toDouble(), o.getString("lon").toDouble())
            }
        }.getOrDefault(emptyList())
    }

    /** Busca un lugar por su nombre o dirección (MapTiler si hay clave; si no, OpenStreetMap). */
    suspend fun geocodificar(consulta: String, claveMapTiler: String): Lugar? = withContext(Dispatchers.IO) {
        if (claveMapTiler.isNotBlank()) {
            val q = URLEncoder.encode(consulta, "UTF-8").replace("+", "%20")
            val r = get("https://api.maptiler.com/geocoding/$q.json?key=$claveMapTiler&limit=1&country=ar&language=es")
            val lugar = r?.let {
                runCatching {
                    val f = JSONObject(it).getJSONArray("features").getJSONObject(0)
                    val c = f.getJSONArray("center")
                    Lugar(f.optString("place_name", consulta), c.getDouble(1), c.getDouble(0))
                }.getOrNull()
            }
            if (lugar != null) return@withContext lugar
        }
        buscar(consulta).firstOrNull()
    }

    suspend fun direccion(lat: Double, lng: Double): String? = withContext(Dispatchers.IO) {
        get("https://nominatim.openstreetmap.org/reverse?format=json&lat=$lat&lon=$lng")?.let {
            runCatching { JSONObject(it).getString("display_name") }.getOrNull()
        }
    }
}
