package com.micontrol.app.data

import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [Cliente::class, Viaje::class, Jornada::class, Gasto::class, PuntoGps::class, Parada::class, Adelanto::class],
    version = 4,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun clienteDao(): ClienteDao
    abstract fun viajeDao(): ViajeDao
    abstract fun jornadaDao(): JornadaDao
    abstract fun gastoDao(): GastoDao
    abstract fun puntoDao(): PuntoDao
    abstract fun paradaDao(): ParadaDao
    abstract fun adelantoDao(): AdelantoDao

    companion object {
        private val MIGRACION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE viajes ADD COLUMN origenLat REAL")
                db.execSQL("ALTER TABLE viajes ADD COLUMN origenLng REAL")
                db.execSQL("ALTER TABLE viajes ADD COLUMN destinoLat REAL")
                db.execSQL("ALTER TABLE viajes ADD COLUMN destinoLng REAL")
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `puntos_gps` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`viajeId` TEXT NOT NULL, `lat` REAL NOT NULL, `lng` REAL NOT NULL, " +
                        "`precisionM` REAL NOT NULL, `tiempo` INTEGER NOT NULL, " +
                        "FOREIGN KEY(`viajeId`) REFERENCES `viajes`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )"
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_puntos_gps_viajeId` ON `puntos_gps` (`viajeId`)")
            }
        }

        private val MIGRACION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE clientes ADD COLUMN direccion TEXT")
                db.execSQL("ALTER TABLE clientes ADD COLUMN lat REAL")
                db.execSQL("ALTER TABLE clientes ADD COLUMN lng REAL")
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `paradas` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`viajeId` TEXT NOT NULL, `orden` INTEGER NOT NULL, `nombre` TEXT NOT NULL, " +
                        "`lat` REAL NOT NULL, `lng` REAL NOT NULL, " +
                        "FOREIGN KEY(`viajeId`) REFERENCES `viajes`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )"
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_paradas_viajeId` ON `paradas` (`viajeId`)")
            }
        }

        private val MIGRACION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE gastos ADD COLUMN fotoPath TEXT")
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `adelantos` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`viajeId` TEXT NOT NULL, `fechaHora` INTEGER NOT NULL, `importeCentavos` INTEGER NOT NULL, " +
                        "`descripcion` TEXT NOT NULL, " +
                        "FOREIGN KEY(`viajeId`) REFERENCES `viajes`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )"
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_adelantos_viajeId` ON `adelantos` (`viajeId`)")
            }
        }

        @Volatile private var inst: AppDatabase? = null
        fun get(ctx: Context): AppDatabase = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(ctx.applicationContext, AppDatabase::class.java, "micontrol.db")
                .addMigrations(MIGRACION_1_2, MIGRACION_2_3, MIGRACION_3_4)
                .build().also { inst = it }
        }
    }
}
