package com.micontrol.app.data

import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [Cliente::class, Viaje::class, Jornada::class, Gasto::class, PuntoGps::class, Parada::class, Adelanto::class],
    version = 5,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun clienteDao(): ClienteDao
    abstract fun viajeDao(): ViajeDao
    abstract fun jornadaDao(): JornadaDao
    abstract fun gastoDao(): GastoDao
    abstract fun puntoDao(): PuntoDao
    abstract fun paradaDao(): ParadaDao
    abstract fun adelantoDao(): AdelantoDao

    companion object {
        private val MIGRACION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE viajes ADD COLUMN origenLat REAL")
                db.execSQL("ALTER TABLE viajes ADD COLUMN origenLng REAL")
                db.execSQL("ALTER TABLE viajes ADD COLUMN destinoLat REAL")
                db.execSQL("ALTER TABLE viajes ADD COLUMN destinoLng REAL")
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `puntos_gps` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`viajeId` TEXT NOT NULL, `lat` REAL NOT NULL, `lng` REAL NOT NULL, " +
                        "`precisionM` REAL NOT NULL, `tiempo` INTEGER NOT NULL, " +
                        "FOREIGN KEY(`viajeId`) REFERENCES `viajes`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )"
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_puntos_gps_viajeId` ON `puntos_gps` (`viajeId`)")
            }
        }

        private val MIGRACION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE clientes ADD COLUMN direccion TEXT")
                db.execSQL("ALTER TABLE clientes ADD COLUMN lat REAL")
                db.execSQL("ALTER TABLE clientes ADD COLUMN lng REAL")
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `paradas` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`viajeId` TEXT NOT NULL, `orden` INTEGER NOT NULL, `nombre` TEXT NOT NULL, " +
                        "`lat` REAL NOT NULL, `lng` REAL NOT NULL, " +
                        "FOREIGN KEY(`viajeId`) REFERENCES `viajes`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )"
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_paradas_viajeId` ON `paradas` (`viajeId`)")
            }
        }

        private val MIGRACION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE gastos ADD COLUMN fotoPath TEXT")
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `adelantos` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`viajeId` TEXT NOT NULL, `fechaHora` INTEGER NOT NULL, `importeCentavos` INTEGER NOT NULL, " +
                        "`descripcion` TEXT NOT NULL, " +
                        "FOREIGN KEY(`viajeId`) REFERENCES `viajes`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )"
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_adelantos_viajeId` ON `adelantos` (`viajeId`)")
            }
        }

        private val MIGRACION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE gastos ADD COLUMN litros REAL")
            }
        }

        private val instancias = HashMap<String, AppDatabase>()

        /** Archivo de la base de cada perfil. El principal usa el de siempre, así no se pierde nada. */
        fun archivo(perfilId: String): String = if (perfilId == Perfiles.PRINCIPAL) "micontrol.db" else "micontrol_$perfilId.db"

        /** Base del perfil que está en uso. */
        fun get(ctx: Context): AppDatabase = get(ctx, Perfiles.activoId(ctx))

        fun get(ctx: Context, perfilId: String): AppDatabase = synchronized(this) {
            instancias.getOrPut(perfilId) {
                Room.databaseBuilder(ctx.applicationContext, AppDatabase::class.java, archivo(perfilId))
                    .addMigrations(MIGRACION_1_2, MIGRACION_2_3, MIGRACION_3_4, MIGRACION_4_5)
                    .build()
            }
        }

        /** Cierra la base de un perfil (para borrarla o restaurarla). */
        fun cerrar(perfilId: String) {
            synchronized(this) { instancias.remove(perfilId)?.close() }
        }

        fun borrar(ctx: Context, perfilId: String) {
            cerrar(perfilId)
            ctx.applicationContext.deleteDatabase(archivo(perfilId))
        }
    }
}
