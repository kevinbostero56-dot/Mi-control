package com.micontrol.app.data

import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [Cliente::class, Viaje::class, Jornada::class, Gasto::class, PuntoGps::class],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun clienteDao(): ClienteDao
    abstract fun viajeDao(): ViajeDao
    abstract fun jornadaDao(): JornadaDao
    abstract fun gastoDao(): GastoDao
    abstract fun puntoDao(): PuntoDao

    companion object {
        private val MIGRACION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE viajes ADD COLUMN origenLat REAL")
                db.execSQL("ALTER TABLE viajes ADD COLUMN origenLng REAL")
                db.execSQL("ALTER TABLE viajes ADD COLUMN destinoLat REAL")
                db.execSQL("ALTER TABLE viajes ADD COLUMN destinoLng REAL")
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `puntos_gps` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`viajeId` TEXT NOT NULL, `lat` REAL NOT NULL, `lng` REAL NOT NULL, " +
                        "`precisionM` REAL NOT NULL, `tiempo` INTEGER NOT NULL, " +
                        "FOREIGN KEY(`viajeId`) REFERENCES `viajes`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )"
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_puntos_gps_viajeId` ON `puntos_gps` (`viajeId`)")
            }
        }

        @Volatile private var inst: AppDatabase? = null
        fun get(ctx: Context): AppDatabase = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(ctx.applicationContext, AppDatabase::class.java, "micontrol.db")
                .addMigrations(MIGRACION_1_2)
                .build().also { inst = it }
        }
    }
}
