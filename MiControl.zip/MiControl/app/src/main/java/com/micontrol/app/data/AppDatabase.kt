package com.micontrol.app.data

import android.content.Context
import androidx.room.*

@Database(
    entities = [Cliente::class, Viaje::class, Jornada::class, Gasto::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun clienteDao(): ClienteDao
    abstract fun viajeDao(): ViajeDao
    abstract fun jornadaDao(): JornadaDao
    abstract fun gastoDao(): GastoDao

    companion object {
        @Volatile private var inst: AppDatabase? = null
        fun get(ctx: Context): AppDatabase = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(ctx.applicationContext, AppDatabase::class.java, "micontrol.db")
                .build().also { inst = it }
        }
    }
}
