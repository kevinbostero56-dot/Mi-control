package com.micontrol.app.ui

import android.app.Activity
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat

// Colores de la app (rojo y negro)
val Rojo = Color(0xFFE11D2A)
val Fondo = Color(0xFF070708)
val AzulProfundo = Color(0xFF2A0709)   // (nombre histórico) rojo muy oscuro
val AzulMedio = Color(0xFFB4141E)      // (nombre histórico) rojo intenso
val Verde = Color(0xFF16A34A)
val Ambar = Color(0xFFF59E0B)

private val Oscuro = darkColorScheme(
    primary = Rojo, onPrimary = Color.White,
    primaryContainer = Color(0xFF4A0E12), onPrimaryContainer = Color(0xFFFFDAD9),
    secondary = Verde, onSecondary = Color.White,
    secondaryContainer = Color(0xFF3A1014), onSecondaryContainer = Color.White,
    tertiary = Ambar,
    background = Fondo, onBackground = Color(0xFFF2F2F5),
    surface = Color(0xFF121215), onSurface = Color(0xFFF2F2F5),
    surfaceVariant = Color(0xFF1B1B1F), onSurfaceVariant = Color(0xFFD7D7DC),
    outline = Color(0xFF8A2229), error = Color(0xFFFF6B6B), onError = Color(0xFF450A0A)
)

private val Tipografia = Typography(
    headlineLarge = TextStyle(fontWeight = FontWeight.ExtraBold, fontSize = 32.sp, lineHeight = 38.sp),
    headlineSmall = TextStyle(fontWeight = FontWeight.Bold, fontSize = 24.sp, lineHeight = 30.sp),
    titleLarge = TextStyle(fontWeight = FontWeight.Bold, fontSize = 22.sp, lineHeight = 28.sp),
    titleMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 17.sp, lineHeight = 24.sp),
    titleSmall = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 15.sp, lineHeight = 20.sp),
    bodyMedium = TextStyle(fontSize = 15.sp, lineHeight = 21.sp)
)

private val Formas = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp)
)

@Composable
fun MiControlTheme(content: @Composable () -> Unit) {
    val vista = LocalView.current
    if (!vista.isInEditMode) {
        SideEffect {
            val w = (vista.context as Activity).window
            w.statusBarColor = Fondo.toArgb()
            w.navigationBarColor = Fondo.toArgb()
            val c = WindowCompat.getInsetsController(w, vista)
            c.isAppearanceLightStatusBars = false
            c.isAppearanceLightNavigationBars = false
        }
    }
    MaterialTheme(colorScheme = Oscuro, typography = Tipografia, shapes = Formas, content = content)
}

/** Tarjeta oscura con brillo y borde rojo. Reemplaza a la Card normal en toda la app. */
@Composable
fun Card(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val forma = RoundedCornerShape(22.dp)
    Column(
        modifier
            .clip(forma)
            .background(Brush.verticalGradient(listOf(Color(0xFF232327), Color(0xFF0F0F12))), forma)
            .border(1.dp, Brush.linearGradient(listOf(Color(0x66FFFFFF), Color(0x00FFFFFF), Rojo)), forma),
        content = content
    )
}

private val FormaBoton = RoundedCornerShape(16.dp)

@Composable
fun BotonP(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    colors: ButtonColors = ButtonDefaults.buttonColors(),
    content: @Composable RowScope.() -> Unit
) = Button(onClick, modifier, enabled = enabled, shape = FormaBoton, colors = colors, content = content)

@Composable
fun BotonSec(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    content: @Composable RowScope.() -> Unit
) = OutlinedButton(onClick, modifier, enabled = enabled, shape = FormaBoton, content = content)

@Composable
fun Seccion(titulo: String) {
    Text(
        titulo, Modifier.padding(top = 10.dp),
        style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary
    )
}

@Composable
fun EstadoChip(estado: String) {
    val (texto, color) = when (estado) {
        "EN_CURSO" -> "● EN CURSO" to Verde
        "FINALIZADO" -> "FINALIZADO" to Color(0xFF64748B)
        else -> "PENDIENTE" to Ambar
    }
    Surface(color = color, contentColor = Color.White, shape = RoundedCornerShape(50)) {
        Text(texto, Modifier.padding(horizontal = 12.dp, vertical = 4.dp), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
    }
}
