package com.micontrol.app.ui

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val AzulOscuro = Color(0xFF0D2B52)
val Verde = Color(0xFF2E7D32)

@Composable
fun MiControlTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = AzulOscuro, onPrimary = Color.White,
            secondary = Verde, onSecondary = Color.White,
            background = Color(0xFFF5F7FA), surface = Color.White
        ),
        content = content
    )
}
