package com.micontrol.app.ui

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat

val AzulProfundo = Color(0xFF0B1F4D)
val AzulMedio = Color(0xFF2563EB)
val Verde = Color(0xFF16A34A)
val Ambar = Color(0xFFF59E0B)

private val Claro = lightColorScheme(
    primary = Color(0xFF1D4ED8), onPrimary = Color.White,
    primaryContainer = Color(0xFFDBE7FF), onPrimaryContainer = AzulProfundo,
    secondary = Verde, onSecondary = Color.White,
    tertiary = Color(0xFF06B6D4),
    background = Color(0xFFEFF3FA), onBackground = Color(0xFF0F172A),
    surface = Color.White, onSurface = Color(0xFF0F172A),
    surfaceVariant = Color.White, onSurfaceVariant = Color(0xFF334155),
    outline = Color(0xFFCBD5E1), error = Color(0xFFDC2626)
)

private val Oscuro = darkColorScheme(
    primary = Color(0xFF7AA2FF), onPrimary = AzulProfundo,
    primaryContainer = Color(0xFF1E3A8A), onPrimaryContainer = Color(0xFFDBE7FF),
    secondary = Color(0xFF4ADE80), onSecondary = Color(0xFF052E16),
    tertiary = Color(0xFF22D3EE),
    background = Color(0xFF0A101C), onBackground = Color(0xFFE5ECF8),
    surface = Color(0xFF111A2B), onSurface = Color(0xFFE5ECF8),
    surfaceVariant = Color(0xFF182339), onSurfaceVariant = Color(0xFFC3CFE2),
    outline = Color(0xFF334155), error = Color(0xFFF87171), onError = Color(0xFF450A0A)
)

private val Tipografia = Typography(
    headlineLarge = TextStyle(fontWeight = FontWeight.ExtraBold, fontSize = 32.sp, lineHeight = 38.sp),
    headlineSmall = TextStyle(fontWeight = FontWeight.Bold, fontSize = 24.sp, lineHeight = 30.sp),
    titleLarge = TextStyle(fontWeight = FontWeight.Bold, fontSize = 22.sp, lineHeight = 28.sp),
    titleMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 17.sp, lineHeight = 24.sp),
    titleSmall = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 15.sp, lineHeight = 20.sp),
    bodyMedium = TextStyle(fontSize = 15.sp, lineHeight = 21.sp)
)

private val Formas = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp)
)

/** Se ve claro u oscuro según el teléfono (el modo oscuro ayuda a manejar de noche). */
@Composable
fun MiControlTheme(content: @Composable () -> Unit) {
    val oscuro = isSystemInDarkTheme()
    val colores = if (oscuro) Oscuro else Claro
    val vista = LocalView.current
    if (!vista.isInEditMode) {
        SideEffect {
            val w = (vista.context as Activity).window
            w.statusBarColor = colores.background.toArgb()
            w.navigationBarColor = colores.background.toArgb()
            val c = WindowCompat.getInsetsController(w, vista)
            c.isAppearanceLightStatusBars = !oscuro
            c.isAppearanceLightNavigationBars = !oscuro
        }
    }
    MaterialTheme(colorScheme = colores, typography = Tipografia, shapes = Formas, content = content)
}

private val FormaBoton = RoundedCornerShape(16.dp)

@Composable
fun BotonP(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    colors: ButtonColors = ButtonDefaults.buttonColors(),
    content: @Composable RowScope.() -> Unit
) = Button(onClick, modifier, enabled = enabled, shape = FormaBoton, colors = colors, content = content)

@Composable
fun BotonSec(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    content: @Composable RowScope.() -> Unit
) = OutlinedButton(onClick, modifier, enabled = enabled, shape = FormaBoton, content = content)

@Composable
fun Seccion(titulo: String) {
    Text(
        titulo, Modifier.padding(top = 10.dp),
        style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary
    )
}

@Composable
fun EstadoChip(estado: String) {
    val (texto, color) = when (estado) {
        "EN_CURSO" -> "● EN CURSO" to Verde
        "FINALIZADO" -> "FINALIZADO" to Color(0xFF64748B)
        else -> "PENDIENTE" to Ambar
    }
    Surface(color = color, contentColor = Color.White, shape = RoundedCornerShape(50)) {
        Text(texto, Modifier.padding(horizontal = 12.dp, vertical = 4.dp), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
    }
}
