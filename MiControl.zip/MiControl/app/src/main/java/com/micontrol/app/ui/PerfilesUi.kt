package com.micontrol.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.micontrol.app.data.Perfiles
import com.micontrol.app.gps.TrackingService

/** Círculo rojo con la inicial del perfil. */
@Composable
fun Avatar(inicial: String, tam: Dp = 44.dp) {
    Box(Modifier.size(tam).clip(CircleShape).background(Rojo), contentAlignment = Alignment.Center) {
        Text(inicial, color = Color.White, fontWeight = FontWeight.Bold, fontSize = (tam.value * 0.45f).sp)
    }
}

/** Crear un perfil nuevo (perfil == null) o editar uno existente. */
@Composable
fun EditarPerfilDialog(perfil: Perfiles.Perfil?, onDismiss: () -> Unit, onOk: (nombre: String, camion: String, empresa: String) -> Unit) {
    var nombre by remember { mutableStateOf(perfil?.nombre ?: "") }
    var camion by remember { mutableStateOf(perfil?.camion ?: "") }
    var empresa by remember { mutableStateOf(perfil?.empresa ?: "") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (perfil == null) "Nuevo perfil" else "Editar perfil") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (perfil == null) {
                    Text(
                        "Cada perfil tiene sus propios viajes, horas, gastos y clientes. Los datos de los demás perfiles quedan guardados aparte.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                OutlinedTextField(nombre, { nombre = it }, Modifier.fillMaxWidth(), label = { Text("Nombre") }, singleLine = true)
                OutlinedTextField(camion, { camion = it }, Modifier.fillMaxWidth(), label = { Text("Camión (patente o modelo)") }, singleLine = true)
                OutlinedTextField(empresa, { empresa = it }, Modifier.fillMaxWidth(), label = { Text("Empresa") }, singleLine = true)
            }
        },
        confirmButton = {
            TextButton({ onOk(nombre, camion, empresa) }, enabled = nombre.isNotBlank()) { Text("Guardar") }
        },
        dismissButton = { TextButton(onDismiss) { Text("Cancelar") } }
    )
}

/** Lista de perfiles: tocá uno para usarlo, o creá uno nuevo. */
@Composable
fun PerfilesDialog(vm: MainViewModel, onDismiss: () -> Unit) {
    val perfiles by vm.perfiles.collectAsStateWithLifecycle()
    val activo by vm.perfil.collectAsStateWithLifecycle()
    val siguiendo by TrackingService.siguiendo.collectAsStateWithLifecycle()
    var nuevo by remember { mutableStateOf(false) }

    if (nuevo) {
        EditarPerfilDialog(null, onDismiss = { nuevo = false }) { n, c, e ->
            vm.crearPerfil(n, c, e)
            nuevo = false
            onDismiss()
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("¿Quién usa la app?") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                perfiles.forEach { p ->
                    val enUso = p.id == activo.id
                    Card(
                        Modifier.fillMaxWidth().clickable {
                            if (!enUso) vm.cambiarPerfil(p.id)
                            onDismiss()
                        }
                    ) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Avatar(p.inicial, 44.dp)
                            Column(Modifier.weight(1f)) {
                                Text(p.nombre, style = MaterialTheme.typography.titleMedium)
                                val detalle = listOf(p.camion, p.empresa).filter { it.isNotBlank() }.joinToString(" · ")
                                if (detalle.isNotBlank()) Text(detalle, style = MaterialTheme.typography.bodySmall)
                            }
                            if (enUso) Text("En uso", color = Verde, style = MaterialTheme.typography.labelLarge)
                        }
                    }
                }
                if (siguiendo != null) {
                    Text(
                        "Hay un seguimiento GPS activo: se va a detener si cambiás de perfil.",
                        color = Ambar, style = MaterialTheme.typography.bodySmall
                    )
                }
                BotonSec({ nuevo = true }, Modifier.fillMaxWidth()) { Text("＋ Nuevo perfil") }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onDismiss) { Text("Cerrar") } }
    )
}
