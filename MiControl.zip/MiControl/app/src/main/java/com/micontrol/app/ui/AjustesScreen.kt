package com.micontrol.app.ui

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.micontrol.app.BuildConfig
import com.micontrol.app.data.Ajustes
import com.micontrol.app.data.CompartirApp

private fun decimal(s: String): Double? = s.trim().replace(',', '.').toDoubleOrNull()

@Composable
fun AjustesScreen(vm: MainViewModel, nav: NavController) {
    val ctx = LocalContext.current
    var mapa by remember { mutableStateOf(Ajustes.claveMapTilerPropia(ctx)) }
    var ors by remember { mutableStateOf(Ajustes.claveOrsPropia(ctx)) }
    var alto by remember { mutableStateOf("%.2f".format(Ajustes.alturaCamion(ctx)).replace('.', ',')) }
    var largo by remember { mutableStateOf("%.2f".format(Ajustes.largoCamion(ctx)).replace('.', ',')) }
    val altoNum = decimal(alto); val largoNum = decimal(largo)
    val camionOk = altoNum != null && largoNum != null && altoNum in 1.0..6.0 && largoNum in 1.0..30.0

    fun abrir(url: String) = ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Configuración", style = MaterialTheme.typography.headlineSmall)
        Text(
            "Los mapas y las rutas ya vienen listos para usar. Cargá tus propias claves solo si dejan de funcionar por el límite de uso.",
            style = MaterialTheme.typography.bodyMedium
        )

        Text("Mi camión", style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(alto, { alto = it }, Modifier.fillMaxWidth(), label = { Text("Altura (metros)") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
        OutlinedTextField(largo, { largo = it }, Modifier.fillMaxWidth(), label = { Text("Largo (metros)") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
        Text("Conviene poner la altura real más un margen (por ejemplo 4,2).", style = MaterialTheme.typography.bodySmall)
        if (!camionOk) Text("Revisá las medidas.", color = MaterialTheme.colorScheme.error)

        Text("Rutas para camión", style = MaterialTheme.typography.titleMedium)
        Text("Pegá la clave gratuita de OpenRouteService (la que copiaste en account.heigit.org, en \"Clave básica\").", style = MaterialTheme.typography.bodyMedium)
        BotonSec({ abrir("https://account.heigit.org/") }, Modifier.fillMaxWidth()) { Text("Abrir HeiGIT") }
        OutlinedTextField(ors, { ors = it }, Modifier.fillMaxWidth(), label = { Text("Tu clave de OpenRouteService (opcional)") }, singleLine = true)

        Text("Mapa estilo Google", style = MaterialTheme.typography.titleMedium)
        BotonSec({ abrir("https://cloud.maptiler.com/account/keys/") }, Modifier.fillMaxWidth()) { Text("Abrir MapTiler") }
        OutlinedTextField(mapa, { mapa = it }, Modifier.fillMaxWidth(), label = { Text("Tu clave de MapTiler (opcional)") }, singleLine = true)

        BotonP({
            Ajustes.guardarClaveMapTiler(ctx, mapa)
            Ajustes.guardarClaveOrs(ctx, ors)
            if (camionOk) Ajustes.guardarCamion(ctx, altoNum!!, largoNum!!)
            Toast.makeText(ctx, if (camionOk) "Guardado." else "Guardado, pero las medidas del camión no.", Toast.LENGTH_LONG).show()
        }, Modifier.fillMaxWidth().height(52.dp)) { Text("Guardar") }

        Text("Versión", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
        Text("Mi Control ${BuildConfig.VERSION_NAME}", style = MaterialTheme.typography.bodyMedium)
        BotonSec({
            vm.buscarActualizacion(true) { msg -> if (msg != null) Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show() }
        }, Modifier.fillMaxWidth()) { Text("🔄 Buscar actualizaciones") }

        Text("Compartir la app", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
        Text(
            "Mandá Mi Control a otro celular (WhatsApp, Bluetooth, Drive). Cada persona carga sus propios datos " +
                "y sus propias claves de mapa y rutas: no se comparten tus viajes ni tus claves.",
            style = MaterialTheme.typography.bodyMedium
        )
        BotonSec({
            try {
                CompartirApp.compartir(ctx)
            } catch (e: Exception) {
                Toast.makeText(ctx, "No se pudo preparar la app para compartir.", Toast.LENGTH_LONG).show()
            }
        }, Modifier.fillMaxWidth()) { Text("📲 Compartir Mi Control") }
    }
}
