package com.micontrol.app.ui

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.micontrol.app.data.Ajustes

private fun decimal(s: String): Double? = s.trim().replace(',', '.').toDoubleOrNull()

@Composable
fun AjustesScreen(nav: NavController) {
    val ctx = LocalContext.current
    var mapa by remember { mutableStateOf(Ajustes.claveMapTiler(ctx)) }
    var ors by remember { mutableStateOf(Ajustes.claveOrs(ctx)) }
    var alto by remember { mutableStateOf("%.2f".format(Ajustes.alturaCamion(ctx)).replace('.', ',')) }
    var largo by remember { mutableStateOf("%.2f".format(Ajustes.largoCamion(ctx)).replace('.', ',')) }
    val altoNum = decimal(alto); val largoNum = decimal(largo)
    val camionOk = altoNum != null && largoNum != null && altoNum in 1.0..6.0 && largoNum in 1.0..30.0

    fun abrir(url: String) = ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Configuración", style = MaterialTheme.typography.headlineSmall)

        Text("Mi camión", style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(alto, { alto = it }, Modifier.fillMaxWidth(), label = { Text("Altura (metros)") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
        OutlinedTextField(largo, { largo = it }, Modifier.fillMaxWidth(), label = { Text("Largo (metros)") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
        Text("Conviene poner la altura real más un margen (por ejemplo 4,2).", style = MaterialTheme.typography.bodySmall)
        if (!camionOk) Text("Revisá las medidas.", color = MaterialTheme.colorScheme.error)

        Text("Rutas para camión", style = MaterialTheme.typography.titleMedium)
        Text("Pegá la clave gratuita de OpenRouteService (la que copiaste en account.heigit.org, en \"Clave básica\").", style = MaterialTheme.typography.bodyMedium)
        OutlinedButton({ abrir("https://account.heigit.org/") }, Modifier.fillMaxWidth()) { Text("Abrir HeiGIT") }
        OutlinedTextField(ors, { ors = it }, Modifier.fillMaxWidth(), label = { Text("Clave de OpenRouteService") }, singleLine = true)

        Text("Mapa estilo Google", style = MaterialTheme.typography.titleMedium)
        OutlinedButton({ abrir("https://cloud.maptiler.com/account/keys/") }, Modifier.fillMaxWidth()) { Text("Abrir MapTiler") }
        OutlinedTextField(mapa, { mapa = it }, Modifier.fillMaxWidth(), label = { Text("Clave de MapTiler") }, singleLine = true)

        Button({
            Ajustes.guardarClaveMapTiler(ctx, mapa)
            Ajustes.guardarClaveOrs(ctx, ors)
            if (camionOk) Ajustes.guardarCamion(ctx, altoNum!!, largoNum!!)
            Toast.makeText(ctx, if (camionOk) "Guardado." else "Guardado, pero las medidas del camión no.", Toast.LENGTH_LONG).show()
        }, Modifier.fillMaxWidth().height(52.dp)) { Text("Guardar") }
        TextButton({ nav.popBackStack() }) { Text("Volver") }
    }
}
