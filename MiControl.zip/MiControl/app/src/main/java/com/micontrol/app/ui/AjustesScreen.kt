package com.micontrol.app.ui

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.micontrol.app.BuildConfig
import com.micontrol.app.data.Ajustes
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import com.micontrol.app.data.CompartirApp
import com.micontrol.app.data.Servicios
import kotlinx.coroutines.launch

private fun decimal(s: String): Double? = s.trim().replace(',', '.').toDoubleOrNull()

/** Tarjeta con título para agrupar una parte de los ajustes. */
@Composable
private fun Grupo(titulo: String, contenido: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(titulo, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
            contenido()
        }
    }
}

/** Campo de clave: los caracteres quedan ocultos hasta que tocás "Mostrar". */
@Composable
private fun CampoClave(valor: String, onChange: (String) -> Unit, etiqueta: String) {
    var ver by remember { mutableStateOf(false) }
    OutlinedTextField(
        valor, onChange, Modifier.fillMaxWidth(),
        label = { Text(etiqueta) }, singleLine = true,
        visualTransformation = if (ver) VisualTransformation.None else PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
        trailingIcon = { TextButton({ ver = !ver }) { Text(if (ver) "Ocultar" else "Mostrar") } }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AjustesScreen(vm: MainViewModel, nav: NavController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val perfil by vm.perfil.collectAsStateWithLifecycle()
    val perfiles by vm.perfiles.collectAsStateWithLifecycle()

    var mapa by remember { mutableStateOf(Ajustes.claveMapTilerPropia(ctx)) }
    var ors by remember { mutableStateOf(Ajustes.claveOrsPropia(ctx)) }
    var alto by remember(perfil.id) { mutableStateOf("%.2f".format(Ajustes.alturaCamion(ctx)).replace('.', ',')) }
    var largo by remember(perfil.id) { mutableStateOf("%.2f".format(Ajustes.largoCamion(ctx)).replace('.', ',')) }
    var peso by remember(perfil.id) { mutableStateOf(Ajustes.pesoCamion(ctx).let { if (it > 0) "%.1f".format(it).replace('.', ',') else "" }) }
    var vel by remember(perfil.id) { mutableStateOf("%.0f".format(Ajustes.velocidadMaxima(ctx))) }
    var avanzado by remember { mutableStateOf(false) }
    var modoMapa by remember { mutableStateOf(Ajustes.modoMapa(ctx)) }
    var probandoMapa by remember { mutableStateOf(false) }
    var probandoOrs by remember { mutableStateOf(false) }
    var cambiarPerfil by remember { mutableStateOf(false) }
    var editarPerfil by remember { mutableStateOf(false) }
    var borrarPerfil by remember { mutableStateOf(false) }
    var restaurarUri by remember { mutableStateOf<Uri?>(null) }
    var copiaAuto by remember { mutableStateOf(Ajustes.copiaAuto(ctx)) }
    var avisosOn by remember { mutableStateOf(Ajustes.avisosActivos(ctx)) }
    var refrescoCopia by remember { mutableStateOf(0) }
    var hayPin by remember { mutableStateOf(Ajustes.hayPin(ctx)) }
    var pinDialogo by remember { mutableStateOf<Boolean?>(null) }   // null = cerrado, false = poner/cambiar, true = quitar
    val ultimaCopia = remember(refrescoCopia, perfil.id) { Ajustes.ultimaCopia(ctx, perfil.id) }

    val altoNum = decimal(alto)
    val largoNum = decimal(largo)
    val pesoNum = if (peso.isBlank()) 0.0 else decimal(peso)
    val camionOk = altoNum != null && largoNum != null && altoNum in 1.0..6.0 && largoNum in 1.0..30.0 &&
        pesoNum != null && pesoNum in 0.0..80.0 && decimal(vel)?.let { it in 40.0..110.0 } == true

    val elegirCopia = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) restaurarUri = uri
    }

    fun abrir(url: String) = ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Ajustes", style = MaterialTheme.typography.headlineSmall)

        // ---------- Perfil ----------
        Grupo("👤 Mi perfil") {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Avatar(perfil.inicial, 56.dp)
                Column(Modifier.weight(1f)) {
                    Text(perfil.nombre, style = MaterialTheme.typography.titleLarge)
                    if (perfil.camion.isNotBlank()) Text("Camión: ${perfil.camion}", style = MaterialTheme.typography.bodyMedium)
                    if (perfil.empresa.isNotBlank()) Text("Empresa: ${perfil.empresa}", style = MaterialTheme.typography.bodyMedium)
                }
            }
            Text(
                "Cada perfil tiene sus propios viajes, horas, gastos y clientes. Hay ${perfiles.size} " +
                    if (perfiles.size == 1) "perfil en este teléfono." else "perfiles en este teléfono.",
                style = MaterialTheme.typography.bodySmall
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                BotonSec({ editarPerfil = true }, Modifier.weight(1f)) { Text("Editar") }
                BotonP({ cambiarPerfil = true }, Modifier.weight(1f)) { Text("Cambiar / nuevo") }
            }
            if (perfiles.size > 1) {
                TextButton({ borrarPerfil = true }) { Text("Eliminar este perfil", color = MaterialTheme.colorScheme.error) }
            }
        }

        // ---------- Camión ----------
        Grupo("🚛 Medidas del camión") {
            Text("Se usan para calcular rutas por donde el camión puede pasar.", style = MaterialTheme.typography.bodySmall)
            OutlinedTextField(
                alto, { alto = it }, Modifier.fillMaxWidth(), label = { Text("Altura (metros)") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
            )
            OutlinedTextField(
                largo, { largo = it }, Modifier.fillMaxWidth(), label = { Text("Largo (metros)") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
            )
            OutlinedTextField(
                peso, { peso = it }, Modifier.fillMaxWidth(), label = { Text("Peso total en toneladas (opcional)") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
            )
            OutlinedTextField(
                vel, { vel = it }, Modifier.fillMaxWidth(), label = { Text("Velocidad máxima cargado (km/h)") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
            Text("Conviene poner la altura real más un margen (por ejemplo 4,2). Con el peso, la ruta evita puentes con límite de carga.", style = MaterialTheme.typography.bodySmall)
            if (!camionOk) Text("Revisá las medidas.", color = MaterialTheme.colorScheme.error)
            BotonP({
                if (camionOk) {
                    Ajustes.guardarCamion(ctx, altoNum!!, largoNum!!)
                    Ajustes.guardarPeso(ctx, pesoNum ?: 0.0)
                    Ajustes.guardarVelocidad(ctx, decimal(vel) ?: 80.0)
                    Toast.makeText(ctx, "Medidas guardadas.", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(ctx, "Revisá las medidas del camión.", Toast.LENGTH_LONG).show()
                }
            }, Modifier.fillMaxWidth()) { Text("Guardar medidas") }
        }

        // ---------- Mapa ----------
        Grupo("🎨 Fondo de pantalla") {
            val fondoActual by vm.fondo.collectAsStateWithLifecycle()
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                FONDOS.forEach { f ->
                    val elegido = f.id == fondoActual
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable { vm.cambiarFondo(f.id) }) {
                        Box(
                            Modifier.size(width = 72.dp, height = 128.dp).clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF111114))
                                .border(if (elegido) 3.dp else 1.dp, if (elegido) Color(0xFFE11D2A) else Color(0xFF555560), RoundedCornerShape(12.dp))
                        ) {
                            f.miniatura?.let {
                                Image(painterResource(it), contentDescription = f.nombre, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                            }
                        }
                        Text(if (elegido) "✔ ${f.nombre}" else f.nombre, style = MaterialTheme.typography.bodySmall, maxLines = 1)
                    }
                }
            }
            Text("Se cambia al instante. Los textos se leen bien con cualquiera.", style = MaterialTheme.typography.bodySmall)
        }

        Card(Modifier.fillMaxWidth().clickable { avanzado = !avanzado }) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("⚙️ Avanzado (claves, mapa, avisos, ayuda)", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                Text(if (avanzado) "▴" else "▾", style = MaterialTheme.typography.titleMedium)
            }
        }
        if (avanzado) {
        Grupo("🗺️ Mapa de día o de noche") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("auto" to "Automático", "claro" to "Claro", "oscuro" to "Oscuro").forEach { (clave, nombre) ->
                    FilterChip(modoMapa == clave, { modoMapa = clave; Ajustes.guardarModoMapa(ctx, clave) }, label = { Text(nombre) })
                }
            }
            Text("Automático sigue el modo claro u oscuro del teléfono.", style = MaterialTheme.typography.bodySmall)
        }

        }
        // ---------- Claves ----------
        if (avanzado) {
        Grupo("🔑 Mapas y rutas") {
            Text(
                "Los mapas y las rutas ya vienen listos para usar. Cargá tus propias claves solo si dejan de funcionar por el límite de uso. " +
                    "Las claves quedan ocultas.",
                style = MaterialTheme.typography.bodySmall
            )

            Text("Mapa estilo Google (MapTiler)", style = MaterialTheme.typography.titleSmall)
            Text(
                when {
                    mapa.isNotBlank() -> "✅ Usando tu clave"
                    BuildConfig.MAPTILER_KEY.isNotBlank() -> "✅ Usando la clave que viene con la app"
                    else -> "⚠️ Sin clave: el mapa de calles y el satélite no van a funcionar bien"
                },
                style = MaterialTheme.typography.bodyMedium
            )
            CampoClave(mapa, { mapa = it }, "Tu clave de MapTiler (opcional)")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                BotonSec({ abrir("https://cloud.maptiler.com/account/keys/") }, Modifier.weight(1f)) { Text("Conseguir clave") }
                BotonSec({
                    probandoMapa = true
                    scope.launch {
                        val r = Servicios.probarMapTiler(mapa.trim().ifBlank { BuildConfig.MAPTILER_KEY })
                        probandoMapa = false
                        Toast.makeText(ctx, r, Toast.LENGTH_LONG).show()
                    }
                }, Modifier.weight(1f), enabled = !probandoMapa) { Text(if (probandoMapa) "Probando…" else "Probar") }
            }

            Text("Rutas para camión (OpenRouteService)", style = MaterialTheme.typography.titleSmall)
            Text(
                when {
                    ors.isNotBlank() -> "✅ Usando tu clave"
                    BuildConfig.ORS_KEY.isNotBlank() -> "✅ Usando la clave que viene con la app"
                    else -> "⚠️ Sin clave: no se pueden calcular rutas para camión"
                },
                style = MaterialTheme.typography.bodyMedium
            )
            CampoClave(ors, { ors = it }, "Tu clave de OpenRouteService (opcional)")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                BotonSec({ abrir("https://account.heigit.org/") }, Modifier.weight(1f)) { Text("Conseguir clave") }
                BotonSec({
                    probandoOrs = true
                    scope.launch {
                        val r = Servicios.probarOrs(ors.trim().ifBlank { BuildConfig.ORS_KEY })
                        probandoOrs = false
                        Toast.makeText(ctx, r, Toast.LENGTH_LONG).show()
                    }
                }, Modifier.weight(1f), enabled = !probandoOrs) { Text(if (probandoOrs) "Probando…" else "Probar") }
            }

            BotonP({
                Ajustes.guardarClaveMapTiler(ctx, mapa)
                Ajustes.guardarClaveOrs(ctx, ors)
                Toast.makeText(ctx, "Claves guardadas.", Toast.LENGTH_SHORT).show()
            }, Modifier.fillMaxWidth().height(52.dp)) { Text("Guardar claves") }
        }

        }
        // ---------- Copia de seguridad ----------
        Grupo("🛟 Copia de seguridad") {
            Text(
                "Guarda los datos de este perfil (viajes, horas, gastos, clientes, control del camión) y las fotos de los tickets, " +
                    "para no perderlos si cambiás o se rompe el teléfono. Queda en la carpeta Descargas.",
                style = MaterialTheme.typography.bodySmall
            )
            Text(
                if (ultimaCopia > 0) "Última copia: " + SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("es", "AR")).format(Date(ultimaCopia))
                else "Todavía no hiciste ninguna copia.",
                style = MaterialTheme.typography.bodyMedium
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(copiaAuto, { copiaAuto = it; Ajustes.guardarCopiaAuto(ctx, it) })
                Text("  Hacer una copia sola cada semana", Modifier.weight(1f))
            }
            BotonSec({
                vm.guardarCopia { msg ->
                    refrescoCopia++
                    Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
                }
            }, Modifier.fillMaxWidth()) { Text("💾 Hacer una copia ahora") }
            BotonSec({ elegirCopia.launch(arrayOf("*/*")) }, Modifier.fillMaxWidth()) { Text("📂 Restaurar una copia") }
        }

        // ---------- Avisos ----------
        if (avanzado) {
        Grupo("🔔 Avisos") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(avisosOn, { avisosOn = it; Ajustes.guardarAvisosActivos(ctx, it) })
                Text("  Avisarme con una notificación cuando algo vence o hay que hacer service", Modifier.weight(1f))
            }
            Text("Los vencimientos y el mantenimiento se cargan en Inicio > Control del camión.", style = MaterialTheme.typography.bodySmall)
        }

        }
        // ---------- Seguridad ----------
        Grupo("🔒 Seguridad") {
            Text(
                if (hayPin) "El PIN está activado: se pide al abrir la app y cuando volvés después de un minuto."
                else "Poné un PIN de 4 números para que nadie más abra tus datos.",
                style = MaterialTheme.typography.bodySmall
            )
            BotonSec({ pinDialogo = false }, Modifier.fillMaxWidth()) { Text(if (hayPin) "Cambiar el PIN" else "Poner un PIN") }
            if (hayPin) TextButton({ pinDialogo = true }) { Text("Quitar el PIN", color = MaterialTheme.colorScheme.error) }
        }

        // ---------- Batería ----------
        if (avanzado) {
        Grupo("🔋 GPS en viajes largos") {
            Text(
                "Para que el teléfono no corte el seguimiento GPS con la pantalla apagada, dejá a Mi Control en batería \"Sin restricciones\".",
                style = MaterialTheme.typography.bodySmall
            )
            BotonSec({ pedirBateriaSinRestricciones(ctx) }, Modifier.fillMaxWidth()) { Text("Que la batería no corte el GPS") }
        }

        }
        // ---------- Ayuda ----------
        if (avanzado) {
        Grupo("💡 Ayuda") {
            Text("Para que una ubicación quede EXACTA como en Google Maps:", style = MaterialTheme.typography.titleSmall)
            Text(
                "• En Google Maps tocá el lugar, después Compartir, y elegí Mi Control.\n" +
                    "• O copiá el link y usá \"📍 Pegar ubicación\" en Inicio.\n" +
                    "• Si mantenés apretado un punto del mapa, Google muestra las coordenadas arriba: copialas y pegalas acá.\n" +
                    "• Si solo te mandan la dirección escrita, no hay coordenadas: queda aproximada y hay que ajustarla en el mapa.",
                style = MaterialTheme.typography.bodyMedium
            )
            BotonSec({
                ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")))
            }, Modifier.fillMaxWidth()) { Text("⚙️ Permisos y batería del teléfono") }
        }

        }
        // ---------- Versión ----------
        Grupo("ℹ️ Mi Control") {
            Text("Versión ${BuildConfig.VERSION_NAME}", style = MaterialTheme.typography.bodyLarge)
            BotonSec({
                vm.buscarActualizacion(true) { msg -> if (msg != null) Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show() }
            }, Modifier.fillMaxWidth()) { Text("🔄 Buscar actualizaciones") }
            Text(
                "Mandá Mi Control a otro celular (WhatsApp, Bluetooth, Drive). Cada persona carga sus propios datos " +
                    "y sus propias claves: no se comparten tus viajes ni tus claves.",
                style = MaterialTheme.typography.bodySmall
            )
            BotonSec({
                try {
                    CompartirApp.compartir(ctx)
                } catch (e: Exception) {
                    Toast.makeText(ctx, "No se pudo preparar la app para compartir.", Toast.LENGTH_LONG).show()
                }
            }, Modifier.fillMaxWidth()) { Text("📲 Compartir Mi Control") }
        }
    }

    if (cambiarPerfil) PerfilesDialog(vm) { cambiarPerfil = false }

    if (editarPerfil) {
        EditarPerfilDialog(perfil, onDismiss = { editarPerfil = false }) { n, c, e ->
            vm.guardarPerfil(perfil.copy(nombre = n.trim(), camion = c.trim(), empresa = e.trim()))
            editarPerfil = false
        }
    }

    if (borrarPerfil) AlertDialog(
        onDismissRequest = { borrarPerfil = false },
        title = { Text("¿Eliminar el perfil ${perfil.nombre}?") },
        text = {
            Text(
                "Se borran todos sus viajes, horas, gastos y clientes. No se puede deshacer. " +
                    "Antes podés guardar una copia de seguridad."
            )
        },
        confirmButton = {
            TextButton({
                vm.eliminarPerfil(perfil.id)
                borrarPerfil = false
            }) { Text("Eliminar", color = MaterialTheme.colorScheme.error) }
        },
        dismissButton = { TextButton({ borrarPerfil = false }) { Text("Cancelar") } }
    )

    pinDialogo?.let { quitar ->
        DialogoPin(quitar, onDismiss = { pinDialogo = null }) { nuevoPin ->
            if (quitar) {
                Ajustes.quitarPin(ctx)
                vm.bloqueado.value = false
                Toast.makeText(ctx, "PIN quitado.", Toast.LENGTH_SHORT).show()
            } else {
                Ajustes.fijarPin(ctx, nuevoPin)
                Toast.makeText(ctx, "PIN guardado.", Toast.LENGTH_SHORT).show()
            }
            hayPin = Ajustes.hayPin(ctx)
            pinDialogo = null
        }
    }

    restaurarUri?.let { uri ->
        AlertDialog(
            onDismissRequest = { restaurarUri = null },
            title = { Text("¿Restaurar la copia?") },
            text = {
                Text(
                    "Esto reemplaza TODOS los datos del perfil ${perfil.nombre} por los de la copia. " +
                        "Lo que cargaste después de hacer esa copia se pierde."
                )
            },
            confirmButton = {
                TextButton({
                    vm.restaurarCopia(uri) { msg -> refrescoCopia++; Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show() }
                    restaurarUri = null
                }) { Text("Restaurar", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton({ restaurarUri = null }) { Text("Cancelar") } }
        )
    }
}

@Composable
private fun CampoPin(valor: String, onChange: (String) -> Unit, etiqueta: String) {
    OutlinedTextField(
        valor, { onChange(it.filter(Char::isDigit).take(LARGO_PIN)) }, Modifier.fillMaxWidth(),
        label = { Text(etiqueta) }, singleLine = true,
        visualTransformation = PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
    )
}

@Composable
private fun DialogoPin(quitar: Boolean, onDismiss: () -> Unit, onListo: (String) -> Unit) {
    val ctx = LocalContext.current
    val hay = Ajustes.hayPin(ctx)
    var actual by remember { mutableStateOf("") }
    var nuevo by remember { mutableStateOf("") }
    var repetir by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (quitar) "Quitar el PIN" else if (hay) "Cambiar el PIN" else "Poner un PIN") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                if (hay) CampoPin(actual, { actual = it }, "PIN actual")
                if (!quitar) {
                    CampoPin(nuevo, { nuevo = it }, "PIN nuevo (4 números)")
                    CampoPin(repetir, { repetir = it }, "Repetí el PIN nuevo")
                    Text(
                        "Si te olvidás del PIN, la única forma de volver a entrar es desinstalar la app y se pierden los datos. Hacé antes una copia de seguridad.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton({
                if (hay && !Ajustes.pinCorrecto(ctx, actual)) {
                    error = "El PIN actual no es correcto."
                } else if (quitar) {
                    onListo("")
                } else if (nuevo.length != LARGO_PIN) {
                    error = "El PIN tiene que ser de $LARGO_PIN números."
                } else if (nuevo != repetir) {
                    error = "Los dos PIN no coinciden."
                } else {
                    onListo(nuevo)
                }
            }) { Text("Aceptar") }
        },
        dismissButton = { TextButton(onDismiss) { Text("Cancelar") } }
    )
}
