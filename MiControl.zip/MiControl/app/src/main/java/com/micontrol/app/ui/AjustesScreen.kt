package com.micontrol.app.ui

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.micontrol.app.data.Ajustes

@Composable
fun AjustesScreen(nav: NavController) {
    val ctx = LocalContext.current
    var clave by remember { mutableStateOf(Ajustes.claveMapTiler(ctx)) }

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Configuración", style = MaterialTheme.typography.headlineSmall)
        Text("Mapa estilo Google", style = MaterialTheme.typography.titleMedium)
        Text(
            "Para ver el mapa con calles claras como en Google Maps hace falta una clave gratuita de MapTiler " +
                "(no pide tarjeta). Pasos: 1) Tocá el botón de abajo y creá una cuenta. 2) Entrá a \"API keys\" " +
                "(o Account > Keys). 3) Copiá la clave y pegala acá.",
            style = MaterialTheme.typography.bodyMedium
        )
        OutlinedButton({
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://cloud.maptiler.com/account/keys/")))
        }, Modifier.fillMaxWidth()) { Text("Abrir MapTiler") }
        OutlinedTextField(clave, { clave = it }, Modifier.fillMaxWidth(), label = { Text("Clave de MapTiler") }, singleLine = true)
        Button({
            Ajustes.guardarClaveMapTiler(ctx, clave)
            Toast.makeText(ctx, "Guardado. Abrí el mapa de nuevo para verlo.", Toast.LENGTH_LONG).show()
        }, Modifier.fillMaxWidth().height(52.dp)) { Text("Guardar") }
        Text("Sin clave se usa el mapa básico de OpenStreetMap.", style = MaterialTheme.typography.bodySmall)
        TextButton({ nav.popBackStack() }) { Text("Volver") }
    }
}
