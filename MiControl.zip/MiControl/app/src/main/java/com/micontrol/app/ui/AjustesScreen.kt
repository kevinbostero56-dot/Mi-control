package com.micontrol.app.ui

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.micontrol.app.BuildConfig
import com.micontrol.app.data.Ajustes
import com.micontrol.app.data.CompartirApp
import com.micontrol.app.data.Servicios
import kotlinx.coroutines.launch

private fun decimal(s: String): Double? = s.trim().replace(',', '.').toDoubleOrNull()

/** Tarjeta con título para agrupar una parte de los ajustes. */
@Composable
private fun Grupo(titulo: String, contenido: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(titulo, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
            contenido()
        }
    }
}

/** Campo de clave: los caracteres quedan ocultos hasta que tocás "Mostrar". */
@Composable
private fun CampoClave(valor: String, onChange: (String) -> Unit, etiqueta: String) {
    var ver by remember { mutableStateOf(false) }
    OutlinedTextField(
        valor, onChange, Modifier.fillMaxWidth(),
        label = { Text(etiqueta) }, singleLine = true,
        visualTransformation = if (ver) VisualTransformation.None else PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
        trailingIcon = { TextButton({ ver = !ver }) { Text(if (ver) "Ocultar" else "Mostrar") } }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AjustesScreen(vm: MainViewModel, nav: NavController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val perfil by vm.perfil.collectAsStateWithLifecycle()
    val perfiles by vm.perfiles.collectAsStateWithLifecycle()

    var mapa by remember { mutableStateOf(Ajustes.claveMapTilerPropia(ctx)) }
    var ors by remember { mutableStateOf(Ajustes.claveOrsPropia(ctx)) }
    var alto by remember(perfil.id) { mutableStateOf("%.2f".format(Ajustes.alturaCamion(ctx)).replace('.', ',')) }
    var largo by remember(perfil.id) { mutableStateOf("%.2f".format(Ajustes.largoCamion(ctx)).replace('.', ',')) }
    var modoMapa by remember { mutableStateOf(Ajustes.modoMapa(ctx)) }
    var probandoMapa by remember { mutableStateOf(false) }
    var probandoOrs by remember { mutableStateOf(false) }
    var cambiarPerfil by remember { mutableStateOf(false) }
    var editarPerfil by remember { mutableStateOf(false) }
    var borrarPerfil by remember { mutableStateOf(false) }
    var restaurarUri by remember { mutableStateOf<Uri?>(null) }

    val altoNum = decimal(alto)
    val largoNum = decimal(largo)
    val camionOk = altoNum != null && largoNum != null && altoNum in 1.0..6.0 && largoNum in 1.0..30.0

    val elegirCopia = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) restaurarUri = uri
    }

    fun abrir(url: String) = ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Ajustes", style = MaterialTheme.typography.headlineSmall)

        // ---------- Perfil ----------
        Grupo("👤 Mi perfil") {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Avatar(perfil.inicial, 56.dp)
                Column(Modifier.weight(1f)) {
                    Text(perfil.nombre, style = MaterialTheme.typography.titleLarge)
                    if (perfil.camion.isNotBlank()) Text("Camión: ${perfil.camion}", style = MaterialTheme.typography.bodyMedium)
                    if (perfil.empresa.isNotBlank()) Text("Empresa: ${perfil.empresa}", style = MaterialTheme.typography.bodyMedium)
                }
            }
            Text(
                "Cada perfil tiene sus propios viajes, horas, gastos y clientes. Hay ${perfiles.size} " +
                    if (perfiles.size == 1) "perfil en este teléfono." else "perfiles en este teléfono.",
                style = MaterialTheme.typography.bodySmall
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                BotonSec({ editarPerfil = true }, Modifier.weight(1f)) { Text("Editar") }
                BotonP({ cambiarPerfil = true }, Modifier.weight(1f)) { Text("Cambiar / nuevo") }
            }
            if (perfiles.size > 1) {
                TextButton({ borrarPerfil = true }) { Text("Eliminar este perfil", color = MaterialTheme.colorScheme.error) }
            }
        }

        // ---------- Camión ----------
        Grupo("🚛 Medidas del camión") {
            Text("Se usan para calcular rutas por donde el camión puede pasar.", style = MaterialTheme.typography.bodySmall)
            OutlinedTextField(
                alto, { alto = it }, Modifier.fillMaxWidth(), label = { Text("Altura (metros)") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
            )
            OutlinedTextField(
                largo, { largo = it }, Modifier.fillMaxWidth(), label = { Text("Largo (metros)") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
            )
            Text("Conviene poner la altura real más un margen (por ejemplo 4,2).", style = MaterialTheme.typography.bodySmall)
            if (!camionOk) Text("Revisá las medidas.", color = MaterialTheme.colorScheme.error)
            BotonP({
                if (camionOk) {
                    Ajustes.guardarCamion(ctx, altoNum!!, largoNum!!)
                    Toast.makeText(ctx, "Medidas guardadas.", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(ctx, "Revisá las medidas del camión.", Toast.LENGTH_LONG).show()
                }
            }, Modifier.fillMaxWidth()) { Text("Guardar medidas") }
        }

        // ---------- Mapa ----------
        Grupo("🗺️ Mapa de día o de noche") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("auto" to "Automático", "claro" to "Claro", "oscuro" to "Oscuro").forEach { (clave, nombre) ->
                    FilterChip(modoMapa == clave, { modoMapa = clave; Ajustes.guardarModoMapa(ctx, clave) }, label = { Text(nombre) })
                }
            }
            Text("Automático sigue el modo claro u oscuro del teléfono.", style = MaterialTheme.typography.bodySmall)
        }

        // ---------- Claves ----------
        Grupo("🔑 Mapas y rutas") {
            Text(
                "Los mapas y las rutas ya vienen listos para usar. Cargá tus propias claves solo si dejan de funcionar por el límite de uso. " +
                    "Las claves quedan ocultas.",
                style = MaterialTheme.typography.bodySmall
            )

            Text("Mapa estilo Google (MapTiler)", style = MaterialTheme.typography.titleSmall)
            Text(
                when {
                    mapa.isNotBlank() -> "✅ Usando tu clave"
                    BuildConfig.MAPTILER_KEY.isNotBlank() -> "✅ Usando la clave que viene con la app"
                    else -> "⚠️ Sin clave: el mapa de calles y el satélite no van a funcionar bien"
                },
                style = MaterialTheme.typography.bodyMedium
            )
            CampoClave(mapa, { mapa = it }, "Tu clave de MapTiler (opcional)")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                BotonSec({ abrir("https://cloud.maptiler.com/account/keys/") }, Modifier.weight(1f)) { Text("Conseguir clave") }
                BotonSec({
                    probandoMapa = true
                    scope.launch {
                        val r = Servicios.probarMapTiler(mapa.trim().ifBlank { BuildConfig.MAPTILER_KEY })
                        probandoMapa = false
                        Toast.makeText(ctx, r, Toast.LENGTH_LONG).show()
                    }
                }, Modifier.weight(1f), enabled = !probandoMapa) { Text(if (probandoMapa) "Probando…" else "Probar") }
            }

            Text("Rutas para camión (OpenRouteService)", style = MaterialTheme.typography.titleSmall)
            Text(
                when {
                    ors.isNotBlank() -> "✅ Usando tu clave"
                    BuildConfig.ORS_KEY.isNotBlank() -> "✅ Usando la clave que viene con la app"
                    else -> "⚠️ Sin clave: no se pueden calcular rutas para camión"
                },
                style = MaterialTheme.typography.bodyMedium
            )
            CampoClave(ors, { ors = it }, "Tu clave de OpenRouteService (opcional)")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                BotonSec({ abrir("https://account.heigit.org/") }, Modifier.weight(1f)) { Text("Conseguir clave") }
                BotonSec({
                    probandoOrs = true
                    scope.launch {
                        val r = Servicios.probarOrs(ors.trim().ifBlank { BuildConfig.ORS_KEY })
                        probandoOrs = false
                        Toast.makeText(ctx, r, Toast.LENGTH_LONG).show()
                    }
                }, Modifier.weight(1f), enabled = !probandoOrs) { Text(if (probandoOrs) "Probando…" else "Probar") }
            }

            BotonP({
                Ajustes.guardarClaveMapTiler(ctx, mapa)
                Ajustes.guardarClaveOrs(ctx, ors)
                Toast.makeText(ctx, "Claves guardadas.", Toast.LENGTH_SHORT).show()
            }, Modifier.fillMaxWidth().height(52.dp)) { Text("Guardar claves") }
        }

        // ---------- Copia de seguridad ----------
        Grupo("🛟 Copia de seguridad") {
            Text(
                "Guardá una copia de los datos de este perfil (viajes, horas, gastos, clientes) para no perderlos si cambiás o " +
                    "se rompe el teléfono. La copia no incluye las fotos de los tickets.",
                style = MaterialTheme.typography.bodySmall
            )
            BotonSec({
                vm.guardarCopia { msg -> Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show() }
            }, Modifier.fillMaxWidth()) { Text("💾 Guardar copia en Descargas") }
            BotonSec({ elegirCopia.launch(arrayOf("*/*")) }, Modifier.fillMaxWidth()) { Text("📂 Restaurar una copia") }
        }

        // ---------- Ayuda ----------
        Grupo("💡 Ayuda") {
            Text("Para que una ubicación quede EXACTA como en Google Maps:", style = MaterialTheme.typography.titleSmall)
            Text(
                "• En Google Maps tocá el lugar, después Compartir, y elegí Mi Control.\n" +
                    "• O copiá el link y usá \"📍 Pegar ubicación\" en Inicio.\n" +
                    "• Si mantenés apretado un punto del mapa, Google muestra las coordenadas arriba: copialas y pegalas acá.\n" +
                    "• Si solo te mandan la dirección escrita, no hay coordenadas: queda aproximada y hay que ajustarla en el mapa.",
                style = MaterialTheme.typography.bodyMedium
            )
            BotonSec({
                ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")))
            }, Modifier.fillMaxWidth()) { Text("⚙️ Permisos y batería del teléfono") }
        }

        // ---------- Versión ----------
        Grupo("ℹ️ Mi Control") {
            Text("Versión ${BuildConfig.VERSION_NAME}", style = MaterialTheme.typography.bodyLarge)
            BotonSec({
                vm.buscarActualizacion(true) { msg -> if (msg != null) Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show() }
            }, Modifier.fillMaxWidth()) { Text("🔄 Buscar actualizaciones") }
            Text(
                "Mandá Mi Control a otro celular (WhatsApp, Bluetooth, Drive). Cada persona carga sus propios datos " +
                    "y sus propias claves: no se comparten tus viajes ni tus claves.",
                style = MaterialTheme.typography.bodySmall
            )
            BotonSec({
                try {
                    CompartirApp.compartir(ctx)
                } catch (e: Exception) {
                    Toast.makeText(ctx, "No se pudo preparar la app para compartir.", Toast.LENGTH_LONG).show()
                }
            }, Modifier.fillMaxWidth()) { Text("📲 Compartir Mi Control") }
        }
    }

    if (cambiarPerfil) PerfilesDialog(vm) { cambiarPerfil = false }

    if (editarPerfil) {
        EditarPerfilDialog(perfil, onDismiss = { editarPerfil = false }) { n, c, e ->
            vm.guardarPerfil(perfil.copy(nombre = n.trim(), camion = c.trim(), empresa = e.trim()))
            editarPerfil = false
        }
    }

    if (borrarPerfil) AlertDialog(
        onDismissRequest = { borrarPerfil = false },
        title = { Text("¿Eliminar el perfil ${perfil.nombre}?") },
        text = {
            Text(
                "Se borran todos sus viajes, horas, gastos y clientes. No se puede deshacer. " +
                    "Antes podés guardar una copia de seguridad."
            )
        },
        confirmButton = {
            TextButton({
                vm.eliminarPerfil(perfil.id)
                borrarPerfil = false
            }) { Text("Eliminar", color = MaterialTheme.colorScheme.error) }
        },
        dismissButton = { TextButton({ borrarPerfil = false }) { Text("Cancelar") } }
    )

    restaurarUri?.let { uri ->
        AlertDialog(
            onDismissRequest = { restaurarUri = null },
            title = { Text("¿Restaurar la copia?") },
            text = {
                Text(
                    "Esto reemplaza TODOS los datos del perfil ${perfil.nombre} por los de la copia. " +
                        "Lo que cargaste después de hacer esa copia se pierde."
                )
            },
            confirmButton = {
                TextButton({
                    vm.restaurarCopia(uri) { msg -> Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show() }
                    restaurarUri = null
                }) { Text("Restaurar", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton({ restaurarUri = null }) { Text("Cancelar") } }
        )
    }
}
