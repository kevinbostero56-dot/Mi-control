package com.micontrol.app.data

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Comparte la propia app (el instalador .apk dentro de un .zip) por WhatsApp, Bluetooth, Drive, etc. */
object CompartirApp {
    fun compartir(ctx: Context) {
        val apk = File(ctx.applicationInfo.sourceDir)
        val carpeta = File(ctx.cacheDir, "informes").apply { mkdirs() }
        val zip = File(carpeta, "MiControl.zip")
        ZipOutputStream(FileOutputStream(zip)).use { z ->
            z.putNextEntry(ZipEntry("MiControl.apk"))
            apk.inputStream().use { it.copyTo(z) }
            z.closeEntry()
        }
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", zip)
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "application/zip"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(
                Intent.EXTRA_TEXT,
                "Mi Control: app para controlar viajes, horas, gastos y recorridos.\n" +
                    "1) Descomprimí el zip. 2) Abrí MiControl.apk. " +
                    "3) Si el celular avisa, permití instalar apps de esta fuente. (Android 10 o más)"
            )
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(i, "Compartir Mi Control").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
