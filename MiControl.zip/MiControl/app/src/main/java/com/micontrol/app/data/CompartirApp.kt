package com.micontrol.app.data

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import com.micontrol.app.BuildConfig
import java.io.File

/**
 * Comparte la propia app por WhatsApp, Bluetooth, Drive, etc.
 * Manda el instalador .apk directo (sin zip, que muchos celulares no saben abrir)
 * y en el mensaje va también el link para descargarla de internet.
 */
object CompartirApp {
    fun compartir(ctx: Context) {
        val apk = File(ctx.applicationInfo.sourceDir)
        val carpeta = File(ctx.cacheDir, "informes").apply { mkdirs() }
        // Borra copias viejas para no ocupar lugar
        carpeta.listFiles()?.forEach { f ->
            if (f.name.startsWith("MiControl") && (f.name.endsWith(".apk") || f.name.endsWith(".zip"))) f.delete()
        }
        val copia = File(carpeta, "MiControl-${BuildConfig.VERSION_NAME}.apk")
        apk.inputStream().use { entrada -> copia.outputStream().use { entrada.copyTo(it) } }

        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", copia)
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "application/vnd.android.package-archive"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "Mi Control ${BuildConfig.VERSION_NAME}")
            putExtra(Intent.EXTRA_TEXT, mensaje())
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(i, "Compartir Mi Control").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    /** Link a la última versión publicada (vacío si la app no sabe de qué repositorio viene). */
    fun linkDescarga(): String =
        if (BuildConfig.REPO.isBlank()) "" else "https://github.com/${BuildConfig.REPO}/releases/latest"

    private fun mensaje(): String {
        val link = linkDescarga()
        return buildString {
            append("Mi Control: app para controlar viajes, horas, gastos y recorridos.\n\n")
            append("Para instalarla:\n")
            append("1) Tocá el archivo MiControl.apk (si no abre, buscalo en la carpeta Descargas).\n")
            append("2) Si el celular avisa, permití \"instalar apps desconocidas\" y volvé a tocarlo.\n")
            append("3) Si aparece Play Protect, tocá \"Más detalles\" y \"Instalar de todas formas\".\n")
            if (link.isNotBlank()) {
                append("\nTambién la podés bajar de acá (abrilo con Chrome y descargá el archivo .apk):\n")
                append(link)
                append("\n")
            }
            append("\nNecesita Android 10 o más nuevo.")
        }
    }
}
