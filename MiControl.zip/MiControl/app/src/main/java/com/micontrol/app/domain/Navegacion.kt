package com.micontrol.app.domain

import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

/** Cálculos para la navegación: dónde estás sobre la ruta y cuánto falta. */
object Navegacion {
    private const val M_POR_GRADO = 111_320.0

    private fun haversine(lat1: Double, lng1: Double, lat2: Double, lng2: Double): Double {
        val r = 6_371_000.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLng = Math.toRadians(lng2 - lng1)
        val a = sin(dLat / 2) * sin(dLat / 2) +
            cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLng / 2) * sin(dLng / 2)
        return 2 * r * asin(sqrt(a))
    }

    /** Ruta con la distancia acumulada (en metros) hasta cada punto. */
    class Ruta(val puntos: List<Pair<Double, Double>>) {
        val acum = DoubleArray(puntos.size)
        init {
            for (i in 1 until puntos.size) {
                acum[i] = acum[i - 1] + haversine(puntos[i - 1].first, puntos[i - 1].second, puntos[i].first, puntos[i].second)
            }
        }
        val total: Double get() = if (acum.isEmpty()) 0.0 else acum[acum.size - 1]
    }

    /** idx: tramo de la ruta donde estás; distM: a cuántos metros de la ruta; progresoM: metros ya recorridos. */
    data class Proy(val idx: Int, val distM: Double, val progresoM: Double)

    fun proyectar(r: Ruta, lat: Double, lng: Double, desde: Int, ventana: Int = 400): Proy {
        val n = r.puntos.size
        if (n < 2) return Proy(0, Double.MAX_VALUE, 0.0)
        val k = cos(Math.toRadians(lat))

        fun buscar(ini: Int, fin: Int): Proy {
            var mejor = Proy(ini, Double.MAX_VALUE, 0.0)
            for (i in ini until min(fin, n - 1)) {
                val ax = (r.puntos[i].second - lng) * k * M_POR_GRADO
                val ay = (r.puntos[i].first - lat) * M_POR_GRADO
                val bx = (r.puntos[i + 1].second - lng) * k * M_POR_GRADO
                val by = (r.puntos[i + 1].first - lat) * M_POR_GRADO
                val dx = bx - ax
                val dy = by - ay
                val l2 = dx * dx + dy * dy
                val t = if (l2 == 0.0) 0.0 else (((-ax) * dx + (-ay) * dy) / l2).coerceIn(0.0, 1.0)
                val px = ax + t * dx
                val py = ay + t * dy
                val d = sqrt(px * px + py * py)
                if (d < mejor.distM) mejor = Proy(i, d, r.acum[i] + t * sqrt(l2))
            }
            return mejor
        }

        val cerca = buscar(max(0, desde - 5), min(n - 1, desde + ventana))
        return if (cerca.distM <= 80.0) cerca else buscar(0, n - 1)
    }
}
