package com.micontrol.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.micontrol.app.data.*
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val db = AppDatabase.get(app)
    private fun <T> kotlinx.coroutines.flow.Flow<T>.state(init: T) =
        stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), init)

    val viajes = db.viajeDao().todos().state(emptyList())
    val clientes = db.clienteDao().todos().state(emptyList())
    val todasJornadas = db.jornadaDao().todas().state(emptyList())
    val todosGastos = db.gastoDao().todos().state(emptyList())

    fun viaje(id: String) = db.viajeDao().porId(id)
    fun jornadas(id: String) = db.jornadaDao().porViaje(id)
    fun gastos(id: String) = db.gastoDao().porViaje(id)

    fun iniciarViaje(v: Viaje) = viewModelScope.launch {
        if (v.cliente.isNotBlank()) db.clienteDao().insertar(Cliente(nombre = v.cliente.trim()))
        db.viajeDao().insertar(v)
    }
    fun finalizarViaje(v: Viaje, odometroFinal: Long) = viewModelScope.launch {
        db.viajeDao().actualizar(
            v.copy(estado = Viaje.Estado.FINALIZADO, fin = System.currentTimeMillis(), odometroFinal = odometroFinal)
        )
    }
    fun actualizarViaje(v: Viaje) = viewModelScope.launch { db.viajeDao().actualizar(v) }
    fun borrarViaje(v: Viaje) = viewModelScope.launch { db.viajeDao().borrar(v) }

    fun guardarJornada(j: Jornada) = viewModelScope.launch {
        if (j.id == 0L) db.jornadaDao().insertar(j) else db.jornadaDao().actualizar(j)
    }
    fun borrarJornada(j: Jornada) = viewModelScope.launch { db.jornadaDao().borrar(j) }

    fun guardarGasto(g: Gasto) = viewModelScope.launch {
        if (g.id == 0L) db.gastoDao().insertar(g) else db.gastoDao().actualizar(g)
    }
    fun borrarGasto(g: Gasto) = viewModelScope.launch { db.gastoDao().borrar(g) }
}
