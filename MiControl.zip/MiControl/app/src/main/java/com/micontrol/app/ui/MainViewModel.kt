package com.micontrol.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.micontrol.app.data.*
import com.micontrol.app.domain.Calculos
import com.micontrol.app.domain.Recorrido
import com.micontrol.app.gps.Gps
import com.micontrol.app.gps.TrackingService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.time.LocalDate

@OptIn(ExperimentalCoroutinesApi::class)
class MainViewModel(app: Application) : AndroidViewModel(app) {
    /** En true mientras la app está tapada por el PIN. */
    val bloqueado = MutableStateFlow(Ajustes.hayPin(app))

    // ---- Perfil en uso: cada perfil tiene su propia base de datos
    private val _perfil = MutableStateFlow(Perfiles.activo(app))
    val perfil: StateFlow<Perfiles.Perfil> = _perfil
    private val _perfiles = MutableStateFlow(Perfiles.todos(app))
    val perfiles: StateFlow<List<Perfiles.Perfil>> = _perfiles
    /** En true mientras se restaura una copia: las pantallas sueltan la base un momento. */
    private val pausa = MutableStateFlow(false)

    private val db: AppDatabase get() = AppDatabase.get(getApplication(), _perfil.value.id)
    private val dbFlow: Flow<AppDatabase?> =
        combine(_perfil.map { it.id }.distinctUntilChanged(), pausa) { id, p -> if (p) null else AppDatabase.get(app, id) }

    private fun <T> Flow<T>.state(init: T) =
        stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), init)

    private fun <T> lista(f: (AppDatabase) -> Flow<List<T>>): StateFlow<List<T>> =
        dbFlow.flatMapLatest { d -> if (d == null) flowOf(emptyList<T>()) else f(d) }.state(emptyList<T>())

    val viajes = lista { it.viajeDao().todos() }
    val clientes = lista { it.clienteDao().todos() }
    val todasJornadas = lista { it.jornadaDao().todas() }
    val todosGastos = lista { it.gastoDao().todos() }
    val todosAdelantos = lista { it.adelantoDao().todos() }
    val mantenimientos = lista { it.mantenimientoDao().todos() }
    val vencimientos = lista { it.vencimientoDao().todos() }

    fun viaje(id: String) = db.viajeDao().porId(id)
    fun jornadas(id: String) = db.jornadaDao().porViaje(id)
    fun gastos(id: String) = db.gastoDao().porViaje(id)
    fun puntos(id: String) = db.puntoDao().porViaje(id)
    fun paradas(id: String) = db.paradaDao().porViaje(id)
    fun adelantos(id: String) = db.adelantoDao().porViaje(id)

    /** Al iniciar el viaje se guarda la hora de inicio y se abre la primera jornada con esa hora. */
    fun iniciarViaje(v: Viaje, paradas: List<Parada> = emptyList()) = viewModelScope.launch {
        if (v.cliente.isNotBlank()) db.clienteDao().insertar(Cliente(nombre = v.cliente.trim()))
        db.viajeDao().insertar(v)
        if (paradas.isNotEmpty()) db.paradaDao().insertarTodas(paradas)
        db.jornadaDao().insertar(
            Jornada(viajeId = v.id, fecha = LocalDate.now().toString(),
                inicioMin = Calculos.minutoActual(), finMin = Calculos.ABIERTA)
        )
    }

    /** Al finalizar se guarda la hora de fin y se cierra la jornada abierta (las extras se calculan solas). */
    fun finalizarViaje(v: Viaje, odometroFinal: Long) = viewModelScope.launch {
        db.jornadaDao().abiertas(v.id).forEach {
            db.jornadaDao().actualizar(it.copy(finMin = Calculos.minutoActual()))
        }
        db.viajeDao().actualizar(
            v.copy(estado = Viaje.Estado.FINALIZADO, fin = System.currentTimeMillis(), odometroFinal = odometroFinal)
        )
    }

    fun iniciarJornada(viajeId: String) = viewModelScope.launch {
        if (db.jornadaDao().abiertas(viajeId).isEmpty()) {
            db.jornadaDao().insertar(
                Jornada(viajeId = viajeId, fecha = LocalDate.now().toString(),
                    inicioMin = Calculos.minutoActual(), finMin = Calculos.ABIERTA)
            )
        }
    }

    fun finalizarJornada(j: Jornada) = viewModelScope.launch {
        db.jornadaDao().actualizar(j.copy(finMin = Calculos.minutoActual()))
    }

    fun guardarCliente(c: Cliente) = viewModelScope.launch {
        if (c.id == 0L) db.clienteDao().insertar(c) else db.clienteDao().actualizar(c)
    }
    fun borrarCliente(c: Cliente) = viewModelScope.launch { db.clienteDao().borrar(c) }
    fun agregarParada(p: Parada) = viewModelScope.launch { db.paradaDao().insertar(p) }
    fun borrarParada(p: Parada) = viewModelScope.launch { db.paradaDao().borrar(p) }

    fun actualizarViaje(v: Viaje) = viewModelScope.launch { db.viajeDao().actualizar(v) }
    fun borrarViaje(v: Viaje) = viewModelScope.launch { db.viajeDao().borrar(v) }

    fun guardarJornada(j: Jornada) = viewModelScope.launch {
        if (j.id == 0L) db.jornadaDao().insertar(j) else db.jornadaDao().actualizar(j)
    }
    fun borrarJornada(j: Jornada) = viewModelScope.launch { db.jornadaDao().borrar(j) }

    fun guardarGasto(g: Gasto) = viewModelScope.launch {
        if (g.id == 0L) db.gastoDao().insertar(g) else db.gastoDao().actualizar(g)
    }
    fun borrarGasto(g: Gasto) = viewModelScope.launch {
        db.gastoDao().borrar(g)
        g.fotoPath?.let { File(it).delete() }
    }

    fun guardarAdelanto(a: Adelanto) = viewModelScope.launch {
        if (a.id == 0L) db.adelantoDao().insertar(a) else db.adelantoDao().actualizar(a)
    }
    fun borrarAdelanto(a: Adelanto) = viewModelScope.launch { db.adelantoDao().borrar(a) }

    /** Al abrir la app: copia automática si toca y avisos. */
    fun tareasAlAbrir() {
        viewModelScope.launch { com.micontrol.app.work.Tareas.correr(getApplication()) }
    }

    // ---- Control del camión
    fun guardarMantenimiento(m: Mantenimiento) = viewModelScope.launch {
        if (m.id == 0L) db.mantenimientoDao().insertar(m) else db.mantenimientoDao().actualizar(m)
    }
    fun borrarMantenimiento(m: Mantenimiento) = viewModelScope.launch { db.mantenimientoDao().borrar(m) }
    fun guardarVencimiento(v: Vencimiento) = viewModelScope.launch {
        if (v.id == 0L) db.vencimientoDao().insertar(v) else db.vencimientoDao().actualizar(v)
    }
    fun borrarVencimiento(v: Vencimiento) = viewModelScope.launch { db.vencimientoDao().borrar(v) }

    /** Agrega los clientes que no estén ya (por nombre). Devuelve cuántos agregó. */
    fun importarClientes(nuevos: List<Cliente>, alTerminar: (Int) -> Unit) {
        viewModelScope.launch {
            val dao = db.clienteDao()
            val existentes = clientes.value.map { it.nombre.trim().lowercase() }.toMutableSet()
            var agregados = 0
            nuevos.forEach { c ->
                val clave = c.nombre.trim().lowercase()
                if (clave.isNotBlank() && existentes.add(clave)) {
                    dao.insertar(c.copy(nombre = c.nombre.trim()))
                    agregados++
                }
            }
            alTerminar(agregados)
        }
    }

    // ---- Ubicaciones recibidas por WhatsApp (compartir > Mi Control)
    data class Recibida(val cargando: Boolean, val punto: UbicacionLink.Punto?, val texto: String)
    private val _recibida = MutableStateFlow<Recibida?>(null)
    val recibida: StateFlow<Recibida?> = _recibida

    fun recibirUbicacion(texto: String) {
        viewModelScope.launch {
            _recibida.value = Recibida(true, null, texto)
            val clave = Ajustes.claveMapTiler(getApplication<Application>())
            val p = UbicacionLink.resolver(texto, clave)
            val dir = p?.direccion ?: p?.let { Geo.direccion(it.lat, it.lng) }
            val completo = p?.copy(direccion = dir, direccionAprox = p.direccion == null && dir != null)
            _recibida.value = Recibida(false, completo, texto)
        }
    }
    fun descartarRecibida() { _recibida.value = null }

    /** La persona eligió a mano el lugar en el mapa (cuando la búsqueda automática no alcanzó). */
    fun fijarRecibida(lat: Double, lng: Double, direccion: String?, nombre: String?) {
        val texto = _recibida.value?.texto ?: ""
        _recibida.value = Recibida(false, UbicacionLink.Punto(lat, lng, nombre, direccion, manual = true, fuente = "Elegida a mano en el mapa"), texto)
    }

    // ---- Perfiles
    private fun refrescarPerfiles() {
        val app = getApplication<Application>()
        _perfiles.value = Perfiles.todos(app)
        _perfil.value = Perfiles.activo(app)
    }

    fun cambiarPerfil(id: String) {
        val app = getApplication<Application>()
        if (id == _perfil.value.id) return
        if (TrackingService.siguiendo.value != null) Gps.detener(app)
        Perfiles.activar(app, id)
        _recibida.value = null
        refrescarPerfiles()
    }

    fun crearPerfil(nombre: String, camion: String, empresa: String) {
        val nuevo = Perfiles.crear(getApplication(), nombre.trim(), camion.trim(), empresa.trim())
        cambiarPerfil(nuevo.id)
    }

    fun guardarPerfil(p: Perfiles.Perfil) {
        Perfiles.actualizar(getApplication(), p)
        refrescarPerfiles()
    }

    /** Borra un perfil y todos sus datos. Si es el que está en uso, primero pasa a otro. */
    fun eliminarPerfil(id: String): Boolean {
        val otros = Perfiles.todos(getApplication()).filter { it.id != id }
        if (otros.isEmpty()) return false
        if (id == _perfil.value.id) cambiarPerfil(otros.first().id)
        viewModelScope.launch {
            delay(600)   // deja que las pantallas suelten la base vieja antes de borrarla
            withContext(Dispatchers.IO) { Perfiles.eliminar(getApplication(), id) }
            refrescarPerfiles()
        }
        return true
    }

    // ---- Copia de seguridad
    fun guardarCopia(alTerminar: (String) -> Unit) {
        val perfil = _perfil.value
        viewModelScope.launch {
            val msg = withContext(Dispatchers.IO) { Respaldo.exportar(getApplication(), perfil) }
            alTerminar(msg)
        }
    }

    fun restaurarCopia(uri: android.net.Uri, alTerminar: (String) -> Unit) {
        val app = getApplication<Application>()
        val perfil = _perfil.value
        viewModelScope.launch {
            if (TrackingService.siguiendo.value != null) Gps.detener(app)
            pausa.value = true
            delay(400)
            val error = withContext(Dispatchers.IO) { Respaldo.restaurar(app, perfil.id, uri) }
            pausa.value = false
            alTerminar(error ?: "Copia restaurada. Ya están tus datos.")
        }
    }

    // ---- Actualizaciones de la app
    private val _actualizacion = MutableStateFlow<Actualizaciones.Nueva?>(null)
    val actualizacion: StateFlow<Actualizaciones.Nueva?> = _actualizacion

    /** Busca una versión nueva. Sola, como mucho una vez cada 12 horas; a mano, siempre. */
    fun buscarActualizacion(manual: Boolean, alTerminar: (String?) -> Unit = {}) {
        val app = getApplication<Application>()
        if (!manual && System.currentTimeMillis() - Ajustes.ultimaBusqueda(app) < 12 * 3600 * 1000L) return
        viewModelScope.launch {
            when (val r = Actualizaciones.buscar()) {
                is Actualizaciones.Resultado.Hay -> {
                    Ajustes.marcarBusqueda(app)
                    _actualizacion.value = r.n
                    alTerminar(null)
                }
                Actualizaciones.Resultado.AlDia -> {
                    Ajustes.marcarBusqueda(app)
                    alTerminar("Ya tenés la última versión.")
                }
                Actualizaciones.Resultado.Error ->
                    alTerminar(if (manual) "No se pudo comprobar. Revisá tu conexión a internet." else null)
            }
        }
    }
    fun cerrarActualizacion() { _actualizacion.value = null }

    /** Agrega varias paradas al final, en el orden dado. */
    fun agregarParadas(viajeId: String, lugares: List<Recorrido.Lugar>) = viewModelScope.launch {
        var n = db.paradaDao().cuenta(viajeId)
        lugares.forEach {
            db.paradaDao().insertar(Parada(viajeId = viajeId, orden = n++, nombre = it.nombre, lat = it.lat, lng = it.lng))
        }
    }

    fun paradaAlFinal(viajeId: String, nombre: String, lat: Double, lng: Double) = viewModelScope.launch {
        val n = db.paradaDao().cuenta(viajeId)
        db.paradaDao().insertar(Parada(viajeId = viajeId, orden = n, nombre = nombre, lat = lat, lng = lng))
    }
}
