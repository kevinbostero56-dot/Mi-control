package com.micontrol.app.domain

import com.micontrol.app.data.Adelanto
import com.micontrol.app.data.Cliente
import com.micontrol.app.data.Orden
import com.micontrol.app.data.Gasto
import com.micontrol.app.data.Jornada
import com.micontrol.app.data.Viaje
import java.text.Normalizer
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import kotlin.math.abs

/**
 * Asistente de Mi Control. Entiende frases en español, responde con los datos del teléfono
 * y funciona sin internet. No inventa nada: todo sale de los viajes, gastos y jornadas cargados.
 */
object Asistente {
    sealed class Accion {
        data class NuevoGasto(val viajeId: String, val categoria: String, val centavos: Long, val descripcion: String, val litros: Double? = null) : Accion()
        data class NuevoAdelanto(val viajeId: String, val centavos: Long, val descripcion: String) : Accion()
    }

    class Lugar(val nombre: String, val lat: Double, val lng: Double)

    class Respuesta(val texto: String, val accion: Accion? = null, val lugares: List<Lugar> = emptyList())

    class Datos(
        val viajes: List<Viaje>,
        val jornadas: List<Jornada>,
        val gastos: List<Gasto>,
        val adelantos: List<Adelanto>,
        val clientes: List<Cliente> = emptyList(),
        val ubicacion: Pair<Double, Double>? = null
    )

    private class Alcance(
        val nombre: String,
        val gastos: List<Gasto>,
        val jornadas: List<Jornada>,
        val adelantos: List<Adelanto>
    )

    const val SALUDO = "¡Hola! Soy tu asistente. Puedo contestarte y anotar cosas por vos. Probá así:\n" +
        "• ¿Cuánto gasté?\n" +
        "• Horas extras del mes\n" +
        "• ¿Cuánto me deben?\n" +
        "• Km del último viaje\n" +
        "• Gasté 15000 en nafta\n" +
        "• Me dieron 50000 de adelanto\n" +
        "• Hoteles cerca (los que guardaste como \"Hotel / cochera\")"

    private fun limpiar(t: String): String =
        Normalizer.normalize(t.lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")

    private fun tiene(t: String, vararg palabras: String): Boolean = palabras.any { t.contains(it) }

    private fun dia(ms: Long): LocalDate = Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).toLocalDate()

    /** Primer importe que aparece en la frase, en centavos. Entiende 5000, 1.500, 1.500,50 y "5 mil". */
    private fun monto(t: String): Long? {
        val m = Regex("""\d[\d.,]*""").find(t) ?: return null
        var s = m.value.trimEnd('.', ',')
        s = if (Regex("""\d{1,3}(\.\d{3})+(,\d+)?""").matches(s)) {
            s.replace(".", "").replace(',', '.')
        } else {
            s.replace(',', '.')
        }
        var d = s.toDoubleOrNull() ?: return null
        val resto = t.substring(m.range.last + 1).trimStart()
        if (resto.startsWith("mil") || resto.startsWith("luca")) d *= 1000.0
        return if (d > 0) Math.round(d * 100.0) else null
    }

    private fun categoria(t: String): String = when {
        tiene(t, "nafta", "gasoil", "combustible", "diesel", "ypf", "shell", "axion", "gnc") -> "Combustible"
        tiene(t, "peaje", "telepeaje") -> "Peajes"
        tiene(t, "comida", "almuerzo", "cena", "desayuno", "restaurante", "sandwich", "bebida", "cafe", "milanesa") -> "Comida"
        tiene(t, "hotel", "alojamiento", "hospedaje", "hostel", "dormi") -> "Alojamiento"
        tiene(t, "repar", "arreglo", "gomeria", "cubierta", "neumatico", "mecanico", "taller", "aceite", "service") -> "Reparaciones"
        else -> "Otros"
    }

    private fun alcance(t: String, d: Datos): Alcance {
        val hoy = LocalDate.now()
        val activo = d.viajes.firstOrNull { it.estado == Viaje.Estado.EN_CURSO }
        val ultimo = d.viajes.firstOrNull { it.estado == Viaje.Estado.FINALIZADO }
        val todo = Alcance("en total", d.gastos, d.jornadas, d.adelantos)

        fun delViaje(v: Viaje, nombre: String) = Alcance(
            nombre,
            d.gastos.filter { it.viajeId == v.id },
            d.jornadas.filter { it.viajeId == v.id },
            d.adelantos.filter { it.viajeId == v.id }
        )

        return when {
            tiene(t, "hoy") -> Alcance(
                "de hoy",
                d.gastos.filter { dia(it.fechaHora) == hoy },
                d.jornadas.filter { it.fecha == hoy.toString() },
                d.adelantos.filter { dia(it.fechaHora) == hoy }
            )
            tiene(t, "semana") -> {
                val desde = hoy.minusDays(6)
                Alcance(
                    "de los últimos 7 días",
                    d.gastos.filter { !dia(it.fechaHora).isBefore(desde) },
                    d.jornadas.filter { it.fecha >= desde.toString() },
                    d.adelantos.filter { !dia(it.fechaHora).isBefore(desde) }
                )
            }
            Regex("""\bmes(es)?\b""").containsMatchIn(t) -> {
                val prefijo = "%04d-%02d".format(hoy.year, hoy.monthValue)
                Alcance(
                    "de este mes",
                    d.gastos.filter { dia(it.fechaHora).year == hoy.year && dia(it.fechaHora).monthValue == hoy.monthValue },
                    d.jornadas.filter { it.fecha.startsWith(prefijo) },
                    d.adelantos.filter { dia(it.fechaHora).year == hoy.year && dia(it.fechaHora).monthValue == hoy.monthValue }
                )
            }
            tiene(t, "ultimo viaje", "viaje anterior", "viaje pasado") ->
                ultimo?.let { delViaje(it, "del último viaje (${it.nombre})") } ?: todo
            tiene(t, "este viaje", "viaje actual", "en curso", "ahora") ->
                activo?.let { delViaje(it, "del viaje en curso (${it.nombre})") } ?: todo
            tiene(t, "total", "todos", "siempre", "historico", "acumulado") -> todo
            activo != null -> delViaje(activo, "del viaje en curso (${activo.nombre})")
            ultimo != null -> delViaje(ultimo, "del último viaje (${ultimo.nombre})")
            else -> todo
        }
    }

    fun responder(texto: String, d: Datos): Respuesta {
        val t = limpiar(texto)
        val activo = d.viajes.firstOrNull { it.estado == Viaje.Estado.EN_CURSO }
        val importe = monto(t)
        val esPregunta = t.contains('?') || tiene(t, "cuanto", "cuantos", "cuantas")
        val pideAdelanto = tiene(t, "recibi", "me dieron", "me dio", "me dejaron", "me pasaron", "me depositaron", "adelanto", "viatico")
        val pideGasto = tiene(t, "gaste", "pague", "compre", "puse", "cargue", "gasto de", "anota gasto", "anotar gasto", "agrega gasto", "agregar gasto")

        // "Hoy cargué 200 litros por 350000": los litros no son plata
        val mLitros = Regex("""(\d+(?:[.,]\d+)?)\s*(?:litros|litro|lts|lt)\b""").find(t)
        if (!esPregunta && mLitros != null && (pideGasto || tiene(t, "cargue", "carga", "llene"))) {
            val litros = mLitros.groupValues[1].replace(',', '.').toDoubleOrNull()
            val sinLitros = t.removeRange(mLitros.range)
            val plata = monto(sinLitros)
            if (activo == null) return Respuesta("Para anotarlo necesito un viaje en curso. Iniciá el viaje desde Inicio y volvé a decírmelo.")
            if (litros == null || plata == null) {
                return Respuesta("Entendí ${mLitros.groupValues[1]} litros, pero no sé cuánto pagaste. Decímelo así: \"Cargué ${mLitros.groupValues[1]} litros por 350.000\".")
            }
            return Respuesta(
                "Anoto combustible: ${"%.1f".format(java.util.Locale("es", "AR"), litros)} L por ${Calculos.pesos(plata)}. ¿Lo guardo en \"${activo.nombre}\"?",
                Accion.NuevoGasto(activo.id, "Combustible", plata, texto.trim().take(80), litros)
            )
        }
        if (!esPregunta && importe == null && pideGasto && !tiene(t, "litro")) {
            return Respuesta("Me falta el importe. Decímelo así: \"Gasté 35 lucas en comida\" o \"Gasté 12.855,25 en peaje\".")
        }

        // Anotar cosas: siempre pide confirmación antes de guardar
        if (!esPregunta && importe != null && (pideAdelanto || pideGasto)) {
            if (activo == null) {
                return Respuesta("Para anotarlo necesito un viaje en curso. Iniciá el viaje desde Inicio y volvé a decírmelo.")
            }
            val detalle = texto.trim().take(80)
            return if (pideAdelanto) {
                Respuesta(
                    "Anoto plata recibida de la empresa: ${Calculos.pesos(importe)}. ¿Lo guardo en \"${activo.nombre}\"?",
                    Accion.NuevoAdelanto(activo.id, importe, detalle)
                )
            } else {
                val cat = categoria(t)
                Respuesta(
                    "Anoto un gasto de ${Calculos.pesos(importe)} en $cat. ¿Lo guardo en \"${activo.nombre}\"?",
                    Accion.NuevoGasto(activo.id, cat, importe, detalle)
                )
            }
        }

        if (tiene(t, "hotel", "cochera", "dormir", "hospedaje", "alojamiento", "donde paro", "donde duermo")) {
            return hoteles(d)
        }

        val a = alcance(t, d)
        if (esPregunta && tiene(t, "gast", "cuanto") && categoria(t) != "Otros" && !tiene(t, "extra", "km", "kilomet", "hora")) {
            val cat = categoria(t)
            val delaCat = a.gastos.filter { it.categoria == cat }
            return Respuesta(
                if (delaCat.isEmpty()) "No hay gastos de $cat ${a.nombre}."
                else "Gastos de $cat ${a.nombre}: ${Calculos.pesos(delaCat.sumOf { it.importeCentavos })} (${delaCat.size} ${if (delaCat.size == 1) "carga" else "cargas"})."
            )
        }
        return when {
            tiene(t, "extra") -> horasExtras(a)
            tiene(t, "saldo", "deben", "debo", "devolver", "rendicion", "rendir", "a mano", "plata de la empresa") -> saldo(a)
            tiene(t, "consumo", "litros", "rinde", "rendimiento", "l/100") -> consumo(d)
            tiene(t, "km", "kilomet", "recorr") -> km(d)
            tiene(t, "horas", "trabaj", "jornada") -> horas(a)
            tiene(t, "gast", "plata", "pesos", "costo") -> gastos(a)
            tiene(t, "resumen", "como voy", "estado", "novedad") -> resumen(a, d)
            tiene(t, "ubicacion", "whatsapp", "mapa", "direccion", "pegar") -> Respuesta(
                "Para cargar una ubicación de WhatsApp: mantené apretado el mensaje, tocá Copiar, abrí Mi Control y tocá " +
                    "\"📍 Pegar ubicación de WhatsApp\" en Inicio. Si solo trae la dirección, el mapa se abre solo para que " +
                    "pongas el punto exacto. También podés compartir la ubicación directo a Mi Control."
            )
            else -> Respuesta(SALUDO)
        }
    }

    private fun hoteles(d: Datos): Respuesta {
        val hoteles = d.clientes.filter { it.tipo.startsWith("Hotel") && it.lat != null && it.lng != null }
        if (hoteles.isEmpty()) {
            return Respuesta(
                "Todavía no tenés hoteles guardados. Andá a Lugares, tocá un lugar y ponele el tipo \"Hotel / cochera\" " +
                    "(o agregá uno nuevo con ese tipo). Después preguntame de nuevo."
            )
        }
        val yo = d.ubicacion
            ?: return Respuesta(
                "No tengo tu ubicación todavía. Activá el GPS, abrí Inicio un momento y volvé a preguntarme. " +
                    "Tenés ${hoteles.size} ${if (hoteles.size == 1) "hotel guardado" else "hoteles guardados"}."
            )
        val cerca = hoteles.map { it to Orden.metros(yo, (it.lat ?: 0.0) to (it.lng ?: 0.0)) }.sortedBy { it.second }.take(5)
        val txt = cerca.joinToString("\n") { (h, m) ->
            val km = m / 1000.0
            val dist = if (km < 1) "${m.toInt()} m" else "${"%.0f".format(java.util.Locale.US, km)} km"
            "• ${h.nombre} — a $dist (en línea recta)"
        }
        return Respuesta(
            "Hoteles guardados más cerca de donde estás:\n$txt\nTocá un botón para abrirlo en Google Maps.",
            null,
            cerca.map { Lugar(it.first.nombre, it.first.lat ?: 0.0, it.first.lng ?: 0.0) }
        )
    }

    private fun horasExtras(a: Alcance): Respuesta {
        if (a.jornadas.isEmpty()) return Respuesta("No hay jornadas cargadas ${a.nombre}.")
        val extras = Calculos.extrasTotales(a.jornadas)
        val dias = a.jornadas.count { Calculos.extras(Calculos.minutosTrabajados(it)) > 0 }
        return Respuesta(
            "Horas extras ${a.nombre}: ${Calculos.hhmm(extras)} h, en $dias ${if (dias == 1) "día" else "días"} " +
                "con más de 9 horas trabajadas."
        )
    }

    private fun horas(a: Alcance): Respuesta {
        if (a.jornadas.isEmpty()) return Respuesta("No hay jornadas cargadas ${a.nombre}.")
        val total = a.jornadas.sumOf { Calculos.minutosTrabajados(it) }
        val extras = Calculos.extrasTotales(a.jornadas)
        return Respuesta(
            "Horas trabajadas ${a.nombre}: ${Calculos.hhmm(total)} h (de las cuales ${Calculos.hhmm(extras)} h son extras)."
        )
    }

    private fun gastos(a: Alcance): Respuesta {
        if (a.gastos.isEmpty()) return Respuesta("No hay gastos cargados ${a.nombre}.")
        val total = a.gastos.sumOf { it.importeCentavos }
        val porCategoria = a.gastos
            .groupBy { it.categoria }
            .map { (c, l) -> c to l.sumOf { it.importeCentavos } }
            .sortedByDescending { it.second }
        val detalle = porCategoria.joinToString("\n") { "• ${it.first}: ${Calculos.pesos(it.second)}" }
        return Respuesta("Gastos ${a.nombre}: ${Calculos.pesos(total)} (${a.gastos.size} en total).\n$detalle")
    }

    private fun saldo(a: Alcance): Respuesta {
        val recibido = a.adelantos.sumOf { it.importeCentavos }
        val gastado = a.gastos.sumOf { it.importeCentavos }
        val s = Calculos.saldoEmpresa(a.adelantos, a.gastos)
        val conclusion = when {
            s > 0 -> "Tenés que devolver a la empresa ${Calculos.pesos(s)}."
            s < 0 -> "La empresa te debe ${Calculos.pesos(abs(s))}."
            else -> "Estás a mano con la empresa."
        }
        return Respuesta(
            "Rendición ${a.nombre}:\n• Plata recibida: ${Calculos.pesos(recibido)}\n• Gastos: ${Calculos.pesos(gastado)}\n$conclusion"
        )
    }

    /** Los km oficiales salen SOLO del odómetro (final − inicial), nunca del GPS. */
    private fun km(d: Datos): Respuesta {
        val terminados = d.viajes.filter { it.estado == Viaje.Estado.FINALIZADO }
        val activo = d.viajes.firstOrNull { it.estado == Viaje.Estado.EN_CURSO }
        val lineas = mutableListOf<String>()
        val ultimo = terminados.firstOrNull()
        if (ultimo != null) {
            val k = Calculos.kmViajeTxt(ultimo)
            if (k != null) lineas.add("• Último viaje (${ultimo.nombre}): $k km")
        }
        if (terminados.size > 1) {
            val suma = terminados.sumOf { Calculos.kmDecimas(it) ?: 0L }
            lineas.add("• En total: ${Calculos.decimasTxt(suma)} km en ${terminados.size} viajes")
        }
        if (activo != null) {
            lineas.add("• El viaje en curso empezó con el odómetro en ${Calculos.decimasTxt(Calculos.odoDecimas(activo.odometroInicial, activo.odoInicialDec))} km; los km se calculan al finalizar.")
        }
        if (lineas.isEmpty()) return Respuesta("Todavía no hay viajes con kilómetros cargados.")
        return Respuesta("Kilómetros (según el odómetro):\n" + lineas.joinToString("\n"))
    }

    private fun consumo(d: Datos): Respuesta {
        val v = d.viajes.firstOrNull { it.estado == Viaje.Estado.FINALIZADO }
            ?: return Respuesta("Necesito un viaje finalizado para calcular el consumo con los km del odómetro.")
        val km = Calculos.kmDecimas(v)?.let { it / 10.0 }
        val c = Calculos.consumo(d.gastos.filter { it.viajeId == v.id }, km, 0.0)
            ?: return Respuesta("En el último viaje (${v.nombre}) no hay litros cargados. Al anotar un gasto de Combustible, completá los litros.")
        val l100 = c.lPor100 ?: return Respuesta("Consumo pendiente: el último viaje no tiene kilómetros de odómetro para calcularlo.")
        return Respuesta(
            "Consumo del último viaje (${v.nombre}):\n• ${"%.1f".format(c.litros)} L en ${"%.0f".format(c.km)} km\n" +
                "• ${"%.1f".format(l100)} L cada 100 km\n• ${"%.2f".format(c.kmPorLitro ?: 0.0)} km por litro\n" +
                "• Combustible: ${Calculos.pesos(c.costoCentavos)}"
        )
    }

    private fun resumen(a: Alcance, d: Datos): Respuesta {
        val gastado = a.gastos.sumOf { it.importeCentavos }
        val extras = Calculos.extrasTotales(a.jornadas)
        val s = Calculos.saldoEmpresa(a.adelantos, a.gastos)
        val saldoTxt = when {
            s > 0 -> "a devolver ${Calculos.pesos(s)}"
            s < 0 -> "la empresa te debe ${Calculos.pesos(abs(s))}"
            else -> "a mano"
        }
        return Respuesta(
            "Resumen ${a.nombre}:\n• Gastos: ${Calculos.pesos(gastado)}\n• Horas extras: ${Calculos.hhmm(extras)} h\n" +
                "• Saldo con la empresa: $saldoTxt\n• Viajes cargados: ${d.viajes.size}"
        )
    }
}
