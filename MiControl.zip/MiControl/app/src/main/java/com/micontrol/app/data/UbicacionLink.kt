package com.micontrol.app.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder

/** Lee ubicaciones de los links que pasan por WhatsApp (Google Maps, geo:, coordenadas sueltas). */
object UbicacionLink {
    data class Punto(val lat: Double, val lng: Double, val nombre: String?)

    private val patrones = listOf(
        Regex("""[?&](?:q|ll|query|destination|daddr)=(-?\d{1,3}\.\d+),\s*(-?\d{1,3}\.\d+)"""),
        Regex("""@(-?\d{1,3}\.\d+),(-?\d{1,3}\.\d+)"""),
        Regex("""!3d(-?\d{1,3}\.\d+)!4d(-?\d{1,3}\.\d+)"""),
        Regex("""geo:(-?\d{1,3}\.\d+),(-?\d{1,3}\.\d+)"""),
        Regex("""(-?\d{1,3}\.\d{3,})\s*[,;]\s*(-?\d{1,3}\.\d{3,})""")
    )
    private val lugar = Regex("""/maps/place/([^/@?]+)""")
    private val enlaces = Regex("""https?://[^\s"'<>]+""")

    private fun decodificar(t: String) = try { URLDecoder.decode(t, "UTF-8") } catch (e: Exception) { t }

    /** Busca coordenadas en el texto, sin usar internet. */
    fun extraer(texto: String): Punto? {
        val t = decodificar(texto)
        for (r in patrones) {
            val m = r.find(t) ?: continue
            val lat = m.groupValues[1].toDoubleOrNull() ?: continue
            val lng = m.groupValues[2].toDoubleOrNull() ?: continue
            if (lat in -90.0..90.0 && lng in -180.0..180.0) {
                val nombre = lugar.find(t)?.groupValues?.get(1)?.replace('+', ' ')?.trim()?.ifBlank { null }
                return Punto(lat, lng, nombre)
            }
        }
        return null
    }

    /** Sigue los redirects de un link corto (maps.app.goo.gl) hasta encontrar las coordenadas. */
    private fun seguir(url: String): Punto? {
        var actual = url
        repeat(6) {
            val c = URL(actual).openConnection() as HttpURLConnection
            try {
                c.instanceFollowRedirects = false
                c.connectTimeout = 8000
                c.readTimeout = 8000
                c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) MiControl")
                val codigo = c.responseCode
                if (codigo in 300..399) {
                    val destino = c.getHeaderField("Location") ?: return null
                    actual = URL(URL(actual), destino).toString()
                    extraer(actual)?.let { return it }
                } else {
                    val cuerpo = c.inputStream.bufferedReader().use { it.readText().take(300_000) }
                    return extraer(actual) ?: extraer(cuerpo)
                }
            } finally {
                c.disconnect()
            }
        }
        return null
    }

    suspend fun resolver(texto: String): Punto? = withContext(Dispatchers.IO) {
        extraer(texto)?.let { return@withContext it }
        for (m in enlaces.findAll(texto)) {
            val p = try { seguir(m.value) } catch (e: Exception) { null }
            if (p != null) return@withContext p
        }
        null
    }
}
