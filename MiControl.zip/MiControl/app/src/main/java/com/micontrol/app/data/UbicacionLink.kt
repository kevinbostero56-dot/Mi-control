package com.micontrol.app.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder

/** Lee ubicaciones de lo que se pasa por WhatsApp: links de Google Maps, geo:, coordenadas sueltas, nombres de lugar. */
object UbicacionLink {
    data class Punto(
        val lat: Double,
        val lng: Double,
        val nombre: String? = null,
        val direccion: String? = null,
        val aproximada: Boolean = false,  // true si se buscó por el nombre o la dirección
        val zona: Boolean = false,        // true si solo se encontró la localidad, no la dirección
        val consulta: String? = null,     // lo que se buscó
        val manual: Boolean = false,      // true si la persona la eligió a mano en el mapa
        val fuente: String = "",          // de dónde salió la ubicación (se muestra en pantalla)
        val vista: Boolean = false,       // true si son las coordenadas del centro del mapa del link (puede diferir del pin)
        val direccionAprox: Boolean = false // true si la dirección se averiguó por las coordenadas (OpenStreetMap)
    )

    private const val N = """(-?\d{1,3}\.\d+)"""
    private const val PIN = "Pin exacto de Google Maps"

    private class Regla(val rango: Int, val fuente: String, val vista: Boolean, val regex: Regex)
    private class Hit(val lat: Double, val lng: Double, val rango: Int, val fuente: String, val vista: Boolean)

    /**
     * Formas de encontrar coordenadas, de la más precisa (rango 0) a la menos precisa.
     * Ojo: "@lat,lng" y "center=" son el CENTRO DE LA VISTA del mapa, no el pin: por eso van abajo.
     * El pin de un lugar de Google Maps viene como "!3d<lat>!4d<lng>" o en "/place/<lat>,<lng>".
     */
    private val reglas = listOf(
        Regla(0, PIN, false, Regex("""!3d$N!4d$N""")),
        Regla(1, PIN, false, Regex("""/place/\+?$N\s*,\s*\+?$N""")),
        Regla(2, "Coordenadas del link", false, Regex("""[?&](?:q|ll|query|destination|daddr)=(?:loc:)?\s*$N\s*,\s*$N""")),
        Regla(3, "Coordenadas del mensaje", false, Regex("""geo:$N\s*,\s*$N""")),
        Regla(4, "Coordenadas del link", false, Regex("""[?&]mlat=$N&(?:amp;)?mlon=$N""")),
        Regla(5, "Centro del mapa del link", true, Regex("""[?&](?:center|sll)=(?:loc:)?\s*$N\s*,\s*$N""")),
        Regla(5, "Centro del mapa del link", true, Regex("""@$N\s*,\s*$N""")),
        Regla(6, "Coordenadas del mapa", false, Regex("""#map=\d+/$N/$N""")),
        Regla(7, "Coordenadas escritas", false, Regex("""$N\s*[,;]\s*$N"""))
    )

    /** La mejor coordenada del texto (la de menor rango). */
    private fun buscarCoordenadas(t: String, maxRango: Int = 9): Hit? {
        var mejor: Hit? = null
        for (r in reglas) {
            if (r.rango > maxRango) continue
            for (m in r.regex.findAll(t)) {
                val lat = m.groupValues[1].toDoubleOrNull() ?: continue
                val lng = m.groupValues[2].toDoubleOrNull() ?: continue
                if (lat !in -90.0..90.0 || lng !in -180.0..180.0 || (lat == 0.0 && lng == 0.0)) continue
                val actual = mejor
                if (actual == null || r.rango < actual.rango) mejor = Hit(lat, lng, r.rango, r.fuente, r.vista)
                break
            }
        }
        return mejor
    }

    private val geoQ = Regex("""geo:[^?\s]*\?(?:[^\s&]*&)*q=([^&\s]+)""")
    private val urlQ = Regex("""[?&](?:q|query|destination|daddr|address)=([^&\s]+)""")
    private val codigoPostal = Regex("""(?i)(cp\s*)?[A-Z]?\d{4}[A-Z]{0,3}""")
    private val lugar = Regex("""/maps/place/([^/@?]+)""")
    private val etiquetaGeo = Regex("""geo:\S*\(([^)]{1,80})\)""")
    private val consultaGeo = Regex("""geo:[^?\s]*\?(?:[^\s]*&)?q=([^&\s]+)""")
    private val enlaces = Regex("""https?://[^\s"'<>]+""")
    private val lineaInutil = Regex("""(?i)(mi )?(ubicaci[oó]n|location)( en vivo)?[:\s]*""")
    private val lineaConCoordenadas = Regex(""".*-?\d{1,3}\.\d+\s*,\s*-?\d{1,3}\.\d+.*""")

    /** Coordenadas exactas (pin) que ya vienen escritas en el texto o link, sin usar internet. */
    fun coordenadasDirectas(texto: String): Pair<Double, Double>? =
        buscarCoordenadas(decodificar(texto), 2)?.let { it.lat to it.lng }

    private fun decodificar(t: String) = try { URLDecoder.decode(t, "UTF-8") } catch (e: Exception) { t }

    /** Texto de búsqueda de un geo:?q=... (lo que manda WhatsApp cuando el lugar no trae coordenadas). */
    fun consultaDeTexto(texto: String): String? {
        val m = consultaGeo.find(texto) ?: return null
        val q = decodificar(m.groupValues[1]).replace(Regex("""\([^)]*\)\s*$"""), "").trim()
        return q.ifBlank { null }
    }

    /** Partes de una dirección separadas por coma, sin el código postal ni "Argentina". */
    fun partes(q: String): List<String> = q.split(",").map { it.trim() }.filter {
        it.isNotBlank() && !it.matches(Regex("""(?i)(cp|c\.p\.)\s*\d+""")) && !it.equals("Argentina", true)
    }

    /** Nombre y dirección tal como vienen en el mensaje (si vienen). */
    private fun nombreYDireccion(t: String): Pair<String?, String?> {
        etiquetaGeo.find(t)?.groupValues?.get(1)?.trim()?.takeIf { it.isNotBlank() }?.let { return it to null }
        lugar.find(t)?.groupValues?.get(1)?.replace('+', ' ')?.trim()
            ?.takeIf { it.isNotBlank() && !it.matches(soloNumeros) }?.let { return it to null }
        val lineas = t.lines()
            .map { it.trim().trim('*', '_', '~').removePrefix("📍").trim() }
            .filter {
                it.isNotBlank() && !it.startsWith("http", true) && !it.startsWith("geo:", true) &&
                    !it.contains("maps.") && !lineaInutil.matches(it) && !lineaConCoordenadas.matches(it)
            }
        return lineas.firstOrNull() to lineas.drop(1).joinToString(", ").ifBlank { null }
    }

    /** Busca coordenadas en el texto, sin usar internet. */
    fun extraer(texto: String): Punto? {
        val t = decodificar(texto)
        val h = buscarCoordenadas(t) ?: return null
        val (nombre, direccion) = nombreYDireccion(t)
        return Punto(h.lat, h.lng, nombre, direccion, fuente = h.fuente, vista = h.vista)
    }

    /** En el contenido de una página solo se aceptan formas seguras (nada de números sueltos). */
    private fun buscarEnCuerpo(cuerpo: String): Hit? = buscarCoordenadas(decodificar(cuerpo), 5)

    /** Dirección o nombre que viene como texto, por ejemplo geo:?q=Calle 123, Ciudad. */
    private fun consultaTexto(texto: String): String? {
        val crudo = geoQ.find(texto)?.groupValues?.get(1) ?: urlQ.find(texto)?.groupValues?.get(1) ?: return null
        val t = decodificar(crudo).replace(Regex("""\([^)]*\)\s*$"""), "").trim()
        if (t.isBlank() || reglas.any { it.regex.containsMatchIn(t) }) return null
        return t
    }

    /** Si pegaron una dirección suelta (sin links), se usa tal cual. */
    private fun textoPlano(texto: String): String? {
        val lineas = texto.lines().map { it.trim() }.filter { it.isNotBlank() && !it.startsWith("http", true) }
        val t = lineas.take(2).joinToString(", ")
        return if (t.isBlank() || t.length > 200) null else t
    }

    /** Cuanto más bajo, más precisa la ubicación encontrada. */
    private fun nivel(tipo: String?): Int = when (tipo) {
        "address", "poi" -> 0
        "street" -> 1
        null -> 2
        "neighbourhood" -> 3
        "locality" -> 4
        "municipality", "joint_municipality" -> 5
        else -> 6
    }

    /** Prueba varias versiones de la dirección y se queda con el resultado más preciso. */
    private suspend fun buscarDireccion(consulta: String, clave: String): Pair<Geo.Lugar, Int>? {
        val partes = consulta.split(",").map { it.trim() }.filter { it.isNotBlank() }
        val sinCp = partes.filterNot { codigoPostal.matches(it) }
        val intentos = LinkedHashSet<String>()
        intentos.add(partes.joinToString(", "))
        intentos.add(sinCp.joinToString(", "))
        if (sinCp.size > 1) intentos.add(sinCp.drop(1).joinToString(", "))
        if (sinCp.size >= 3) intentos.add((listOf(sinCp.first()) + sinCp.takeLast(2)).joinToString(", "))
        if (sinCp.size > 3) intentos.add(sinCp.takeLast(3).joinToString(", "))
        var mejor: Pair<Geo.Lugar, Int>? = null
        for (q in intentos) {
            if (q.isBlank()) continue
            val l = Geo.geocodificar(q, clave) ?: continue
            val n = nivel(l.tipo)
            if (mejor == null || n < mejor.second) mejor = l to n
            if (n <= 0) break
        }
        return mejor
    }

    private class Hallazgo(val hit: Hit?, val nombreLugar: String?)

    private val soloNumeros = Regex("""[-\d.,\s+]+""")

    /**
     * Sigue los redirects de un link corto (maps.app.goo.gl). Va juntando coordenadas y se queda con la más
     * precisa (el pin). Si solo aparece el centro del mapa, sigue mirando la página buscando el pin.
     */
    private fun seguir(url: String): Hallazgo {
        var actual = url
        var nombreLugar: String? = lugar.find(decodificar(url))?.groupValues?.get(1)?.replace('+', ' ')?.trim()
            ?.takeIf { it.isNotBlank() && !it.matches(soloNumeros) }
        var mejorHit: Hit? = null
        repeat(8) {
            val c = URL(actual).openConnection() as HttpURLConnection
            try {
                c.instanceFollowRedirects = false
                c.connectTimeout = 8000
                c.readTimeout = 8000
                c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36")
                c.setRequestProperty("Accept-Language", "es-AR,es;q=0.9")
                val codigo = c.responseCode
                if (codigo in 300..399) {
                    val destino = c.getHeaderField("Location") ?: return Hallazgo(mejorHit, nombreLugar)
                    actual = URL(URL(actual), destino).toString()
                    val dec = decodificar(actual)
                    val h = buscarCoordenadas(dec)
                    val previo = mejorHit
                    if (h != null && (previo == null || h.rango < previo.rango)) mejorHit = h
                    val ahora = mejorHit
                    if (ahora != null && ahora.rango <= 2) return Hallazgo(ahora, nombreLugar)
                    lugar.find(dec)?.groupValues?.get(1)?.trim()
                        ?.takeIf { it.isNotBlank() && !it.matches(soloNumeros) }?.let { nombreLugar = it }
                } else {
                    val cuerpo = try {
                        c.inputStream.bufferedReader().use { it.readText().take(400_000) }
                    } catch (e: Exception) {
                        ""
                    }
                    for (h in listOf(buscarCoordenadas(decodificar(actual)), buscarEnCuerpo(cuerpo))) {
                        val previo = mejorHit
                        if (h != null && (previo == null || h.rango < previo.rango)) mejorHit = h
                    }
                    return Hallazgo(mejorHit, nombreLugar)
                }
            } finally {
                c.disconnect()
            }
        }
        return Hallazgo(mejorHit, nombreLugar)
    }

    /**
     * Devuelve la ubicación que haya en el texto o link. Con coordenadas en el link queda EXACTA (el pin de Google).
     * Si solo viene una dirección o un nombre, la busca y marca el resultado como aproximado.
     */
    suspend fun resolver(texto: String, claveMapTiler: String = ""): Punto? = withContext(Dispatchers.IO) {
        val decodificado = decodificar(texto)
        val (nombreTexto, direccionTexto) = nombreYDireccion(decodificado)

        // 1) Coordenadas claras en el mismo texto (pin, ?q=lat,lng, geo:lat,lng): no hace falta internet
        val directo = buscarCoordenadas(decodificado)
        if (directo != null && directo.rango <= 4) {
            return@withContext Punto(directo.lat, directo.lng, nombreTexto, direccionTexto, fuente = directo.fuente, vista = directo.vista)
        }

        // 2) WhatsApp manda geo:?q=Dirección cuando el lugar no trae coordenadas: se busca por la dirección
        val consultaGeoTexto = if (directo == null) consultaDeTexto(texto) else null
        if (consultaGeoTexto != null) {
            val (l, n) = buscarDireccion(consultaGeoTexto, claveMapTiler) ?: return@withContext null
            val ps = partes(consultaGeoTexto)
            val nombre = ps.firstOrNull()?.takeIf { it.isNotBlank() && !it[0].isDigit() }
            val direccion = ps.drop(1).joinToString(", ").ifBlank { l.nombre }
            return@withContext Punto(
                l.lat, l.lng, nombre, direccion,
                aproximada = true, zona = n >= 3, consulta = consultaGeoTexto,
                fuente = "Buscada por la dirección (no hay coordenadas)"
            )
        }

        // 3) Links: se siguen para sacar el pin; si el texto ya tenía el centro del mapa, se usa solo si no hay nada mejor
        var mejorHit = directo
        var nombreLugar: String? = null
        var huboEnlaces = false
        for (m in enlaces.findAll(texto)) {
            huboEnlaces = true
            val h = try { seguir(m.value) } catch (e: Exception) { null }
            if (h == null) continue
            if (nombreLugar == null) nombreLugar = h.nombreLugar
            val nuevo = h.hit
            val previo = mejorHit
            if (nuevo != null && (previo == null || nuevo.rango < previo.rango)) mejorHit = nuevo
            val ahora = mejorHit
            if (ahora != null && ahora.rango <= 2) break
        }
        val hit = mejorHit
        if (hit != null) {
            return@withContext Punto(
                hit.lat, hit.lng, nombreTexto ?: nombreLugar, direccionTexto,
                fuente = hit.fuente, vista = hit.vista
            )
        }

        // 4) Sin coordenadas: se busca por la dirección o el nombre que vengan en el mensaje
        val consulta = consultaTexto(texto) ?: nombreLugar ?: (if (!huboEnlaces) textoPlano(texto) else null)
            ?: return@withContext null
        val (l, n) = buscarDireccion(consulta, claveMapTiler) ?: return@withContext null
        val primera = consulta.split(",").firstOrNull()?.trim()
        Punto(
            l.lat, l.lng, nombreTexto ?: primera, direccionTexto ?: l.nombre,
            aproximada = true, zona = n >= 3, consulta = consulta,
            fuente = "Buscada por la dirección (no hay coordenadas)"
        )
    }
}
