package com.micontrol.app.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder

/** Lee ubicaciones de lo que se pasa por WhatsApp: links de Google Maps, geo:, coordenadas sueltas, nombres de lugar. */
object UbicacionLink {
    data class Punto(
        val lat: Double,
        val lng: Double,
        val nombre: String? = null,
        val direccion: String? = null,
        val aproximada: Boolean = false   // true si se buscó por el nombre del lugar
    )

    private const val N = """(-?\d{1,3}\.\d+)"""

    private val patrones = listOf(
        Regex("""[?&](?:q|ll|query|destination|daddr|center|sll)=(?:loc:)?$N\s*,\s*$N"""),
        Regex("""@$N,$N"""),
        Regex("""!3d$N!4d$N"""),
        Regex("""geo:$N,$N"""),
        Regex("""[?&]mlat=$N&(?:amp;)?mlon=$N"""),
        Regex("""#map=\d+/$N/$N"""),
        Regex("""$N\s*[,;]\s*$N""")
    )
    private val lugar = Regex("""/maps/place/([^/@?]+)""")
    private val etiquetaGeo = Regex("""geo:\S*\(([^)]{1,80})\)""")
    private val enlaces = Regex("""https?://[^\s"'<>]+""")
    private val lineaInutil = Regex("""(?i)(mi )?(ubicaci[oó]n|location)( en vivo)?[:\s]*""")
    private val lineaConCoordenadas = Regex(""".*-?\d{1,3}\.\d+\s*,\s*-?\d{1,3}\.\d+.*""")

    private fun decodificar(t: String) = try { URLDecoder.decode(t, "UTF-8") } catch (e: Exception) { t }

    /** Nombre y dirección tal como vienen en el mensaje (si vienen). */
    private fun nombreYDireccion(t: String): Pair<String?, String?> {
        etiquetaGeo.find(t)?.groupValues?.get(1)?.trim()?.takeIf { it.isNotBlank() }?.let { return it to null }
        lugar.find(t)?.groupValues?.get(1)?.replace('+', ' ')?.trim()?.takeIf { it.isNotBlank() }?.let { return it to null }
        val lineas = t.lines()
            .map { it.trim().trim('*', '_', '~').removePrefix("📍").trim() }
            .filter {
                it.isNotBlank() && !it.startsWith("http", true) && !it.startsWith("geo:", true) &&
                    !it.contains("maps.") && !lineaInutil.matches(it) && !lineaConCoordenadas.matches(it)
            }
        return lineas.firstOrNull() to lineas.drop(1).joinToString(", ").ifBlank { null }
    }

    /** Busca coordenadas en el texto, sin usar internet. */
    fun extraer(texto: String): Punto? {
        val t = decodificar(texto)
        for (r in patrones) {
            val m = r.find(t) ?: continue
            val lat = m.groupValues[1].toDoubleOrNull() ?: continue
            val lng = m.groupValues[2].toDoubleOrNull() ?: continue
            if (lat !in -90.0..90.0 || lng !in -180.0..180.0 || (lat == 0.0 && lng == 0.0)) continue
            val (nombre, direccion) = nombreYDireccion(t)
            return Punto(lat, lng, nombre, direccion)
        }
        return null
    }

    /** En el contenido de una página solo se aceptan formas seguras (nada de números sueltos). */
    private fun extraerCuerpo(cuerpo: String): Punto? {
        val t = decodificar(cuerpo)
        for (r in patrones.take(3)) {
            val m = r.find(t) ?: continue
            val lat = m.groupValues[1].toDoubleOrNull() ?: continue
            val lng = m.groupValues[2].toDoubleOrNull() ?: continue
            if (lat in -90.0..90.0 && lng in -180.0..180.0 && !(lat == 0.0 && lng == 0.0)) return Punto(lat, lng)
        }
        return null
    }

    private class Hallazgo(val punto: Punto?, val nombreLugar: String?)

    /** Sigue los redirects de un link corto (maps.app.goo.gl) buscando coordenadas o, al menos, el nombre del lugar. */
    private fun seguir(url: String): Hallazgo {
        var actual = url
        var nombreLugar: String? = null
        repeat(8) {
            val c = URL(actual).openConnection() as HttpURLConnection
            try {
                c.instanceFollowRedirects = false
                c.connectTimeout = 8000
                c.readTimeout = 8000
                c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36")
                c.setRequestProperty("Accept-Language", "es-AR,es;q=0.9")
                val codigo = c.responseCode
                if (codigo in 300..399) {
                    val destino = c.getHeaderField("Location") ?: return Hallazgo(null, nombreLugar)
                    actual = URL(URL(actual), destino).toString()
                    extraer(actual)?.let { return Hallazgo(it, null) }
                    lugar.find(decodificar(actual))?.groupValues?.get(1)?.trim()?.let { nombreLugar = it }
                } else {
                    val cuerpo = c.inputStream.bufferedReader().use { it.readText().take(400_000) }
                    return Hallazgo(extraer(actual) ?: extraerCuerpo(cuerpo), nombreLugar)
                }
            } finally {
                c.disconnect()
            }
        }
        return Hallazgo(null, nombreLugar)
    }

    /**
     * Devuelve la ubicación que haya en el texto o link. Si el link solo trae el nombre del lugar,
     * lo busca por nombre y marca el resultado como aproximado.
     */
    suspend fun resolver(texto: String, claveMapTiler: String = ""): Punto? = withContext(Dispatchers.IO) {
        val (nombreTexto, direccionTexto) = nombreYDireccion(decodificar(texto))
        extraer(texto)?.let { return@withContext it }

        var nombreLugar: String? = null
        for (m in enlaces.findAll(texto)) {
            val h = try { seguir(m.value) } catch (e: Exception) { null }
            if (h == null) continue
            val p = h.punto
            if (p != null) {
                return@withContext p.copy(nombre = p.nombre ?: nombreTexto, direccion = p.direccion ?: direccionTexto)
            }
            if (nombreLugar == null) nombreLugar = h.nombreLugar
        }

        val consulta = nombreLugar ?: return@withContext null
        val l = Geo.geocodificar(consulta, claveMapTiler) ?: return@withContext null
        Punto(l.lat, l.lng, nombreTexto ?: consulta, direccionTexto ?: l.nombre, aproximada = true)
    }
}
