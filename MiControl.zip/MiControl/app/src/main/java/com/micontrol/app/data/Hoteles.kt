package com.micontrol.app.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.text.Normalizer
import java.util.UUID

/**
 * Hoteles y descanso para camioneros: una sola base compartida entre los celulares autorizados.
 * Se guarda en una base aparte (hoteles.db) que no depende del perfil, así que no toca los viajes.
 * Funciona sin internet: lo nuevo queda "pendiente" y se manda cuando vuelve la señal.
 */
@Entity(tableName = "hoteles")
data class Hotel(
    @PrimaryKey val uid: String = UUID.randomUUID().toString(),
    val nombre: String = "",
    val direccion: String = "",
    val localidad: String = "",
    val provincia: String = "",
    val lat: Double? = null,
    val lng: Double? = null,
    val telefono: String = "",
    val whatsapp: String = "",
    val precio: String = "",
    val cochera: Boolean = false,
    val cocheraCerrada: Boolean = false,
    val accesoCamion: Boolean = false,
    val accesoAcoplado: Boolean = false,
    val vigilancia: Boolean = false,
    val restaurante: Boolean = false,
    val banoDucha: Boolean = false,
    val estacionamiento: String = "",   // precio y condiciones del estacionamiento
    val seguridad: String = "",
    val observaciones: String = "",
    val creadoPor: String = "",
    val modificadoPor: String = "",
    val editado: Long = System.currentTimeMillis(),
    val borrado: Boolean = false,
    val pendiente: Boolean = true,
    val posibleDuplicadoDe: String = ""
)

@Entity(tableName = "opiniones", indices = [Index("hotelUid")])
data class Opinion(
    @PrimaryKey val uid: String = UUID.randomUUID().toString(),
    val hotelUid: String,
    val autor: String = "",
    val estrellas: Int = 5,
    val recomendado: Boolean = true,
    val texto: String = "",
    val fecha: Long = System.currentTimeMillis(),
    val pendiente: Boolean = true
)

@Dao
interface HotelDao {
    @Query("SELECT * FROM hoteles WHERE borrado = 0 ORDER BY nombre COLLATE NOCASE")
    fun todos(): Flow<List<Hotel>>

    @Query("SELECT * FROM hoteles WHERE borrado = 0")
    suspend fun lista(): List<Hotel>

    @Query("SELECT * FROM hoteles WHERE uid = :uid")
    suspend fun porUid(uid: String): Hotel?

    @Query("SELECT * FROM hoteles WHERE pendiente = 1")
    suspend fun pendientes(): List<Hotel>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun guardar(h: Hotel)

    @Query("DELETE FROM hoteles WHERE uid = :uid")
    suspend fun quitar(uid: String)

    @Query("SELECT * FROM opiniones ORDER BY fecha DESC")
    fun opiniones(): Flow<List<Opinion>>

    @Query("SELECT * FROM opiniones WHERE pendiente = 1")
    suspend fun opinionesPendientes(): List<Opinion>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun guardarOpinion(o: Opinion)

    @Query("UPDATE opiniones SET hotelUid = :nuevo WHERE hotelUid = :viejo")
    suspend fun moverOpiniones(viejo: String, nuevo: String)
}

@Database(entities = [Hotel::class, Opinion::class], version = 1, exportSchema = false)
abstract class HotelesDb : RoomDatabase() {
    abstract fun dao(): HotelDao

    companion object {
        @Volatile private var inst: HotelesDb? = null
        fun get(ctx: Context): HotelesDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(ctx.applicationContext, HotelesDb::class.java, "hoteles.db").build().also { inst = it }
        }
    }
}

/** Reconoce si un hotel ya está cargado (mismo teléfono, mismo nombre cerca, o casi el mismo lugar). */
object Antiduplicados {
    private val sobra = Regex("\\b(hotel|hostal|hosteria|motel|parador|posada|apart|complejo|el|la|los|las|de|del)\\b")
    fun normal(t: String): String =
        Normalizer.normalize(t.lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "")
            .replace(sobra, " ").replace(Regex("[^a-z0-9]+"), " ").trim()

    fun tel(t: String): String { val x = t.filter { it.isDigit() }; return if (x.length >= 7) x.takeLast(8) else "" }

    fun metros(a: Hotel, b: Hotel): Double {
        val la1 = a.lat ?: return 1e9; val lo1 = a.lng ?: return 1e9
        val la2 = b.lat ?: return 1e9; val lo2 = b.lng ?: return 1e9
        val r = FloatArray(1)
        android.location.Location.distanceBetween(la1, lo1, la2, lo2, r)
        return r[0].toDouble()
    }

    private fun parecidos(a: Hotel, b: Hotel): Boolean {
        val na = normal(a.nombre); val nb = normal(b.nombre)
        if (na.isBlank() || nb.isBlank()) return false
        return na == nb || na.contains(nb) || nb.contains(na)
    }

    enum class Coincidencia { SEGURA, PROBABLE }

    /** Busca un hotel ya cargado que coincida con el nuevo. */
    fun buscar(nuevo: Hotel, existentes: List<Hotel>): Pair<Hotel, Coincidencia>? {
        var probable: Hotel? = null
        for (h in existentes) {
            if (h.uid == nuevo.uid || h.borrado) continue
            val t1 = tel(h.telefono); val t2 = tel(nuevo.telefono)
            val m = metros(h, nuevo)
            if ((t1.isNotBlank() && t1 == t2) || (parecidos(h, nuevo) && m < 400) || m < 40) return h to Coincidencia.SEGURA
            if (probable == null && parecidos(h, nuevo) &&
                (m < 3000 || (normal(h.localidad).isNotBlank() && normal(h.localidad) == normal(nuevo.localidad)))
            ) probable = h
        }
        return probable?.let { it to Coincidencia.PROBABLE }
    }

    /** Completa los datos vacíos del existente con los del nuevo (no borra nada). */
    fun completar(existente: Hotel, nuevo: Hotel, quien: String): Hotel = existente.copy(
        nombre = existente.nombre.ifBlank { nuevo.nombre },
        direccion = existente.direccion.ifBlank { nuevo.direccion },
        localidad = existente.localidad.ifBlank { nuevo.localidad },
        provincia = existente.provincia.ifBlank { nuevo.provincia },
        lat = existente.lat ?: nuevo.lat, lng = existente.lng ?: nuevo.lng,
        telefono = existente.telefono.ifBlank { nuevo.telefono },
        whatsapp = existente.whatsapp.ifBlank { nuevo.whatsapp },
        precio = nuevo.precio.ifBlank { existente.precio },
        cochera = existente.cochera || nuevo.cochera,
        cocheraCerrada = existente.cocheraCerrada || nuevo.cocheraCerrada,
        accesoCamion = existente.accesoCamion || nuevo.accesoCamion,
        accesoAcoplado = existente.accesoAcoplado || nuevo.accesoAcoplado,
        vigilancia = existente.vigilancia || nuevo.vigilancia,
        restaurante = existente.restaurante || nuevo.restaurante,
        banoDucha = existente.banoDucha || nuevo.banoDucha,
        estacionamiento = existente.estacionamiento.ifBlank { nuevo.estacionamiento },
        seguridad = existente.seguridad.ifBlank { nuevo.seguridad },
        observaciones = listOf(existente.observaciones, nuevo.observaciones).filter { it.isNotBlank() }.distinct().joinToString(" · "),
        modificadoPor = quien, editado = System.currentTimeMillis(), pendiente = true
    )
}

/** Intercambio de hoteles y opiniones con la planilla de Google (solo celulares autorizados). */
object HotelesSync {
    private fun p(ctx: Context) = ctx.getSharedPreferences("hoteles_sync", Context.MODE_PRIVATE)
    fun ultima(ctx: Context): Long = p(ctx).getLong("desde", 0L)

    private fun aJson(h: Hotel): JSONObject = JSONObject().apply {
        put("uid", h.uid); put("nombre", h.nombre); put("direccion", h.direccion); put("localidad", h.localidad)
        put("provincia", h.provincia); put("lat", h.lat ?: JSONObject.NULL); put("lng", h.lng ?: JSONObject.NULL)
        put("telefono", h.telefono); put("whatsapp", h.whatsapp); put("precio", h.precio)
        put("cochera", h.cochera); put("cocheraCerrada", h.cocheraCerrada); put("accesoCamion", h.accesoCamion)
        put("accesoAcoplado", h.accesoAcoplado); put("vigilancia", h.vigilancia); put("restaurante", h.restaurante)
        put("banoDucha", h.banoDucha); put("estacionamiento", h.estacionamiento); put("seguridad", h.seguridad)
        put("observaciones", h.observaciones); put("creadoPor", h.creadoPor); put("modificadoPor", h.modificadoPor)
        put("editado", h.editado)
    }

    private fun deJson(o: JSONObject): Hotel {
        fun d(k: String): Double? = if (o.isNull(k)) null else o.optDouble(k).takeIf { !it.isNaN() }
        fun t(k: String): String = if (o.isNull(k)) "" else o.optString(k, "")
        return Hotel(
            uid = o.getString("uid"), nombre = t("nombre"), direccion = t("direccion"), localidad = t("localidad"),
            provincia = t("provincia"), lat = d("lat"), lng = d("lng"), telefono = t("telefono"), whatsapp = t("whatsapp"),
            precio = t("precio"), cochera = o.optBoolean("cochera"), cocheraCerrada = o.optBoolean("cocheraCerrada"),
            accesoCamion = o.optBoolean("accesoCamion"), accesoAcoplado = o.optBoolean("accesoAcoplado"),
            vigilancia = o.optBoolean("vigilancia"), restaurante = o.optBoolean("restaurante"), banoDucha = o.optBoolean("banoDucha"),
            estacionamiento = t("estacionamiento"), seguridad = t("seguridad"), observaciones = t("observaciones"),
            creadoPor = t("creadoPor"), modificadoPor = t("modificadoPor"), editado = o.optLong("editado", 0L),
            borrado = o.optBoolean("borrado"), pendiente = false, posibleDuplicadoDe = t("posibleDuplicadoDe")
        )
    }

    private fun opJson(x: Opinion) = JSONObject().put("uid", x.uid).put("hotelUid", x.hotelUid).put("autor", x.autor)
        .put("estrellas", x.estrellas).put("recomendado", x.recomendado).put("texto", x.texto).put("fecha", x.fecha)

    private fun opDe(o: JSONObject) = Opinion(
        uid = o.getString("uid"), hotelUid = o.optString("hotelUid"), autor = o.optString("autor"),
        estrellas = o.optInt("estrellas", 5), recomendado = o.optBoolean("recomendado", true),
        texto = o.optString("texto"), fecha = o.optLong("fecha", 0L), pendiente = false
    )

    /** Manda lo pendiente y baja lo nuevo. Devuelve un mensaje para mostrar, o null si salió bien. */
    suspend fun sincronizar(ctx: Context): String? = withContext(Dispatchers.IO) {
        if (!Compu.activo(ctx)) return@withContext "Falta conectar la app a la página (Ajustes > Ver desde la computadora)."
        val dao = HotelesDb.get(ctx).dao()
        val hs = dao.pendientes()
        val os = dao.opinionesPendientes()
        val o = JSONObject().put("tipo", "hoteles_sync").put("desde", ultima(ctx))
            .put("hoteles", JSONArray().apply { hs.forEach { put(aJson(it)) } })
            .put("opiniones", JSONArray().apply { os.forEach { put(opJson(it)) } })
        val r = Compu.pedir(ctx, o) ?: return@withContext "Sin conexión: se manda cuando vuelva la señal."
        if (!r.optBoolean("ok")) return@withContext r.optString("error", "No se pudo sincronizar.")
        // Duplicados que Google unió: el hotel local pasa a llamarse como el que ya existía
        r.optJSONObject("alias")?.let { al ->
            al.keys().forEach { viejo ->
                val nuevo = al.optString(viejo)
                if (nuevo.isNotBlank() && dao.porUid(viejo) != null) {
                    dao.moverOpiniones(viejo, nuevo)
                    dao.quitar(viejo)
                }
            }
        }
        r.optJSONArray("hoteles")?.let { a -> for (i in 0 until a.length()) dao.guardar(deJson(a.getJSONObject(i))) }
        r.optJSONArray("opiniones")?.let { a -> for (i in 0 until a.length()) dao.guardarOpinion(opDe(a.getJSONObject(i))) }
        // Lo que se mandó ya no está pendiente (si Google lo devolvió, ya quedó actualizado arriba)
        hs.forEach { h -> dao.porUid(h.uid)?.let { if (it.pendiente) dao.guardar(it.copy(pendiente = false)) } }
        os.forEach { x -> dao.guardarOpinion(x.copy(pendiente = false)) }
        p(ctx).edit().putLong("desde", r.optLong("ahora", ultima(ctx))).apply()
        null
    }

    /** Acciones del administrador (Google verifica que de verdad sea el administrador). */
    suspend fun admin(ctx: Context, o: JSONObject): String? = withContext(Dispatchers.IO) {
        val r = Compu.pedir(ctx, o) ?: return@withContext "Sin conexión."
        if (!r.optBoolean("ok")) return@withContext r.optString("error", "No se pudo.")
        sincronizar(ctx)
    }
}
