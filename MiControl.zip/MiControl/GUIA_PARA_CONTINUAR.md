# Mi Control — guía para seguir desarrollando la app

App Android para camioneros argentinos: viajes, horas y horas extras, gastos, plata de la empresa (rendición), recorrido GPS, mapas, rutas para camión, navegación con voz, informes PDF, clientes y ubicaciones de WhatsApp.
El dueño NO programa: trabaja desde el celular. Hablarle en español rioplatense, con pasos cortos y concretos (qué botón tocar).

## 1. Cómo está armado
- Kotlin + Jetpack Compose (Material 3) + Room (SQLite). Paquete `com.micontrol.app`, minSdk 29, targetSdk 34.
- Mapas: osmdroid con tiles de MapTiler (claro, oscuro, satélite). Rutas para camión: OpenRouteService (perfil driving-hgv, https://api.heigit.org/openrouteservice).
- Versión actual del código: ver `versionName` en `app/build.gradle.kts` (la 1.5.0 compiló y se probó; la 1.6.0 todavía NO se confirmó que compile).

Carpetas principales (`app/src/main/java/com/micontrol/app/`):
- `data/`: entidades y base Room (`Entities.kt`, `Daos.kt`, `AppDatabase.kt` con migraciones 1→4), `Geo.kt` (búsqueda de direcciones), `UbicacionLink.kt` (lee links/textos de ubicación de WhatsApp), `RutaCamion.kt` (OpenRouteService), `Actualizaciones.kt` (avisa versión nueva leyendo GitHub Releases), `Ajustes.kt`, `Fotos.kt`, `CompartirApp.kt`.
- `domain/`: `Calculos.kt` (km por odómetro, horas extras >9 h por día, saldo con la empresa), `Navegacion.kt`, `Recorrido.kt` (divide un texto en varios lugares y los ordena por cercanía), `Asistente.kt` (asistente local sin internet: entiende frases en español, responde con los datos del teléfono y anota gastos/adelantos con confirmación).
- `gps/`: `TrackingService.kt` (GPS en segundo plano) y `Gps.kt`.
- `pdf/InformePdf.kt`: informe PDF por viaje.
- `ui/`: pantallas (`Screens.kt` inicio/viaje, `Mapa.kt`, `NavegacionUi.kt`, `Clientes.kt`, `AjustesScreen.kt`, `UbicacionRecibida.kt`, `Cercania.kt`, `AsistenteScreen.kt`, `VariasUbicaciones.kt`), tema rojo y negro (`Theme.kt`), `MainActivity.kt` (navegación + barra inferior).
- Imágenes del diseño en `app/src/main/res/drawable-nodpi/`.

Reglas del negocio (no cambiar sin avisar): los km OFICIALES salen solo del odómetro (final − inicial); el GPS es solo referencia. Horas extras = máx(0, horas del día − 9). Saldo = plata recibida de la empresa − gastos.

## 2. Cómo se compila y se publica (sin PC)
El dueño NO usa Android Studio. En su repositorio de GitHub (público) hay solo:
- `MiControl.zip` (este proyecto, con la carpeta `MiControl/` adentro)
- `.github/workflows/main.yml`

Cada vez que sube un `MiControl.zip` nuevo (Code > Add file > Upload files), GitHub Actions lo descomprime, compila `assembleDebug`, y publica un Release con el APK. La app instalada avisa sola cuando hay una versión más nueva.

Para que una actualización funcione:
1. Subir `versionCode` (número entero) y `versionName` en `app/build.gradle.kts` en CADA versión.
2. Actualizar `NOVEDADES.txt` (se muestra como "qué hay de nuevo" en el aviso).
3. Entregar un `.zip` con la carpeta `MiControl/` en la raíz y NADA de archivos sueltos o viejos adentro.
4. No cambiar `applicationId` ni el archivo `app/micontrol-debug.keystore`: la firma tiene que ser siempre la misma o las versiones no se instalan encima y se pierden los datos.

Claves (NO están en el código): GitHub > Settings > Secrets and variables > Actions: `MAPTILER_KEY` y `ORS_KEY`. El workflow las pasa al compilar y quedan dentro del APK. El repositorio (`GITHUB_REPOSITORY`) también se inyecta al compilar.

Texto de `.github/workflows/main.yml` (por si hay que restaurarlo):

```yaml
name: Compilar APK
on:
  workflow_dispatch:
  push:
    branches: [main]
permissions:
  contents: write
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: unzip -q MiControl.zip
      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: 17
      - uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: 8.7
      - run: gradle assembleDebug
        working-directory: MiControl
        env:
          MAPTILER_KEY: ${{ secrets.MAPTILER_KEY }}
          ORS_KEY: ${{ secrets.ORS_KEY }}
      - uses: actions/upload-artifact@v4
        with:
          name: MiControl-APK
          path: MiControl/app/build/outputs/apk/debug/*.apk
      - id: ver
        run: |
          code=$(grep -oP 'versionCode = \K[0-9]+' MiControl/app/build.gradle.kts)
          name=$(grep -oP 'versionName = "\K[^"]+' MiControl/app/build.gradle.kts)
          echo "code=$code" >> "$GITHUB_OUTPUT"
          echo "name=$name" >> "$GITHUB_OUTPUT"
          cp MiControl/app/build/outputs/apk/debug/app-debug.apk "MiControl-$name.apk"
      - uses: softprops/action-gh-release@v2
        with:
          tag_name: build-${{ steps.ver.outputs.code }}
          name: Mi Control ${{ steps.ver.outputs.name }}
          body_path: MiControl/NOVEDADES.txt
          files: MiControl-${{ steps.ver.outputs.name }}.apk
```

## 3. Cómo seguir trabajando con otra IA (o herramienta)
Lo más simple desde el celular: abrir un chat nuevo de una IA que acepte archivos (Claude, ChatGPT, etc.), subir `MiControl.zip` y este archivo, y pegar el mensaje de abajo. La IA te devuelve un `MiControl.zip` nuevo; se sube a GitHub como siempre.
Con PC: abrir la carpeta en Android Studio, Cursor o Claude Code y compilar con `./gradlew assembleDebug`.

Mensaje para pegar:
> Te paso el proyecto Android "Mi Control" (zip) y su guía. Leé primero GUIA_PARA_CONTINUAR.md. Quiero seguir mejorando la app. Yo trabajo solo desde el celular, sin PC: cada cambio tiene que volver como un nuevo MiControl.zip con la misma estructura, subiendo versionCode y versionName y actualizando NOVEDADES.txt. Explicame los pasos cortos y en español. Antes de decir que algo está listo, revisá que el código compile (la 1.6.0 todavía no se confirmó).

## 4. Lecciones de errores anteriores (para no repetirlos)
- Archivos sueltos o de otro intento dentro del zip rompieron la compilación: el zip tiene que quedar limpio.
- En Kotlin una función con cuerpo de expresión (`= try {...}`) no puede usar `return`.
- Usamos Material 3 de la BOM 2024.06 (compose 1.6): evitar APIs más nuevas.
- Cualquier cambio en las entidades Room exige una migración nueva en `AppDatabase.kt` (versión actual 5; la 4→5 agrega `litros` a gastos).
- El copiado desde páginas traducidas por el navegador rompe archivos YAML (palabras traducidas).

## 5. Pendientes e ideas
- Versión 1.6.0 (nueva, sin probar): "Pegar varias ubicaciones" (orden por cercanía en línea recta, greedy: arranca por el más cercano al origen/teléfono) y consumo de combustible (litros en gastos de Combustible, tarjeta en el viaje, PDF y Asistente). Idea futura: ordenar por distancia real de ruta (OpenRouteService matrix) en vez de línea recta.
- Importante al subir a GitHub: el zip debe llamarse EXACTAMENTE `MiControl.zip` (el celular lo renombra a `MiControl (1).zip` o `MiControl.zip 000.zip` si ya existe uno igual; GitHub solo compila el que se llama así).
- Versión 1.5.0 (nueva): botón "Pegar ubicación de WhatsApp" en Inicio, mapa manual más simple (arranca donde estás, abre solo si la ubicación es aproximada), filtros para abrir links de Google Maps y Asistente local (`Asistente.kt`). Hay que probarla en el teléfono.
- Android 12+ no abre solo los links https en apps no verificadas: el camino confiable es copiar el mensaje y usar "Pegar ubicación". Si se quiere que abra links directo: Ajustes del teléfono > Apps > Mi Control > Abrir de forma predeterminada > agregar enlaces.
- IA en línea (un modelo de lenguaje de verdad): NO se hizo a propósito. Una clave de API dentro del APK (el repo y los Releases son públicos) puede ser extraída y gastada por otros. Si se quiere, hace falta un servidor intermedio que guarde la clave. Mientras tanto el Asistente local cubre preguntas y anotaciones.
- Confirmar que la 1.4.2 compile y andar bien las ubicaciones de WhatsApp con solo dirección (geo:?q=Dirección): hoy se busca por MapTiler/OpenStreetMap, queda "aproximada" y hay que ajustarla en el mapa con el satélite.
- Leer el importe de la foto del ticket (OCR) — no implementado.
- Mapa vectorial (más fluido) y cuenta propia de Google Maps — no implementados.
- Los logos de Guerrini y Kumho Tire son de esas marcas: si la app sale de la empresa, pedir autorización.

## 6. Archivos del proyecto
```
  NOVEDADES.txt
  app/build.gradle.kts
  app/micontrol-debug.keystore
  app/src/main/AndroidManifest.xml
  app/src/main/java/com/micontrol/app/data/Actualizaciones.kt
  app/src/main/java/com/micontrol/app/data/Ajustes.kt
  app/src/main/java/com/micontrol/app/data/AppDatabase.kt
  app/src/main/java/com/micontrol/app/data/CompartirApp.kt
  app/src/main/java/com/micontrol/app/data/Daos.kt
  app/src/main/java/com/micontrol/app/data/Entities.kt
  app/src/main/java/com/micontrol/app/data/Fotos.kt
  app/src/main/java/com/micontrol/app/data/Geo.kt
  app/src/main/java/com/micontrol/app/data/RutaCamion.kt
  app/src/main/java/com/micontrol/app/data/UbicacionLink.kt
  app/src/main/java/com/micontrol/app/domain/Asistente.kt
  app/src/main/java/com/micontrol/app/domain/Calculos.kt
  app/src/main/java/com/micontrol/app/domain/Recorrido.kt
  app/src/main/java/com/micontrol/app/domain/Navegacion.kt
  app/src/main/java/com/micontrol/app/gps/Gps.kt
  app/src/main/java/com/micontrol/app/gps/TrackingService.kt
  app/src/main/java/com/micontrol/app/pdf/InformePdf.kt
  app/src/main/java/com/micontrol/app/ui/ActualizacionDialog.kt
  app/src/main/java/com/micontrol/app/ui/AjustesScreen.kt
  app/src/main/java/com/micontrol/app/ui/AsistenteScreen.kt
  app/src/main/java/com/micontrol/app/ui/Cercania.kt
  app/src/main/java/com/micontrol/app/ui/Clientes.kt
  app/src/main/java/com/micontrol/app/ui/MainActivity.kt
  app/src/main/java/com/micontrol/app/ui/MainViewModel.kt
  app/src/main/java/com/micontrol/app/ui/Mapa.kt
  app/src/main/java/com/micontrol/app/ui/NavegacionUi.kt
  app/src/main/java/com/micontrol/app/ui/RutaCamionUi.kt
  app/src/main/java/com/micontrol/app/ui/Screens.kt
  app/src/main/java/com/micontrol/app/ui/Theme.kt
  app/src/main/java/com/micontrol/app/ui/UbicacionRecibida.kt
  app/src/main/java/com/micontrol/app/ui/VariasUbicaciones.kt
  app/src/main/res/drawable-nodpi/bg_footer.jpg
  app/src/main/res/drawable-nodpi/bg_header.jpg
  app/src/main/res/drawable-nodpi/ic_hero_ruta.png
  app/src/main/res/drawable-nodpi/ic_stat_monedas.png
  app/src/main/res/drawable-nodpi/ic_stat_reloj.png
  app/src/main/res/drawable-nodpi/ic_stat_ruta.png
  app/src/main/res/drawable-nodpi/ic_stat_tablero.png
  app/src/main/res/drawable-nodpi/nav_ajustes_gris.png
  app/src/main/res/drawable-nodpi/nav_ajustes_rojo.png
  app/src/main/res/drawable-nodpi/nav_camion_gris.png
  app/src/main/res/drawable-nodpi/nav_camion_rojo.png
  app/src/main/res/drawable-nodpi/nav_casa_gris.png
  app/src/main/res/drawable-nodpi/nav_casa_roja.png
  app/src/main/res/drawable-nodpi/nav_gente_gris.png
  app/src/main/res/drawable-nodpi/nav_gente_rojo.png
  app/src/main/res/drawable/ic_truck.xml
  app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml
  app/src/main/res/mipmap-anydpi-v26/ic_launcher_round.xml
  app/src/main/res/values/colors.xml
  app/src/main/res/values/themes.xml
  app/src/main/res/xml/file_paths.xml
  build.gradle.kts
  gradle.properties
  settings.gradle.kts
```


## Versión 1.7.0 (versionCode 24)
- Base de datos Room versión 5 (migración 4→5 agrega gastos.litros). Una base por perfil: `micontrol.db` = perfil "principal" (datos viejos), `micontrol_<id>.db` = otros. Perfil activo en SharedPreferences (`data/Perfiles.kt`).
- Copia de seguridad en `data/Respaldo.kt` (VERSION_BASE debe coincidir con AppDatabase). No incluye fotos de tickets.
- Precisión de ubicaciones en `data/UbicacionLink.kt`: !3d!4d y /place/lat,lng = pin; @ y center= = vista del mapa (se avisa). Direcciones sin coordenadas quedan aproximadas.
- Ajustes: claves ocultas con PasswordVisualTransformation; probar claves con `data/Servicios.kt`.
- Subir siempre el zip con el nombre EXACTO `MiControl.zip` (renombrar el viejo antes).


## Versión 1.8.0 (versionCode 25)
- Base de datos Room versión 6: tablas nuevas `mantenimientos` y `vencimientos` (migración 5→6). `Respaldo.VERSION_BASE = 6`.
- Copia de seguridad ahora es un `.zip` (`datos.db` + `tickets/*.jpg`); también restaura copias viejas `.db`. Copia automática semanal en Descargas (`Respaldo.automatica`), sobrescribe `MiControl-copia-automatica-<perfil>.zip`.
- WorkManager (`work/Tareas.kt`, dependencia `androidx.work:work-runtime-ktx:2.9.0`): tarea diaria = copia automática + notificación de avisos graves. También corre al abrir la app (`vm.tareasAlAbrir()`).
- Avisos (`domain/Avisos.kt`): vencimientos, mantenimiento por km (odómetro actual = el más alto cargado en viajes), gastos sin cargar, litros sin cargar, copia vieja. Se ven en Inicio.
- Pantallas nuevas: `ui/CamionUi.kt` (ruta "camion"), `ui/ResumenUi.kt` (ruta "resumen"), `ui/ImportarUi.kt` + `data/ImportarGoogle.kt` (Google Takeout: .zip/.json/.csv/.kml → Clientes), `ui/Bloqueo.kt` (PIN de 4 números, hash SHA-256 con sal, estado en `vm.bloqueado`).
- Mapas: caché más grande (1,5 GB, 90 días) y botón "Zona sin señal" (`ui/MapaOffline.kt`, máximo 900 mapas, usa CacheManager de osmdroid; con el mapa básico de OSM no permite descargar).
- GPS: wake lock parcial en `TrackingService` y pedido de batería sin restricciones.
- Pendiente de revisar en un teléfono real: todo lo anterior no se pudo compilar en el entorno de desarrollo.


## Versión 1.9.0 (versionCode 26)
- Sin cambios de base de datos (sigue en versión 6).
- Respaldo.kt: copias vía archivo temporal verificado; `copiaPrevia(ctx, perfil, motivo)` antes de restaurar y de eliminar perfil (MainViewModel).
- PIN: bloqueo progresivo tras 5 fallos (`Ajustes.registrarFalloPin/pinBloqueadoHasta`, UI en Bloqueo.kt).
- Inicio: tarjeta "Carga rápida" (gastos + jornada). `vm.repetirViaje(v, alReves)` y botones en Historial/Detalle.
- `data/Exportar.kt`: CSV (UTF-8 con BOM, separador `;`) de gastos y viajes del mes, botones en ResumenUi.
- Asistente: dictado con RecognizerIntent (es-AR).
- Peso del camión por perfil (`Ajustes.pesoCamion`) → restricción `weight` en ORS (`RutaCamion.calcular(..., pesoTn)`).
- Todo sin compilar: revisar Actions al subir.


## Versión 1.10.0 (versionCode 27)
- `ui/RecorridoInicio.kt`: mapa en Inicio con recorrido (viaje en curso = paradas de la base; sin viaje = recorrido libre con clientes). Reordenar/borrar/agregar paradas, ordenar por cercanía, ORS para la ruta, estimación en línea recta ×1,3 si falta la clave.
- Se eliminó `ui/RutaCamionUi.kt` y los botones "Calcular ruta para camión" (NuevoViaje/Detalle). `NavegacionDialog` se usa desde RecorridoInicio.
- Tiempo cargado: `RutaCamion.segundosCargado` (máx. entre ORS y distancia a 90% de `Ajustes.velocidadMaxima`, por defecto 80). Peso por defecto 8 t (`Ajustes.pesoCamion`).
- `ParadaDao.actualizar` + `vm.reordenarParadas` (sin cambio de esquema).
- Sin compilar en el entorno: revisar Actions.


## Versión 1.11.0 (versionCode 28)
- Room versión 7 (migración 6→7): `clientes.lista` y `clientes.tipo` (NOT NULL con DEFAULT) + tabla `recorridos` (`RecorridoGuardado`, paradas en JSON vía `data/Recorridos.kt`). `Respaldo.VERSION_BASE = 7`.
- `ui/Clientes.kt` = pantalla "Lugares": búsqueda, filtros (tipo/lista), selección múltiple (recorrido, compartir, lista, tipo, borrar) y recorridos guardados.
- `ImportarGoogle`: `Item.lista` (nombre del archivo dentro del zip), ignora archivos ajenos del Takeout, `esEnlaceDeLista` (la app NO baja listas por enlace: Google no tiene API pública; decisión deliberada, no scrapear).
- `vm.importarClientes`: duplicados por nombre o por proximidad (~30 m); si el existente no tiene lista se le asigna.
- `vm.recorridoPendiente`: Lugares/Recorridos guardados dejan paradas que `RecorridoInicio` carga.
- `abrirRecorridoEnGoogleMaps` (Util.kt): URL dir/?api=1 con waypoints (máx. 9).
- Sin compilar en el entorno: revisar Actions.


## Versión 1.11.1 (versionCode 29)
- ImportarGoogle: CSV con links /maps/search/lat,lng traen coordenadas; se descartan filas cuyo link es solo un dominio. El Takeout "Guardado" tiene un CSV por lista con columnas Título, Nota, URL (sin coordenadas en /maps/place/...!1s0x..:0x..).


## Versión 1.12.0 (versionCode 30)
- Nuevo viaje: empresa y origen por defecto (`Ajustes.empresaViaje/origenFijo`, se guardan al confirmar), `ui/ElegirClientesViaje.kt` (lista con búsqueda, filtro por lista y edición de nombre vía `DialogoCliente` internal), `data/Orden.kt` (vecino más cercano + 2-opt en línea recta, `nombreViaje`), `Geo.localidad` (Nominatim reverse, 1 consulta por segundo) para nombrar el viaje.
- El orden es por distancia en línea recta; el peso del camión no cambia el orden, solo la ruta real (ORS).


## Versión 1.12.1 (versionCode 31)
- Los links /maps/place/Nombre/data=!..1s0x..:0x.. devolvían 200 sin coordenadas y sin nombre: ahora `seguir` toma el nombre del link y `Geo.buscarPorNombre` (nombre, luego nombre + Mendoza) es el respaldo; todo queda aproximado. Botón en Lugares para completar los que faltan. No se pudo probar contra Google desde el entorno.


## Versión 1.13.0 (versionCode 32)
- Diseño: icono adaptativo con PNG (`ic_fondo_launcher`, `ic_primer_plano`), fondos `fondo_*.jpg` y miniaturas `th_fondo_*.jpg` en drawable-nodpi (generados con script propio, no son la imagen de referencia). `ui/Fondos.kt` (FONDOS), `Ajustes.fondo`, `vm.fondo`, dibujado en MainActivity con capa oscura 65% y `widthIn(max=720dp)`. Sin cambios de base de datos.
- Nuevo viaje: origen = GPS (`Gps.ultimaUbicacion`) o salida guardada de respaldo; se quitaron los campos de origen y destino (el destino es la última parada).


## Versión 1.13.1 (versionCode 33)
- Icono: arte aportado por el usuario (imagen con la G de Guerrini, camión y cubierta) como primer plano del icono adaptativo (`ic_primer_plano.png`, 304 px dentro de 432) sobre fondo liso (`ic_fondo_launcher.png`).


## Versión 1.14.0 (versionCode 34)
- Room versión 8 (migración 7→8: `clientes.url`). `Respaldo.VERSION_BASE = 8`.
- `data/UbicarConGoogle.kt`: WebView oculto (UA de escritorio) que abre el link guardado de Google y lee la URL final (`!3d..!4d..`) con `UbicacionLink.coordenadasDirectas`. Sin API ni claves. NO se pudo probar desde el entorno (sin acceso a Google).
- Importar ya no adivina por nombre (causaba ubicaciones en otras ciudades). `vm.importarClientes` borra las ubicaciones viejas marcadas con ⚠ y guarda la url.
- `RecorridoInicio` reescrito: orden automático, "Iniciar viaje y abrir Google Maps" (odómetro sugerido, `SolicitudGps` internal), opciones en "Más opciones". Ajustes: grupo "Avanzado" plegado.


## Versión 1.15.0 (versionCode 35)
- `TIPOS_LUGAR` suma "Hotel / cochera" (sin cambio de base de datos: `tipo` es texto).
- `Asistente.Datos` recibe `clientes` y `ubicacion`; rama `hoteles()` (palabras: hotel, cochera, dormir, hospedaje...) devuelve los 5 más cercanos por distancia en línea recta (`Orden.metros`). `Respuesta.lugares` -> botones "🗺️" en `AsistenteScreen` que llaman `abrirEnGoogleMaps`.
- Pendiente (esperando OK del usuario): informe mensual/por viaje en PDF, resumen en Inicio, tarjetas en Historial.


## Versión 1.16.0 (versionCode 36)
- Decisión del usuario: el mapa se vincula solo con Google Maps. `RecorridoInicio` ya no dibuja `MapaOsm` ni ofrece "Navegar dentro de Mi Control". `DetalleViajeScreen` abre `abrirRecorridoEnGoogleMaps` en vez de `MapaRecorrido`. El código del mapa propio (Mapa.kt, NavegacionUi.kt) queda sin usar en esas pantallas; `SelectorUbicacion` (buscar/marcar parada) y UbicacionRecibida todavía usan MapaOsm.
- `DialogoGasto(precioLitroUltimo)`: litros sugeridos = importe / precio por litro de la última carga con litros (se corrige a mano).
- Detalle del viaje: opciones técnicas del GPS plegadas (`masGps`).


## Versión 1.16.1 (versionCode 37)
- En 1.16.0 se había perdido de vista el panel de detenciones/km por hora (vivía en `MapaRecorrido`). Ahora `DetalleViajeScreen` lista `Calculos.detenciones` y `Calculos.kmPorHora` y cada fila abre el punto en Google Maps (`abrirEnGoogleMaps`).


## Versión 1.17.0 (versionCode 38)
- Bug: el campo de odómetro filtraba solo dígitos, así que "101857,7" quedaba 1018577. Ahora `Calculos.parseOdometro` acepta coma/punto decimal y puntos de mil y redondea a km enteros (la base sigue en Long, sin migración; error máximo < 1 km por extremo). `Calculos.kmTxt` da formato "101.858".
- Inicio: se quitó el BotonHero "Iniciar viaje" (llevaba a `NuevoViajeScreen`, duplicado). La ruta "nuevo" y su código siguen existiendo pero sin acceso desde Inicio.
- Ajustes: se quitó el grupo "Medidas del camión" (las medidas siguen con valores por defecto en `Ajustes`: peso 8 t, velocidad 80, altura/largo guardados).
- Posible mejora futura: guardar décimas del odómetro (requeriría migración de base).


## Versión 1.18.0 (versionCode 39)
- Detalle del viaje: se quitó la lista de detenciones (>10 min) del 1.16.1 (`Calculos.detenciones` queda sin uso en UI, salvo el viejo `MapaRecorrido`). Se mantiene "hora por hora". Nuevo slider "Por dónde pasaste" sobre los puntos GPS + botón a Google Maps. La jornada terminada muestra "Parado y descansando desde".
- `corrigiendoOdo`: diálogo para editar `odometroInicial/odometroFinal` de un viaje con `vm.actualizarViaje`.


## Versión 1.19.0 (versionCode 40) - Etapa 1 del plan de ChatGPT
- `Calculos.consumo`: nunca usa km GPS (`kmDeGps` siempre false); sin odómetro final => `lPor100` null => "Consumo pendiente" (Screens, PDF, Asistente).
- `Calculos.pesos`: formato manual $12.855,25 (negativos "-$..."). `Calculos.parseImporte`: BigDecimal, "12.855" = miles.
- Asistente: "lucas" = x1000.
- Pendiente del plan (ver conversación): décimas de odómetro (migración 8->9), foto de perfil, Inicio con resumen mensual, carga rápida con Hotel/Otro, informes mensual/individual, copia con verificación, GPS más robusto, tramos de Google Maps (>9 paradas).


## Versión 1.20.0 (versionCode 41) - Etapa 2
- Room versión 9: `viajes.odoInicialDec`, `viajes.odoFinalDec` (0..9, DEFAULT 0). `Respaldo.VERSION_BASE = 9`. Los km enteros siguen en `odometroInicial/odometroFinal` (Long); la décima va aparte.
- `Calculos.odoDecimas/kmDecimas/decimasTxt/kmViajeTxt/parseOdometroDec/odometroActualTxt`. `Calculos.consumo` recibe km oficiales como Double. Mantenimientos y `Avisos.odometroActual` siguen en km enteros.
- Foto de perfil: `Perfiles.fotoArchivo/guardarFoto/quitarFoto/fotoVersion` (archivo filesDir/perfiles/<id>.jpg); `Avatar(inicial, tam, perfilId)`; entrada `perfil/foto.jpg` en la copia de seguridad y restauración.


## Versión 1.21.0 (versionCode 42) - Etapa 3
- `ui/ResumenMes.kt`: `ResumenMesInicio` (selector de mes, totales y últimos 3 viajes) reemplaza las 4 tarjetas `Dato` de Inicio.
- Carga rápida con Hotel (Alojamiento) y Otro gasto (última categoría usada).
- `Calculos.extrasTotales` agrupa por fecha. Asistente: litros, gasto por categoría, pregunta si falta importe; `Accion.NuevoGasto.litros`.


## Versión 1.22.0 (versionCode 43) - Etapas 4 y 5
- `InformePdf.generarMes` (resumen + sección por viaje). UI en `ResumenMesInicio` (PDF: compartir/WhatsApp/Descargas; Excel = CSV de `Exportar.viajes`).
- `Respaldo.copiaTemporal` verifica el `datos.db` de la copia (integrity_check). `Ajustes.marcarCopia(.., bytes)` / `tamanoCopia`; Ajustes muestra fecha y tamaño.
- GPS: `TrackingService.EXTRA_PERFIL`/`Gps.KEY_PERFIL`: los puntos van a `AppDatabase.get(ctx, perfilId)`. Sin puntos repetidos. `vm.finalizarViaje` detiene el GPS. Aviso de "último punto hace N min" en el detalle.
- `abrirRecorridoEnGoogleMaps(ctx, puntos, tramo)` + `cantidadTramos`: tramos de 11 puntos (origen + 9 + destino), cada uno empieza donde terminó el anterior. Botón rotativo en Inicio y en el detalle del viaje.
- Pendiente: probar todo en el teléfono; mejorar asistente según frases reales.


## Versión 1.23.0 (versionCode 44)
- Detalle de viaje: se quitó la lista km hora por hora; "Recorrido y GPS" (`verGps`, abierto si está en curso) y "Paradas" (`verParadas`) plegables; menos textos de ayuda.


## Versión 1.31.0 (versionCode 54)
- Room 11: `gastos.pagoPropio` (INTEGER NOT NULL DEFAULT 0, migración 10->11). `Calculos.dinero` incluye combustible con pagoPropio; `sinCombustible`, `combustiblePropio`, `consumoRaro`. `DialogoCarga`: chips Tarjeta/Plata mía, litros opcionales. PDF viaje/mes y ConsumoCard separan tarjeta vs propio. PDF mensual: consumo con todas las cargas (antes usaba `dinero` y quedaba vacío).
- `Respaldo.VERSION_BASE = 11` (estaba en 9 y rechazaba copias de la base 10).
- Panel automático: `vm.iniciarViaje`/`finalizarViaje` llaman `Compu.programarEnvio`; `SolicitudGps` arranca el GPS sin diálogo si ya hay permiso; `TrackingService` llama `Compu.reiniciarUbicacion()` y manda la última posición conocida (<30 min) al arrancar.
- `ui/PerfilObligatorio.kt`: diálogo que no se cierra si el perfil activo se llama "Mi perfil" o está vacío (MainActivity, debajo del PIN).
- El link de la empresa va en el secreto `COMPU_URL` de GitHub (no en el código: el repo es público). Los celulares nuevos quedan "pendiente" hasta que el administrador los autoriza.

## Versión 1.31.1 (versionCode 55)
- `vm.reanudarGps()` (MainActivity.onStart): viaje EN_CURSO + GPS parado + permiso => `Gps.iniciar`. No si `Gps.pausadoManual` ("Detener seguimiento" llama `Gps.pausarManual`; `Gps.iniciar` borra la marca).
- `gps/ReanudarReceiver` (BOOT_COMPLETED, MY_PACKAGE_REPLACED): si `Gps.viajeQueSeguia` != null, notificación "Tenés un viaje en curso" que abre la app. No arranca el servicio desde el receiver (Android 12+ restringe FGS de ubicación en segundo plano).
